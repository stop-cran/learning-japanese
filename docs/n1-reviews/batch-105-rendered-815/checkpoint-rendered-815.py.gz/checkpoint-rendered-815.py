"""Persist exact rendered review evidence and history-preserving checkpoint."""
import base64
import copy
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

C = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("rendered815", C / "review-rendered-815.py")
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
R, A, W, L = m.R, m.A, m.W, m.L
D = R / "docs" / "n1-reviews" / "batch-105-rendered-815"
E = R / "docs" / "n1-sources" / "execution-815.json"


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def runtime():
    spec = importlib.util.spec_from_file_location("runtime814", C / "prepare-native-label-sources-814.py")
    previous = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(previous)
    return previous.runtime()


def archive():
    m.frozen()
    assert not D.exists() and not E.exists()
    records = {label: m.load(W / f"{label}-execution.json") for label in m.MODELS}
    for label, record in records.items():
        assert record["exitCode"] == 0 and record["processExited"] and m.absent(record["launcherPid"])
        assert record["actualModels"] == [m.MODELS[label]]
        assert record["usageCurrentModel"] == m.MODELS[label]
        assert record["allAssignedTextReturned"] and not record["missingImages"]
        assert not record["unfinishedTools"] and not record["observedToolOverlaps"]
        assert record["multiToolResponseCount"] == 0
        assert all(call["name"] == "view" and call["success"] for call in record["toolCalls"])
        assert m.sha(W / f"{label}.md") == record["reportSha256"]
        assert m.sha(W / f"{label}.jsonl") == record["rawExecutionSha256"]
        assert (W / f"{label}-preserved.json").exists()
        assert len(record["successfulImageOpens"]) == 22
        assert len({row["path"] for row in record["successfulImageOpens"]}) == 22
        assert all(row["payloads"] for row in record["successfulImageOpens"])
        assert all(payload["pngDimensions"] == [900, 2000]
                   and payload["originalPngDimensions"] == [1080, 2400]
                   and not payload["equalsOriginalBytes"]
                   for row in record["successfulImageOpens"] for payload in row["payloads"])
        resources = {row["path"] for row in m.load(W / "resources.json")}
        complete = {call["arguments"]["path"] for call in record["toolCalls"]
                    if call["arguments"]["path"] in resources
                    and "view_range" not in call["arguments"]
                    and call["exactRequestedTextContainedInResult"]}
        assert complete == resources
    assert records["claude"]["completedAt"] < records["gpt"]["startedAt"]
    for row in m.load(W / "source-provenance.json")["sources"]:
        assert m.sha(Path(row["path"])) == row["sha256"]
    for row in m.load(W / "resources.json") + m.load(W / "image-scope.json")["images"]:
        assert m.sha(Path(row["path"])) == row["sha256"]
    verified_runtime = runtime()
    D.mkdir()
    payload_dir = D / "image-payloads"
    payload_dir.mkdir()
    archives = []
    for source in sorted(W.iterdir()):
        if source.is_dir() or source.suffix == ".gz":
            continue
        raw = source.read_bytes()
        if source.suffix != ".jsonl":
            target = D / (source.name + ".gz")
            target.write_bytes(gzip.compress(raw, compresslevel=9, mtime=0))
            assert gzip.decompress(target.read_bytes()) == raw
            archives.append({"archive": target.name, "archiveSha256": m.sha(target),
                             "rawSha256": digest(raw), "rawBytes": len(raw)})
            continue
        transformed, replacements = [], {}
        for line in raw.splitlines(keepends=True):
            event = json.loads(line)
            if event["type"] == "tool.execution_complete":
                for item in event.get("data", {}).get("result", {}).get("binaryResultsForLlm", []):
                    if item.get("type") == "image" and isinstance(item.get("data"), str):
                        encoded = item["data"].encode("ascii")
                        image = base64.b64decode(encoded, validate=True)
                        assert base64.b64encode(image) == encoded
                        image_hash = digest(image)
                        marker = ("__N1_IMAGE_PAYLOAD_SHA256_" + image_hash + "__").encode("ascii")
                        assert marker not in raw and encoded in line
                        target = payload_dir / (image_hash + ".png")
                        if target.exists():
                            assert target.read_bytes() == image
                        else:
                            target.write_bytes(image)
                        replacements[marker] = encoded
                        line = line.replace(encoded, marker)
            transformed.append(line)
        factored = b"".join(transformed)
        target = D / (source.name + ".factored.gz")
        target.write_bytes(gzip.compress(factored, compresslevel=9, mtime=0))
        restored = gzip.decompress(target.read_bytes())
        for marker, encoded in replacements.items():
            restored = restored.replace(marker, encoded)
        assert restored == raw
        archives.append({"archive": target.name, "archiveSha256": m.sha(target),
                         "factoredSha256": digest(factored), "rawSha256": digest(raw),
                         "rawBytes": len(raw), "distinctPayloadsUsed": len(replacements),
                         "payloadMarker": "__N1_IMAGE_PAYLOAD_SHA256_<sha256>__",
                         "reconstruction": "Decompress; replace markers with canonical base64 of named PNG. EVERY original stdout byte/hash round-tripped exactly, including all events and tool results."})
    m.save(D / "archive-integrity.json", archives)
    payloads = [{"file": str(path.relative_to(D)), "sha256": m.sha(path),
                 "bytes": path.stat().st_size} for path in sorted(payload_dir.glob("*.png"))]
    m.save(D / "image-payload-index.json", payloads)
    for source in [C / name for name in [
            "review-rendered-815.py", "review-rendered-804.py", "preflight-815.ps1",
            "checkpoint-rendered-815.py"]] + sorted(L.glob("preflight-815*.json")):
        target = D / (source.name + ".gz")
        assert not target.exists()
        target.write_bytes(gzip.compress(source.read_bytes(), mtime=0))
        assert gzip.decompress(target.read_bytes()) == source.read_bytes()
    m.save(D / "process-order.json", [
        {"label": label, **{key: record[key] for key in [
            "sessionId", "actualModels", "launcherPid", "startedAt", "completedAt", "exitCode",
            "processExited", "multiToolResponseCount"]}}
        for label, record in records.items()])
    m.save(E, {
        "schemaVersion": 1, "execution": 815, "batch": "105", "recordedAt": m.now(),
        "stage": "original-family-rendered-confirmations-preserved-awaiting-final-acceptance-reconciliation",
        "startingState": m.load(L / "starting-state-815.json"),
        "sourceSnapshot": m.HEAD, "unchangedTeachingSnapshot": m.TEACHING,
        "qualifiedAndroidHead": m.APP, "evidenceDirectory": str(D.relative_to(R)),
        "originalSessionConfirmationsExecuted": 2, "newBlindInitialReviewCredit": 0,
        "bothProcessesSerialAndExited": True, "bothReviewersPerToolSerial": True,
        "actualModels": m.MODELS, "originalSessions": m.SESSIONS,
        "commonResources": m.load(W / "resources.json"),
        "sourceProvenance": m.load(W / "source-provenance.json"),
        "bothAssignedTextScopesReturnedExactly": True,
        "nativeImageScope": m.load(W / "image-scope.json"),
        "actualImageDelivery": {
            "originalSourceDimensions": [1080, 2400], "deliveredDimensions": [900, 2000],
            "successfulCallsPerFamily": 22, "repeatedImageCalls": 0,
            "originalNativePathsRepresentedByExactByteAliases": 36,
            "coordinatorResizedSubstitutes": False, "originalPixelPayloadsDelivered": 0,
            "distinctActualDeliveredPayloadHashes": len(payloads),
            "warningCounts": {label: len(record["warnings"]) for label, record in records.items()},
            "compactionCounts": {label: len(record["compactions"]) for label, record in records.items()},
            "compactionTimestamps": {label: [row["timestamp"] for row in record["compactions"]]
                                     for label, record in records.items()},
            "limits": "Actual payload delivery, not equal comprehension, guaranteed visual retention in every model request, original-pixel/font-face/physical-phone certification. Complete original compaction events preserved losslessly."},
        "protocolDisposition": {
            "claude": "35 actual serial view calls: SIX complete forced-large-file resource reads, SEVEN additional boundary/recovery attempts, and22originalPNG calls exactly once. ZERO overlaps/multi-tool responses. All six full requests independently returned exact complete resources. THREE redundant ranged requests did not contain the full requested range; later small boundary requests returned. These partial redundant reads and the report's stated recovery rationale remain recorded, not silently reported as exact range returns. They do not remove the independently verified complete forced reads. TWO successful context compactions; no warning.",
            "gpt": "28 actual serial view calls: SIX exact complete forced-large-file resource reads plus22originalPNG calls exactly once; no boundary reread/overlap/multi-tool response. ONE successful context compaction; no warning.",
            "processOrder": "Claude actual exit and complete report/lossless archive verified before GPT launch. Both original model/session/usage identities agree. Only view available; editing/shell/delegation/parallel wrappers unavailable.",
            "historicalLimits": "Original733/734 and all other prior source/process/read-depth/routing/ANR/permission/OOM/phone limitations unchanged. No historical execution retroaccepted."},
        "reviewDisposition": {
            "twoNewArticles": "Both retain correctness/scoped coverage/text and inspected-rendered comprehensibility CLEAN in bounded unchanged teaching; zero changed reused passages. No established actionable teaching defect.",
            "finiteSemantics": "Both reports CLEAN for target-relative64HOSTkanji+64HOSTword+64nativekanji exact ordered samples and actual default UI options. FIVEnewnative labels亥/巳/彗/柚/鵬 plus inherited凌 inspected with complete character meanings/applicable fullJMdictfamilies/restrictions/actualbodies. Kanaほうきhomophones not extra彗senses; broadcitron/phoenix glosses not unrestricted identity. Not arbitrary/future-pool or every-pair semantic certification.",
            "poolDistinction": "DefaultN1/All/custom retain ALLTHREE功/劾/剖 and ZEROfallback. Native16-member filteredpool retainsTWO功/劾, omits剖, ONEfallback perseed. HOST811 differently named filteredpool retainsNONE. No pool substitution.",
            "originalHypotheses": [
                {"pair": ["雄勁", "活気"], "claudeStatus": "partially resolved; low-confidence note for future pools, not a defect", "gptStatus": "no actionable hypothesis or missing mandatory guard established", "coordinatorDisposition": "No demonstrated alternative answer in bounded exact samples or supplied unguarded pair checks; no new direct exclusion justified. Preserve Claude's residual low-confidence future-pool concern and original810 withdrawn disposition separately, not as forced agreement or universal semantic boundary."},
                {"pair": ["雄勁", "もりもり"], "claudeStatus": "partially resolved; low-confidence note for future pools, not a defect", "gptStatus": "no actionable hypothesis or missing mandatory guard established", "coordinatorDisposition": "Complete energetic-work/welling-strength senses considered, not just eating or different grammar. No established ambiguity for art/prose-qualified label; no new guard justified. Preserve residual concern without claiming every future context safe."}],
            "optional": "Claude's original characteristically hedges/title/imposing/search-only explanation/display-key wording/extra勁草 remain nonblocking; search-only guidance partially clarified by already-existing visible Recognition only/use ordinary強い. GPT original/current optional section none. No new teaching edit or finding quota.",
            "font": "Both delivered-scale four-font/default verdicts CLEAN for all14actualHan and whole雄勁; actual勁/巠/刂 readable and distinguishable from功/劾/力. Cmap absence not failure. Fallback-face identity remainsUNVERIFIED; equal rasters/appearance not proof. Mixed fallback stroke weight is nonblocking visual observation.",
            "readingDrawingRoutes": "Soleけい/displayケイ/gooddone1of1/no kunquestion; legacy feedbackrawつよい is reference display, not offered question. Nine reference-point trace touches ungraded/modelunavailable; deliberate recall revealgrade1onNext NOTmastery. ONEpair/TWOdirections/ZERObaselinepairs/ZEROreusedchanges/systemBack/offline inherited from actual813 receipts.",
            "renderedLimitations": "Both inspect actual delivered900x2000renditions, not original1080x2400pixels. Article08/09 duplicate viewport represented by exact-byte aliases; no all-table-columns claim. GPT notes article11/16 substantially repeating a viewport. Claude notes missing word-header capture and no native word-quiz samples; host word-option evidence is not native word-quiz execution. Generic drawing feedback/downloading-model text is inherited shared UI, not new content defect or proof of recognition. No unrelated app edit.",
            "compactionLimit": "ClaudeTWO/GPTONE context compactions preserved. Complete returned resources/images and report claims establish access, not equal fresh sense-by-sense comprehension, every-model-request visual retention, native-speaker certification or learning effectiveness.",
            "uniqueVerifiedUsefulFindingsByModel": {"claude-opus-5.5": [], "gpt-6.1-sol": []},
            "comparisonMethod": "Compared equivalent observations throughout findings/hypotheses/optional/limits. No manufactured unique finding or model ranking; both full original reports authoritative.",
            "preliminaryConclusion": "No consequential in-scope defect or native fallback ambiguity established; both bounded rendered confirmations preserved. Final whole-batch acceptance reconciliation and all publication gates remain pending."},
        "ordinarySenseFallbackSemanticAcceptance": "Both bounded target-relative report verdicts CLEAN; final batch acceptance reconciliation pending.",
        "independentRenderedReviewClosed": False, "fullBatchAcceptanceComplete": False,
        "runtimeAccepted": False, "runtimePublished": False,
        "runtimeChanged": False, "manifestChanged": False, "freshNativeExecuted": False,
        **verified_runtime,
        "rawExecutionPackaging": {
            "mode": "Lossless exact-byte delivered-image payload factoring; not event omission or source-image reconstruction.",
            "archiveIndex": "archive-integrity.json", "payloadIndex": "image-payload-index.json",
            "allOriginalRawBytesReconstructedExactly": True,
            "originalRawStdout": str(W),
            "limits": "Delivered900x2000 payloads archive actual transport, NOT replacement native1080x2400images or fresh reviews."},
        "parentLockTouched": False, "optionalHistoricalHelpersAccessed": False,
        "actualNewPermissionDenials": [], "reviewClosed": [], "published": [],
        "publishedAdditions": 131, "remainingAdditions": 1097, "lastPublishedCommit": m.MAIN,
        "physicalPhoneAcceptance": "outstanding", "generalReleaseAcceptance": "outstanding",
        "wholeProjectComplete": False, "nextBatchStarted": False,
        "nextAction": "SAME105 final bounded acceptance reconciliation of both complete original-family rendered reports, exact execution/range/compaction/rendition limits and inherited810textual/811HOST/813native/814new-label-sources. No new blind initial reviews or repeated image/native loop absent consequential new defect. Then full required combined-current-main/Python/vocabulary/baseline-membership-links/manifest-budget/signing/owner-fast-forward/terminalCI/EVERYimmutableZIPmanifesthash/per-file-media-path/publicissue gates remain mandatory before publication; unchanged18000entries42MiBcompressed80MiBinflated56MiBretained. No106. CompatibleAndroid125/132required; phone/generalrelease/whole-setoutstanding."})
    print(json.dumps({"evidence": str(E), "runtimeHashes": verified_runtime["runtimeHashesVerified"],
                      "losslessArchives": len(archives), "actualDeliveredPayloadHashes": len(payloads),
                      "runtimeChanged": False}))


def seal():
    assert m.git("rev-parse", "HEAD") == m.HEAD
    for row in m.load(D / "archive-integrity.json"):
        packed = D / row["archive"]
        assert m.sha(packed) == row["archiveSha256"]
        restored = gzip.decompress(packed.read_bytes())
        if "factoredSha256" in row:
            assert digest(restored) == row["factoredSha256"]
            for payload in m.load(D / "image-payload-index.json"):
                image = (D / payload["file"]).read_bytes()
                assert digest(image) == payload["sha256"]
                marker = ("__N1_IMAGE_PAYLOAD_SHA256_" + payload["sha256"] + "__").encode("ascii")
                restored = restored.replace(marker, base64.b64encode(image))
        assert len(restored) == row["rawBytes"] and digest(restored) == row["rawSha256"]
    verified_runtime = runtime()
    assert (L / "validate-815.txt").read_text(encoding="utf-8-sig").rstrip().endswith("0 error(s)")
    for source in [L / "validate-815.txt", L / "manifest-815.txt"]:
        target = D / (source.name + ".gz")
        assert not target.exists()
        target.write_bytes(gzip.compress(source.read_bytes(), mtime=0))
        assert gzip.decompress(target.read_bytes()) == source.read_bytes()
    e = m.load(E)
    e["validation"] = {
        "commands": ["python -B tools\\validate.py", "python -B tools\\build_manifest.py",
                     "git diff --exit-code -- manifest.json", "git diff --check"],
        "observedTerminalExitCode": 0, "validatorErrors": 0, "manifestRegenerated": True,
        "manifestUnchanged": True, **verified_runtime,
        "allArchivedRawEventsReportsAndResourcesReconstructedExactly": True,
        "fullPythonOrAndroidOrNativeRerun": False,
        "limits": "Unchanged runtime evidence checkpoint only; all full required combined-main/publication gates pending."}
    m.save(E, e)
    index = [{"file": str(path.relative_to(D)), "bytes": path.stat().st_size, "sha256": m.sha(path)}
             for path in sorted(D.rglob("*")) if path.is_file()]
    m.save(D / "artifact-index.json", index)
    print("Every original event/report/resource byte reconstructed; all8469 runtime hashes and unchanged manifest verified.")


def finish():
    before, current = m.load(L / "progress-before-815.json"), m.load(C / "progress.json")
    allowed = {"checkpoint", "status", "stage", "nextAction", "blocker"}
    assert all(current[key] == value for key, value in before.items() if key not in allowed)
    assert (current["checkpoint"], current["batch"], current["status"]) == (814, "105", "continue")
    head = m.git("rev-parse", "HEAD")
    assert m.git("rev-parse", "HEAD^") == m.HEAD and m.git("log", "-1", "--format=%G?") == "G"
    for repo in [R, A]:
        assert not m.git("status", "--porcelain", "--untracked-files=all", repo=repo)
    assert m.git("rev-parse", "HEAD", repo=A) == m.APP
    assert m.git("log", "-1", "--format=%G?", repo=A) == "G"
    assert m.git("rev-parse", "origin/main") == m.MAIN
    changed = m.git("diff", "--name-only", m.HEAD, head).splitlines()
    assert changed and all(name.startswith("docs/n1-reviews/batch-105-rendered-815/") or
                           name == "docs/n1-sources/execution-815.json" for name in changed)
    verified_runtime = runtime()
    for row in m.load(D / "artifact-index.json"):
        path = (D / row["file"]).relative_to(R).as_posix()
        blob = subprocess.check_output(["git", "-C", str(R), "show", head + ":" + path])
        assert digest(blob) == row["sha256"], path
    posted, reread = m.load(L / "issue-815-posted.json"), m.load(L / "issue-815-reread.json")
    body = (C / "batch-105-rendered-815-issue-body.txt").read_bytes()
    assert posted["author"] == reread["user"]["login"] == "stop-cran"
    assert digest(body) == posted["bodySha256"] and body.decode("utf-8") == reread["body"]
    assert posted["url"] == reread["html_url"]
    role = m.load(L / "preflight-815-before-issue.json")
    assert role["contentHead"] == head and not role["lockTouched"]
    next_action = (
        f"SAME105 checkpoint815 signed LOCAL original-family rendered evidence HEAD{head}, qualifiedAndroid{m.APP}. "
        "Read docs/n1-sources/execution-815.json and docs/n1-reviews/batch-105-rendered-815/ plus original810/"
        "HOST811/native813/source814. TWO ORIGINAL-session dependent rendered confirmations ClaudeOpus5.5 "
        "6f978e1c-a137-4b6c-879f-c7874d512549 then GPT6.1Sol113f3d1f-f44b-4233-91f2-f7bf720262b2; "
        "BOTHprocessesexit0/exited/actualmodel-session-usageidentityverified/archivedbefore nextlaunch. "
        "BOTHactualpertoolSERIAL/ZEROoverlap/ZEROmultitoolresponse. SameSIXresources504537bytes/"
        "87completearticlebodies/originalfullfamilies+HOST26+FIVEnewnativecharacters23families/allnativeordered"
        "options/seeds/poolmembers; allSIXfullforcedreads EXACTLYreturned permodel. Claude35calls includesSEVEN"
        "redundantboundaryattempts/THREEpartialrangedreturns preserved; fullforcedreads independentlyexact; "
        "GPT28calls/noextras. Each22originalPNGpathsONCE represent36nativePNGpaths viaexactbytealiases; "
        "actualpayload900x2000 NOT1080x2400originalpixels/noresizedsubstitutes. Rawexecution EVERYbytehash"
        "losslesslyfactored/reconstructed. ClaudeTWO/GPTONEcompactions/ZEROwarnings, NOTguaranteedevery"
        "modelrequestvisualretention/equalcomprehension. Both勁/雄勁 allthreefacetsCLEAN withinboundedunchanged"
        "teaching/inspectedrendering; finite64HOSTkanji64HOSTword64nativekanji targetrelativeCLEAN, notevery"
        "futurepool/everywrongpair. Newnative亥巳彗柚鵬 plus凌 completeapplicablesenses/restrictions; "
        "defaultN1/All/customTHREE功劾剖/ZEROfallback; nativefiltered16retainsTWO功劾/missing剖/ONEfallback, "
        "HOSTfilteredretainsNONE. Bothfourfonts14Han/whole雄勁 readable/distinguishableincluding勁巠刂; "
        "fallbackfaceUNKNOWN, notinferredfromrasters. ClauderetainsLOWconfidencefuturepool活気/もりもり"
        "hypothesesPARTIALLYRESOLVED/notdefects; GPTnoactionablehypothesis; preserveoriginal810withdrawn"
        "historyseparately/noforcedagreement/newguard. ClaudeSIXoriginaloptionalpolish/GPTnone; "
        "noactionableteachingchange. Missingwordheadercapture/nativewordquiznotexecuted/partialhorizontal"
        "table/duplicatearticle08-09and11-16/weightmix/legacyfeedbackつよい/sharedpracticewording/"
        "downloadmodeltext limitationspreserved. Fullonケイ/kunつよ.い; selectedケイ/[]; "
        "soleけいdisplayケイgooddone1of1/nineungradedreferencetouches/modelunavailable/recallgrade1NOTmastery/"
        "ONEpairTWOdirections/ZERObaselinepairs/ZEROreusedchanges/Back/offline inherited813NOTrepeated. "
        "NEXT SAME105 FINAL bounded acceptance reconciliation of bothoriginalreports/exactexecution/"
        "ranges/compactions/renditions and inherited810/811/813/814; no newblindinitials/repeatedimageor"
        "native loop absentconsequentialnewdefect. No consequentialdefectestablished here, but final"
        "wholebatchacceptance/reviewclosure STILLpending. Anydemonstratedconsequentialdefect:minimal"
        "sourcebackedfix/audits/manifest/normalsignednewfreeze/BOTHoriginal-familyconfirmations. "
        "All8469runtimehashes/version5572c6c467e6b73b/manifestunchanged;validator0errors/regenerated"
        "manifestunchanged. All priorgates+nextAction preservedVERBATIM in historicalExecution814Before815Rendered"
        ".nextAction/execution814CoordinatorCheckpoint: combinedcurrentmain/nonrewritingmerge/"
        "changedteachingreview/fullrequiredPython/vocabulary/baseline-membership-links/manifestbudget/"
        "normalsigning/ownerfastforward/terminalgreenCI/EVERYimmutableGitHubZIPmanifesthash/"
        "unchanged18000entries42MiBcompressed80MiBinflated56MiBretained/perfilepathmedia/verifiedownerissue"
        "remainMANDATORY. No106/unreviewedpush/authoragents/concurrentheavywork/secondrunner/signingretry/"
        "guardincrease. Freshsignedheads/checkpoint/whollyclean/freshmain/liveparentancestry/"
        "decodedlauncher/exactsessionrequired;parent13320ownsrunner.lock:nochildacquire/delete/unlock/"
        "readprobe. Approvedcontrol/committedsource/frozeninputs only;preserve/report/yieldactualnewdenial/"
        "signinghang/uncertainownership. QualifiedAndroidapprovedpairguard+schemaonly NOTlatestappmain. "
        "Published131/1228/remainder1097/lastpublished047c2cef6b6a48b1738f2c5957de01be481c63e1unchanged; "
        "batch105unaccepted/unpublished;ONEsupport雄勁 notdeliveredN1vocabulary. CompatibleAndroid125/132"
        "required;oldclientsignore. Physicalphone/generalrelease/whole-setoutstanding;projectincomplete.")
    checkpoint = {
        "schemaVersion": 1, "execution": 815, "checkpoint": 815, "batch": "105",
        "status": "continue",
        "stage": "batch-105-original-family-rendered-confirmations-preserved-awaiting-final-acceptance-reconciliation",
        "savedCommit": head, "signature": "G", "qualifiedAndroidHead": m.APP,
        "recordedAt": m.now(), "evidence": str(E.relative_to(R)),
        "issueUpdate": posted["url"], "ownerIssueAuthorAndExactBodyVerified": True,
        "originalSessionConfirmationsExecuted": 2, "bothProcessesSerialAndExited": True,
        "bothReviewersPerToolSerial": True, "actualModels": m.MODELS,
        "bothAssignedTextScopesReturnedExactly": True,
        "distinctOriginalPngsOpenedPerFamily": 22, "nativePngPathsRepresented": 36,
        "deliveredImageDimensions": [900, 2000], "originalImageDimensions": [1080, 2400],
        "originalPixelAndEqualComprehensionAcceptance": "UNVERIFIED", "actualFallbackFace": "UNVERIFIED",
        "independentRenderedReviewClosed": False, "fullBatchAcceptanceComplete": False,
        "ordinarySenseFallbackSemanticAcceptance": "Both bounded report verdicts CLEAN; final batch reconciliation pending.",
        "runtimeAccepted": False, "runtimePublished": False, "runtimeChanged": False,
        "manifestChanged": False, "freshNativeExecuted": False, **verified_runtime,
        "dedicatedWorktreesClean": True, "parentLockTouched": False,
        "optionalHistoricalHelpersAccessed": False, "actualNewPermissionDenials": [],
        "reviewClosed": [], "published": [], "publishedAdditions": 131, "remainingAdditions": 1097,
        "lastPublishedCommit": m.MAIN, "physicalPhoneAcceptance": "outstanding",
        "generalReleaseAcceptance": "outstanding", "wholeProjectComplete": False,
        "nextBatchStarted": False, "nextAction": next_action, "blocker": None,
        "finalRunnerPreflight": role,
        "historicalRootKeysCompared": len(before), "allOriginalHistoricalValuesPreserved": True}
    updated = copy.deepcopy(current)
    updated["execution815StartingState"]["status"] = "signed-local-original-family-rendered-checkpoint-complete"
    assert "execution815CoordinatorCheckpoint" not in updated
    updated["execution815CoordinatorCheckpoint"] = checkpoint
    for key in allowed:
        updated[key] = checkpoint[key]
    assert all(updated[key] == value for key, value in before.items() if key not in allowed)
    tmp = C / "progress.json.815-finish.tmp"
    assert not tmp.exists()
    m.save(tmp, updated)
    assert m.load(tmp) == updated and m.load(C / "progress.json") == current
    os.replace(tmp, C / "progress.json")
    saved = m.load(C / "progress.json")
    assert saved == updated
    assert all(saved[key] == value for key, value in before.items() if key not in allowed)
    m.save(L / "checkpoint-815-verification.json", checkpoint)
    print(json.dumps({key: checkpoint[key] for key in ["checkpoint", "status", "savedCommit",
        "issueUpdate", "historicalRootKeysCompared", "allOriginalHistoricalValuesPreserved"]}, indent=2))


if __name__ == "__main__":
    {"archive": archive, "seal": seal, "finish": finish}[sys.argv[1]]()
