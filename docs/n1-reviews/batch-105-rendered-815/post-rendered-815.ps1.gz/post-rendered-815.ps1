$ErrorActionPreference = 'Stop'
$control = $PSScriptRoot
$log = "$control\logs\3b15757e-db6c-4eed-b892-75584044f80f"
$content = "$control\..\learning-japanese"
$bodyPath = "$control\batch-105-rendered-815-issue-body.txt"
if ((Test-Path "$log\issue-815-posted.json") -or (Test-Path $bodyPath)) { throw 'Do not duplicate issue update' }
$head = git -C $content rev-parse HEAD
if ($LASTEXITCODE -ne 0) { throw 'HEAD lookup failed' }
& "$control\preflight-815.ps1" -ReceiptName 'preflight-815-before-issue.json' -ExpectedContentHead $head
if ((git -C $content rev-parse 'HEAD^') -ne '2e252a09d46826f58fb901eb56c641bbc09fd9ed' -or
    $LASTEXITCODE -ne 0) { throw 'Wrong evidence ancestry' }
$e = [IO.File]::ReadAllText("$content\docs\n1-sources\execution-815.json") | ConvertFrom-Json
if ($e.runtimeChanged -or $e.runtimePublished -or $e.fullBatchAcceptanceComplete -or
    $e.runtimeHashesVerified -ne 8469 -or $e.originalSessionConfirmationsExecuted -ne 2 -or
    -not $e.bothProcessesSerialAndExited -or -not $e.bothReviewersPerToolSerial) {
    throw 'Rendered evidence mismatch'
}
$body = @"
Checkpoint815, SAME batch105: completed TWO dependent ORIGINAL-session rendered/finite-semantic confirmations, Claude Opus5.5 then GPT6.1Sol, on frozen signed2e252a09 and unchanged teaching27e252da. Signed LOCAL evidence $head preserves docs/n1-sources/execution-815.json and docs/n1-reviews/batch-105-rendered-815/. Both actual model/session/usage identities agree; both reviewer processes exited0 and were archived before the next launch. BOTH per-tool executions were serial: ZERO overlap or multi-tool response. No new blind initial-review credit, author agents, native rerun, teaching/app edit, push or batch106.

Both reports retain CLEAN correctness/scoped coverage/text-and-inspected-rendered comprehensibility for 勁 and necessary support雄勁, and bounded target-relative finite semantics/four-font presentation/reading-drawing presentation. Common evidence: six resources504,537bytes/87complete article bodies, original full families plus HOST811 sources and the FIVE native-label/23-family supplement814; all six complete forced reads returned exactly per model. Each reviewer opened22original byte-distinct PNG paths exactly once, representing36native captures through exact-byte aliases. Delivered images are900x2000renditions of1080x2400sources, NOT original-pixel or physical-phone certification. Raw events, reports, source resources and actual delivered payloads are archived losslessly; EVERY original stdout byte/hash round-tripped.

Ordinary secondary senses were assessed against64HOSTkanji+64HOSTword+64nativekanji exact ordered samples, both word directions and explicit活気/もりもり pair checks. DefaultN1/All/custom use ALLTHREE curated功/劾/剖 and ZEROfallback; native16-card filteredpool retainsTWO功/劾, omits剖 and uses ONEfallback perseed, unlike HOST811's distinct pool with NONE. New native亥/巳/彗/柚/鵬 plus inherited凌 do not establish another answer for 勁 "strong; taut" in those samples. This is not every-future-pool or every-wrong-choice-pair certification. Claude retains partially resolved LOW-confidence future-pool活気/もりもり notes, not established defects; GPT establishes no actionable hypothesis. Preserve this alongside original810's withdrawn disposition, not forced agreement or an invented exclusion. Claude's original optional wording/example suggestions remain nonblocking; GPT optional none.

Execution limits are explicit: Claude35view calls include SEVEN redundant boundary attempts, THREE of whose ranged responses did not contain the whole requested range; independently verified complete forced reads already returned all assigned text. GPT28calls/no extras. ClaudeTWO/GPTONE successful context compactions, ZERO warnings; access is not equal read depth or guaranteed visual retention in every model request. All14Han/whole雄勁 visibly readable in four-font/default panels, including bundled-cmap-absent勁/巠/刂; actual fallback face remainsUNKNOWN. Partial horizontal table/duplicate viewports/missing word-header capture/no native word-quiz samples remain disclosed. Soleけい/displayケイ/gooddone1of1/no kunquestion, legacy rawつよい reference display, nine UNGRADED reference touches/model unavailable/intentional recall grade1onNext are not handwriting mastery. ONE mapped pair/TWOdirections/ZERObaselinepairs/ZEROreusedchanges/Back/offline and native813's terminal success are inherited, not repeated. Historical process/source/permission/OOM/ANR/routing/phone evidence unchanged.

All8,469runtime hashes/version5572c6c467e6b73b unchanged; validator0errors/regeneratedmanifest unchanged. Final batch acceptance reconciliation remains pending; these preserved bounded report verdicts are NOT whole-batch acceptance or delivery. Next: SAME105 reconcile these complete reports and exact execution limits with original810/HOST811/native813/source814, without new blind initials or repeated image/native loops absent a consequential new defect. All combined-current-main/nonrewriting-merge/changed-teaching-review/full-required-Python/vocabulary/baseline-membership-links/manifest-budget/normal-signing/owner-fast-forward/terminal-green-CI/EVERY-immutable-GitHub-ZIP-hash/per-file-media-path/publication gates remain mandatory;18,000entries/42MiBcompressed/80MiBinflated/56MiBretained unchanged.

Published131/1,228; remaining1,097; last published047c2cef6b6a48b1738f2c5957de01be481c63e1. Batch105 unaccepted/unpublished; no next batch. Compatible stop-cran/kanji-cards-android#125 and stop-cran/kanji-cards-android#132 client required; old clients ignore curation/guards; qualified backport, not latest app main. Parent runner.lock untouched; approved control/committed sources only; no optional historical-session recipes or new denial. Physical-phone, general-release and whole-set acceptance outstanding; project incomplete.
"@
[IO.File]::WriteAllText($bodyPath, $body + "`n", [Text.UTF8Encoding]::new($false))
$priorToken = $env:GH_TOKEN
try {
    $env:GH_TOKEN = (gh auth token --user stop-cran)
    if ($LASTEXITCODE -ne 0 -or -not $env:GH_TOKEN) { throw 'Owner credential unavailable' }
    $login = gh api user --jq .login
    if ($LASTEXITCODE -ne 0 -or $login -cne 'stop-cran') { throw 'Wrong command-scoped identity' }
    $url = gh issue comment 60 --repo stop-cran/learning-japanese --body-file $bodyPath
    if ($LASTEXITCODE -ne 0) { throw 'Issue update failed' }
    $url = $url.Trim()
    @{ url=$url; author=$login; bodySha256=(Get-FileHash $bodyPath).Hash.ToLowerInvariant() } |
        ConvertTo-Json | Set-Content "$log\issue-815-posted.json" -Encoding utf8NoBOM
    if ($url -notmatch '#issuecomment-(\d+)$') { throw 'Unexpected comment URL; preserve receipt' }
    $raw = gh api "repos/stop-cran/learning-japanese/issues/comments/$($Matches[1])"
    if ($LASTEXITCODE -ne 0) { throw 'Comment reread failed' }
    $raw | Set-Content "$log\issue-815-reread.json" -Encoding utf8NoBOM
    $comment = $raw | ConvertFrom-Json
    if ($comment.user.login -cne 'stop-cran' -or $comment.body -cne [IO.File]::ReadAllText($bodyPath) -or
        $comment.html_url -cne $url) { throw 'Exact owner/body verification failed' }
    Write-Output "Verified owner update: $url"
} finally {
    $env:GH_TOKEN = $priorToken
}
