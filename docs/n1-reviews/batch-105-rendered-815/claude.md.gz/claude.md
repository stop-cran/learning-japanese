I confirm my original textual verdicts: both new articles are **CLEAN**, with no proved defects. The rendered screens and supplied quiz-option data support this, but nothing here is my own fresh device or phone test.

**Snapshot**
- Signed snapshot 2e252a09d46826f58fb901eb56c641bbc09fd9ed; teaching unchanged at 27e252daa091e21c907ff6799818f6b2da74c7aa (supplied teaching diff is empty); Android bf30cdead8515739bc0e671d57a54b9a3109dd46.
- Article hashes still match my original review: 勁.md 45ea30bf…, 雄勁.md ee7f12d1….
- Model: Claude Opus 5.5 (`claude-opus-5.5`); session 6f978e1c-a137-4b6c-879f-c7874d512549. Only `view` was used, one call per response, serially.

**Scope**
- **Text:** resources 01–06 read in order. 01–04 needed short serial range checks to confirm their ends; 05 and 06 were each one full read. No unrecovered gaps.
- **Images:** each of the 22 listed PNGs viewed once, at the scale delivered to me. That is not original-pixel inspection.
- **Missing from the evidence:** no image shows the top of the 雄勁 word article (the word captures start at "Meaning"), and no native word-quiz option sets were supplied; only host ones.

**Verdicts**
| Article | Correctness | Scoped coverage | Phone-text comprehensibility |
|---|---|---|---|
| 勁.md | CLEAN | CLEAN | CLEAN |
| 雄勁.md | CLEAN | CLEAN | CLEAN |

- **Article rendering:** the rendered sections match the text I reviewed. Visible items include:
  - title, strokes and radical;
  - the mnemonic, labelled as modern-shape only;
  - the ケイ reading row, and the つよ.い row explaining 勁い as a search-only spelling;
  - the 強い spelling-guidance note, and the notes on 功, 劾, 剖 and the near-synonym pairs;
  - grade 9 explained as name-use;
  - 雄勁な筆跡 with kana and translation, the な and です usage, the "not male handwriting" caution, the 力強い reassuring-sense comparison, and art/prose as characteristic contexts rather than a restriction.
- **Reading quiz:**
  - Full readings: on ケイ and kun つよ.い. Quiz selection: ケイ only, key けい, displayed as ケイ.
  - Offered choices: ボウ, コウ, ケイ, ガイ. No kun'yomi question; the session finished at 1 of 1 correct.
  - The feedback line still shows "ケイ、つよい". That is expected: curation removes the question, not the reference text.
- **Meaning quiz (finite semantics): CLEAN.**
  - Default N1, All and custom pools show only 功 "merit; achievement", 劾 "censure; impeach" and 剖 "dissect; split open" as wrong choices, with no fallback.
  - The native random N1 subset uses 功 and 劾 (not 剖) plus one fallback per seed: 凌 "endure; surpass", 鵬 "peng; giant mythical bird", 彗 "broom; comet", 亥 "Boar zodiac sign", 柚 "yuzu citrus" or 巳 "Snake zodiac sign".
  - None of these matches "strong; taut". 凌 is the weakest neighbour, but endure/defy/surpass is not strength or tautness. Bird grandeur and zodiac animals do not make the others synonyms.
  - The host 811 random subset contains none of 功, 劾 or 剖. I have kept it separate from the native subset.
  - For the word quiz, 雄勁's wrong choices in the host All and custom sets were 書道, 傑作 and unrelated words; all are distinguishable.
  - The four kanji pairs (強, 剛, 力, 勢) and six word pairs (強い, 強力, 力強い, 剛健, 力, 勢い) kept apart in quizzes are each direct and two-way only. They do not chain into groups.
- **Fonts (four families): CLEAN.**
  - All 14 characters render in Gothic, Mincho, Textbook and Brush, and 雄勁 renders whole.
  - 勁, 巠 and 刂 are missing from all three bundled fonts' character tables, but they still render visibly. 勁 is distinguishable from 功 and 劾, and 刂 from 力.
  - Which fallback font draws them is unknown. Identical images across families do not identify it.
- **Reading, drawing and presentation: CLEAN.**
  - The drawing shows nine numbered strokes; the reference touches were ungraded because the handwriting model was unavailable.
  - The recall reveal records grade 1 when Next is pressed.
  - One linked pair (勁 and 雄勁), working in both directions; Back and offline operation were supplied as passed.

**Findings:** none proved.

**Reconciling my earlier points**
- **活気 and もりもり as wrong choices for 雄勁:** partially resolved. Neither appears in any actual host set; they occur only in two-option hypothesis-pair checks. Labels like "liveliness; vigor" and "heartily; full of vigor" still differ from 雄勁's art/prose label. This remains a low-confidence note for future pools, not a defect.
- **Missing hedges at 勁.md:23 and :31:** still optional. The rendered meaning line still lacks a "characteristically" hedge.
- **Title "vigorous style (art; prose)":** still optional.
- **"Imposing" at 雄勁.md:21:** still optional; it is visible on screen.
- **"Search-only" at 勁.md:32:** partially resolved, because the table adds "Recognition only; use the ordinary spelling 強い."
- **"Practiced as けい" at 勁.md:34:** still optional, since the on-screen label is ケイ.
- **Adding 勁草 as an example:** still optional.

**Rendered-only observations**
- In captures 00, 02 and 05, the table cell's "spelling" is cut off at the screen edge; capture 06, scrolled sideways, shows the full text.
- Textbook, and to a lesser degree Brush, mix stroke weights: the fallback 勁 and 巠 look heavier than the surrounding glyphs.
- The offline trace screen says "Downloading the handwriting model". That is existing app behaviour, not caused by these articles.

**Optional:** the edits listed above (hedges, title, "imposing", "search-only", "practiced as けい", 勁草).

**Limits**
- No independent Git or upstream retrieval, and no fresh device test. The native run, content sync and guard counts are supplied receipts.
- Not certified: the fallback font's identity, original pixels, physical phone use, native-speaker review, equal reading depth across fonts, every future quiz pool, or learning effectiveness.
- Captures 08 and 09 duplicate one viewport (both were absent from the PNG list I was given). Not all table columns are visible at once, and capture IDs or distinct hashes do not prove distinct coverage.
- Gates still pending: combined current main, full Python run, vocabulary checks, baseline links and membership, manifest budget, signing, owner push, terminal CI, immutable ZIP and publication.
