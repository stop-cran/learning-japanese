package io.github.stopcran.kanji.ui

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.os.Build
import androidx.activity.ComponentActivity
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.junit4.createEmptyComposeRule
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.res.ResourcesCompat
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.room.withTransaction
import androidx.test.core.app.ActivityScenario
import androidx.test.platform.app.InstrumentationRegistry
import io.github.stopcran.kanji.KanjiApp
import io.github.stopcran.kanji.MainActivity
import io.github.stopcran.kanji.R
import io.github.stopcran.kanji.core.content.ContentParser
import io.github.stopcran.kanji.core.content.RepoSource
import io.github.stopcran.kanji.core.quiz.QuizBuilder
import io.github.stopcran.kanji.core.reading.ReadingKind
import io.github.stopcran.kanji.core.srs.KanjiFont
import io.github.stopcran.kanji.core.srs.StudyMode
import io.github.stopcran.kanji.core.words.WordDirection
import io.github.stopcran.kanji.core.words.WordQuizBuilder
import io.github.stopcran.kanji.data.*
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.File
import java.security.MessageDigest
import java.util.UUID


private fun disposable105() {
    assertEquals("true", InstrumentationRegistry.getArguments().getString("n1Disposable"))
    assertTrue(Build.HARDWARE in setOf("ranchu", "goldfish"))
}

class N1Batch105Glyph812Test {
    @get:Rule val rule = createAndroidComposeRule<ComponentActivity>()

    @Test fun strengthAllFourteenHanAndExplicitThreeFallbacksAcrossFourFamilies() {
        disposable105()
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val fonts = listOf(KanjiFont.Gothic, KanjiFont.Mincho, KanjiFont.Textbook, KanjiFont.Brush)
        val pages = listOf("健 刂 剖 剛 力 功 劾 勁 勢 巠", "強 筆 跡 雄", "勁 功 劾 剖 強 剛 力 勢 巠 刂 雄勁")
        val page = mutableStateOf(0)
        rule.setContent {
            MaterialTheme {
                Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Batch 105: strength / look-alikes / 勁 巠 刂 fallback")
                    Text("Panel ${page.value + 1} / ${pages.size}")
                    fonts.forEach { font ->
                        Text(font.name)
                        Text(pages[page.value], fontFamily = font.family(), fontSize = 18.sp, lineHeight = 26.sp)
                    }
                    Text("Inspect all 14 scoped Han. 勁 巠 刂 are absent from all three bundled cmaps: inspect real fallback in every family. Raster hashes are not readability.", fontSize = 16.sp)
                }
            }
        }
        val typefaces = listOf(Typeface.DEFAULT,
            requireNotNull(ResourcesCompat.getFont(context, R.font.kanji_mincho)),
            requireNotNull(ResourcesCompat.getFont(context, R.font.kanji_textbook)),
            requireNotNull(ResourcesCompat.getFont(context, R.font.kanji_brush)))
        val rows = JSONArray()
        for ((index, typeface) in typefaces.withIndex()) {
            val hashes = mutableSetOf<String>()
            for (char in listOf("健", "刂", "剖", "剛", "力", "功", "劾", "勁", "勢", "巠", "強", "筆", "跡", "雄")) {
                val paint = Paint(Paint.ANTI_ALIAS_FLAG).also {
                    it.typeface = typeface
                    it.textSize = 96f
                    it.textLocale = java.util.Locale.JAPAN
                }
                assertTrue("$char ${fonts[index]}", paint.hasGlyph(char))
                val image = Bitmap.createBitmap(if (char.length > 1) 256 else 128, 128, Bitmap.Config.ARGB_8888)
                Canvas(image).drawText(char, 8f, 104f, paint)
                val pixels = IntArray(image.width * image.height)
                image.getPixels(pixels, 0, image.width, 0, 0, image.width, image.height)
                assertTrue(pixels.any { it != 0 })
                val bytes = java.nio.ByteBuffer.allocate(pixels.size * 4)
                    .also { it.asIntBuffer().put(pixels) }.array()
                val hash = MessageDigest.getInstance("SHA-256").digest(bytes)
                    .joinToString("") { "%02x".format(it) }
                assertTrue("Indistinguishable raster ${fonts[index]}", hashes.add(hash))
                rows.put(JSONObject().put("character", char).put("font", fonts[index].name)
                    .put("hasGlyph", true).put("nativePaintRasterSha256", hash))
                image.recycle()
            }
            for (word in listOf("雄勁")) {
                val paint = Paint(Paint.ANTI_ALIAS_FLAG).also {
                    it.typeface = typeface
                    it.textSize = 96f
                    it.textLocale = java.util.Locale.JAPAN
                }
                // hasGlyph tests multi-character ligatures, not ordinary word coverage.
                val image = Bitmap.createBitmap(kotlin.math.ceil(paint.measureText(word)).toInt() + 16, 128, Bitmap.Config.ARGB_8888)
                Canvas(image).drawText(word, 8f, 104f, paint)
                val pixels = IntArray(image.width * image.height)
                image.getPixels(pixels, 0, image.width, 0, 0, image.width, image.height)
                for (position in word.indices) {
                    val left = (8f + paint.measureText(word, 0, position)).toInt()
                    val right = kotlin.math.ceil(8f + paint.measureText(word, 0, position + 1)).toInt()
                    assertTrue("Word raster bounds $word ${fonts[index]}", left >= 0 && right <= image.width && left < right)
                    assertTrue("Blank word character ${word[position]} ${fonts[index]}",
                        (0 until image.height).any { y -> (left until right).any { x -> pixels[y * image.width + x] != 0 } })
                }
                val bytes = java.nio.ByteBuffer.allocate(pixels.size * 4)
                    .also { it.asIntBuffer().put(pixels) }.array()
                val hash = MessageDigest.getInstance("SHA-256").digest(bytes)
                    .joinToString("") { "%02x".format(it) }
                rows.put(JSONObject().put("word", word).put("font", fonts[index].name)
                    .put("renderedCharactersNonblank", word.length).put("nativePaintRasterSha256", hash))
                image.recycle()
            }
        }
        assertEquals(60, rows.length())
        for (index in pages.indices) {
            rule.runOnIdle { page.value = index }
            rule.waitForIdle()
            rule.onAllNodesWithText(pages[index]).assertCountEquals(4)
            for (fontIndex in fonts.indices) rule.onAllNodesWithText(pages[index])[fontIndex].assertIsDisplayed()
            File(context.getExternalFilesDir(null), "n1-105-font-panel-${index + 1}.png").outputStream().use {
                assertTrue(rule.onRoot().captureToImage().asAndroidBitmap().compress(Bitmap.CompressFormat.PNG, 100, it))
            }
        }
        File(context.getExternalFilesDir(null), "n1-105-font-raster.json").writeText(JSONObject()
            .put("fingerprint", Build.FINGERPRINT).put("sdk", Build.VERSION.SDK_INT)
            .put("fontScale", context.resources.configuration.fontScale).put("rows", rows)
            .put("individualGlyphProbes", 56).put("wholeWordRasterProbes", 4).put("panels", 3)
            .put("limits", "14 actual scoped Han across four production families/default, three bounded Compose panels and four whole-word rasters. 勁 U+52C1, 巠 U+5DE0 and 刂 U+5202 are absent from all three bundled cmaps; this explicitly exercises actual native fallback, not acceptance by cmap. Hashes are not readability or fallback-face evidence. Actual PNG inspection required; emulator not phone.")
            .toString(2))
    }
}


class N1Batch105Article812Test {
    @get:Rule val rule = createEmptyComposeRule()
    private lateinit var app: KanjiApp
    private lateinit var scenario: ActivityScenario<MainActivity>

    @Test fun fullSingleImportStrengthDirectGuardsSoleOnSourceOnlyKunOnePairNineStrokesOfflineAndBack() {
        disposable105()
        val instrumentation = InstrumentationRegistry.getInstrumentation()
        app = instrumentation.targetContext.applicationContext as KanjiApp
        val source = RepoSource("acceptance-fixture", "n1-105-${UUID.randomUUID()}", "main")
        val head = "303a8cf752f70c024626c9e4e56b9b7b317a41e4"
        assertTrue(app.settings.setSource("https://github.com/${source.id}", source.branch))
        var archiveRequests = 0
        val http = ContentHttp { url, _, _, _ ->
            val input = when (url) {
                "https://api.github.com/repos/${source.id}/commits/main" -> ByteArrayInputStream(head.toByteArray())
                source.commitZipUrl(head) -> {
                    archiveRequests++
                    instrumentation.context.assets.open("n1-batch-105-303a8cf7-lf-envelope.zip")
                }
                else -> error("Unexpected fixture request: $url")
            }
            object : ContentResponse {
                override val code = 200
                override val body = input
                override fun header(name: String): String? = null
                override fun close() = input.close()
            }
        }
        val result = runBlocking { ContentSync(app.db, app.settings.sync, http).sync(source, force = true) }
        assertTrue(result.toString(), result is SyncResult.Updated)
        val updated = result as SyncResult.Updated
        assertEquals(1, archiveRequests)
        assertEquals(1128, updated.kanji)
        assertEquals(5079, updated.words)
        assertTrue(updated.problems.toString(), updated.problems.isEmpty())
        val meta = requireNotNull(runBlocking { app.db.content().meta(source.id) })
        assertEquals("5572c6c467e6b73b", meta.contentVersion)
        assertEquals(0, meta.problems)
        assertNull(meta.grammarProblem)
        assertNull(meta.listeningProblem)
        assertNull(meta.grammarCurriculumProblem)
        assertEquals(1, ContentParser.KANJI_READING_PARSER_EPOCH)
        assertEquals(ContentParser.KANJI_READING_PARSER_EPOCH, meta.kanjiReadingParserEpoch)
        assertEquals(1, ContentParser.KANJI_MEANING_PARSER_EPOCH)
        assertEquals(ContentParser.KANJI_MEANING_PARSER_EPOCH, meta.kanjiMeaningParserEpoch)
        val all = runBlocking { app.db.content().kanjiLite(source.id) }
        val n1 = all.filter { it.jlpt == 1 }
        assertEquals(137, n1.size)
        assertEquals(n1.map { it.kanji }.toSet(),
            all.filter { "jlpt-n1" in it.tags.splitSep() }.map { it.kanji }.toSet())
        val target = n1.single { it.kanji == "勁" }
        val guards = listOf("強", "剛", "力", "勢")
        assertEquals(guards, target.quizExclusions.splitSep())
        val observed = runBlocking { app.db.content().observeKanjiLite(source.id).first() }.single { it.kanji == "勁" }
        assertEquals(guards, observed.toQuizCard().quizExclusions)
        val full = requireNotNull(runBlocking { app.db.content().kanjiCard(source.id, "勁") })
        assertEquals(guards, full.quizExclusions.splitSep())
        assertEquals(guards, full.toQuizCard().quizExclusions)
        assertEquals(guards, runBlocking { app.db.content().kanji(source.id) }
            .single { it.kanji == "勁" }.toQuizCard().quizExclusions)
        assertEquals(listOf("功", "劾", "剖"), target.distractors.splitSep())
        assertEquals(listOf("ケイ"), target.onyomi.splitSep())
        assertEquals(listOf("つよ.い"), target.kunyomi.splitSep())
        assertEquals(listOf("ケイ"), target.quizOnyomi?.splitSep())
        assertEquals(emptyList<String>(), target.quizKunyomi?.splitSep())
        assertEquals(listOf("けい"), target.toReadingCard().quizKeys(ReadingKind.On))
        assertEquals(emptyList<String>(), target.toReadingCard().quizKeys(ReadingKind.Kun))
        assertNull(io.github.stopcran.kanji.core.reading.KanjiReadingQuiz.question(
            target.toReadingCard(), ReadingKind.Kun, all.map { it.toReadingCard() }, kotlin.random.Random(812)))
        assertEquals(listOf("つよ.い"), full.kunyomi.splitSep())
        assertEquals(emptyList<String>(), full.quizKunyomi?.splitSep())
        assertEquals(listOf("ケイ"), full.onyomi.splitSep())
        assertEquals(listOf("ケイ"), full.quizOnyomi?.splitSep())
        val expectedMeanings = mapOf("勁" to "strong; taut", "功" to "merit; achievement",
            "劾" to "censure; impeach", "剖" to "dissect; split open")
        val curatedIds = listOf("功", "劾", "剖")
        assertEquals(mapOf("功" to 1, "劾" to 1, "剖" to 1),
            all.filter { it.kanji in curatedIds }.associate { it.kanji to it.jlpt })
        assertEquals(setOf("功", "劾", "剖"), n1.filter { it.kanji in curatedIds }.map { it.kanji }.toSet())
        val custom = all.filter { it.kanji in expectedMeanings }
        val randomSubset = listOf(target) +
            n1.filter { it.kanji != "勁" }.shuffled(kotlin.random.Random(812)).take(15)
        val choices = JSONArray()
        for ((poolName, pool) in listOf("N1" to n1, "All" to all,
            "boundedCustom" to custom, "randomN1Subset" to randomSubset)) {
            val cards = pool.map { it.toQuizCard() }
            val quizTarget = cards.single { it.kanji == "勁" }
            val available = curatedIds.filter { id -> cards.any { it.kanji == id } }
            repeat(16) { seed ->
                val options = QuizBuilder.options(quizTarget, cards, kotlin.random.Random(seed))
                assertEquals(4, options.size)
                assertEquals(4, options.map { it.title }.toSet().size)
                assertEquals(1, options.count { it.kanji == "勁" })
                val offeredCards = options.map { option -> cards.single { it.kanji == option.kanji } }
                for (left in offeredCards) for (right in offeredCards.filter { it.kanji != left.kanji })
                    assertFalse(right.kanji in left.quizExclusions || left.kanji in right.quizExclusions)
                assertTrue(options.none { it.kanji in guards })
                assertTrue(available.all { id -> options.any { it.kanji == id } })
                assertTrue(options.all { o -> pool.any { it.kanji == o.kanji && it.title == o.title } })
                if (available.size == 3) assertEquals(expectedMeanings, options.associate { it.kanji to it.title })
                choices.put(JSONObject().put("pool", poolName).put("seed", seed)
                    .put("poolMembershipInOrder", JSONArray(pool.map { it.kanji }))
                    .put("options", JSONArray().also { rows ->
                        options.forEach { rows.put(JSONObject().put("kanji", it.kanji).put("title", it.title)) }
                    }))
            }
        }
        assertEquals(64, choices.length())
        val allCards = all.map { it.toQuizCard() }
        val guardChecks = JSONArray()
        for (excludedId in guards) {
            val pair = allCards.filter { it.kanji in setOf("勁", excludedId) }
            assertEquals(2, pair.size)
            for (quizTarget in pair) {
                val excluded = pair.single { it.kanji != quizTarget.kanji }
                repeat(16) { seed ->
                    val sampled = pair + allCards.filter { it.kanji !in setOf("勁", excludedId) }
                        .shuffled(kotlin.random.Random(812 + seed)).take(seed)
                    for ((poolName, pool) in listOf(
                        "N1" to n1.map { it.toQuizCard() }, "All" to allCards,
                        "boundedCustom" to (pair + allCards.filter { it.kanji in curatedIds }),
                        "randomN1Subset812" to (pair + randomSubset.map { it.toQuizCard() }
                            .filter { it.kanji !in setOf("勁", excludedId) }),
                        "sampledFiltered" to sampled, "pairOnly" to pair,
                        "targetOutsidePool" to sampled.filter { it.kanji != quizTarget.kanji },
                    )) {
                        val options = QuizBuilder.options(quizTarget, pool, kotlin.random.Random(seed))
                        assertEquals(1, options.count { it.kanji == quizTarget.kanji })
                        assertFalse("Direct guard leaked $excludedId $poolName", options.any { it.kanji == excluded.kanji })
                        assertTrue(options.size in 1..4)
                        val offeredCards = options.map { option -> allCards.single { it.kanji == option.kanji } }
                        for (left in offeredCards) for (right in offeredCards.filter { it.kanji != left.kanji })
                            assertFalse(right.kanji in left.quizExclusions || left.kanji in right.quizExclusions)
                        assertEquals(options.size, options.map { it.title }.toSet().size)
                        assertTrue(options.all { it.kanji == quizTarget.kanji || pool.any { p -> p.kanji == it.kanji } })
                        if (poolName == "pairOnly") assertEquals(1, options.size)
                        guardChecks.put(JSONObject().put("target", quizTarget.kanji).put("excluded", excluded.kanji)
                            .put("pool", poolName).put("seed", seed)
                            .put("poolMembershipInOrder", JSONArray(pool.map { it.kanji }))
                            .put("options", JSONArray(options.map { it.kanji })))
                    }
                }
            }
        }
        assertEquals(896, guardChecks.length())
        val nontransitiveChecks = JSONArray()
        for (left in guards) for (right in guards.filter { it != left }) repeat(16) { seed ->
            val pair = allCards.filter { it.kanji in setOf(left, right) }
            val leftCard = pair.single { it.kanji == left }
            val rightCard = pair.single { it.kanji == right }
            assertFalse(right in leftCard.quizExclusions || left in rightCard.quizExclusions)
            val options = QuizBuilder.options(leftCard, pair, kotlin.random.Random(seed))
            assertEquals(setOf(left, right), options.map { it.kanji }.toSet())
            nontransitiveChecks.put(JSONObject().put("target", left).put("neighbor", right).put("seed", seed)
                .put("options", JSONArray(options.map { it.kanji })))
        }
        assertEquals(192, nontransitiveChecks.length())
        val words = runBlocking { app.db.content().wordsLite(source.id) }.map { it.toCard() }
        val preserved = mapOf("雄勁" to listOf("強い", "強力", "力強い", "剛健", "力", "勢い"))
        val wordChecks = JSONArray()
        for ((id, excludedIds) in preserved) {
            val left = words.single { it.word == id }
            assertEquals(excludedIds, left.quizExclusions)
            assertNull(left.jlpt)
            for (excludedId in excludedIds) {
                val right = words.single { it.word == excludedId }
                val pair = listOf(left, right)
                for (wordTarget in pair)
                    for (direction in listOf(WordDirection.JpToEn, WordDirection.EnToJp)) repeat(16) { seed ->
                        val options = WordQuizBuilder.options(wordTarget, pair, direction, kotlin.random.Random(seed))
                        assertEquals(listOf(wordTarget.word), options.map { it.word })
                        wordChecks.put(JSONObject().put("declaredOn", id).put("excluded", excludedId)
                            .put("target", wordTarget.word).put("pool", "pairOnly")
                            .put("direction", direction.name).put("seed", seed)
                            .put("label", options.single().label))
                    }
            }
        }
        assertEquals(384, wordChecks.length())
        val now = System.currentTimeMillis()
        app.settings.sync.lastCheckMs = now
        app.settings.setStartingGuideVisible(false)
        app.settings.setDailyNewCards(50)
        app.settings.setWeekPlan("FFFFFFF")
        app.settings.setTraceNew(true)
        app.settings.setVaryFonts(true)
        app.settings.setStack("jlpt-n5")
        runBlocking {
            app.db.withTransaction {
                n1.forEach { card ->
                    app.db.reviews().putState(ReviewStateEntity(
                        source.id, "jlpt-n1", card.kanji, StudyMode.Quiz.name, "Review", 30.0, 5.0,
                        if (card.kanji == "勁") now - 60_000 else now + 30L * 86_400_000,
                        now - 2L * 86_400_000, 3, 0,
                    ))
                    for (kind in ReadingKind.entries) for (key in card.toReadingCard().quizKeys(kind))
                        app.db.reviews().putState(ReviewStateEntity(
                            source.id, "jlpt-n1", card.kanji, kind.mode.name, "Review", 30.0, 5.0,
                            if (card.kanji == "勁") now - 60_000 else now + 30L * 86_400_000,
                            now - 2L * 86_400_000, 3, 0, reading = key,
                        ))
                }
                for (days in 1..2) app.db.reviews().putLog(ReviewLogEntity(
                    0, source.id, "jlpt-n1", "勁", StudyMode.Quiz.name, 3, now - days * 86_400_000L,
                ))
            }
        }
        val connectivity = app.getSystemService(ConnectivityManager::class.java)
        assertNull("Disable owned emulator Wi-Fi/data before offline acceptance", connectivity.activeNetwork)
        val evidence = JSONObject().put("contentSnapshot", head).put("contentVersion", meta.contentVersion)
            .put("archiveRequests", archiveRequests).put("importedKanji", updated.kanji).put("importedWords", updated.words)
            .put("problems", updated.problems.size).put("n1Cards", n1.size)
            .put("acceptedReadingParserEpoch", meta.kanjiReadingParserEpoch)
            .put("acceptedMeaningParserEpoch", meta.kanjiMeaningParserEpoch)
            .put("productionBuilderN1AndAllExactChoices", choices).put("kanjiDirectGuardChecks", guardChecks)
            .put("nontransitiveNeighborChecks", nontransitiveChecks).put("preservedWordGuardChecks", wordChecks)
            .put("fullOnyomi", JSONArray(target.onyomi.splitSep())).put("fullKunyomi", JSONArray(target.kunyomi.splitSep()))
            .put("quizOnKeys", JSONArray(target.toReadingCard().quizKeys(ReadingKind.On)))
            .put("quizKunKeys", JSONArray(target.toReadingCard().quizKeys(ReadingKind.Kun)))
            .put("kanjiQuizExclusions", JSONArray(guards))
            .put("fingerprint", Build.FINGERPRINT).put("sdk", Build.VERSION.SDK_INT)
            .put("transport", "Exact full git archive through production ContentSync ONCE; synthetic source/HEAD")
            .put("fixture", "Other N1 meanings/readings postponed; only勁 meaning and soleけい on-reading due; source-onlyつよ.い preserved but not offered. Two historical good meaning logs unlock drawing. No drawing state seeded. Disposable source, not owner progress.")
            .put("limits", "Sampled pools, not exhaustive future semantics. Direct conservative guards are not unrestricted synonyms. Sampled fallback ordinary-sense semantic acceptance remains UNVERIFIED until source-backed rendered review. Raster hashes are not readability. Emulator, not phone.")
            .put("phoneEvidence", false).put("passed", false)
        scenario = ActivityScenario.launch(MainActivity::class.java)
        try {
            click("Kanji")
            click("N1")
            rule.waitUntil(30_000) { app.settings.stack.value == "jlpt-n1" }
            await("N1 · 137 cards").performScrollTo().assertIsDisplayed()
            capture("selection")
            click("Browse all kanji")
            rule.onNode(hasSetTextAction()).performTextReplacement("勁")
            click("strong; taut")
            await("勁 — strong; taut")
            show(articleBullet("Strokes: 9 · Key (radical): 力 (no. 19), at the right · JLPT: N1 (community list)"), "article-00")
            section("Meaning and origin")
            show(articleBullet("勁 conveys strength, including the idea of being stretched taut and strong. Learn it through 雄勁 ゆうけい, which describes vigorous, forceful expression in art or prose. It is not a general replacement for the everyday spelling 強い つよい, \"strong.\""), "article-02")
            show(articleBullet("Modern-shape mnemonic, not etymology: Imagine the 巠-shaped left part held taut beside 力, \"strength,\" on the right. This is a memory aid for the modern shape, not a historical derivation or a claim about a phonetic component."), "article-03")
            section("Readings")
            show(readingExample("ケイ"), "article-05")
            show(readingExample("雄勁 ゆうけい — vigorous style in art or prose"), "article-06")
            show(readingExample("つよ.い"), "article-07")
            show(readingExample("勁い (つよい), \"strong,\" is indexed by JMdict as a search-only spelling. Recognition only; use the ordinary spelling 強い."), "article-08")
            show(articleBullet("Reading questions select only ケイ, practiced as けい. In 雄勁, 雄 supplies ユウ and 勁 supplies ケイ. The full source reading つよ.い is preserved, but its indexed spelling is not recommended as ordinary usage or offered in reading questions. The link to the ordinary 強い article is spelling guidance, not an example of a word written with 勁."), "article-09")
            section("Common words")
            show(articleBullet("雄勁 ゆうけい — vigorous, forceful style, especially in art or prose"), "article-11")
            section("Notes")
            show(articleBullet("功, \"merit; achievement,\" and 劾, \"censure; impeach,\" also have 力 at the right, but their left parts and meanings differ."), "article-13")
            show(articleBullet("剖, \"dissect; split open,\" has 刂 rather than 力 at the right. Keep that blade-shaped component distinct from the strength radical."), "article-14")
            show(articleBullet("強, \"strong,\" 剛, \"sturdy; unyielding strength,\" 力, \"power,\" and 勢, \"force; momentum,\" have overlapping strength or force meanings. They are useful comparisons, not clearly wrong meaning choices."), "article-15")
            show(articleBullet("The source's grade-9 classification concerns name-use kanji. It does not mean every use is a personal name or that the character is ordinary everyday spelling. Personal-name readings are not taught here."), "article-16")
            show(articleBullet("Metadata: KANJIDIC2, 2026-11-02 snapshot. Word identity and search-only spelling: JMdict, entries 1839950 and 1236070. Character meaning and reading example: Digital Daijisen, 勁; compound use: 雄勁."), "article-17")
            section("Common words")
            inline(await(articleBullet("雄勁 ゆうけい — vigorous, forceful style, especially in art or prose")), "雄勁", 0)
            await("雄勁 (ゆうけい) — vigorous style (art; prose)")
            section("Meaning")
            show(articleBullet("雄勁 describes vigor or power, characteristically in calligraphy, painting, poetry or prose. It is a noun and a na-adjective: 雄勁な + noun, or 雄勁です as a polite predicate."), "word-0-01")
            show(articleBullet("Digital Daijisen gives the phrase 雄勁な筆跡 (ゆうけいなひっせき), \"vigorous handwriting.\" Here 筆跡 means handwriting, and な connects 雄勁 to that noun. The phrase praises forceful expression, not the physical strength of the writer's hand."), "word-0-02")
            section("How the kanji combine")
            show(articleBullet("雄 (ユウ) evokes imposing strength here; 勁 (ケイ) contributes strength. Their related meanings reinforce the idea of forceful expression. This is a meaning aid, not a historical reconstruction: the compound does not mean \"male handwriting.\""), "word-0-04")
            section("Synonyms and antonyms")
            show(articleBullet("力強い (ちからづよい), \"powerful; reassuring,\" overlaps in its powerful or vigorous sense, but is a broader i-adjective. Its separate reassurance sense is not the meaning taught by 雄勁."), "word-0-06")
            show(articleBullet("強い (つよい), \"strong; powerful,\" is the ordinary broad adjective. 雄勁 is not a general substitute for it when describing a strong team, wind or resistance."), "word-0-07")
            show(articleBullet("Weak or feeble expression gives a contextual contrast. There is no single opposite that works for every artistic description."), "word-0-08")
            section("Distinctive meaning")
            show(articleBullet("Learn 雄勁 as descriptive vocabulary for a vigorous style, rather than as the everyday word for every kind of strength. Art and prose are characteristic contexts, not an absolute restriction on every dictionary use."), "word-0-10")
            show(articleBullet("Use な before a noun, not the ending い of an i-adjective. Noun status alone does not make this a する verb. The word assesses force or vigor in the expression; it does not by itself establish the work's overall quality or the creator's personal character."), "word-0-11")
            show(articleBullet("Dictionary: JMdict, entry 1839950; handwriting 1487850 and comparisons 1554940 and 1236070. Meaning and the short handwriting example: Digital Daijisen, 雄勁. Component senses and readings: 雄 and 勁."), "word-0-12")
            section("How the kanji combine")
            show(articleBullet("雄 (ユウ) evokes imposing strength here; 勁 (ケイ) contributes strength. Their related meanings reinforce the idea of forceful expression. This is a meaning aid, not a historical reconstruction: the compound does not mean \"male handwriting.\""), "pair-0-components")
            inline(await(articleBullet("雄 (ユウ) evokes imposing strength here; 勁 (ケイ) contributes strength. Their related meanings reinforce the idea of forceful expression. This is a meaning aid, not a historical reconstruction: the compound does not mean \"male handwriting.\"")), "勁", 38)
            await("勁 — strong; taut")
            back()
            await(articleBullet("雄 (ユウ) evokes imposing strength here; 勁 (ケイ) contributes strength. Their related meanings reinforce the idea of forceful expression. This is a meaning aid, not a historical reconstruction: the compound does not mean \"male handwriting.\"")).assertIsDisplayed()
            back()
            await(articleBullet("雄勁 ゆうけい — vigorous, forceful style, especially in art or prose")).assertIsDisplayed()
            back()
            await("Search kanji, meaning or reading")
            back()
            await("Meaning quiz")
            evidence.put("mappedReciprocalPairs", 1).put("directedLinkTransitions", 2)
                .put("activatedBaselinePairs", 0).put("changedReusedArticles", 0)
                .put("changedReusedNavigationTransitions", 0).put("reciprocalLinkAndSystemBack", true)
            click(rule.onNode(hasText("Start") and hasAnyAncestor(hasText("Meaning quiz"))))
            rule.waitUntil(30_000) { (model("quiz:") as? QuizViewModel)?.ui is QuizUi.Question }
            val quiz = model("quiz:") as QuizViewModel
            val meaning = quiz.ui as QuizUi.Question
            assertEquals("勁", meaning.card.kanji)
            val n1Curated = curatedIds.filter { id -> n1.any { it.kanji == id } }
            assertEquals(setOf("功", "劾", "剖"), n1Curated.toSet())
            assertEquals(4, meaning.options.size)
            assertEquals(4, meaning.options.map { it.title }.toSet().size)
            assertEquals(1, meaning.options.count { it.kanji == "勁" })
            assertTrue(n1Curated.all { id -> meaning.options.any { it.kanji == id && it.title == expectedMeanings[id] } })
            assertTrue(meaning.options.all { option -> n1.any { it.kanji == option.kanji && it.title == option.title } })
            assertEquals(expectedMeanings, meaning.options.associate { it.kanji to it.title })
            val fallback = meaning.options.filter { it.kanji != "勁" && it.kanji !in curatedIds }
            assertEquals(0, fallback.size)
            assertEquals(guards, meaning.card.toQuizCard().quizExclusions)
            assertTrue(meaning.options.none { it.kanji in guards })
            val actualCards = meaning.options.map { option -> n1.single { it.kanji == option.kanji }.toQuizCard() }
            for (left in actualCards) for (right in actualCards.filter { it.kanji != left.kanji })
                assertFalse(right.kanji in left.quizExclusions || left.kanji in right.quizExclusions)
            for (option in meaning.options) await(option.title).assertIsDisplayed()
            evidence.put("exactDefaultMeaningOptions", JSONArray().also { rows ->
                meaning.options.forEach { rows.put(JSONObject().put("kanji", it.kanji).put("title", it.title)) }
            }).put("actualN1CuratedAvailable", 3).put("actualN1FallbackOptions", 0)
                .put("curatedDistractorLevels", JSONObject().put("功", 1).put("劾", 1).put("剖", 1))
                .put("meaningFallbackNeedsSemanticReview", true)
            capture("meaning-question")
            click("strong; taut")
            await("Correct!")
            capture("meaning-feedback")
            back()
            await("Meaning quiz")
            click(rule.onNode(hasText("Start") and hasAnyAncestor(hasText("Readings (on'yomi and kun'yomi)"))))
            val answeredKeys = mutableSetOf<String>()
            rule.waitUntil(30_000) { (model("kreading:") as? KanjiReadingViewModel)?.ui is ReadingUi.Question }
            val reading = model("kreading:") as KanjiReadingViewModel
            val question = reading.ui as ReadingUi.Question
            assertEquals("勁", question.card.kanji)
            assertEquals(ReadingKind.On, question.question.kind)
            assertEquals("けい", question.question.correctKey)
            assertEquals(listOf("つよ.い"), question.card.kunyomi.splitSep())
            assertEquals(emptyList<String>(), question.card.quizKunyomi?.splitSep())
            assertTrue(answeredKeys.add("けい"))
            assertEquals(1, question.question.options.count { it.key == "けい" })
            assertEquals("ケイ", question.question.options.single { it.key == "けい" }.label)
            evidence.put("exactOnReadingOptions", JSONArray().also { rows ->
                question.question.options.forEach { rows.put(JSONObject().put("key", it.key).put("label", it.label)) }
            })
            capture("curated-on-question")
            click("ケイ")
            await("Correct! — on'yomi")
            assertTrue((reading.ui as ReadingUi.Answer).correct)
            capture("curated-on-feedback")
            click("Next")
            assertEquals(setOf("けい"), answeredKeys)
            rule.waitUntil(30_000) { (model("kreading:") as? KanjiReadingViewModel)?.ui is ReadingUi.Done }
            val done = (model("kreading:") as KanjiReadingViewModel).ui as ReadingUi.Done
            assertEquals(1, done.answered)
            assertEquals(1, done.correct)
            rule.waitUntil(30_000) { runBlocking {
                app.db.reviews().allLog().count { log -> log.sourceId == source.id && log.kanji == "勁" &&
                    log.mode in setOf(ReadingKind.On.mode.name, ReadingKind.Kun.mode.name) && log.grade == 3 } == 1
            } }
            val logs = runBlocking { app.db.reviews().allLog().filter {
                it.sourceId == source.id && it.kanji == "勁" &&
                    it.mode in setOf(ReadingKind.On.mode.name, ReadingKind.Kun.mode.name)
            } }
            assertEquals(1, logs.size)
            assertEquals(setOf("けい"), logs.map { it.reading }.toSet())
            assertTrue(logs.all { it.grade == 3 && it.mode == ReadingKind.On.mode.name })
            capture("curated-sole-on-done")
            back()
            await("Meaning quiz")
            click(rule.onNode(hasText("Start") and hasAnyAncestor(hasText("Drawing"))))
            await("Trace the kanji for")
            await("strong; taut").assertIsDisplayed()
            val card = requireNotNull(runBlocking { app.db.content().kanjiCard(source.id, "勁") })
            assertEquals(listOf("ケイ"), card.onyomi.splitSep())
            assertEquals(listOf("つよ.い"), card.kunyomi.splitSep())
            assertEquals(listOf("ケイ"), card.quizOnyomi?.splitSep())
            assertEquals(emptyList<String>(), card.quizKunyomi?.splitSep())
            assertEquals(guards, card.quizExclusions.splitSep())
            evidence.put("fullProjectionOnyomi", JSONArray(card.onyomi.splitSep()))
                .put("fullProjectionKunyomi", JSONArray(card.kunyomi.splitSep()))
                .put("fullProjectionQuizOnyomi", JSONArray(requireNotNull(card.quizOnyomi).splitSep()))
                .put("fullProjectionQuizKunyomi", JSONArray(requireNotNull(card.quizKunyomi).splitSep()))
            val strokes = JSONObject(requireNotNull(card.strokesJson)).getJSONArray("strokes")
            assertEquals(9, strokes.length())
            capture("drawing-trace")
            val pad = rule.onNode(hasContentDescription("Drawing area for the kanji", substring = true))
            pad.performScrollTo()
            for (index in 0 until strokes.length()) {
                val points = strokes.getJSONObject(index).getJSONArray("points")
                pad.performTouchInput {
                    fun point(i: Int): Offset {
                        val pair = points.getJSONArray(i)
                        return Offset(pair.getDouble(0).toFloat() * width / 109f,
                            pair.getDouble(1).toFloat() * height / 109f)
                    }
                    down(point(0))
                    for (i in 1 until points.length()) moveTo(point(i), delayMillis = 16)
                    up()
                }
            }
            rule.onNode(hasContentDescription("9 strokes drawn", substring = true)).assertExists()
            click("Check")
            await("Practice only: this attempt is not graded.")
            assertFalse(runBlocking { app.db.reviews().allLog().any {
                it.sourceId == source.id && it.kanji == "勁" && it.mode == StudyMode.Draw.name
            } })
            await("Correct strokes").performScrollTo().assertIsDisplayed()
            capture("drawing-feedback")
            click("Next")
            await("Draw the kanji for")
            click("I don't remember")
            await("Here is the kanji")
            capture("drawing-recall-feedback")
            click("Next")
            rule.waitUntil(30_000) { runBlocking { app.db.reviews().allLog().any {
                it.sourceId == source.id && it.kanji == "勁" && it.mode == StudyMode.Draw.name && it.grade == 1
            } } }
            back()
            await("Meaning quiz")
            assertEquals("jlpt-n1", app.settings.stack.value)
            assertNull(connectivity.activeNetwork)
            assertEquals(1, archiveRequests)
            evidence.put("meaningQuestionAndFeedback", true).put("soleCuratedOnPersistedGoodAndDone", true)
                .put("touchInjectedReferenceStrokes", strokes.length()).put("drawingTraceThenRecall", true)
                .put("drawingGradeRecordedOnNext", true).put("offline", true).put("passed", true)
        } finally {
            File(app.getExternalFilesDir(null), "n1-105-article-route.json").writeText(evidence.toString(2))
            File(app.getExternalFilesDir(null), "n1-105-article-tree.txt").writeText(rule.onRoot().printToString())
            scenario.close()
        }
    }

    private fun model(prefix: String): ViewModel? {
        var result: ViewModel? = null
        scenario.onActivity { activity ->
            result = activity.viewModelStore.keys().lastOrNull { it.startsWith(prefix) }?.let { activity.viewModelStore[it] }
        }
        return result
    }

    private fun await(text: String, substring: Boolean = false): SemanticsNodeInteraction {
        return await(hasText(text, substring = substring))
    }

    private fun await(matcher: SemanticsMatcher): SemanticsNodeInteraction {
        rule.waitUntil(30_000) { rule.onAllNodes(matcher).fetchSemanticsNodes().isNotEmpty() }
        rule.onAllNodes(matcher).assertCountEquals(1)
        return rule.onNode(matcher)
    }

    private fun readingExample(text: String): SemanticsMatcher {
        return hasText(text) and hasAnyAncestor(hasTestTag("article-body")) and
            hasAnyAncestor(SemanticsMatcher.keyIsDefined(SemanticsProperties.HorizontalScrollAxisRange))
    }

    private fun articleBullet(text: String): SemanticsMatcher {
        return hasText(text) and hasAnyAncestor(hasTestTag("article-body")) and
            !hasAnyAncestor(SemanticsMatcher.keyIsDefined(SemanticsProperties.HorizontalScrollAxisRange))
    }

    private fun click(text: String) = click(await(text))

    private fun click(node: SemanticsNodeInteraction) {
        rule.waitUntil(30_000) { !node.fetchSemanticsNode().config.contains(SemanticsProperties.Disabled) }
        if (node.onAncestors().filter(hasScrollAction()).fetchSemanticsNodes().isNotEmpty()) node.performScrollTo()
        node.assertIsDisplayed().assertIsEnabled().performClick()
    }

    private fun section(title: String) {
        rule.onNodeWithTag("article-body").performScrollToIndex(0)
        click("Article contents")
        rule.onNode(hasText(title, substring = true) and hasClickAction()).performScrollTo().performClick()
        rule.waitForIdle()
    }

    private fun show(selector: String, step: String) {
        show(hasText(selector, substring = true), step)
    }

    private fun show(matcher: SemanticsMatcher, step: String, occurrence: Int = 0, expectedCount: Int = 1) {
        val body = rule.onNodeWithTag("article-body")
        body.performScrollToNode(matcher)
        rule.onAllNodes(matcher).assertCountEquals(expectedCount)
        val target = rule.onAllNodes(matcher)[occurrence]
        target.performScrollTo()
        val viewport = body.fetchSemanticsNode()
        val cell = target.fetchSemanticsNode()
        val top = viewport.positionInRoot.y
        val bottom = top + viewport.size.height
        if (cell.positionInRoot.y < top || cell.positionInRoot.y + cell.size.height > bottom) {
            body.performSemanticsAction(SemanticsActions.ScrollBy) {
                it(0f, cell.positionInRoot.y - top - 16f)
            }
            rule.waitForIdle()
        }
        target.assertIsDisplayed()
        capture(step)
    }

    private fun inline(node: SemanticsNodeInteraction, label: String, offset: Int) {
        node.performScrollTo().assertIsDisplayed()
        val text = node.fetchSemanticsNode().config[SemanticsProperties.Text].joinToString("") { it.text }
        val layouts = mutableListOf<TextLayoutResult>()
        node.performSemanticsAction(SemanticsActions.GetTextLayoutResult) { it(layouts) }
        assertTrue("Wrong linked offset $offset for $label in $text", offset >= 0 && text.substring(offset).startsWith(label))
        node.performTouchInput { click(layouts.single().getBoundingBox(offset).center) }
    }

    private fun back() {
        InstrumentationRegistry.getInstrumentation().uiAutomation.performGlobalAction(
            android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
        rule.waitForIdle()
    }

    private fun capture(step: String) {
        rule.waitForIdle()
        val automation = InstrumentationRegistry.getInstrumentation().uiAutomation
        automation.waitForIdle(500, 5_000)
        android.os.SystemClock.sleep(1_000)
        rule.waitForIdle()
        val bitmap = requireNotNull(automation.takeScreenshot())
        File(app.getExternalFilesDir(null), "n1-105-$step.png").outputStream().use {
            assertTrue(bitmap.compress(Bitmap.CompressFormat.PNG, 100, it))
        }
        bitmap.recycle()
    }
}
