"""Normalize new contributor JSON only; preserve all original evidence bytes."""
import gzip
import hashlib
import json
from pathlib import Path

C = Path(__file__).resolve().parent
R = C.parent / "learning-japanese"
D = R / "docs" / "n1-reviews" / "batch-105-reconciliation-816"
E = R / "docs" / "n1-sources" / "execution-816.json"
original = D / "artifact-index-before-lf-normalization.json.gz"
assert not original.exists()
original.write_bytes(gzip.compress((D / "artifact-index.json").read_bytes(), mtime=0))
e = json.loads(E.read_bytes())
e["stagingDiagnostic"] = {
    "initialAttempt": "Pre-commit exact staged-blob audit caught disposition.json checkout CRLF versus Git LF; commit was not reached.",
    "disposition": "Normalize only new contributor JSON to LF and regenerate its artifact index. Original attempted index archived; complete original reports/events/resources remain exact lossless archives, with no source/teaching/test/signing change."
}
E.write_bytes((json.dumps(e, ensure_ascii=False, indent=2) + "\n").encode())
for path in D.glob("*.json"):
    path.write_bytes(path.read_bytes().replace(b"\r\n", b"\n"))
(D / (Path(__file__).name + ".gz")).write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
rows = [
    {"file": str(p.relative_to(D)), "sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
     "bytes": p.stat().st_size}
    for p in sorted(D.iterdir()) if p.is_file() and p.name != "artifact-index.json"
]
(D / "artifact-index.json").write_bytes((json.dumps(rows, indent=2) + "\n").encode())
print("New contributor JSON/index normalized to Git LF; original raw evidence unchanged.")
