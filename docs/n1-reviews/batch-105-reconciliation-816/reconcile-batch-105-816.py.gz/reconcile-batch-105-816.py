"""Reconcile preserved batch 105 evidence; never rerun reviewers or native tests."""
import base64
import copy
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import xml.etree.ElementTree as ET

C = Path(__file__).resolve().parent
R = C.parent / "learning-japanese"
A = C.parent / "kanji-cards-android"
L = C / "logs" / "51f3511e-4796-42c2-9183-db5ae225a16c"
D = R / "docs" / "n1-reviews" / "batch-105-reconciliation-816"
HEAD = "af2ef667321b33786938cf5518f8403454072fda"
TEACHING = "27e252daa091e21c907ff6799818f6b2da74c7aa"
APP = "bf30cdead8515739bc0e671d57a54b9a3109dd46"
MAIN = "047c2cef6b6a48b1738f2c5957de01be481c63e1"
VERSION = "5572c6c467e6b73b"


def load(path):
    return json.loads(path.read_bytes())


def save(path, value):
    path.write_bytes((json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode())


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def now():
    return datetime.now(timezone.utc).isoformat()


def git(*args, repo=R):
    return subprocess.check_output(
        ["git", "--no-pager", "-C", str(repo), *args], encoding="utf-8").strip()


def replace_progress(current, updated, suffix):
    assert load(C / "progress.json") == current
    temp = C / f"progress.json.816-{suffix}.tmp"
    assert not temp.exists()
    save(temp, updated)
    assert load(temp) == updated
    os.replace(temp, C / "progress.json")
    assert load(C / "progress.json") == updated


def start():
    assert git("rev-parse", "HEAD") == HEAD
    assert git("rev-parse", "origin/main") == MAIN
    for repo in [R, A]:
        assert not git("status", "--porcelain", "--untracked-files=all", repo=repo)
        assert git("log", "-1", "--format=%G?", repo=repo) == "G"
    assert git("rev-parse", "HEAD", repo=A) == APP
    before = (C / "progress.json").read_bytes()
    p = json.loads(before)
    assert (p["checkpoint"], p["status"], p["batch"]) == (815, "continue", "105")
    request = (L / "request.txt").read_bytes()
    text = request.decode("utf-8-sig")
    marker = "Current execution checkpoint (complete historical state remains at checkpointHistory paths):"
    checkpoint = json.loads(text.split(marker, 1)[1])
    assert checkpoint["checkpoint"] == 815
    assert checkpoint["execution815CoordinatorCheckpoint"]["savedCommit"] == HEAD
    assert not (L / "progress-before-816.json").exists()
    (L / "progress-before-816.json").write_bytes(before)
    state = {
        "execution": 816, "batch": "105", "startedAt": now(),
        "startingHead": HEAD, "androidHead": APP, "freshOriginMain": MAIN,
        "scope": "SAME105 bounded final acceptance reconciliation and content checks; signed LOCAL evidence only. No runtime edit, reviewer/native/HOST rerun, publication,106 or second runner.",
        "request": {
            "sha256": sha(request), "bytes": len(request), "lines": len(text.splitlines()),
            "completeFileLoadedAndCheckpointParsed": True,
            "limits": "Entire request loaded/decoded and embedded checkpoint parsed; operative contract, complete approved issue and final815 directly inspected. Historical middle parsed, not freshly semantically re-reviewed."
        },
        "runnerPreflight": load(L / "preflight-816.json"),
        "artifactPathPreflight": "Approved committed source packets and control helpers only; optional historical-session recipes not accessed.",
        "parentLockTouched": False, "actualNewPermissionDenials": [],
        "status": "final-acceptance-reconciliation-in-progress"
    }
    assert "execution816StartingState" not in p
    updated = copy.deepcopy(p)
    updated["execution816StartingState"] = state
    assert all(updated[k] == v for k, v in p.items())
    save(L / "starting-state-816.json", state)
    replace_progress(p, updated, "start")
    print("Starting scope persisted; all original historical values preserved.")


def runtime():
    sys.path.insert(0, str(R / "tools"))
    from build_manifest import build_manifest, sha256
    manifest = load(R / "manifest.json")
    assert manifest == build_manifest(R)
    assert manifest["contentVersion"] == VERSION
    count = 0
    for section, entries in manifest.items():
        if not isinstance(entries, dict):
            continue
        for name, expected in entries.items():
            path = R / Path(*name.split("/"))
            actual = sha(path.read_bytes()) if section in {
                "images", "audio", "listeningTaskAudio", "listeningTaskImages"} else sha256(path)
            assert actual == expected, name
            count += 1
    assert count == 8469
    assert not git("diff", TEACHING, "--", "kanji", "words", "articles", "strokes", "manifest.json", "tools")
    return {"contentVersion": VERSION, "runtimeHashesVerified": count,
            "manifestSha256": sha((R / "manifest.json").read_bytes()),
            "unchangedSinceTeaching": TEACHING}


def audit():
    assert git("rev-parse", "HEAD") == HEAD
    verified_runtime = runtime()
    directory = R / "docs" / "n1-reviews" / "batch-105-rendered-815"
    for row in load(directory / "artifact-index.json"):
        assert sha((directory / Path(row["file"])).read_bytes()) == row["sha256"], row["file"]
    payloads = load(directory / "image-payload-index.json")
    archives = load(directory / "archive-integrity.json")
    events_by_label = {}
    restored_by_name = {}
    for row in archives:
        packed = (directory / row["archive"]).read_bytes()
        assert sha(packed) == row["archiveSha256"]
        raw = gzip.decompress(packed)
        if "factoredSha256" in row:
            assert sha(raw) == row["factoredSha256"]
            for item in payloads:
                image = (directory / item["file"]).read_bytes()
                assert sha(image) == item["sha256"]
                raw = raw.replace(
                    ("__N1_IMAGE_PAYLOAD_SHA256_" + item["sha256"] + "__").encode(),
                    base64.b64encode(image))
            label = row["archive"].removesuffix(".jsonl.factored.gz")
            events_by_label[label] = [json.loads(line) for line in raw.splitlines()]
        assert len(raw) == row["rawBytes"] and sha(raw) == row["rawSha256"]
        restored_by_name[row["archive"]] = raw
    order = load(directory / "process-order.json")
    process_checks = []
    resources = json.loads(restored_by_name["resources.json.gz"])
    resource_paths = {row["path"] for row in resources}
    for index, row in enumerate(order):
        label = row["label"]
        e = json.loads(restored_by_name[f"{label}-execution.json.gz"])
        assert row["exitCode"] == 0 and row["processExited"]
        assert e["allAssignedTextReturned"] and not e["unfinishedTools"] and not e["missingImages"]
        assert e["actualModels"] == row["actualModels"]
        assert e["usageCurrentModel"] == e["actualModels"][0]
        assert e["multiToolResponseCount"] == 0 and not e["observedToolOverlaps"]
        assert all(t["success"] and t["name"] == "view" for t in e["toolCalls"])
        complete = {call["arguments"]["path"] for call in e["toolCalls"]
                    if call["arguments"]["path"] in resource_paths
                    and "view_range" not in call["arguments"]
                    and call["exactRequestedTextContainedInResult"]}
        assert complete == resource_paths and len(complete) == 6
        assert len(e["successfulImageOpens"]) == 22
        assert len({x["path"] for x in e["successfulImageOpens"]}) == 22
        assert all(p["pngDimensions"] == [900, 2000]
                   and p["originalPngDimensions"] == [1080, 2400]
                   and not p["equalsOriginalBytes"]
                   for image in e["successfulImageOpens"] for p in image["payloads"])
        if index:
            assert datetime.fromisoformat(order[index-1]["completedAt"]) < datetime.fromisoformat(row["startedAt"])
        assert len(e["toolCalls"]) == (35 if label == "claude" else 28)
        assert len(e["compactions"]) == (2 if label == "claude" else 1)
        assert not e["warnings"]
        report = restored_by_name[f"{label}.md.gz"]
        assert sha(report) == e["reportSha256"]
        process_checks.append({
            "label": label, "actualModels": e["actualModels"], "sessionId": row["sessionId"],
            "terminalExitCode": row["exitCode"], "processExitedAsRecorded": row["processExited"],
            "sixCompleteForcedReadsExactlyReturned": True, "toolCalls": len(e["toolCalls"]),
            "multiToolResponseCount": e["multiToolResponseCount"],
            "observedToolOverlaps": e["observedToolOverlaps"],
            "successfulImageCalls": 22, "compactions": len(e["compactions"]),
            "warnings": len(e["warnings"]), "eventCount": len(events_by_label[label]),
            "reportSha256": sha(report),
            "limits": "Fresh mechanical reconstruction of archived events, not fresh reviewer comprehension, every-request visual retention or native execution."
        })
    host = load(R / "docs" / "n1-sources" / "execution-811.json")
    assert host["totalTests"] == 5 and host["failures"] == host["errors"] == host["skipped"] == 0
    host_checks = []
    for test in host["tests"]:
        raw = (R / Path(test["archive"])).read_bytes()
        assert sha(raw) == test["sha256"]
        suite = ET.fromstring(raw)
        assert int(suite.attrib["tests"]) == test["tests"]
        assert all(int(suite.attrib[k]) == 0 for k in ["failures", "errors", "skipped"])
        host_checks.append({"name": test["name"], "tests": test["tests"], "sha256": sha(raw)})
    native = load(R / "docs" / "n1-sources" / "execution-813.json")
    assert native["nativeAttempt"]["passed"] and native["nativeAttempt"]["terminalSuccessCases"] == 2
    assert native["nativeAttempt"]["ownedHelperStopped"] and native["nativeAttempt"]["ownedQemuStopped"]
    assert native["runtime"]["contentVersion"] == VERSION
    assert native["runtime"]["manifestSha256"] == verified_runtime["manifestSha256"]
    index = load(R / "docs" / "n1-reviews" / "batch-105-native-813" / "artifact-index.json")
    for row in index:
        packed = (R / "docs" / "n1-reviews" / "batch-105-native-813" / Path(row["file"])).read_bytes()
        assert sha(packed) == row["storedSha256"], row["file"]
        raw = gzip.decompress(packed) if row["file"].endswith(".gz") else packed
        assert len(raw) == row["sourceBytes"] and sha(raw) == row["sourceSha256"], row["file"]
    D.mkdir()
    save(D / "integrity-audit.json", {
        "schemaVersion": 1, "execution": 816, "recordedAt": now(), "snapshot": HEAD,
        "losslessRenderedArchiveRowsReconstructed": len(archives),
        "allOriginalRawBytesAndHashesVerified": True, "processChecks": process_checks,
        "hostTests": host_checks, "nativeArtifactRowsVerified": len(index),
        "nativeTerminalSuccessCasesInherited": 2, "freshNativeOrHostOrReviewerRuns": 0,
        **verified_runtime,
        "limits": "Hash reconstruction proves bytes/access, not comprehension. Original range, rendition, compaction, source and historical limits remain intact."
    })
    print(json.dumps({"runtimeHashes": 8469, "losslessArchiveRows": len(archives),
                      "nativeArtifactRows": len(index), "hostTests": 5,
                      "originalFamilyReports": len(process_checks)}))


def deep_audit():
    native_dir = R / "docs" / "n1-reviews" / "batch-105-native-813"
    terminal = gzip.decompress((native_dir / "native" / "instrumentation.txt.gz").read_bytes()).decode()
    assert terminal.count("INSTRUMENTATION_STATUS_CODE: 0") == 2
    assert terminal.count("INSTRUMENTATION_STATUS_CODE: 1") == 2
    assert "OK (2 tests)" in terminal and "INSTRUMENTATION_CODE: -1" in terminal
    route = json.loads(gzip.decompress(
        (native_dir / "native" / "n1-105-article-route.json.gz").read_bytes()))
    assert route["passed"] and route["archiveRequests"] == 1
    assert [route[k] for k in ["importedKanji", "importedWords", "n1Cards", "problems"]] == [1128, 5079, 137, 0]
    assert route["contentVersion"] == VERSION
    assert len(route["productionBuilderN1AndAllExactChoices"]) == 64
    assert len(route["kanjiDirectGuardChecks"]) == 896
    assert len(route["nontransitiveNeighborChecks"]) == 192
    assert len(route["preservedWordGuardChecks"]) == 384
    assert route["fullOnyomi"] == ["ケイ"] and route["fullKunyomi"] == ["つよ.い"]
    assert route["quizOnKeys"] == ["けい"] and route["quizKunKeys"] == []
    assert route["fullProjectionQuizOnyomi"] == ["ケイ"] and route["fullProjectionQuizKunyomi"] == []
    assert route["mappedReciprocalPairs"] == 1 and route["directedLinkTransitions"] == 2
    assert route["activatedBaselinePairs"] == route["changedReusedArticles"] == 0
    assert route["soleCuratedOnPersistedGoodAndDone"] and route["reciprocalLinkAndSystemBack"]
    assert route["touchInjectedReferenceStrokes"] == 9
    assert route["drawingTraceThenRecall"] and route["drawingGradeRecordedOnNext"] and route["offline"]
    assert route["actualN1CuratedAvailable"] == 3 and route["actualN1FallbackOptions"] == 0
    directory = R / "docs" / "n1-reviews" / "batch-105-rendered-815"
    scope = json.loads(gzip.decompress((directory / "image-scope.json.gz").read_bytes()))
    represented = set()
    for image in scope["images"]:
        original = Path(image["path"])
        original.relative_to(native_dir)
        raw = original.read_bytes()
        assert sha(raw) == image["sha256"] and len(raw) == image["bytes"]
        for path in [image["path"], *image["byteIdenticalAliases"]]:
            path = Path(path)
            path.relative_to(native_dir)
            assert path.read_bytes() == raw and path not in represented
            represented.add(path)
    assert len(represented) == scope["originalNativePngPaths"] == 36
    assert len(scope["images"]) == scope["distinctByteHashes"] == 22
    source = load(R / "docs" / "n1-sources" / "execution-814.json")
    for row in source["sourcePacketArtifacts"]:
        path = R / "docs" / "n1-reviews" / "batch-105-native-labels-814" / Path(row["file"])
        assert len(path.read_bytes()) == row["bytes"] and sha(path.read_bytes()) == row["sha256"]
    selection = source["sourceSelection"]
    assert selection["fullCharacterRecords"] == 5 and selection["completeFamilies"] == 23
    assert selection["completeArticleBodies"] == 10 and selection["sourceHashesVerified"]
    audit_path = D / "integrity-audit.json"
    result = load(audit_path)
    result.update({
        "nativeRawTerminalCase0Count": 2, "nativeActualRouteAssertionsVerified": True,
        "nativePngAliasPathsVerified": 36, "distinctNativePngByteHashes": 22,
        "supplement814ArtifactHashesVerified": len(source["sourcePacketArtifacts"]),
        "supplement814CompleteCharacterRecords": 5, "supplement814CompleteLexicalFamilies": 23,
        "supplement814CompleteArticleBodies": 10,
        "historicalSemanticPendingFlagsPreserved": True,
        "pendingFlagDisposition": "813 meaningFallbackNeedsSemanticReview=true remains a historical gate, not a claim that default N1 used fallback. Source814 plus both original-family815 confirmations supply the finite semantic evidence; final816 disposition closes only that bounded gate."
    })
    save(audit_path, result)
    print("Both raw terminal case0 results, actual route assertions,36 source-image aliases and814 packet hashes verified.")


def content_audit():
    sys.path.insert(0, str(R / "tools"))
    from audit_n1_batch import lexical_pair, runtime_delta
    from audit_n1_pilot import metadata, offered_keys, quiz_readings
    from build_manifest import sha256
    from generate_strokes import convert

    snapshot = load(R / "docs" / "n1-source-snapshot.json")
    for name, row in snapshot["inputs"].items():
        raw = (C / "inputs" / name).read_bytes()
        assert sha(raw) == row["sha256"] and len(raw) == row["bytes"]
    source = R / "docs" / "n1-sources"
    membership = load(source / "batch-105-membership.json")
    ledger = load(source / "batch-105-progress.json")
    assert membership["membership"] == ledger["membership"] == ["勁"]
    assert membership["baseCommit"] == ledger["baseCommit"] == MAIN
    assert membership["members"] == [{"kanji": "勁", "sourceRow": 116}]
    index = load(source / "source-index.json")
    row = next(r for r in index if r["kanji"] == "勁")
    assert row["sourceRow"] == 116
    assert (source / "source-index.json").read_text(encoding="utf-8") == subprocess.check_output(
        ["git", "-C", str(R), "show", MAIN + ":docs/n1-sources/source-index.json"]).decode()
    before = json.loads(git("show", MAIN + ":manifest.json"))
    current = load(R / "manifest.json")
    additions = ["kanji/勁.md", "strokes/勁.json", "words/雄勁.md"]
    runtime_delta(before, current, additions, [])
    for section, entries in before.items():
        if isinstance(entries, dict):
            assert all(current[section][name] == digest for name, digest in entries.items())
    k = metadata(R, "kanji/勁.md")
    w = metadata(R, "words/雄勁.md")
    for field in ["kanji", "strokes", "radical", "radicalNumber", "onyomi", "kunyomi"]:
        assert k[field] == row["metadata"][field]
    assert k["title"] == "strong; taut" and k["jlpt"] == 1
    assert k["tags"] == ["jlpt-n1", "grade-9", "structure-unclassified"]
    assert "phonetic" not in k
    assert k["quizOnyomi"] == ["ケイ"] and k["quizKunyomi"] == []
    assert offered_keys(quiz_readings(k, "onyomi")) == ["けい"]
    assert offered_keys(quiz_readings(k, "kunyomi")) == []
    assert k["distractors"] == ["功", "劾", "剖"]
    assert k["quiz_exclusions"] == ["強", "剛", "力", "勢"]
    assert [metadata(R, f"kanji/{c}.md")["title"] for c in k["distractors"]] == [
        "merit; achievement", "censure; impeach", "dissect; split open"]
    assert all(metadata(R, f"kanji/{c}.md")["jlpt"] == 1 for c in k["distractors"])
    assert w["word"] == "雄勁" and w["reading"] == "ゆうけい"
    assert w["kanji"] == ["雄", "勁"] and "jlpt" not in w
    assert w["quiz_exclusions"] == ["強い", "強力", "力強い", "剛健", "力", "勢い"]
    mapped = sorted(p.name for p in (R / "words").glob("*.md")
                    if "勁" in metadata(R, "words/" + p.name).get("kanji", []))
    assert mapped == ["雄勁.md"]
    candidates = load(source / "baseline-word-candidates.json")
    assert not [r for r in candidates if r["kanji"] == "勁"]
    kt = (R / "kanji" / "勁.md").read_text(encoding="utf-8")
    wt = (R / "words" / "雄勁.md").read_text(encoding="utf-8")
    assert "| ケイ | on | [雄勁](../words/雄勁.md) ゆうけい" in kt
    assert "| つよ.い | kun | 勁い (つよい)" in kt and "search-only spelling" in kt
    assert "[勁](../kanji/勁.md) (ケイ)" in wt
    assert not (R / "kanji" / "雄.md").exists()
    families = ET.parse(source / "batch-105-jmdict.xml").getroot().findall("entry")
    assert len(families) == 9
    family = next(e for e in families if e.findtext("ent_seq") == "1839950")
    assert lexical_pair(family, "雄勁", "ゆうけい")
    character = ET.parse(source / "batch-105-kanjidic2.xml").getroot().find("character")
    assert character.findtext("literal") == "勁"
    assert [e.text for e in character.findall(".//reading[@r_type='ja_on']")] == k["onyomi"]
    assert [e.text for e in character.findall(".//reading[@r_type='ja_kun']")] == k["kunyomi"]
    strokes = load(R / "strokes" / "勁.json")
    assert strokes == convert("勁", (source / "batch-105-kanjivg.svg").read_text(encoding="utf-8"))
    assert strokes["sourceRevision"] == "70a0b7ae0c18ceb5cb358274b029cce0234a43bc"
    assert sha256(R / "tools" / "generate_strokes.py") == "22677a42589c5a8e21c2f1cf25ada71ad4987684d8309820ea70b1354fe06625"
    result = {
        "schemaVersion": 1, "execution": 816, "batch": "105", "baseCommit": MAIN,
        "frozenInputHashesVerified": len(snapshot["inputs"]), "sourceRow": 116,
        "draftKanji": 1, "newWords": 1, "changedReusedArticles": 0,
        "requiredReciprocalPairs": 1, "directedLinksVerified": 2, "activatedBaselinePairs": 0,
        "fullReadingDispositions": 2, "curatedOfferedKeys": ["けい"],
        "sourceOnlyOfferedKeys": [], "exactPinnedGeometryRegenerated": True,
        "baselineRuntimeHashesPreserved": sum(len(e) for e in before.values() if isinstance(e, dict)),
        "exactBaseRuntimePreservedOutsideRecordedChanges": True, **runtime(),
        "genericAuditDiagnostic": "Original816 tools/audit_n1_batch.py failed KeyError:supportMappings before content auditing. Batch105 uses a newer source-plan/draft ledger without that legacy field. Original failure retained; no tool/teaching/ledger fabrication to pass it. This named current816 audit reuses tested runtime_delta/lexical_pair/metadata/offered-key helpers and exact committed source-plan/draft evidence, and explicitly checks baseline, membership, complete reading lists, linked selected row, search-only disposition, all mapped/activated pairs, guards and pinned geometry.",
        "limits": "Mechanical current-tree audit, not a new linguistic, native or independent review."
    }
    save(D / "content-audit.json", result)
    print(json.dumps(result, ensure_ascii=False, indent=2))


def seal():
    assert git("rev-parse", "HEAD") == HEAD and git("rev-parse", "origin/main") == MAIN
    subprocess.run(["git", "-C", str(R), "merge-base", "--is-ancestor", MAIN, HEAD], check=True)
    initial = load(L / "checks-816.json")
    completion = load(L / "checks-816-completion.json")
    assert [r["name"] for r in initial] == ["validate", "manifest", "manifest-diff", "tests", "batch-audit"]
    assert all(r["exitCode"] == 0 for r in initial[:-1]) and initial[-1]["exitCode"] == 1
    assert [r["name"] for r in completion] == ["batch-audit-current", "vocabulary", "budget", "whitespace"]
    assert all(r["exitCode"] == 0 for r in completion)
    assert "KeyError: 'supportMappings'" in (L / "816-batch-audit.txt").read_text(encoding="utf-8-sig")
    assert re.search(r"Ran 377 tests in [\d.]+s", (L / "816-tests.txt").read_text(encoding="utf-8-sig"))
    assert "\nOK\n" in (L / "816-tests.txt").read_text(encoding="utf-8-sig")
    assert (L / "816-validate.txt").read_text(encoding="utf-8-sig").rstrip().endswith("0 error(s)")
    archived = []
    for row in initial + completion:
        raw = Path(row["output"]).read_bytes()
        target = D / (row["name"] + ".txt.gz")
        assert not target.exists()
        packed = gzip.compress(raw, mtime=0)
        target.write_bytes(packed)
        assert gzip.decompress(packed) == raw
        archived.append({**row, "archive": target.name, "rawSha256": sha(raw), "archiveSha256": sha(packed)})
    current_audit = load(D / "content-audit.json")
    assert current_audit["baselineRuntimeHashesPreserved"] == 8466
    integrity = load(D / "integrity-audit.json")
    assert integrity["allOriginalRawBytesAndHashesVerified"] and integrity["nativeActualRouteAssertionsVerified"]
    decision = load(D / "disposition.json")["acceptanceDecision"]
    assert not decision["consequentialUnresolvedTeachingDefects"] and decision["independentRenderedReviewClosed"]
    ledger_path = R / "docs" / "n1-sources" / "batch-105-progress.json"
    ledger = load(ledger_path)
    assert ledger["status"] == "textually-reconciled-awaiting-qualified-host-and-native-acceptance"
    assert ledger["reviewClosed"] == ledger["published"] == []
    ledger["historicalBefore816Reconciliation"] = {
        key: copy.deepcopy(ledger[key]) for key in ["status", "nextAction", "limits"]}
    ledger.update({
        "status": "bounded-rendered-native-reconciliation-closed-publication-pending",
        "independentRenderedReviewClosed": True, "nativeRouteExecutionAccepted": True,
        "finiteSampleSemanticAcceptance": "192 exact target-relative sets and live default only",
        "finalReconciliation": "../n1-reviews/batch-105-reconciliation-816/disposition.json",
        "fullBatchAcceptanceComplete": False, "runtimeAccepted": False,
        "limits": [
            "Textual810, HOST811, native813, source814 and original-family rendered815 reconciled816; no fresh native/HOST/reviewer run.",
            "Both family tool executions serial; Claude redundant ranged partial returns, TWO/GPTONE compactions and delivered900x2000 limits preserved.",
            "Low-confidence future-pool hypotheses remain partially resolved/nondefects; original810 withdrawn dispositions remain historical.",
            "Original pixels/equal comprehension/fallback-face/every-request retention/phone remain UNVERIFIED.",
            "Current-schema named816 audit passed; generic legacy-audit KeyError:supportMappings preserved, no fabricated ledger/tool changes.",
            "Current-main signed acceptance/source-row/inventory/publication record, owner fast-forward, CI and exact immutable ZIP gates remain mandatory.",
            "No reviewed/published row credit yet. Physical-phone/general-release and whole-set acceptance outstanding."
        ],
        "nextAction": "SAME105 signed acceptance/source-row/inventory/publication-ledger reconciliation on unchanged teaching, fresh current main/nonrewriting merge if advanced, regenerate/revalidate changed combined tree and independently confirm changed substantive teaching. Then normal signed owner fast-forward, terminalgreenCI and EVERY exact immutableZIP runtimehash/per-file-media-path/18000entries42MiBcompressed80MiBinflated56MiBretained acceptance. Inherit unchanged HOST811/native813/source814/original-family815 and final816 without rerun absent consequential change. Preserve all original hypotheses/optional/readdepth/range/compaction/rendition/source/permission/OOM/ANR/routing/phone limits. No106 or delivery credit until verified publication/checkpoint. CompatibleAndroid125/132 required; oldclientsignore. Parent lock untouched; approvedcontrol/committedsources only. Project incomplete."
    })
    save(ledger_path, ledger)
    evidence = {
        "schemaVersion": 1, "execution": 816, "batch": "105", "recordedAt": now(),
        "stage": "bounded-rendered-native-reconciliation-closed-awaiting-signed-acceptance-record",
        "startingState": load(L / "starting-state-816.json"), "sourceSnapshot": HEAD,
        "unchangedTeachingSnapshot": TEACHING, "qualifiedAndroidHead": APP,
        "finalDisposition": str((D / "disposition.json").relative_to(R)),
        "integrityAudit": integrity, "currentContentAudit": current_audit, "checks": archived,
        "pythonTestsPassed": 377, "validatorErrors": 0, "manifestRegenerated": True,
        "manifestChanged": False, **runtime(),
        "independentRenderedReviewClosed": True,
        "independentRenderedReviewClosedScope": decision["independentRenderedReviewClosedScope"],
        "finiteSampleSemanticAcceptance": decision["finiteSampleSemanticAcceptance"],
        "nativeRouteExecutionAccepted": True, "nonSkippedHostAcceptanceInheritedFrom": 811,
        "nativeEvidenceExecution": 813, "sourceSupplementExecution": 814,
        "originalFamilyRenderedConfirmationExecution": 815,
        "newReviewerProcesses": 0, "freshNativeOrHostExecuted": False, "newImageInspection": False,
        "runtimeChanged": False, "runtimeAccepted": False, "runtimePublished": False,
        "fullBatchAcceptanceComplete": False, "reviewClosed": [], "published": [],
        "parentLockTouched": False, "optionalHistoricalHelpersAccessed": False,
        "actualNewPermissionDenials": [], "publishedAdditions": 131, "remainingAdditions": 1097,
        "lastPublishedCommit": MAIN, "physicalPhoneAcceptance": "outstanding",
        "generalReleaseAcceptance": "outstanding", "wholeSetAcceptance": "outstanding",
        "wholeProjectComplete": False, "nextBatchStarted": False,
        "freshOriginMain": MAIN, "mainAlreadyAncestor": True, "mergeNeededAtThisCheckpoint": False,
        "genericAuditFailure": "Original failed selector and traceback preserved; named816 current-schema audit passed without changing tools, source claims or teaching. Subsequent selectors completed without rerunning successful377tests.",
        "coordinatorReadDiagnostic": "Three guessed optional documentation names did not exist; approved directory inventories identified the actual committed names. No required source/evidence absent, denial or historical-session access.",
        "limits": load(D / "disposition.json")["limits"],
        "nextAction": ledger["nextAction"]
    }
    save(R / "docs" / "n1-sources" / "execution-816.json", evidence)
    for path in [Path(__file__), C / "preflight-816.ps1", C / "checks-batch-105-816.ps1",
                 C / "checks-batch-105-816-completion.ps1", C / "post-reconciliation-816.ps1",
                 C / "batch-105-reconciliation-816-issue-template.txt", L / "preflight-816.json"]:
        target = D / (path.name + ".gz")
        assert not target.exists()
        target.write_bytes(gzip.compress(path.read_bytes(), mtime=0))
    save(D / "artifact-index.json", [
        {"file": str(p.relative_to(D)), "sha256": sha(p.read_bytes()), "bytes": p.stat().st_size}
        for p in sorted(D.iterdir()) if p.is_file()])
    print("Final bounded reconciliation sealed; full signed batch/publication acceptance still pending.")


def finish():
    before = load(L / "progress-before-816.json")
    current = load(C / "progress.json")
    assert all(current[k] == v for k, v in before.items())
    assert (current["checkpoint"], current["status"], current["batch"]) == (815, "continue", "105")
    head = git("rev-parse", "HEAD")
    assert git("rev-parse", "HEAD^") == HEAD and git("log", "-1", "--format=%G?") == "G"
    for repo in [R, A]:
        assert not git("status", "--porcelain", "--untracked-files=all", repo=repo)
    assert git("rev-parse", "HEAD", repo=A) == APP and git("log", "-1", "--format=%G?", repo=A) == "G"
    assert git("rev-parse", "origin/main") == MAIN
    paths = git("diff", "--name-only", HEAD, head).splitlines()
    assert paths and all(p.startswith("docs/n1-reviews/batch-105-reconciliation-816/") or
                         p in {"docs/n1-sources/batch-105-progress.json", "docs/n1-sources/execution-816.json"}
                         for p in paths)
    for row in load(D / "artifact-index.json"):
        path = str((D / row["file"]).relative_to(R)).replace("\\", "/")
        raw = subprocess.check_output(["git", "-C", str(R), "show", head + ":" + path])
        assert sha(raw) == row["sha256"]
    posted, reread = load(L / "issue-816-posted.json"), load(L / "issue-816-reread.json")
    body = (C / "batch-105-reconciliation-816-issue-body.txt").read_bytes()
    assert posted["author"] == reread["user"]["login"] == "stop-cran"
    assert sha(body) == posted["bodySha256"] and body.decode() == reread["body"]
    assert posted["url"] == reread["html_url"]
    role = load(L / "preflight-816-before-issue.json")
    assert role["contentHead"] == head and not role["lockTouched"]
    next_action = (
        f"SAME105 checkpoint816 signed LOCAL final-reconciliation HEAD{head}, qualifiedAndroid{APP}. "
        "Read docs/n1-sources/execution-816.json and docs/n1-reviews/batch-105-reconciliation-816/disposition.json. "
        "Bounded independent rendered/native/finite-semantic reconciliation CLOSED: both complete original810 "
        "initial and815 ORIGINAL-session family reports retained; no consequential in-scope defect established. "
        "AllthreefacetsCLEAN for勁/ONEsupport雄勁;192exact target-relative sets/live default ONLY. "
        "ClaudeLOWconfidencefuturepool活気/もりもり PARTIALLYRESOLVED/nondefects; GPTnoactionablehypothesis; "
        "original810withdrawnhistorypreserved/noforcedagreement/newguard. Delivered900x2000/fourfonts-default/"
        "14Han/whole雄勁 including勁巠刂 accepted; originalpixels/equalcomprehension/fallbackface/every-request"
        "retention/phone UNVERIFIED. Bothserialtools/zerooverlap; Claude35calls/sevenredundantboundaryattempts/"
        "threepartialrangedreturns versusSIXexactfullforcedreads;GPT28/noextras;ClaudeTWO/GPTONEcompactions "
        "preserved. Missingwordheader/no nativewordquiz/partialtable/duplicateviewports/sharedUI limits retained. "
        "Fresh all29losslessarchive rows/rawstdout+reporthashes/55nativeartifacts/36imagealiases/2rawterminalcase0/"
        "actualContentSyncONCEroute/source814packet verified; inheritedHOST811FIVE0failures/errors/skips and "
        "native813116.338s/896direct192NONTRANSITIVE384wordguards64builderchoices/soleけいdisplayケイgooddone1of1/"
        "nineungradedreferencetouches/modelunavailable/intentionalrecallgrade1/ONEpairTWOdirections/zero"
        "baselinepairs/reusedchanges/Back/offline NOTrepeated. Fullonケイ/kunつよ.い; selectedケイ/[]; legacyつよい "
        "referencevisible. DefaultN1/All/customTHREE功劾剖/ZEROfallback; nativefilteredTWO/ONEfallback, HOSTNONE. "
        "Fresh377PythonPASS/validator0errors/regeneratedmanifestunchanged/vocabulary2122of2431pilot/"
        "originalbudgetguardsPASS. Generictools/audit_n1_batch.py failedKeyError:supportMappings BEFOREauditing "
        "newerbatch105ledger; originalfailurepreserved, namedcurrent816audit reusestestedhelpers/exactsource "
        "and PASSES8466baselinehashes/row116/fullreadings-curation/selectedrow/searchonly/allmappedpairs/"
        "directguards/pinnedgeometry; NOTfabricatedlegacyfields/toolchange/waiver. All8469runtimehashes/"
        "version5572c6c467e6b73b unchanged. NEXT SAME105 signedacceptance/source-row/inventory/publicationrecord; "
        "freshcurrentmain/nonrewritingmergeifadvanced/regeneraterevalidatechangedcombinedtree/independent"
        "changedteachingconfirmation asneeded; thennormal ownerfastforward/remoteSHA/terminalgreenCI/EVERY"
        "exactimmutableGitHubZIPmanifestentryhash/per-file-media-path/18000entries42MiBcompressed80MiBinflated"
        "56MiBretained/verifiedownerissue+historycheckpoint. Fullbatchacceptance/runtimeAccepted/reviewClosed"
        "rowcredit/publication stillPENDING. Freshmain047c2cef alreadyancestor; no unnecessarymerge. No106/"
        "newblindinitials/repeatednativeorimageloop absentconsequentialchange. Freshsignedheads/whollyclean/"
        "liveparentancestry/decodedlauncher/exactsession required;parent13320ownsrunner.lock:NOchildacquire/"
        "delete/unlock/readprobe. Approvedcontrol/committedsources/frozeninputs only, notoptionalhistorical"
        "sessionrecipes; preserve/report/yield actualnewdenial/signinghang/uncertainownership. Noauthoragents/"
        "concurrentheavywork/secondrunner/signingretry/guardincrease/unreviewedpush. QualifiedAPPguard+schema"
        "only NOTlatestmain; compatibleAndroid125/132required/oldclientsignore. All originalsource/review/"
        "process/readdepth/permission/OOM/ANR/routing/phone limits and priorNEXT actions preserved verbatim in "
        "historicalExecution815Before816Reconciliation and execution815CoordinatorCheckpoint. Published131/"
        "1228/remainder1097/lastpublished047c2cef unchanged;supportNOTN1vocabularydelivery. "
        "Physicalphone/generalrelease/whole-setoutstanding;projectincomplete.")
    checkpoint = {
        "schemaVersion": 1, "execution": 816, "checkpoint": 816, "batch": "105",
        "status": "continue", "stage": "batch-105-bounded-reconciliation-closed-awaiting-signed-acceptance-record",
        "savedCommit": head, "signature": "G", "qualifiedAndroidHead": APP, "recordedAt": now(),
        "evidence": "docs/n1-sources/execution-816.json", "issueUpdate": posted["url"],
        "ownerIssueAuthorAndExactBodyVerified": True, "independentRenderedReviewClosed": True,
        "finiteSampleSemanticAcceptance": "192 exact target-relative sets/live default only",
        "nativeRouteExecutionAccepted": True, "fullBatchAcceptanceComplete": False,
        "newReviewerProcesses": 0, "freshNativeOrHostExecuted": False, "newImageInspection": False,
        "pythonTestsPassed": 377, "genericLegacyAuditFailurePreserved": True,
        "namedCurrentSchemaBatchAuditPassed": True, **runtime(),
        "runtimeChanged": False, "manifestChanged": False, "runtimeAccepted": False, "runtimePublished": False,
        "reviewClosed": [], "published": [], "dedicatedWorktreesClean": True,
        "parentLockTouched": False, "optionalHistoricalHelpersAccessed": False,
        "actualNewPermissionDenials": [], "publishedAdditions": 131, "remainingAdditions": 1097,
        "lastPublishedCommit": MAIN, "physicalPhoneAcceptance": "outstanding",
        "generalReleaseAcceptance": "outstanding", "wholeProjectComplete": False,
        "nextBatchStarted": False, "finalRunnerPreflight": role, "nextAction": next_action, "blocker": None,
        "historicalRootKeysCompared": len(before), "allOriginalHistoricalValuesPreserved": True
    }
    updated = copy.deepcopy(current)
    updated["execution816StartingState"]["status"] = "signed-local-bounded-reconciliation-checkpoint-complete"
    updated["historicalExecution815Before816Reconciliation"] = {
        key: copy.deepcopy(before[key]) for key in ["checkpoint", "status", "stage", "nextAction", "blocker"]}
    updated["execution816CoordinatorCheckpoint"] = checkpoint
    allowed = {"checkpoint", "status", "stage", "nextAction", "blocker"}
    for key in allowed:
        updated[key] = checkpoint[key]
    assert all(updated[k] == v for k, v in before.items() if k not in allowed)
    replace_progress(current, updated, "finish")
    save(L / "checkpoint-816-verification.json", checkpoint)
    print(json.dumps({key: checkpoint[key] for key in ["checkpoint", "status", "savedCommit",
                      "issueUpdate", "historicalRootKeysCompared", "allOriginalHistoricalValuesPreserved"]}, indent=2))


if __name__ == "__main__":
    {"start": start, "audit": audit, "deep-audit": deep_audit,
     "content-audit": content_audit, "seal": seal, "finish": finish}[sys.argv[1]]()
