$ErrorActionPreference = 'Stop'
$control = $PSScriptRoot
$log = "$control\logs\51f3511e-4796-42c2-9183-db5ae225a16c"
$runner = [IO.File]::ReadAllText("$control\runner.json") | ConvertFrom-Json
if ($runner.status -ne 'running' -or $runner.pid -ne 13320 -or
    $runner.sessionId -ne '51f3511e-4796-42c2-9183-db5ae225a16c') { throw 'Uncertain parent ownership' }
Set-Location "$control\..\learning-japanese"
if ((git rev-parse HEAD) -ne 'af2ef667321b33786938cf5518f8403454072fda') { throw 'Content head changed' }
if ((git log -1 '--format=%G?') -ne 'G') { throw 'Signature not verified' }
if (git diff --name-only HEAD) { throw 'Unexpected tracked changes before checks' }
$untracked = @(git -c core.quotepath=false ls-files --others --exclude-standard)
if ($untracked | Where-Object { -not $_.StartsWith('docs/n1-reviews/batch-105-reconciliation-816/') }) {
    throw 'Unexpected untracked files'
}
$env:PYTHONUTF8 = '1'
$checks = @(
    @{Name='validate'; Program='python'; Arguments=@('-B', 'tools\validate.py')},
    @{Name='manifest'; Program='python'; Arguments=@('-B', 'tools\build_manifest.py')},
    @{Name='manifest-diff'; Program='git'; Arguments=@('--no-pager', 'diff', '--exit-code', '--', 'manifest.json')},
    @{Name='tests'; Program='python'; Arguments=@('-B', '-m', 'unittest', 'discover', '-s', 'tools', '-p', 'test_*.py')},
    @{Name='batch-audit'; Program='python'; Arguments=@('-B', 'tools\audit_n1_batch.py', '--batch', '105')},
    @{Name='vocabulary'; Program='python'; Arguments=@('-B', 'tools\grammar_vocabulary.py', 'check')},
    @{Name='budget'; Program='python'; Arguments=@('-B', 'tools\check_content_budget.py')},
    @{Name='whitespace'; Program='git'; Arguments=@('--no-pager', 'diff', '--check')}
)
$results = @()
foreach ($check in $checks) {
    $target = "$log\816-$($check.Name).txt"
    if (Test-Path $target) { throw 'Do not overwrite check evidence' }
    $start = [DateTimeOffset]::UtcNow.ToString('o')
    & $check.Program @($check.Arguments) *> $target
    $code = $LASTEXITCODE
    $results += [ordered]@{
        name=$check.Name; program=$check.Program; arguments=$check.Arguments
        startedAt=$start; completedAt=[DateTimeOffset]::UtcNow.ToString('o')
        exitCode=$code; output=$target
    }
    $results | ConvertTo-Json -Depth 6 | Set-Content "$log\checks-816.json" -Encoding utf8NoBOM
    Write-Output "$($check.Name): exit $code"
    if ($code -ne 0) { throw "Required check failed: $($check.Name); preserve and inspect." }
}
