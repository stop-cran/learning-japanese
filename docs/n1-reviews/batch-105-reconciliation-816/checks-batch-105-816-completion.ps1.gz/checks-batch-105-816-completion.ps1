$ErrorActionPreference = 'Stop'
$control = $PSScriptRoot
$log = "$control\logs\51f3511e-4796-42c2-9183-db5ae225a16c"
$env:PYTHONUTF8 = '1'
Set-Location "$control\..\learning-japanese"
if ((git rev-parse HEAD) -ne 'af2ef667321b33786938cf5518f8403454072fda') { throw 'Content head changed' }
$checks = @(
    @{Name='batch-audit-current'; Program='python'; Arguments=@('-B', "$control\reconcile-batch-105-816.py", 'content-audit')},
    @{Name='vocabulary'; Program='python'; Arguments=@('-B', 'tools\grammar_vocabulary.py', 'check')},
    @{Name='budget'; Program='python'; Arguments=@('-B', 'tools\check_content_budget.py')},
    @{Name='whitespace'; Program='git'; Arguments=@('--no-pager', 'diff', '--check')}
)
$results = @()
foreach ($check in $checks) {
    $target = "$log\816-$($check.Name).txt"
    if (Test-Path $target) { throw 'Do not overwrite check evidence' }
    $start = [DateTimeOffset]::UtcNow.ToString('o')
    & $check.Program @($check.Arguments) *> $target
    $code = $LASTEXITCODE
    $results += [ordered]@{
        name=$check.Name; program=$check.Program; arguments=$check.Arguments
        startedAt=$start; completedAt=[DateTimeOffset]::UtcNow.ToString('o')
        exitCode=$code; output=$target
    }
    $results | ConvertTo-Json -Depth 6 | Set-Content "$log\checks-816-completion.json" -Encoding utf8NoBOM
    Write-Output "$($check.Name): exit $code"
    if ($code -ne 0) { throw "Required check failed: $($check.Name); preserve and inspect." }
}
