$ErrorActionPreference = 'Stop'
$control = $PSScriptRoot
$log = "$control\logs\51f3511e-4796-42c2-9183-db5ae225a16c"
$content = "$control\..\learning-japanese"
$bodyPath = "$control\batch-105-reconciliation-816-issue-body.txt"
if ((Test-Path "$log\issue-816-posted.json") -or (Test-Path $bodyPath)) { throw 'Do not duplicate issue update' }
$head = git -C $content rev-parse HEAD
if ($LASTEXITCODE -ne 0) { throw 'HEAD lookup failed' }
& "$control\preflight-816.ps1" -ReceiptName 'preflight-816-before-issue.json' -ExpectedContentHead $head
if ((git -C $content rev-parse 'HEAD^') -ne 'af2ef667321b33786938cf5518f8403454072fda') {
    throw 'Wrong evidence ancestry'
}
$e = [IO.File]::ReadAllText("$content\docs\n1-sources\execution-816.json") | ConvertFrom-Json
if ($e.runtimeChanged -or $e.runtimePublished -or $e.fullBatchAcceptanceComplete -or
    -not $e.independentRenderedReviewClosed -or $e.runtimeHashesVerified -ne 8469) {
    throw 'Reconciliation evidence mismatch'
}
$template = [IO.File]::ReadAllText("$control\batch-105-reconciliation-816-issue-template.txt")
[IO.File]::WriteAllText($bodyPath, $template.Replace('{HEAD}', $head), [Text.UTF8Encoding]::new($false))
$priorToken = $env:GH_TOKEN
try {
    $env:GH_TOKEN = (gh auth token --user stop-cran)
    if ($LASTEXITCODE -ne 0 -or -not $env:GH_TOKEN) { throw 'Owner credential unavailable' }
    $login = gh api user --jq .login
    if ($LASTEXITCODE -ne 0 -or $login -cne 'stop-cran') { throw 'Wrong command-scoped identity' }
    $url = gh issue comment 60 --repo stop-cran/learning-japanese --body-file $bodyPath
    if ($LASTEXITCODE -ne 0) { throw 'Issue update failed' }
    $url = $url.Trim()
    @{ url=$url; author=$login; bodySha256=(Get-FileHash $bodyPath).Hash.ToLowerInvariant() } |
        ConvertTo-Json | Set-Content "$log\issue-816-posted.json" -Encoding utf8NoBOM
    if ($url -notmatch '#issuecomment-(\d+)$') { throw 'Unexpected comment URL; preserve receipt' }
    $raw = gh api "repos/stop-cran/learning-japanese/issues/comments/$($Matches[1])"
    if ($LASTEXITCODE -ne 0) { throw 'Comment reread failed' }
    $raw | Set-Content "$log\issue-816-reread.json" -Encoding utf8NoBOM
    $comment = $raw | ConvertFrom-Json
    if ($comment.user.login -cne 'stop-cran' -or
        $comment.body -cne [IO.File]::ReadAllText($bodyPath) -or $comment.html_url -cne $url) {
        throw 'Exact owner/body verification failed'
    }
    Write-Output "Verified owner update: $url"
} finally {
    $env:GH_TOKEN = $priorToken
}
