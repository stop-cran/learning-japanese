from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import gzip
import hashlib
import json
import re
import shutil
import subprocess
import zipfile

C = Path(__file__).resolve().parent
R, A = C.parent / "learning-japanese", C.parent / "kanji-cards-android"
L = C / "logs" / "1609d87b-eea5-4d77-898f-edae33fa4278"
RAW = C / "artifacts" / "batch-106-native-825"
D = R / "docs" / "n1-reviews" / "batch-106-native-825"
BASE = "f1e1f24e329fa55445a6c9f4f8d2cc8ca4eb9c98"
APP = "bf30cdead8515739bc0e671d57a54b9a3109dd46"


def load(p):
    return json.loads(p.read_text(encoding="utf-8-sig"))


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def save(p, data):
    assert not p.exists(), p
    p.write_text(json.dumps(data, ensure_ascii=True, indent=2) + "\n", encoding="utf-8")
    assert load(p) == data


def git(*args, root=R):
    return subprocess.check_output(["git", "--no-pager", "-C", str(root), *args], encoding="utf-8").strip()


def runtime():
    packet = load(R / "docs" / "n1-reviews" / "batch-106-native-824" / "compiled-packet.json")
    prep, compiled = packet["preparation"], packet["compilation"]
    for path, digest in [(prep["archive"], prep["archiveSha256"]), (prep["fixture"], prep["fixtureSha256"]),
                         (compiled["appApk"], compiled["appApkSha256"]), (compiled["testApk"], compiled["testApkSha256"])]:
        assert sha(Path(path)) == digest, path
    manifest_bytes = (R / "manifest.json").read_bytes()
    assert manifest_bytes == subprocess.check_output(["git", "-C", str(R), "show", prep["contentSnapshot"] + ":manifest.json"])
    m = json.loads(manifest_bytes)
    assert m["contentVersion"] == "89809c00e1676979"
    assert not git("diff", "--name-only", prep["contentSnapshot"], "HEAD", "--",
                   "kanji", "words", "articles", "strokes", "manifest.json", "grammar", "listening",
                   "listening-tasks", "audio", "task-audio", "task-images")
    with zipfile.ZipFile(prep["archive"]) as z:
        names = z.namelist()
        prefix = names[0].split("/")[0] + "/"
        assert len(names) == len(set(names)) == 8494 <= 18000
        assert all(n.startswith(prefix) and "\\" not in n and ".." not in PurePosixPath(n).parts
                   and not n.startswith("/") and not re.search(r"(^|/)[^/]*:", n) for n in names)
        assert not any("/docs/" in n or "/tools/" in n for n in names)
        assert z.read(prefix + "manifest.json") == manifest_bytes
        retained, media, count = len(manifest_bytes), 0, 0
        for section, entries in m.items():
            if not isinstance(entries, dict):
                continue
            for name, digest in entries.items():
                assert len(PurePosixPath(name).parts) == 2 and ".." not in PurePosixPath(name).parts
                assert not name.startswith("/") and "\\" not in name and ":" not in name
                data = z.read(prefix + name)
                local = (R / name).read_bytes()
                binary = section in {"images", "audio", "listeningTaskAudio", "listeningTaskImages"}
                limit = 150 * 1024 if section in {"images", "listeningTaskImages"} else (
                    512 * 1024 if section in {"audio", "listeningTaskAudio"} else 2 * 1024 * 1024)
                assert len(data) <= limit, name
                normalized = data if binary else data.replace(b"\r\n", b"\n")
                assert hashlib.sha256(normalized).hexdigest() == digest, name
                assert normalized == (local if binary else local.replace(b"\r\n", b"\n")), name
                retained += len(data)
                count += 1
                if section in {"listeningTaskAudio", "listeningTaskImages"}:
                    media += len(data)
        inflated = sum(i.file_size for i in z.infolist())
        compressed = Path(prep["archive"]).stat().st_size
        assert count == 8472
        assert retained == 44429769 <= 56 * 1024 * 1024
        assert inflated == 44698107 <= 80 * 1024 * 1024
        assert compressed == 30503741 <= 42 * 1024 * 1024
        assert media == 5893602 <= 20 * 1024 * 1024
    return {"contentVersion": m["contentVersion"], "runtimeHashesVerified": count,
            "manifestSha256": sha(R / "manifest.json"), "runtimeUnchanged": True,
            "manifestEqualsCompiledArchive": True, "archiveContentSnapshot": prep["contentSnapshot"],
            "archiveSha256": prep["archiveSha256"], "zipEntries": len(names), "compressedBytes": compressed,
            "inflatedBytes": inflated, "retainedBytes": retained, "listeningTaskMediaBytes": media,
            "allOriginalBudgetsAndPerFilePathMediaGuardsPassed": True}


def results():
    attempt = load(RAW / "execution.json")
    assert attempt["passed"] and attempt["nativeExecuted"] and attempt["failure"] is None
    assert attempt["terminalSuccessCases"] == 2 and attempt["adbExitCode"] == 0
    assert attempt["ownedHelperStopped"] and attempt["ownedQemuStopped"]
    assert attempt["coordinatorHead"] == BASE and attempt["androidSnapshot"] == APP
    assert attempt["prelaunch"]["connections"] == []
    assert attempt["heapGrowth"] == "192m" and attempt["heapSize"] == "576m"
    assert attempt["network"] == "Active default network: none"
    assert not any(attempt[k] for k in ("parentLockTouched", "guestOrAppHeapChanged", "guardsChanged"))
    raw = (RAW / "instrumentation.txt").read_text(encoding="utf-8-sig")
    assert len(re.findall(r"(?m)^INSTRUMENTATION_STATUS_CODE: 0\s*$", raw)) == 2
    assert "OK (2 tests)" in raw and "Time: 137.131" in raw
    assert not re.search(r"INSTRUMENTATION_STATUS_CODE: -[234]|FAILURES|INSTRUMENTATION_FAILED|ignored|assumptionFailure", raw)
    for cls, method in [("N1Batch106Article824Test", "fullSingleImportImperialDirectGuardsSoleOnTwoPairsNineStrokesOfflineAndBack"),
                        ("N1Batch106Glyph824Test", "imperialOrderAllSeventeenHanAndPreceptComparisonAcrossFourFamilies")]:
        assert f"class=io.github.stopcran.kanji.ui.{cls}" in raw and f"test={method}" in raw
    route = load(RAW / "n1-106-article-route.json")
    assert route["passed"] and route["archiveRequests"] == 1
    assert (route["importedKanji"], route["importedWords"], route["n1Cards"], route["problems"],
            route["acceptedReadingParserEpoch"], route["acceptedMeaningParserEpoch"]) == (1129, 5080, 138, 0, 1, 1)
    assert (route["mappedReciprocalPairs"], route["directedLinkTransitions"],
            route["activatedBaselinePairs"], route["changedReusedArticles"]) == (2, 4, 0, 1)
    assert all(route[k] for k in ("reciprocalLinkAndSystemBack", "meaningQuestionAndFeedback",
                                 "soleCuratedOnPersistedGoodAndDone", "drawingTraceThenRecall",
                                 "drawingGradeRecordedOnNext", "offline"))
    assert route["touchInjectedReferenceStrokes"] == 9
    assert route["fullOnyomi"] == route["fullProjectionOnyomi"] == route["fullProjectionQuizOnyomi"] == ["チョク"]
    assert route["fullKunyomi"] == route["fullProjectionKunyomi"] == ["いまし.める", "みことのり"]
    assert route["fullProjectionQuizKunyomi"] == route["quizKunKeys"] == []
    assert route["quizOnKeys"] == ["ちょく"]
    assert (route["actualN1CuratedAvailable"], route["actualN1FallbackOptions"]) == (0, 3)
    assert route["curatedDistractorLevels"] == {"束": 3, "効": 2, "勤": 3}
    for key, count in {"productionBuilderN1AndAllExactChoices": 64, "kanjiDirectGuardChecks": 448,
                       "nontransitiveNeighborChecks": 32, "preservedWordGuardChecks": 384,
                       "unresolvedNonblockingKunHypothesisPairs": 32}.items():
        assert len(route[key]) == count, key
    for row in route["kanjiDirectGuardChecks"]:
        assert row["target"] in row["options"] and row["excluded"] not in row["options"]
        assert len(row["options"]) == len(set(row["options"]))
    assert all(set(r["options"]) == {r["target"], r["neighbor"]} for r in route["nontransitiveNeighborChecks"])
    for row in route["unresolvedNonblockingKunHypothesisPairs"]:
        assert {o["kanji"] for o in row["options"]} == {"勅", "訓"}
    raster = load(RAW / "n1-106-font-raster.json")
    assert (raster["individualGlyphProbes"], raster["wholeWordRasterProbes"], raster["panels"],
            len(raster["rows"]), raster["sdk"], raster["fontScale"]) == (72, 4, 3, 76, 35, 1)
    assert len({r["character"] for r in raster["rows"] if "character" in r}) == 18
    assert all(r["hasGlyph"] for r in raster["rows"] if "character" in r)
    return attempt, route, raster


def main():
    p = load(C / "progress.json")
    assert (p["checkpoint"], p["status"], p["batch"]) == (824, "continue", "106")
    for root, expected in ((R, BASE), (A, APP)):
        assert git("rev-parse", "HEAD", root=root) == expected
        assert git("log", "-1", "--format=%G?", root=root) == "G"
        assert not git("status", "--porcelain", "--untracked-files=all", root=root)
    verified_runtime = runtime()
    attempt, route, raster = results()
    inspection = load(L / "coordinator-inspection-825.json")
    pngs = sorted(x.name for x in RAW.glob("*.png"))
    assert inspection["totalOriginalPngs"] == len(pngs) == 42
    assert inspection["viewedCount"] == len(set(inspection["viewedOriginalPngs"])) == 19
    assert set(inspection["viewedOriginalPngs"]) <= set(pngs)
    labels = {(o["kanji"], o["title"]) for r in route["productionBuilderN1AndAllExactChoices"] for o in r["options"]}
    labels.update((o["kanji"], o["title"]) for o in route["exactDefaultMeaningOptions"])
    host = {tuple(r) for r in load(R / "docs" / "n1-reviews" / "batch-106-host-823" / "sampled-labels.json")["kanji"]}
    delta = {"nativeUniqueLabelCount": len(labels), "nativeLabels": [list(x) for x in sorted(labels)],
             "newVersusHost823": [list(x) for x in sorted(labels - host)],
             "absentVersusHost823": [list(x) for x in sorted(host - labels)],
             "exactLiveDefault": route["exactDefaultMeaningOptions"],
             "unresolvedHypothesisLabels": route["unresolvedNonblockingKunHypothesisPairs"][0]["options"],
             "limits": "Five new native labels require exact frozen sources/applicable complete comparison bodies before original-family rendered confirmation. Default N1 has ZERO curated and THREE fallback. Mechanics do not prove semantic acceptance; original822 weak precept hypothesis remains unresolved nonblocking."}
    assert len(labels) == 43 and {x[0] for x in labels - host} == set("剰扱獣矛芋")
    D.mkdir(exist_ok=False)
    index = []

    def preserve(source, destination):
        destination.parent.mkdir(exist_ok=True, parents=True)
        assert not destination.exists()
        data = source.read_bytes()
        if destination.suffix == ".gz":
            destination.write_bytes(gzip.compress(data, mtime=0))
            assert gzip.decompress(destination.read_bytes()) == data
        else:
            shutil.copyfile(source, destination)
        index.append({"file": destination.relative_to(D).as_posix(), "sourceBytes": len(data),
                      "sourceSha256": sha(source), "storedSha256": sha(destination)})

    for source in sorted(RAW.iterdir()):
        assert source.is_file()
        preserve(source, D / "native" / (source.name if source.suffix == ".png" else source.name + ".gz"))
    for name in ("preflight-825.ps1", "start-native-825.py", "run-native-825.ps1", "archive-native-825.py",
                 "report-792-correction-825.ps1", "repair_792_history.py"):
        preserve(C / name, D / "receipts" / (name + ".gz"))
    for name in ("preflight-825.json", "preflight-825-native.json", "starting-state-825.json",
                 "correction-owner-reread.json"):
        preserve(L / name, D / "receipts" / (name + ".gz"))
    preserve(R / "docs" / "n1-reviews" / "batch-106-native-824" / "compiled-packet.json",
             D / "receipts" / "824-compiled-packet.json.gz")
    save(D / "artifact-index.json", index)
    save(D / "coordinator-inspection.json", inspection)
    save(D / "sampled-labels-and-host-delta.json", delta)
    evidence = {
        "schemaVersion": 1, "execution": 825, "batch": "106",
        "stage": "native-two-terminal-cases-passed-awaiting-new-label-sources-and-original-family-rendered-confirmations",
        "recordedAt": datetime.now(timezone.utc).isoformat(),
        "startingState": p["execution825StartingState"], "testedContentHead": BASE,
        "qualifiedAndroidHead": APP, "runtime": verified_runtime, "nativeAttempt": attempt,
        "nativeResults": {
            "terminalSuccessCases": 2, "terminalFailureCases": 0, "skipped": 0, "seconds": 137.131,
            "productionContentSyncCalls": 1, "preparseCalls": 0,
            "importedCounts": {"kanji": 1129, "words": 5080, "n1": 138, "problems": 0},
            "acceptedReadingParserEpoch": 1, "acceptedMeaningParserEpoch": 1,
            "directSymmetricGuardChecks": 448, "nontransitiveNeighborChecks": 32,
            "preservedWordGuardChecks": 384, "productionBuilderChoices": 64,
            "unresolvedNonblockingKunHypothesisPairs": 32,
            "individualGlyphProbes": 72, "wholeWordRasterProbes": 4, "fontPanels": 3,
            "scopedHan": 17, "additionalComparisonHan": ["訓"], "explicitFallbackCodepoints": [],
            "nativePngs": 41, "preservedPngs": 42, "environmentPreflightPngs": 1,
            "soleCuratedOnPersistedGoodAndDone": True, "selectedSourceEntries": 1,
            "actualKeys": route["quizOnKeys"], "emptyKunQuestionExpectedNull": True,
            "drawingStrokes": 9, "mappedReciprocalPairs": 2, "directedLinkTransitions": 4,
            "activatedBaselinePairs": 0, "changedReusedArticles": 1, "offline": True, "systemBack": True,
            "actualN1CuratedAvailable": 0, "actualN1FallbackOptions": 3},
        "sampledLabels": delta, "coordinatorInspection": inspection,
        "nativeExecutionComplete": True, "independentReviewersLaunched": 0,
        "independentRenderedReviewClosed": False,
        "newNativeOrdinarySenseFallbackSemanticAcceptance": "UNVERIFIED",
        "runtimeChanged": False, "manifestChanged": False, "runtimeAccepted": False, "runtimePublished": False,
        "reviewClosed": [], "published": [], "nextBatchStarted": False,
        "publishedAdditions": 132, "remainingAdditions": 1096, "lastPublishedCommit": p["lastPublishedCommit"],
        "physicalPhoneAcceptance": "outstanding", "generalReleaseAcceptance": "outstanding",
        "wholeProjectComplete": False, "actualNewPermissionDenials": [],
        "historyCorrection": p["execution792HistoryCorrection"],
        "limits": inspection["limits"] + [
            "Exact prepared824 debug APKs/full archive executed without rebuild. Not an owner-signed release or published immutable GitHub ZIP.",
            "Prior822 textual and823 HOST/source judgments inherited, not repeated; two original-family rendered confirmations and five new-label source supplementation remain.",
            "Combined-current-main integration, all required Python/vocabulary/baseline/link/membership checks, signing, owner fast-forward publication, CI and exact GitHub ZIP checks remain mandatory.",
            "All original historical gates/limits remain preserved verbatim in historicalExecution824Before825Native.nextAction; no retrospective acceptance."
        ],
    }
    save(R / "docs" / "n1-sources" / "execution-825.json", evidence)
    print(json.dumps({"runtimeHashes": 8472, "terminalCases": 2, "pngs": 42, "viewed": 19,
                      "labels": 43, "newLabels": delta["newVersusHost823"], "artifacts": len(index)}, ensure_ascii=True))


if __name__ == "__main__":
    main()
