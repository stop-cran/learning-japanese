#!/usr/bin/env python3
"""Restore the two omitted checkpoint-792 history records under the active runner."""

import copy
import ctypes
import hashlib
import json
import os
import re
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path


CONTROL = Path(__file__).resolve().parent
PROPOSAL_HASH = "e301c6da66376c3987854efdef9592dd104f1a8074681c302d57f792dde10c07"
ROOTS = ("historicalExecution791Before792Sources", "execution792CoordinatorCheckpoint")
CORRECTION = "execution792HistoryCorrection"
OLD_STATUS = "rendered-evidence-preparing"
NEW_STATUS = "signed-local-rendered-evidence-preparation-checkpoint-complete"
TIMESTAMP = re.compile(
    r"^(\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d)(?:\.(\d+))?(Z|[+-]\d\d:\d\d)$"
)


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def read_json_bytes(data):
    def unique_pairs(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, f"Duplicate JSON key: {key}")
            result[key] = value
        return result

    return json.loads(data.decode("utf-8-sig"), object_pairs_hook=unique_pairs)


def same_value(left, right):
    if type(left) is not type(right):
        return False
    if isinstance(left, dict):
        return left.keys() == right.keys() and all(
            same_value(left[key], right[key]) for key in left
        )
    if isinstance(left, list):
        return len(left) == len(right) and all(
            same_value(a, b) for a, b in zip(left, right)
        )
    if isinstance(left, str) and left != right:
        a, b = TIMESTAMP.fullmatch(left), TIMESTAMP.fullmatch(right)
        if a and b:
            def instant(match):
                offset = "+00:00" if match[3] == "Z" else match[3]
                seconds = datetime.fromisoformat(match[1] + offset).astimezone(timezone.utc)
                return seconds, (match[2] or "").rstrip("0")

            return instant(a) == instant(b)
    return left == right


def prepare_correction(current, proposal, receipt, proposal_hash, before_hash,
                       backup_path, recorded_at, expected_hash=PROPOSAL_HASH):
    require(proposal_hash == expected_hash, "Saved proposal hash does not match.")
    require(receipt.get("exactProposedContinuationHash") == expected_hash,
            "Recovery receipt does not identify the saved proposal.")
    require(same_value(current.get("parentExecution792ProgressSaveRecovery"), receipt),
            "Embedded recovery receipt differs from the preserved receipt.")
    require(proposal.get("checkpoint") == 792 and proposal.get("batch") == "103"
            and proposal.get("status") == "continue"
            and proposal.get("remainingAdditions") == 1099,
            "Unexpected proposed checkpoint identity.")
    for root, execution in zip(ROOTS, (791, 792)):
        record = proposal.get(root)
        require(isinstance(record, dict) and record.get("execution") == execution
                and record.get("batch") == "103",
                f"Unexpected proposed historical record: {root}")

    starting = current.get("execution792StartingState")
    proposed_starting = proposal.get("execution792StartingState")
    require(isinstance(starting, dict) and isinstance(proposed_starting, dict)
            and proposed_starting.get("status") == NEW_STATUS,
            "Missing or unexpected starting-state record.")
    expected_starting = dict(starting, status=NEW_STATUS)
    require(same_value(expected_starting, proposed_starting),
            "Starting-state values differ beyond the expected status/timestamp representation.")

    if CORRECTION in current:
        correction = current[CORRECTION]
        require(isinstance(correction, dict)
                and correction.get("proposalSha256") == expected_hash
                and starting.get("status") == NEW_STATUS
                and all(same_value(current.get(root), proposal[root]) for root in ROOTS),
                "Existing correction does not match the saved proposal.")
        return current, False

    require(type(current.get("checkpoint")) is int and current["checkpoint"] >= 792
            and current.get("status") == "continue",
            "Current progress is not a continuing checkpoint at or after 792.")
    require(starting.get("status") == OLD_STATUS,
            "Unexpected current starting-state status.")
    require(all(root not in current for root in ROOTS),
            "A proposed history root already exists without the correction record.")
    result = dict(current)
    result["execution792StartingState"] = expected_starting
    for root in ROOTS:
        result[root] = copy.deepcopy(proposal[root])
    result[CORRECTION] = {
        "recordedAt": recorded_at,
        "checkpointAtCorrection": current["checkpoint"],
        "batchAtCorrection": current.get("batch"),
        "proposalSha256": proposal_hash,
        "progressBeforeSha256": before_hash,
        "progressBeforePath": backup_path,
        "restoredRoots": list(ROOTS),
        "previousStartingStatus": OLD_STATUS,
        "correctedStartingStatus": NEW_STATUS,
        "receiptCorrection": (
            "The original recovery validated the proposal but built canonical progress "
            "from the prior state; it did not copy these two roots or update this status. "
            "The original receipt and denial remain unchanged. This correction restores "
            "the omitted proposal data without changing later checkpoint or publication state."
        ),
        "previousOwnerReport": (
            "https://github.com/stop-cran/learning-japanese/issues/60#issuecomment-6718176317"
        ),
        "ownerReportCorrection": "pending",
        "originalDenialCause": "Unknown; the original file-handle owner was not captured.",
    }
    return result, True


def write_new_file(path, data):
    with path.open("xb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())


def commit_correction(progress_path, original, result, backup_path, temporary_path):
    write_new_file(backup_path, original)
    candidate = (json.dumps(result, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    write_new_file(temporary_path, candidate)
    require(read_json_bytes(temporary_path.read_bytes()) == result,
            "Prepared correction failed the full JSON round trip.")
    require(sha256(progress_path.read_bytes()) == sha256(original),
            "Live progress changed during correction; candidate and backup were preserved.")
    os.replace(temporary_path, progress_path)
    require(sha256(progress_path.read_bytes()) == sha256(candidate),
            "Replaced progress does not match the prepared correction.")


def process_ancestry(pid):
    require(os.name == "nt", "The active-runner ancestry check requires Windows.")
    from ctypes import wintypes

    class ProcessEntry(ctypes.Structure):
        _fields_ = [
            ("dwSize", wintypes.DWORD),
            ("cntUsage", wintypes.DWORD),
            ("th32ProcessID", wintypes.DWORD),
            ("th32DefaultHeapID", ctypes.c_size_t),
            ("th32ModuleID", wintypes.DWORD),
            ("cntThreads", wintypes.DWORD),
            ("th32ParentProcessID", wintypes.DWORD),
            ("pcPriClassBase", wintypes.LONG),
            ("dwFlags", wintypes.DWORD),
            ("szExeFile", wintypes.WCHAR * 260),
        ]

    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.CreateToolhelp32Snapshot.argtypes = [wintypes.DWORD, wintypes.DWORD]
    kernel.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
    kernel.Process32FirstW.argtypes = [wintypes.HANDLE, ctypes.POINTER(ProcessEntry)]
    kernel.Process32FirstW.restype = wintypes.BOOL
    kernel.Process32NextW.argtypes = [wintypes.HANDLE, ctypes.POINTER(ProcessEntry)]
    kernel.Process32NextW.restype = wintypes.BOOL
    kernel.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel.CloseHandle.restype = wintypes.BOOL
    handle = kernel.CreateToolhelp32Snapshot(2, 0)
    if handle == ctypes.c_void_p(-1).value:
        raise ctypes.WinError(ctypes.get_last_error())
    parents = {}
    try:
        entry = ProcessEntry()
        entry.dwSize = ctypes.sizeof(entry)
        if not kernel.Process32FirstW(handle, ctypes.byref(entry)):
            raise ctypes.WinError(ctypes.get_last_error())
        while True:
            parents[entry.th32ProcessID] = entry.th32ParentProcessID
            if not kernel.Process32NextW(handle, ctypes.byref(entry)):
                error = ctypes.get_last_error()
                if error != 18:
                    raise ctypes.WinError(error)
                break
    finally:
        kernel.CloseHandle(handle)
    ancestry = []
    while pid and pid not in ancestry:
        ancestry.append(pid)
        pid = parents.get(pid, 0)
    return ancestry


def main():
    require(sys.argv[1:] == ["--apply-from-active-coordinator"],
            "Invoke only with --apply-from-active-coordinator.")
    runtime = read_json_bytes((CONTROL / "runner.json").read_bytes())
    session = runtime.get("sessionId")
    require(isinstance(session, str) and str(uuid.UUID(session)) == session,
            "Runner session ID is invalid.")
    require(runtime.get("status") == "running"
            and type(runtime.get("pid")) is int
            and runtime["pid"] in process_ancestry(os.getpid()),
            "Current process is not a descendant of the active runner.")
    log_dir = CONTROL / "logs" / session
    require(os.path.normcase(str(Path(runtime["log"]).resolve()))
            == os.path.normcase(str((log_dir / "output.jsonl").resolve())),
            "Runner log path does not match its session.")
    snapshot = read_json_bytes((log_dir / "checkpoint-full.json").read_bytes())
    progress_path = CONTROL / "progress.json"
    original = progress_path.read_bytes()
    current = read_json_bytes(original)
    for field in ("checkpoint", "batch", "status", "remainingAdditions", "lastPublishedCommit"):
        require(current.get(field) == snapshot.get(field),
                f"Live progress does not match the active snapshot: {field}")
    del snapshot

    proposal_data = (CONTROL / "progress.json.792-finish.tmp").read_bytes()
    archived = (CONTROL / "artifacts" / "batch-103-rendered-preparation-792-parent-recovery"
                / "proposed-continue-792.json").read_bytes()
    require(sha256(archived) == sha256(proposal_data),
            "Preserved proposal copies differ.")
    proposal = read_json_bytes(proposal_data)
    receipt = read_json_bytes(
        (CONTROL / "batch-103-rendered-preparation-792-parent-recovery.json").read_bytes()
    )
    backup_path = log_dir / "progress-before-792-history-correction.json"
    result, changed = prepare_correction(
        current, proposal, receipt, sha256(proposal_data), sha256(original),
        str(backup_path), datetime.now(timezone.utc).isoformat(),
    )
    if changed:
        temporary = CONTROL / f"progress.json.792-history-correction.{session}.tmp"
        commit_correction(progress_path, original, result, backup_path, temporary)
    print(json.dumps({"corrected": changed, "checkpoint": current["checkpoint"],
                      "batch": current["batch"], "preservedProposalSha256": sha256(proposal_data),
                      "backup": str(backup_path) if changed else None}))


if __name__ == "__main__":
    main()
