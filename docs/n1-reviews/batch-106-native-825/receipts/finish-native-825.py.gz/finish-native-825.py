import copy
from datetime import datetime, timezone
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

C = Path(__file__).resolve().parent
R, A = C.parent / "learning-japanese", C.parent / "kanji-cards-android"
L = C / "logs" / "1609d87b-eea5-4d77-898f-edae33fa4278"
D = R / "docs" / "n1-reviews" / "batch-106-native-825"
E = R / "docs" / "n1-sources" / "execution-825.json"
BASE = "f1e1f24e329fa55445a6c9f4f8d2cc8ca4eb9c98"
APP = "bf30cdead8515739bc0e671d57a54b9a3109dd46"
spec = importlib.util.spec_from_file_location("archive825", C / "archive-native-825.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
load, save, sha, git = module.load, module.save, module.sha, module.git


def verify(head, clean=True):
    p = load(C / "progress.json")
    assert (p["checkpoint"], p["status"], p["batch"]) == (824, "continue", "106")
    runner = load(C / "runner.json")
    assert (runner["status"], runner["pid"], runner["sessionId"]) == ("running", 13320, L.name)
    for root, expected in ((R, head), (A, APP)):
        assert git("rev-parse", "HEAD", root=root) == expected
        assert git("log", "-1", "--format=%G?", root=root) == "G"
        if clean or root == A:
            assert not git("status", "--porcelain", "--untracked-files=all", root=root)
    for index in ("artifact-index.json", "finalization-helper-index.json"):
        if (D / index).exists():
            for row in load(D / index):
                assert sha(D / row["file"]) == row["storedSha256"], row["file"]
    return p


def prepare():
    verify(BASE, clean=False)
    assert not git("diff", "--name-only", BASE)
    untracked = git("ls-files", "--others", "--exclude-standard").splitlines()
    assert untracked and all(n.startswith("docs/n1-reviews/batch-106-native-825/")
                             or n == "docs/n1-sources/execution-825.json" for n in untracked)
    index = []
    for name in ("post-native-825.ps1", "finish-native-825.py", "preflight-825.ps1", "archive-native-825.py"):
        source, target = C / name, D / "receipts" / (name + ".gz")
        if name in ("preflight-825.ps1", "archive-native-825.py"):
            target = D / "receipts" / (name + ".corrected-quotepath.gz")
        assert not target.exists()
        target.write_bytes(gzip.compress(source.read_bytes(), mtime=0))
        index.append({"file": target.relative_to(D).as_posix(), "sourceSha256": sha(source),
                      "storedSha256": sha(target)})
    e = load(E)
    e["automatedValidation"] = {
        "validatorErrors": 0, "manifestRegenerated": True, "manifestUnchanged": True,
        "whitespaceDiffCheckPassed": True,
        "executionOutput": str(L / "output.jsonl"),
        "limits": "Fresh validator/build_manifest/diff checks executed during this native checkpoint. Full Python/vocabulary/current-main publication acceptance remains separate; no claim to rerun inherited823 HOST tests."}
    diagnostic = L / "preflight-825-path-quoting-diagnostic.json"
    e["wrapperDiagnostic"] = load(diagnostic)
    target = D / "receipts" / "preflight-825-path-quoting-diagnostic.json"
    save(target, load(diagnostic))
    index.append({"file": target.relative_to(D).as_posix(), "sourceSha256": sha(diagnostic),
                  "storedSha256": sha(target)})
    save(D / "finalization-helper-index.json", index)
    E.write_text(json.dumps(e, ensure_ascii=True, indent=2) + "\n", encoding="utf-8")
    assert e["runtime"] == module.runtime()
    module.results()
    print("Native artifact hashes, runtime equality and checkpoint helper provenance verified.")


def finish():
    before = load(L / "progress-before-825.json")
    head = git("rev-parse", "HEAD")
    current = verify(head)
    assert git("rev-parse", "HEAD^") == BASE
    assert not git("diff", "--name-only", BASE, head, "--", "manifest.json", "kanji", "words", "strokes", "articles")
    runtime = module.runtime()
    attempt, route, raster = module.results()
    posted, reread = load(L / "issue-825-posted.json"), load(L / "issue-825-reread.json")
    body = C / "batch-106-native-825-issue-body.txt"
    assert posted["author"] == reread["user"]["login"] == "stop-cran"
    assert posted["bodySha256"] == sha(body) and body.read_bytes().decode("utf-8") == reread["body"]
    assert posted["url"] == reread["html_url"]
    correction = load(L / "correction-owner-reread.json")
    assert correction["user"]["login"] == "stop-cran"
    assert "Checkpoint-792 history correction e301c6da" in correction["body"]
    assert current["execution792HistoryCorrection"]["ownerReportCorrection"] == correction["html_url"]
    e = load(E)
    assert e["runtime"] == runtime and e["nativeExecutionComplete"]
    assert not e["runtimeChanged"] and not e["runtimePublished"]
    for row in load(D / "artifact-index.json") + load(D / "finalization-helper-index.json"):
        path = (D / row["file"]).relative_to(R).as_posix()
        assert hashlib.sha256(subprocess.check_output(["git", "-C", str(R), "show", head + ":" + path])).hexdigest() == row["storedSha256"]
    next_action = (
        f"SAME106 checkpoint825 signed LOCAL native evidence HEAD{head}, qualifiedAndroid{APP}. "
        "Read docs/n1-sources/execution-825.json and docs/n1-reviews/batch-106-native-825/. "
        "Exact prepared824 APKs/fixture/fullLFarchive executed WITHOUT rebuild; BOTH exact Glyph824/Article824 "
        "terminalcase0/zero failures/skips/137.131s. Full productionContentSyncONCE signed501c280681457cc80434520081beb90362ece211 "
        "archiveSHA256bb3c7fde193b55c43d4742bf7e9eb62513cfde9e1e35cff3d0a42228c5c97302:1129kanji5080words138N1/"
        "0problems/reading+meaningepochs1. ActualRoom/projections448directsymmetricguards/32NONTRANSITIVEneighbors/"
        "384paironlywordguards/64builderchoices/everyofferedsetpairwiseexclusionchecked. "
        "DefaultN1 has ZEROcurated/THREEfallback; All/custom retain束効勤levels3/2/3. "
        "Exactdefault畔paddyboundary-waterside/剰remainder-surplusamount/俸salary-stipend/勅imperialorder. "
        "32explicitunguarded勅訓pairhypothesissamples retained; original822weakhypothesis UNRESOLVED NONBLOCKING, "
        "notforcedwithdrawal/establisheddefect/speculativeguard/universalsafety. "
        "Fullon[チョク]/kun[いまし.める,みことのり]preserved exactsourceorder,selected[チョク]/[]; "
        "soleactualkeyちょく/displayチョク persistedgood/done1of1/kunquestionnull. "
        "Legacyfeedbackrawいましめる/みことのりstillvisible: curationnotallreferencedisplay. "
        "Modernwrittenいまし.める remainsUNVERIFIED;みことのり outsideJoyoREADINGlistNOTfrequency/invalidity. "
        "Ninereferencetouchstrokes/ungradedtrace/modelunavailable/intentionalrecallrevealgrade1onNext, NOTmastery. "
        "TWOactualmappedpairs/FOURdirections/zeroactivatedbaselinepairs/ONEexact令newexampleline/systemBack/offline/meaning passed. "
        "Freshfree5580/5581 localANDremote/TimeWait/PID/readonlyAVD/API35/2gguest192mgrowth576mmax verified; "
        "ownedemulator5580parent9060/QEMU12368 responsiveANDbothstopped. OnlyunrelatedMessagesforce-stoppedonOWNED"
        "disposableemulatorbasedonpreserved802ANR;no packagedisable/targeterrorsuppression/fixture/production/heap/guardchange. "
        "Sharedadb/otherdevices/parentrunner.lock untouched.72glyphprobes/4wordrasters/3panels/17actualHanPLUS訓; "
        "coordinatoropened19of42PNGsincludingALL3fontpanels. Actualwhole勅令word/radical力/lookalikes/all17Han"
        "readabledistinguishableallfourfamilies/default; no scopedcmapabsences,actualfallbackfaceunknown. "
        "900x2000toolrenditionsof1080x2400notoriginalpixel/phone/nativespeaker/equalcomprehensioncertification; "
        "23PNGspreservednotfreshlyviewed; article07/09duplicateviewport,readingtablehorizontalscrollnotallcolumns. "
        "NEXT SAME106 bounded complete-frozen-source preparation/inspection for FIVE native labels absentHOST823:"
        "剰remainder-surplusamount/扱handle-dealwith/獣beast-animal/矛spear-polearm/芋tuber-yam. "
        "Exact43native labels/order/poolmembers/seeds in sampled-labels-and-host-delta.json and native route JSON. "
        "Preserve complete actual raw character records/allEnglishmeanings/applicable fullJMdictfamilies/"
        "restrictionsandsenses/actualcomparisonbodies from committed packets or approvedfrozeninputs; no corpusdump/"
        "optionalhistoricalsessionrecipe. Newnativeordinarysecondarysensefallbacksemanticacceptance UNVERIFIED "
        "until exactsourceinspection and TWO SERIAL ORIGINAL-family rendered confirmations, including retained訓"
        "hypothesis/fullfamilies/exactnativefallbacklabels and actualPNGscope. Use originalsessions/reports from "
        "batch-106-initial-executions-822.json/batch-106-reconciliation.json, notnewblindinitials; each process "
        "mustexitbeforethenext, reviewerpertoolserialization/noeditfrozensnapshot. Native mechanicsNOTwholebatchacceptance. "
        "Original822textualand823HOSTfinite41kanji22words32families inherited,notrepeated; retainall originalreports/"
        "readlimits/hypotheses/optionaldispositions/process/source/historylimitswithoutretroacceptance. Any consequentialdefect:"
        "exactsource/minimalcorrection/audits/manifest/normalsignednewfreeze/BOTHoriginalfamilyconfirmations. "
        "All8472runtimehashes/version89809c00e1676979/manifestunchanged;8494entries/30503741compressed/"
        "44698107inflated/44429769retainedbytes/perfilepathmedia originalguardsverified. Validator0errors/"
        "regeneratedmanifestunchanged. All priorgates/limitations retained verbatim in "
        "historicalExecution824Before825Native.nextAction and execution824CoordinatorCheckpoint. "
        "Execution792HistoryCorrection now restored twoomittedroots/intendedstartingstatus; verifiedownerreport"
        + correction["html_url"] + ";oldreceipt/denialunchanged,causeunknown,counters/acceptanceunchanged. "
        "Combinedcurrentmain/nonrewritingmerge/changedteachingreview/fullrequiredPython/vocabulary/"
        "baseline-membership-links/manifestbudget/normalsigning/ownerfastforward/terminalgreenCI/"
        "EVERYimmutableGitHubZIPmanifesthash/unchanged18000entries42MiBcompressed80MiBinflated56MiBretained/"
        "perfilepathmedia/verifiedownerissue remainMANDATORY. No107/unreviewedpush/authoragents/"
        "concurrentheavywork/secondrunner/signingretry/guardincrease. Freshsignedheads/checkpoint/whollyclean/"
        "freshmain/liveparentancestry/decodedlauncher/exactsession required. Parent13320ownsrunner.lock:"
        "nochildacquire/delete/unlock/readprobe. Approvedcontrol/committedsource/frozeninputs only;preserve/report/"
        "yield actualnewdenial/signinghang/uncertainownership. QualifiedAndroidapprovedpairguard+schemaonly "
        "NOTlatestappmain. Published132/1228/remainder1096unchanged; unaccepted勅/ONEsupport勅令 notdeliveredN1vocabulary. "
        "Sixseparatelyplaced保案派第策結retainN2/noacceptedcredit/noduplicate/relevel. "
        "CompatibleAndroid125+132 required;oldclientsignore. Physicalphone/generalrelease/whole-setoutstanding;projectincomplete."
    )
    checkpoint = {
        "schemaVersion": 1, "execution": 825, "checkpoint": 825, "batch": "106",
        "status": "continue", "stage": "batch-106-native-passed-awaiting-new-label-sources-and-rendered-confirmations",
        "recordedAt": datetime.now(timezone.utc).isoformat(), "savedCommit": head, "signature": "G",
        "qualifiedAndroidHead": APP, "testedContentHead": BASE, "archiveContentSnapshot": route["contentSnapshot"],
        "evidence": "docs/n1-sources/execution-825.json", "issueUpdate": posted["url"],
        "ownerIssueAuthorAndExactBodyVerified": True, "nativeExecuted": True, "glyphCasePassed": True,
        "articleCasePassed": True, "terminalSuccessCases": 2, "terminalFailureCases": 0, "nativeSkipped": 0,
        "nativeExecutionComplete": True, "wholeBatchAcceptanceComplete": False, **runtime,
        "nativePngs": 41, "preservedPngs": 42, "coordinatorViewedOriginalPngs": 19,
        "directSymmetricGuardChecks": 448, "nontransitiveNeighborChecks": 32,
        "preservedWordGuardChecks": 384, "productionBuilderChoices": 64,
        "unresolvedNonblockingKunHypothesisPairs": 32,
        "soleCuratedOnPersistedGoodAndDone": True, "actualKeys": ["ちょく"],
        "mappedReciprocalPairs": 2, "directedLinkTransitions": 4, "changedReusedArticles": 1,
        "ownedHelperStopped": True, "ownedQemuStopped": True, "sharedAdbTouched": False,
        "independentReviewersLaunched": 0, "independentRenderedReviewClosed": False,
        "newNativeOrdinarySenseFallbackSemanticAcceptance": "UNVERIFIED",
        "runtimeChanged": False, "manifestChanged": False, "runtimeAccepted": False, "runtimePublished": False,
        "reviewClosed": [], "published": [], "dedicatedWorktreesClean": True, "parentLockTouched": False,
        "optionalHistoricalHelpersAccessed": False, "actualNewPermissionDenials": [],
        "publishedAdditions": 132, "remainingAdditions": 1096, "lastPublishedCommit": before["lastPublishedCommit"],
        "historyCorrectionOwnerReport": correction["html_url"],
        "physicalPhoneAcceptance": "outstanding", "generalReleaseAcceptance": "outstanding",
        "wholeProjectComplete": False, "nextBatchStarted": False,
        "finalRunnerPreflight": load(L / "preflight-825-before-issue.json"),
        "nextAction": next_action, "blocker": None,
        "historicalRootKeysCompared": len(before), "allOriginalHistoricalValuesPreserved": True,
    }
    after = copy.deepcopy(current)
    assert "execution825CoordinatorCheckpoint" not in after
    after["execution825CoordinatorCheckpoint"] = checkpoint
    after["execution825StartingState"]["status"] = "signed-local-native-checkpoint-complete"
    changed = {"checkpoint", "status", "stage", "nextAction", "blocker"}
    for key in changed:
        after[key] = checkpoint[key]
    for key, value in before.items():
        if key == "execution792HistoryCorrection":
            expected = copy.deepcopy(value)
            expected["ownerReportCorrection"] = correction["html_url"]
            assert after[key] == expected, key
        elif key not in changed:
            assert after[key] == value, key
    assert after["remainingAdditions"] == 1096 and after["lastPublishedCommit"] == before["lastPublishedCommit"]
    save(L / "checkpoint-825-summary.json", checkpoint)
    temp = C / "progress.json.825-final.tmp"
    save(temp, after)
    assert load(C / "progress.json") == current
    os.replace(temp, C / "progress.json")
    assert load(C / "progress.json") == after
    save(L / "checkpoint-825-final-verification.json",
         {"checkpoint": 825, "savedCommit": head, "signature": "G",
          "allOriginalHistoricalValuesPreserved": True, "originalRootKeysCompared": len(before),
          "dedicatedWorktreesClean": True, "runtimeHashesVerified": 8472,
          "ownerIssueAuthorAndExactBodyVerified": True, "parentLockTouched": False,
          "oneTimeHistoryCorrectionPreserved": True})
    print(json.dumps({"checkpoint": 825, "status": "continue", "savedCommit": head,
                      "historicalKeysPreserved": len(before), "issueUpdate": posted["url"]}, ensure_ascii=True))


if __name__ == "__main__":
    {"prepare": prepare, "finish": finish}[sys.argv[1]]()
