from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os

C = Path(__file__).resolve().parent
L = C / "logs" / "1609d87b-eea5-4d77-898f-edae33fa4278"
path = C / "progress.json"
original = path.read_bytes()
p = json.loads(original)
assert (p["checkpoint"], p["batch"], p["status"]) == (824, "106", "continue")
assert "execution825StartingState" not in p
comment = json.loads((L / "correction-owner-reread.json").read_text(encoding="utf-8-sig"))
assert comment["user"]["login"] == "stop-cran"
assert "Checkpoint-792 history correction e301c6da" in comment["body"]
assert p["execution792HistoryCorrection"]["ownerReportCorrection"] == "pending"
p["execution792HistoryCorrection"]["ownerReportCorrection"] = comment["html_url"]
assert not (L / "progress-before-825.json").exists()
(L / "progress-before-825.json").write_bytes(original)
request = (L / "request.txt").read_bytes()
text = request.decode("utf-8-sig")
json.loads(text.split("Current execution checkpoint (complete historical state remains at checkpointHistory paths):", 1)[1])
preflight = json.loads((L / "preflight-825.json").read_text(encoding="utf-8-sig"))
state = {
    "execution": 825, "batch": "106", "startedAt": datetime.now(timezone.utc).isoformat(),
    "startingHead": preflight["contentHead"], "androidHead": preflight["androidHead"],
    "freshOriginMain": preflight["freshOriginMain"],
    "scope": "SAME106 exact compiled824 full-archive production ContentSync ONCE native execution and signed LOCAL evidence checkpoint; no reviewer/publication/107.",
    "request": {"sha256": hashlib.sha256(request).hexdigest(), "bytes": len(request),
                "lines": len(text.splitlines()), "completeFileLoadedAndCheckpointParsed": True,
                "limits": "Entire request loaded/decoded and embedded checkpoint parsed; operative contract, entire approved issue and final824 directly inspected. Historical middle parsed, not freshly semantically re-reviewed. Initial decoded-state print encountered console encoding error; bounded UTF-8 reads supplied current operative state."},
    "runnerPreflight": preflight,
    "artifactPathPreflight": "Approved committed source packets and durable control helpers only; optional historical-session recipes not accessed.",
    "parentLockTouched": False, "actualNewPermissionDenials": [],
    "historyCorrectionOwnerReport": comment["html_url"],
}
p["execution825StartingState"] = state
p["historicalExecution824Before825Native"] = {k: p[k] for k in ("checkpoint", "stage", "status", "nextAction", "blocker")}
p["stage"] = "batch-106-native-execution-in-progress"
assert path.read_bytes() == original
temp = C / "progress.json.825-start.tmp"
assert not temp.exists()
temp.write_text(json.dumps(p, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
os.replace(temp, path)
assert json.loads(path.read_bytes()) == p
(L / "starting-state-825.json").write_text(json.dumps(state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print("Execution825 starting scope and verified history-correction owner URL saved; full history preserved.")
