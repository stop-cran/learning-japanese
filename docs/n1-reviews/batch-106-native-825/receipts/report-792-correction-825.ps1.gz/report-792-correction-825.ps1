$ErrorActionPreference = 'Stop'
$log = "$PSScriptRoot\logs\1609d87b-eea5-4d77-898f-edae33fa4278"
$marker = 'Checkpoint-792 history correction e301c6da'
$body = "$marker`n`nCorrection to the earlier checkpoint-792 recovery report: recovery validated the saved proposal but did not copy two proposal history roots or advance the saved starting-state status. The omitted data and intended status are now restored by the checked active-coordinator repair, with the exact pre-correction progress preserved. The old recovery receipt and original denial remain unchanged; the original denial cause is unknown because no conflicting file-holder identity was captured. Subsequent checkpoint counters, publication and acceptance are unchanged. Batch106 is still unaccepted; no new publication or phone acceptance is claimed."
$prior = $env:GH_TOKEN
try {
    $env:GH_TOKEN = (gh auth token --user stop-cran)
    if ($LASTEXITCODE -ne 0 -or -not $env:GH_TOKEN) { throw 'Owner credential unavailable' }
    $login = gh api user --jq .login
    if ($LASTEXITCODE -ne 0 -or $login -cne 'stop-cran') { throw 'Wrong command-scoped identity' }
    $raw = gh api --paginate --slurp 'repos/stop-cran/learning-japanese/issues/60/comments?per_page=100'
    if ($LASTEXITCODE -ne 0) { throw 'Comment search failed' }
    $pages = ($raw | Out-String) | ConvertFrom-Json
    $matches = @($pages | ForEach-Object { $_ } | Where-Object {
        $_.user.login -ceq 'stop-cran' -and $_.body.Contains($marker)
    })
    if ($matches.Count -gt 1) { throw 'Multiple matching correction reports; preserve and yield' }
    if ($matches.Count -eq 1) {
        $id = $matches[0].id
    } else {
        [IO.File]::WriteAllText("$log\correction-owner-body.txt", $body, [Text.UTF8Encoding]::new($false))
        $url = gh issue comment 60 --repo stop-cran/learning-japanese --body-file "$log\correction-owner-body.txt"
        $code = $LASTEXITCODE
        @{exitCode=$code; output=$url} | ConvertTo-Json |
            Set-Content "$log\correction-owner-post-outcome.json" -Encoding utf8NoBOM
        if ($code -ne 0 -or $url -notmatch '#issuecomment-(\d+)$') { throw 'Uncertain posting outcome; do not repost' }
        $id = $Matches[1]
    }
    $raw = gh api "repos/stop-cran/learning-japanese/issues/comments/$id"
    if ($LASTEXITCODE -ne 0) { throw 'Correction reread failed' }
    $raw | Set-Content "$log\correction-owner-reread.json" -Encoding utf8NoBOM
    $comment = $raw | ConvertFrom-Json
    if ($comment.user.login -cne 'stop-cran' -or -not $comment.body.Contains($marker) -or
        $comment.html_url -cne "https://github.com/stop-cran/learning-japanese/issues/60#issuecomment-$id") {
        throw 'Correction author/URL/marker verification failed'
    }
    Write-Output $comment.html_url
} finally {
    $env:GH_TOKEN = $prior
}
