$ErrorActionPreference = 'Stop'
$control = $PSScriptRoot
$log = "$control\logs\1609d87b-eea5-4d77-898f-edae33fa4278"
$content = "$control\..\learning-japanese"
$bodyPath = "$control\batch-106-native-825-issue-body.txt"
if ((Test-Path "$log\issue-825-posted.json") -or (Test-Path $bodyPath)) { throw 'Do not duplicate issue update' }
$head = git -C $content rev-parse HEAD
if ($LASTEXITCODE -ne 0) { throw 'HEAD lookup failed' }
& "$control\preflight-825.ps1" -ReceiptName 'preflight-825-before-issue.json' -ExpectedContentHead $head
if ((git -C $content rev-parse 'HEAD^') -ne 'f1e1f24e329fa55445a6c9f4f8d2cc8ca4eb9c98' -or
    $LASTEXITCODE -ne 0) { throw 'Wrong evidence ancestry' }
$e = [IO.File]::ReadAllText("$content\docs\n1-sources\execution-825.json") | ConvertFrom-Json
if (-not $e.nativeExecutionComplete -or $e.runtimeChanged -or $e.runtimePublished -or
    -not $e.nativeAttempt.ownedHelperStopped -or -not $e.nativeAttempt.ownedQemuStopped -or
    $e.runtime.runtimeHashesVerified -ne 8472 -or $e.nativeResults.terminalSuccessCases -ne 2) {
    throw 'Native evidence mismatch'
}
$body = @"
Checkpoint825, SAME batch106: BOTH exact prepared824 native cases passed terminal status0, zero failures/skips (137.131s). Signed LOCAL evidence $head preserves docs/n1-sources/execution-825.json and docs/n1-reviews/batch-106-native-825/: complete instrumentation/route/raster results, exact APK/fixture/archive bindings,41 native PNGs plus1 environment screenshot. No teaching/app changes, reviewer, push or batch107.

Fresh signed clean heads, live parent13320 ancestry/decoded launcher/current session/checkpoint, and local+remote5580/5581 including TimeWait/PID checks passed. Owned read-only API35 emulator5580 parent9060/QEMU12368 was responsive; BOTH stopped. Same AVD/host GPU/Vulkan disabled/2GiB guest/192m growth/576m max heap. Only unrelated Google Messages was force-stopped on the OWNED disposable emulator before instrumentation, grounded in preserved802 ANR interference; no package disable, target-error suppression or fixture changes. Parent runner.lock/shared adb/other devices untouched.

Full production ContentSync imported signed501c280681457cc80434520081beb90362ece211 archive ONCE:1,129kanji/5,080words/138N1/zero problems; reading+meaning parser epochs1. Actual Room/projections/builders passed448 direct symmetric kanji guard checks,32 NONTRANSITIVE neighbor checks,384 pair-only word guard checks and64 sampled meaning-option sets; every offered kanji set pairwise exclusion-checked. All THREE curated distractors are OUTSIDE N1 (N3/N2/N3); actual default N1 has ZERO curated and THREE fallback. Default labels: paddy boundary; waterside / remainder; surplus amount / salary; stipend / imperial order. Retained32 explicit unguarded instruction/precept pair samples do NOT resolve original822's weak hypothesis or establish a new defect. Finite mechanics do not certify every future pool's semantics.

Sole selected on-key and katakana display persist correct/done1of1; full source on/kun and exact order preserved, selected sole on/empty kun, no kun question. Legacy feedback still displays both raw unselected kun readings; curation excludes questions, not all reference display. The article explicitly leaves modern written use of the first kun unverified. Nine reference-touch strokes passed ungraded trace, deliberate recall reveal/grade1-on-Next; TWO mapped reciprocal pairs/FOUR directions, the ONE reused command-card example line, system Back and offline route passed. Zero activated baseline pairs; no inferred support vocabulary level. Other N1 questions postponed/two historical meaning logs seeded; no drawing state seeded. Shape-only feedback/model unavailable is not human handwriting recognition or mastery.

72 individual glyph probes/4 word rasters/3 panels passed for all17 scoped Han PLUS retained precept comparison in four production families/default. Coordinator actually opened19of42 original PNGs, including ALL3 font panels: whole word/radical/look-alikes/all scoped Han readable and distinguishable, no established blank/tofu/misleading glyph. No scoped cmap absences; actual fallback face unknown. Tool displays900x2000 renditions of1080x2400 screenshots, not original pixels/phone/native-speaker certification;23 PNGs preserved but not freshly viewed. Horizontal table shows only a scrolled viewport; article07/09 are duplicate visible states, not extra visual coverage. Both complete Japanese/kana/English example bullets are visibly joined correctly.

All8,472 runtime hashes/version89809c00e1676979 unchanged; exact compiled full archive bb3c7fde193b55c43d4742bf7e9eb62513cfde9e1e35cff3d0a42228c5c97302 retained.8,494entries/30,503,741compressed/44,698,107inflated/44,429,769retained bytes and unchanged per-file/media/path limits verified. Validator0 errors; regenerated manifest unchanged. Exact824 APKs were executed without rebuilding; debug artifacts, not owner-signed release.

NEXT SAME106 bounded source supplementation for FIVE native fallback labels absent from HOST823: remainder/surplus, handle/deal with, beast/animal, spear/polearm, tuber/yam (exact IDs and labels in sampled-labels-and-host-delta.json). Preserve exact full frozen character records and applicable complete comparison bodies/families, then TWO SERIAL ORIGINAL-family rendered confirmations using original sessions/reports and actual native images/labels, including the retained instruction/precept hypothesis. New native ordinary-secondary-sense semantic acceptance remains UNVERIFIED until this source-backed work; native mechanical success is NOT whole-batch acceptance. Original822 textual and823 HOST finite target-relative acceptance inherited, not repeated; all original findings, unverified readings, hypotheses, optional dispositions and source/process/read-depth/history limits preserved.

The separately verified owner correction to checkpoint792 is $($e.historyCorrection.ownerReportCorrection). Two omitted proposal roots and the intended starting-state status are now restored; old receipt/denial unchanged, denial cause unknown, subsequent counters/acceptance unchanged.

All combined-current-main/nonrewriting-merge/changed-teaching-review/full-required-validation/normal-signing/owner-fast-forward/terminal-green-CI/EVERY-immutable-GitHub-ZIP-hash/budget/publication gates remain. Original guards18,000entries/42MiBcompressed/80MiBinflated/56MiBretained unchanged. Published132/1,228; acceptance remainder1,096; last published0c582f18b31f65a5e1a908d92e37dde3d34f81ee. Batch106 not closed/published. Compatible stop-cran/kanji-cards-android#125 and stop-cran/kanji-cards-android#132 client required; old clients ignore curation/guards; qualified backport, not latest app main. Physical-phone, general-release and whole-set acceptance outstanding; project incomplete. No new permission denial, optional historical-session helper access, second runner or lock acquisition.
"@
[IO.File]::WriteAllText($bodyPath, $body + "`n", [Text.UTF8Encoding]::new($false))
$priorToken = $env:GH_TOKEN
try {
    $env:GH_TOKEN = (gh auth token --user stop-cran)
    if ($LASTEXITCODE -ne 0 -or -not $env:GH_TOKEN) { throw 'Owner credential unavailable' }
    $login = gh api user --jq .login
    if ($LASTEXITCODE -ne 0 -or $login -cne 'stop-cran') { throw 'Wrong command-scoped identity' }
    $url = gh issue comment 60 --repo stop-cran/learning-japanese --body-file $bodyPath
    if ($LASTEXITCODE -ne 0) { throw 'Issue update failed; preserve outcome, do not repost' }
    $url = $url.Trim()
    @{url=$url; author=$login; bodySha256=(Get-FileHash $bodyPath).Hash.ToLowerInvariant()} |
        ConvertTo-Json | Set-Content "$log\issue-825-posted.json" -Encoding utf8NoBOM
    if ($url -notmatch '#issuecomment-(\d+)$') { throw 'Unexpected comment URL; preserve receipt' }
    $raw = gh api "repos/stop-cran/learning-japanese/issues/comments/$($Matches[1])"
    if ($LASTEXITCODE -ne 0) { throw 'Comment reread failed' }
    $raw | Set-Content "$log\issue-825-reread.json" -Encoding utf8NoBOM
    $comment = $raw | ConvertFrom-Json
    if ($comment.user.login -cne 'stop-cran' -or $comment.body -cne [IO.File]::ReadAllText($bodyPath) -or
        $comment.html_url -cne $url) { throw 'Exact owner/body verification failed' }
    Write-Output "Verified owner update: $url"
} finally {
    $env:GH_TOKEN = $priorToken
}
