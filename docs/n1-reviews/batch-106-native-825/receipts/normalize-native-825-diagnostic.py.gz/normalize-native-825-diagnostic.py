from pathlib import Path
import gzip
import hashlib
import json
import subprocess

C = Path(__file__).resolve().parent
R = C.parent / "learning-japanese"
L = C / "logs" / "1609d87b-eea5-4d77-898f-edae33fa4278"
D = R / "docs" / "n1-reviews" / "batch-106-native-825"
ORIGINAL = "b75de041f075680f1d0580da0207ddc48c50251b"


def sha(b):
    return hashlib.sha256(b).hexdigest()


def save(path, data):
    assert not path.exists(), path
    path.write_bytes((json.dumps(data, ensure_ascii=True, indent=2) + "\n").encode("utf-8"))


assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=R, text=True).strip() == ORIGINAL
assert not subprocess.check_output(["git", "status", "--porcelain"], cwd=R)
index_path = D / "finalization-helper-index.json"
original_index = index_path.read_bytes()
rows = json.loads(original_index)
target = D / "receipts" / "preflight-825-path-quoting-diagnostic.json"
original_bytes = target.read_bytes()
normalized = original_bytes.replace(b"\r\n", b"\n")
committed = subprocess.check_output(["git", "show", ORIGINAL + ":" + target.relative_to(R).as_posix()], cwd=R)
assert committed == normalized and original_bytes != normalized
matches = [row for row in rows if row["file"] == target.relative_to(D).as_posix()]
assert len(matches) == 1 and matches[0]["storedSha256"] == sha(original_bytes)
correction_index = []
for name, data in [
    ("diagnostic-original-crlf.json.gz", original_bytes),
    ("finalization-helper-index-original-crlf.json.gz", original_index),
    ("finish-native-825-normalization-corrected.py.gz", (C / "finish-native-825.py").read_bytes()),
    ("normalize-native-825-diagnostic.py.gz", Path(__file__).read_bytes()),
]:
    path = D / "receipts" / name
    assert not path.exists()
    path.write_bytes(gzip.compress(data, mtime=0))
    correction_index.append({"file": path.relative_to(D).as_posix(),
                             "sourceSha256": sha(data), "storedSha256": sha(path.read_bytes())})
matches[0]["storedSha256"] = sha(normalized)
matches[0]["archiveConvention"] = "LF-normalized JSON; exact pre-normalization bytes preserved separately"
matches[0]["originalBytesArchive"] = "receipts/diagnostic-original-crlf.json.gz"
target.write_bytes(normalized)
index_path.write_bytes((json.dumps(rows, ensure_ascii=True, indent=2) + "\n").encode("utf-8"))
save(D / "normalization-correction-index.json", correction_index)
diagnostic = {
    "execution": 825, "originalSignedEvidenceCommit": ORIGINAL,
    "exactError": "finish-native-825.py:98 AssertionError in git-object evidence hash verification; checkpoint not advanced",
    "scope": "Only receipts/preflight-825-path-quoting-diagnostic.json hash entry differed; all other indexed Git objects matched.",
    "cause": "Python Windows write_text wrote13CRLF lines; Git normalized that JSON to LF, but the index retained its raw CRLF hash. Byte comparison proves newline-only change.",
    "oldRawSha256": sha(original_bytes), "correctGitLfSha256": sha(normalized),
    "remedy": "Preserve exact original CRLF diagnostic and index in gzip; record actual LF Git-object hash, normalize working JSON, preserve corrected finalizer and validate both signed evidence commits without amendment.",
    "originalOwnerNativeReport": json.loads((L / "issue-825-posted.json").read_text(encoding="utf-8-sig"))["url"],
    "permissionDenial": False, "runtimeChanged": False, "nativeRepeated": False,
    "parentLockTouched": False, "originalCommitAmended": False,
}
save(D / "normalization-correction.json", diagnostic)
save(L / "normalization-correction.json", diagnostic)
print("Exact diagnostic newline mismatch corrected; original bytes/index preserved, no runtime or native rerun.")
