"""Publish accepted batch105 under the live parent launcher, then yield."""
import copy
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

C = Path(__file__).resolve().parent
R, A = C.parent / "learning-japanese", C.parent / "kanji-cards-android"
L = C / "logs" / "0462397c-9243-45d1-8912-746da0744c4a"
S, V = R / "docs" / "n1-sources", R / "docs" / "n1-reviews"
D = V / "batch-105-publication-818"
HEAD = "3be9def98ca32d5f9c14a9b6f94c55d87734a05f"
MAIN = "047c2cef6b6a48b1738f2c5957de01be481c63e1"
TEACHING = "27e252daa091e21c907ff6799818f6b2da74c7aa"
APP = "bf30cdead8515739bc0e671d57a54b9a3109dd46"
MEMBER = "\u52c1"
VERSION = "5572c6c467e6b73b"
sys.path.insert(0, str(R / "tools"))
sys.stdout.reconfigure(encoding="utf-8")


def load(path):
    return json.loads(path.read_bytes())


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def now():
    return datetime.now(timezone.utc).isoformat()


def save(path, data, replace=False):
    assert replace or not path.exists(), path
    temp = path.with_suffix(path.suffix + ".818.tmp")
    assert not temp.exists(), temp
    temp.write_bytes((json.dumps(data, ensure_ascii=True, indent=2) + "\n").encode())
    assert load(temp) == data
    os.replace(temp, path)
    assert load(path) == data


def output(args, root=R):
    return subprocess.check_output(args, cwd=root, encoding="utf-8").strip()


def git(*args, root=R):
    return output(["git", "--no-pager", "-C", str(root), *args])


def context(head, label):
    name = f"preflight-818-{label}.json"
    subprocess.run(["pwsh", "-NoProfile", "-NonInteractive", "-File",
                    str(C / "preflight-818.ps1"), "-ExpectedContentHead", head,
                    "-ReceiptName", name], check=True)
    return load(L / name)


def runtime():
    from build_manifest import build_manifest, sha256
    expected = load(S / "batch-105-acceptance-817.json")["runtime"]
    manifest = load(R / "manifest.json")
    assert manifest == build_manifest(R) and manifest["contentVersion"] == VERSION
    count = 0
    for section, entries in manifest.items():
        if not isinstance(entries, dict):
            continue
        for name, value in entries.items():
            path = R / Path(*name.split("/"))
            binary = section in {"images", "audio", "listeningTaskAudio", "listeningTaskImages"}
            assert (sha(path.read_bytes()) if binary else sha256(path)) == value, name
            count += 1
    actual = dict(contentVersion=VERSION, runtimeHashesVerified=count,
                  manifestSha256=sha((R / "manifest.json").read_bytes()),
                  unchangedSinceTeaching=TEACHING)
    assert actual == expected and count == 8469
    assert not git("diff", TEACHING, "--", "manifest.json", "kanji", "words", "strokes",
                   "articles", "tools", ".gitattributes", ".github/workflows")
    return actual


def start():
    state = load(C / "progress.json")
    assert (state["checkpoint"], state["batch"], state["status"]) == (817, "105", "continue")
    assert state["execution817CoordinatorCheckpoint"]["savedCommit"] == HEAD
    raw = (L / "request.txt").read_bytes()
    text = raw.decode("utf-8-sig")
    embedded = json.loads(text.split(
        "Current execution checkpoint (complete historical state remains at checkpointHistory paths):", 1)[1])
    assert embedded["checkpoint"] == 817
    assert embedded["execution817CoordinatorCheckpoint"]["savedCommit"] == HEAD
    save(L / "progress-before-818.json", state)
    record = dict(execution=818, batch="105", startedAt=now(), startingHead=HEAD,
        androidHead=APP, freshOriginMain=None,
        scope="SAME105 accepted signed owner fast-forward publication; terminal CI/exact public ZIP/signed evidence/verified owner issue/full-history checkpoint, then yield before106. No runtime edits or new reviewer/native/HOST/image work.",
        request=dict(sha256=sha(raw), bytes=len(raw), characters=len(text), lines=len(text.splitlines()),
            completeFileLoadedAndCheckpointParsed=True,
            limits="Entire request loaded/decoded and embedded checkpoint parsed before implementation. Operative contract, complete approved issue and final817 inspected directly; historical middle parsed, not freshly semantically re-reviewed."),
        runnerPreflight=load(L / "preflight-818.json"),
        artifactPathPreflight="Approved committed source packets/frozen workspace inputs/control helpers only; optional historical-session recipes not accessed.",
        runtime=runtime(), parentLockTouched=False, actualNewPermissionDenials=[])
    save(L / "starting-state-818.json", record)
    updated = copy.deepcopy(state)
    updated["execution818StartingState"] = record
    updated.update(stage="batch-105-accepted-publication-in-progress",
                   nextAction=record["scope"], blocker=None)
    assert all(updated[k] == v for k, v in state.items() if k not in {"stage", "nextAction", "blocker"})
    assert load(C / "progress.json") == state
    save(C / "progress.json", updated, replace=True)
    print("SAME105 publication starting scope persisted; complete live history preserved.", flush=True)


def readiness():
    context(HEAD, "readiness")
    subprocess.run(["git", "-C", str(R), "fetch", "--quiet", "origin", "main"], check=True)
    main = git("rev-parse", "origin/main")
    assert git("merge-base", main, HEAD) == main, "Main advanced: merge/reconcile/revalidate before publication"
    assert main == MAIN
    accepted = load(S / "batch-105-acceptance-817.json")
    assert accepted["localBatchAcceptanceComplete"] and accepted["runtimeAccepted"]
    assert accepted["reviewClosed"] == [MEMBER] and not accepted["runtimePublished"]
    assert accepted["authoredSnapshot"] == accepted["reviewedSnapshot"] == TEACHING
    assert accepted["pythonTestsPassed"] == 377 and accepted["validatorErrors"] == 0
    assert accepted["sourceAudit"]["baselineRuntimeHashesPreserved"] == 8466
    assert accepted["sourceAudit"]["sourceRow"] == 116
    for row in accepted["checks"]:
        packed = (R / row["archive"]).read_bytes()
        assert sha(packed) == row["archiveSha256"]
        assert sha(gzip.decompress(packed)) == row["rawSha256"]
        assert row["exitCode"] == 0
    indexes = {}
    for name in ["batch-105-acceptance-817", "batch-105-reconciliation-816",
                 "batch-105-rendered-815"]:
        rows = load(V / name / "artifact-index.json")
        for row in rows:
            assert sha((V / name / row["file"]).read_bytes()) == row["sha256"]
        indexes[name] = len(rows)
    previous = load(S / "execution-816.json")
    for row in previous["checks"]:
        raw = (V / "batch-105-reconciliation-816" / row["archive"]).read_bytes()
        assert sha(raw) == row["archiveSha256"]
        assert sha(gzip.decompress(raw)) == row["rawSha256"]
        assert row["exitCode"] == (1 if row["name"] == "batch-audit" else 0)
    decision = load(V / "batch-105-reconciliation-816" / "disposition.json")["acceptanceDecision"]
    assert not decision["consequentialUnresolvedTeachingDefects"]
    assert decision["nativeRouteExecutionAccepted"] and decision["independentRenderedReviewClosed"]
    from check_content_budget import MAX_ENTRIES, MAX_COMPRESSED, MAX_INFLATED, MAX_RETAINED
    assert (MAX_ENTRIES, MAX_COMPRESSED, MAX_INFLATED, MAX_RETAINED) == (
        18000, 42 * 1024**2, 80 * 1024**2, 56 * 1024**2)
    save(L / "publication-readiness-818.json", dict(
        execution=818, batch="105", head=HEAD, freshOriginMain=main, mainAlreadyAncestor=True,
        mergeRequired=False, runtime=runtime(), acceptanceRecord="batch-105-acceptance-817.json",
        acceptanceChecksRehashed=len(accepted["checks"]), artifactIndexesRehashed=indexes,
        pythonTestsInherited=377, validatorErrors=0, newReviewerNativeHostRuns=0,
        genericLegacyAuditFailurePreserved=True,
        sourceAuditInherited=accepted["sourceAudit"],
        inheritedAcceptance=accepted["inheritedAcceptance"],
        limits="Unchanged accepted runtime/tools/archive policy. Fresh byte/provenance checks, not new linguistic/native/phone/Python-suite execution. All original reports and limitations retained.",
        verifiedAt=now()))
    print("Fresh main is already integrated; accepted evidence/runtime unchanged; publication ready.", flush=True)


def public(phase, head):
    assert git("rev-parse", "HEAD") == head and git("log", "-1", "--format=%G?") == "G"
    assert not git("status", "--porcelain", "--untracked-files=all")
    assert git("ls-remote", "origin", "refs/heads/main").split()[0] == head
    ci, archive = load(L / f"{phase}-ci-818.json"), load(L / f"{phase}-archive-818.json")
    assert ci["headSha"] == head and ci["status"] == "completed" and ci["conclusion"] == "success"
    assert ci["jobs"] and all(j["conclusion"] == "success" for j in ci["jobs"])
    assert archive["commit"] == head and archive["contentVersion"] == VERSION
    assert archive["verifiedRuntimeHashes"] == 8469 and archive["manifestEqual"]
    assert all(archive[k] for k in ["allPublishingBudgetsPassed", "contributorEvidenceExcluded",
                                  "perFileLimitsAndSafePathsPassed"])
    assert sha((C / "artifacts" / f"content-{head[:7]}.zip").read_bytes()) == archive["sha256"]
    runtime()
    return ci, archive


def verify(phase, head):
    context(head, f"verify-{phase}")
    assert git("ls-remote", "origin", "refs/heads/main").split()[0] == head
    runs = json.loads(output(["gh", "run", "list", "--repo", "stop-cran/learning-japanese",
        "--commit", head, "--workflow", "Validate content", "--limit", "5",
        "--json", "databaseId,status,conclusion,headSha"]))
    assert runs and runs[0]["headSha"] == head, "Exact CI not available; preserve pending state"
    with (L / f"{phase}-ci-watch-818.txt").open("xb") as stream:
        subprocess.run(["gh", "run", "watch", str(runs[0]["databaseId"]), "--repo",
            "stop-cran/learning-japanese", "--exit-status", "--interval", "10"],
            stdout=stream, stderr=subprocess.STDOUT, check=True)
    ci = json.loads(output(["gh", "run", "view", str(runs[0]["databaseId"]), "--repo",
        "stop-cran/learning-japanese", "--json", "databaseId,status,conclusion,headSha,workflowName,jobs"]))
    save(L / f"{phase}-ci-818.json", ci)
    path = C / "artifacts" / f"content-{head[:7]}.zip"
    assert not path.exists()
    url = f"https://codeload.github.com/stop-cran/learning-japanese/legacy.zip/{head}"
    result = subprocess.run(["curl.exe", "--fail", "--location", "--silent", "--show-error",
        "--max-time", "180", url, "--output", str(path)], capture_output=True, text=True)
    save(L / f"archive-download-{phase}-818.json", dict(commit=head, url=url,
        exitCode=result.returncode, stdout=result.stdout, stderr=result.stderr))
    result.check_returncode()
    verifier = C / "verify-batch-002-publication.py"
    assert sha(verifier.read_bytes()) == "8d07dcdb04eefa2bef9f1fb66f9a47e0f3711f9328eb15c9da13606ed8b42a6d"
    subprocess.run([sys.executable, "-X", "utf8", "-B", str(verifier), head, str(path),
                    str(L / f"{phase}-archive-818.json")], check=True)
    public(phase, head)


def records():
    context(HEAD, "records")
    ci, archive = public("accepted", HEAD)
    accepted = load(S / "batch-105-acceptance-817.json")
    prior = load(S / "batch-104-publication.json")["counts"]
    assert prior["projectPublishedAdditions"] == 131 and prior["projectNewNecessarySupportWords"] == 129
    counts = dict(accepted["sourceAudit"]["currentCounts"])
    counts.update(batchPublishedAdditions=1, projectPublishedAdditions=132, remainingAdditions=1096,
        batchNewNecessarySupportWords=1, projectNewNecessarySupportWords=130,
        batchChangedReusedArticles=0, allMappedReciprocalPairs=1, mappedDirectedLinks=2,
        activatedBaselinePairs=0)
    path = S / "batch-105-publication.json"
    record = load(path)
    record["prePublication818State"] = copy.deepcopy(record)
    record.update(execution=818, status="published-verified-bounded-compatible-client-owner-testing",
        recordedAt=now(), acceptedCommit=HEAD, integratedCommit=HEAD, publishedCommit=HEAD,
        remoteVerified=True, remoteMainVerified=HEAD, ci=ci, archive=archive,
        immutablePublicArchive=archive, counts=counts, contentVersion=VERSION,
        qualifiedAndroidHead=APP, runtimePublished=True, published=[MEMBER],
        localBatchAcceptanceComplete=True, fullBatchAcceptanceComplete=False,
        fullBatchAcceptanceDefinition="Accepted teaching delivery verified; terminal evidence/CI/ZIP/issue/checkpoint still required before next batch.",
        projectPublishedAdditions=132, remainingAdditions=1096,
        inheritedAcceptance=accepted["inheritedAcceptance"], limits=accepted["inheritedAcceptance"]["limits"],
        runtimeAcceptanceScope=accepted["runtimeAcceptanceScope"],
        compatibleClient="Android125 curated readings and approved132 direct kanji pair guards required; old clients ignore them. Qualified bf30 backport carries only approved guards/schema bridges, not unrelated latest-main behavior.",
        normalSignatureStatus="G; normal owner-scoped fast-forward; no bypass/amendment/force push.",
        publicationIdentity="stop-cran process-scoped token only; global romanko-ms unchanged.",
        remainingPublicationGates=["Terminal signed evidence/green CI/every public ZIP hash/verified owner issue/full-history checkpoint before106."],
        nextAction="Verify terminal evidence CI/public ZIP/owner issue; checkpoint and yield before106.")
    save(path, record, replace=True)
    ledger_path = S / "batch-105-progress.json"
    ledger = load(ledger_path)
    ledger["prePublication818State"] = copy.deepcopy(ledger)
    ledger.update(status=record["status"], published=[MEMBER], publishedCommit=HEAD,
        publishedAdditions=132, remainingAdditions=1096, runtimePublished=True,
        publicationRecord=path.name, fullBatchAcceptanceComplete=False,
        pendingGates=record["remainingPublicationGates"], nextAction=record["nextAction"])
    ledger["sourceRowDisposition"] = dict(ledger["sourceRowDisposition"],
        status=record["status"], published=True, publishedCommit=HEAD)
    ledger["limits"].append("Bounded818 accepted runtime delivery verified at signed817 SHA; terminal evidence gates pending. Earlier pending flags remain historical, not current defects. No new native/reviewer/phone claim.")
    save(ledger_path, ledger, replace=True)
    save(S / "execution-818.json", dict(
        schemaVersion=1, execution=818, batch="105", startingState=load(L / "starting-state-818.json"),
        readiness=load(L / "publication-readiness-818.json"), publicationRecord=path.name,
        status=record["status"], acceptedCommit=HEAD, runtimeBytesUnchanged=True,
        runtime=runtime(), runtimeAccepted=True, runtimePublished=True, counts=counts,
        ci=ci, immutablePublicArchive=archive, newReviewerNativeHostRuns=0, newImageInspection=False,
        parentLockTouched=False, optionalHistoricalHelpersAccessed=False, actualNewPermissionDenials=[],
        physicalPhoneAcceptance="outstanding", generalReleaseAcceptance="outstanding",
        wholeSetAcceptance="outstanding", wholeProjectComplete=False, nextBatchStarted=False,
        limits=accepted["inheritedAcceptance"]["limits"],
        nextAction=record["nextAction"]))
    assert not D.exists()
    D.mkdir()
    for artifact in [Path(__file__), C / "preflight-818.ps1", C / "publish-818.ps1",
        C / "verify-batch-002-publication.py", L / "starting-state-818.json",
        L / "publication-readiness-818.json", L / "preflight-818.json",
        L / "owner-push-accepted-818.json", L / "accepted-ci-818.json",
        L / "accepted-ci-watch-818.txt", L / "accepted-archive-818.json",
        L / "archive-download-accepted-818.json", L / "token-preflight-diagnostic-818.json",
        L / "publish-818-original-token-preflight.ps1"]:
        (D / (artifact.name + ".gz")).write_bytes(gzip.compress(artifact.read_bytes(), mtime=0))
    save(D / "artifact-index.json", [dict(file=p.name, bytes=p.stat().st_size,
         sha256=sha(p.read_bytes())) for p in sorted(D.iterdir())])
    state = load(C / "progress.json")
    updated = copy.deepcopy(state)
    updated["execution818AcceptedPublication"] = record
    updated.update(stage="batch-105-published-awaiting-terminal-evidence", nextAction=record["nextAction"])
    save(C / "progress.json", updated, replace=True)
    print("Accepted delivery verified; terminal evidence ledgers prepared for normal signing.", flush=True)


def comment(head):
    context(head, "comment")
    ci, archive = public("terminal", head)
    assert git("rev-parse", f"{head}^") == HEAD
    p = load(S / "batch-105-publication.json")
    body = f"""Batch **105: 勁** and necessary support **雄勁 (ゆうけい)** are published and verified for **bounded compatible-client owner testing**. One new kanji/one support article, not an N1 vocabulary deck. ONE all-mapped reciprocal pair/TWO directions, ZERO activated baseline pairs/reused edits; generated NINE-stroke geometry, labelled modern-shape mnemonic, no adopted etymology.

Authored/reviewed `{TEACHING}`; combined-tested `{p['combinedTestedSnapshot']}`; signed local acceptance/accepted publication `{HEAD}`; terminal evidence/remote main `{head}`. Both complete original blind **claude-opus-5.5 / gpt-6.1-sol** reports810, HOST811, native813, exact supplemental source814, original-session rendered confirmations815 and reconciliation816 retained. Both articles CLEAN for correctness/scoped coverage/comprehensibility within their bounded reviewed scope. No consequential unresolved in-scope defect established. No new reviewer/native/HOST/image runs818 and no retroactive certification of historical executions.

Full metadata **on ケイ / kun つよ.い** preserved; curated **[ケイ]/[]**, sole actual key **けい**, displayed **ケイ**, good/done1of1. Legacy raw つよい remains reference-visible; 勁い is source-only/search spelling, not a useful ordinary production prompt. Four direct symmetric NONTRANSITIVE kanji guard pairs/six direct word pairs, not synonym cliques. Semantic acceptance covers **192 exact target-relative option sets and live default only**, not every future pool or wrong-choice-pair relation. Default N1/All/custom retain ALL THREE 功/劾/剖 and ZERO fallback; native filtered pool retains TWO 功/劾 with ONE fallback per seed; HOST pool retains NONE. Claude's LOW-confidence future-pool 活気/もりもり hypotheses remain **partially resolved/nondefects**, GPT reports no actionable hypothesis; original810 withdrawn history and differing judgments preserved, no forced agreement or new exclusions.

Delivered **900x2000** readability/distinguishability, four-font/default14Han and whole 雄勁 including 勁/巠/刂 accepted within supplied scope. **Original1080x2400 pixels, equal comprehension, fallback-face identity, every-request retention and phone readability remain UNVERIFIED.** Both family tool streams serial/zero overlap. Claude35calls/seven redundant boundary attempts/three partial ranged returns versus six exact full forced reads; GPT28/no extras; ClaudeTWO/GPTONE compactions retained. Hashes/access do not prove equal reading depth or retention. Missing word header, no native word-quiz samples, partial table/duplicate viewports and shared UI limits remain disclosed. Nine ungraded reference-point touches/model unavailable/intentional recall reveal grade1 are NOT recognition, handwriting mastery or effectiveness evidence.

Fresh main `{MAIN}` remains ancestor: no merge or teaching change. Existing **377 Python cases**, validator0errors, regenerated unchanged manifest, vocabulary2122/2431 pilot, exact frozen-source/baseline/membership/all-reading/direct-guard/all-mapped-link/pinned-geometry audits inherited from unchanged816/817 and rehashed818. Generic legacy batch auditor's KeyError:supportMappings remains preserved; named current-schema816/817 audit passed without invented legacy fields/tool edits/waiver. All **8469 runtime hashes**, version `{VERSION}`, unchanged since reviewed teaching. HOST811 FIVE cases/zero failures/errors/skips; native813 TWO terminalcase0 results, actual production **ContentSync ONCE** and N1 meaning/curated-reading/drawing/article/Back/offline routes inherited, NOT rerun818. All original source/process/permission/OOM/ANR/routing limits preserved.

Accepted CI [{p['ci']['databaseId']}](https://github.com/stop-cran/learning-japanese/actions/runs/{p['ci']['databaseId']}) and terminal CI [{ci['databaseId']}](https://github.com/stop-cran/learning-japanese/actions/runs/{ci['databaseId']}) green. BOTH exact immutable public ZIPs preserve **every8469 runtime manifest entry/hash** and manifest; terminal **{archive['zipEntries']}entries / {archive['compressedBytes']}compressed / {archive['inflatedBytes']}inflated / {archive['retainedBytes']}retained bytes** passes unchanged18000entries/42MiB/80MiB/56MiB/per-file/media/safe-path guards. Contributor evidence excluded. Normal signed stop-cran process-scoped fast-forwards; global romanko-ms unchanged.

Published **132/1228 additions;1096 remain**. Collection1128kanji/5079words/137N1labels/142named-source members plus separate妖. SIX separately placed 保案派第策結 retain easierN2 levels/no accepted-addition credit/no duplicate/relevel. Necessary support articles130 project-wide, NOT delivered N1 vocabulary. Compatible **stop-cran/kanji-cards-android#125** and **stop-cran/kanji-cards-android#132** required; old clients ignore curation/guards. Qualified `{APP}` carries approved guard and schema-only bridges, not unrelated latest application main.

Durable `docs/n1-sources/batch-105-publication.json`, `batch-105-acceptance-817.json`, `execution-818.json` and original810/811/813/814/815/816/817 evidence. Historical pending flags preserved with scoped discharge; all original reports and limits intact. Parent13320 retains runner.lock: no child acquire/delete/unlock/readprobe; approved workspace evidence only, no optional historical-session helpers. No actual new permission denial. **Physical-phone/general-release/whole-set acceptance outstanding; project incomplete.** Checkpoint818 yields before106; no next batch/second runner.
"""
    path = C / "batch-105-publication-comment.txt"
    assert not path.exists()
    path.write_bytes(body.encode("utf-8"))
    save(L / "terminal-publication-818.json",
         dict(head=head, ci=ci, archive=archive, issueBodySha256=sha(path.read_bytes())))


def finish(head):
    role = context(head, "finish")
    ci, archive = public("terminal", head)
    receipt = load(L / "issue-818-reread.json")
    remote = json.loads(output(["gh", "api",
        f"repos/stop-cran/learning-japanese/issues/comments/{receipt['id']}"]))
    body = (C / "batch-105-publication-comment.txt").read_bytes()
    assert receipt["user"]["login"] == remote["user"]["login"] == "stop-cran"
    assert receipt["body"] == remote["body"] == body.decode("utf-8")
    assert output(["gh", "api", "user", "--jq", ".login"]) == "romanko-ms"
    assert not (S / "batch-106-progress.json").exists()
    publication = load(S / "batch-105-publication.json")
    ledger = load(S / "batch-105-progress.json")
    assert ledger["membership"] == ledger["reviewClosed"] == ledger["published"] == [MEMBER]
    for row in load(D / "artifact-index.json"):
        assert sha((D / row["file"]).read_bytes()) == row["sha256"]
    before, state = load(L / "progress-before-818.json"), load(C / "progress.json")
    next_action = (
        f"Batch105 accepted/published/verified at {head}; yield before106. Next coordinator ONE bounded106 "
        "source-preparation checkpoint from remaining frozen rows below15. Read entire request/finalcheckpoint/"
        "approvedissue; preserve FULLlivehistory. Verify whollyclean signedheads/freshmain/liveparentancestry/"
        "decodedlauncher/exactsession. Parent13320 ownsrunner.lock: NOchildacquire/delete/unlock/readprobe. "
        "Approvedcontrol/committedsource/frozeninputs only, no optional historicalsessionrecipes. "
        "Preserve/report/yield actualnewdenial/signinghang/uncertainownership. Every original fullfamily/"
        "readingallocation/usefulness/fullbaseline/sourceorder/curation/directNONTRANSITIVEguards/"
        "allmapped+activatedlinks/pinnedstrokes/newHanfonts/TWOserialblinddifferentfamilies/serialinternaltools/"
        "originalsessionconfirmations/non-skippedAndroid/native/combinedmain/normalsigning/ownerfastforward/"
        "terminalgreenCI/EVERYimmutableZIPmanifesthash/unchanged18000entries42MiBcompressed80MiBinflated56MiBretained/"
        "perfilemediasafepaths/verifiedownerissue gates remainMANDATORY. Published132/1228;1096acceptance-remainder;"
        "1128kanji5079words137N1labels142namedmembers+separate妖;130necessarysupportsNOTN1vocabulary. "
        "Sixseparatelyplaced保案派第策結retainN2/noacceptedcredit/noduplicate/relevel. "
        "105勁/ONEsupport雄勁/nolevel/ZEROreusedchanges/ONEallmappedpairTWOdirectionsZEROactivatedbaselinepairs/"
        "NINEpinnedstrokes/modernshapemnemonicNOTetymology/fullonケイkunつよ.い/selectedケイ[]/soleけいdisplayケイ/"
        "gooddone1of1/legacyつよいreferencevisible/勁いsearchonly. FOURdirectkanjiguardsSIXwordpairsNOTcliques. "
        "Text810/HOST811FIVEnonskipped/native813TWOcase0/actualContentSyncONCE/source814/rendered815/reconciliation816/"
        "signedacceptance817 inheritedNOTnew818runs. 192exacttargetrelativeoptionsets+LIVEdefaultONLYnotallfuturepools. "
        "DefaultN1AllcustomTHREE功劾剖ZEROfallback;nativefilteredTWO功劾ONEfallback;HOSTNONE. "
        "ClaudeLOWfuturepool活気もりもりPARTIALLYRESOLVEDnondefects/GPTnoactionablehypothesis/"
        "original810withdrawnhistorypreserved/noforcedagreement/newguard. "
        "Bothserialtoolszerooverlap;Claude35calls7redundantboundaryattempts3partialrangesversus6exactfullforcedreads;"
        "GPT28noextras;ClaudeTWO/GPTONEcompactions. Delivered900x2000fourfontsdefault14Hanwhole雄勁including勁巠刂"
        "boundedreadabilityONLY;originalpixels/equalcomprehension/fallbackface/everyrequestretention/native-speaker/"
        "phone/effectivenessUNVERIFIED. Missingwordheader/nonativewordquiz/partialtable/duplicateviewports/sharedUI"
        "limitsretained;9ungradedreferencetouches/modelunavailable/intentionalrecallrevealgrade1NOTmastery. "
        "377Python816/validator0errors817/manifestunchanged/vocabulary2122of2431pilot/"
        "source-baseline-membership-links-geometry-current816817audits and8469runtimehashes/version5572c6c467e6b73b/"
        "BOTHpublicCI+ZIPhashesownerissueverified818;genericlegacyKeyErrorsupportMappingspreservedNOTtoolchange/"
        "fabricatedfields/waiver. CompatibleAndroid#125+#132required;oldclientsignore. QualifiedsignedAPP"
        "bf30cdead8515739bc0e671d57a54b9a3109dd46approvedguard+schemaonlyNOTlatestmain. Original733/734andALL"
        "priorprocess/source/readdepth/permission/OOM/ANR/routing/rendition/phone/historicalpendinglimitsNOTretroaccepted;"
        "historicalExecution817Before818Publication.nextAction retainsALLpriorgates. "
        "Physicalphone/generalrelease/whole-setoutstanding;projectincomplete. No106started/authoragents/"
        "concurrentheavywork/secondrunner/signingretry/guardincrease.")
    publication.update(finalPublishedCommit=head, remoteMainVerified=head, terminalCi=ci,
        terminalImmutablePublicArchive=archive, issueUpdate=receipt["html_url"],
        fullBatchAcceptanceComplete=True, remainingPublicationGates=[],
        nextAction=next_action)
    save(C / "batch-105-publication-checkpoint.json", publication)
    save(L / "batch-105-publication-checkpoint.json", publication)
    checkpoint = dict(schemaVersion=1, execution=818, checkpoint=818, batch="105",
        savedCommit=head, signature="G", remoteMainVerified=head, acceptedCommit=HEAD,
        acceptedCi=publication["ci"]["databaseId"], terminalCi=ci["databaseId"],
        bothImmutablePublicArchivesVerified=True, runtimeHashesPerArchive=8469, contentVersion=VERSION,
        reviewedRuntimeBytesUnchanged=True, dedicatedWorktreesClean=True,
        ownerIssueAuthorAndBodyVerified=True, issueUpdate=receipt["html_url"], globalIdentityUnchanged=True,
        parentLockTouched=False, optionalHistoricalHelpersAccessed=False, actualNewPermissionDenials=[],
        status="continue", stage="batch-105-published-verified-before-106",
        publishedAdditions=132, remainingAdditions=1096, lastPublishedCommit=head,
        nextAction=next_action, blocker=None, runtimeAccepted=True, runtimePublished=True,
        localBatchAcceptanceComplete=True, fullBatchAcceptanceComplete=True,
        reviewClosed=[MEMBER], published=[MEMBER], newReviewerNativeHostRuns=0,
        physicalPhoneAcceptance="outstanding", generalReleaseAcceptance="outstanding",
        wholeSetAcceptance="outstanding", wholeProjectComplete=False, nextBatchStarted=False,
        finalRunnerPreflight=role, originalRootKeysCompared=len(before),
        allOriginalHistoricalValuesPreserved=True)
    state["execution818CoordinatorCheckpoint"] = checkpoint
    state["batch105PublicationCheckpoint"] = publication
    state["batch105PublicationIssueReceipt"] = dict(id=receipt["id"], url=receipt["html_url"],
        author="stop-cran", bodySha256=sha(body), verified=True)
    changed = {"checkpoint", "status", "stage", "lastPublishedCommit", "remainingAdditions",
               "nextAction", "blocker", "unmetAcceptanceGates"}
    state["historicalExecution817Before818Publication"] = {k: copy.deepcopy(before[k]) for k in changed}
    state.update(checkpoint=818, status="continue", stage=checkpoint["stage"],
        lastPublishedCommit=head, remainingAdditions=1096, nextAction=next_action, blocker=None)
    state["unmetAcceptanceGates"] = copy.deepcopy(before["unmetAcceptanceGates"])
    state["unmetAcceptanceGates"][0] = (
        "Remaining1096 issue60 source-bounded additions not review-closed/published; six separately placed "
        "earlier-level source members require accounted dispositions, not duplicates or issue60 acceptance credit. "
        "All original per-batch and whole-set gates remain mandatory.")
    assert all(state[k] == v for k, v in before.items() if k not in changed)
    assert state["checkpoint"] == before["checkpoint"] + 1
    save(C / "progress.json", state, replace=True)
    save(L / "completed-checkpoint-818.json", checkpoint)
    print(f"Checkpoint818 persisted; published132 remaining1096; {receipt['html_url']}", flush=True)


if __name__ == "__main__":
    {"start": start, "readiness": readiness, "context": context, "verify": verify,
     "records": records, "comment": comment, "finish": finish}[sys.argv[1]](*sys.argv[2:])
