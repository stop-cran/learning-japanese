import copy
from datetime import datetime, timezone
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

C = Path(__file__).resolve().parent
R = C.parent / "learning-japanese"
L = C / "logs" / "e5915513-68ba-4635-b817-0d21a17918c3"
D = R / "docs" / "n1-reviews" / "batch-105-native-labels-814"
E = R / "docs" / "n1-sources" / "execution-814.json"
BASE = "2c2075516ea14b0002eade568fefd8b21ae025b6"
APP = "bf30cdead8515739bc0e671d57a54b9a3109dd46"
spec = importlib.util.spec_from_file_location("sources814", C / "prepare-native-label-sources-814.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
load, save, digest, git = module.load, module.save, module.digest, module.git


def verify(head, clean):
    p = load(C / "progress.json")
    assert (p["checkpoint"], p["status"], p["batch"]) == (813, "continue", "105")
    runner = load(C / "runner.json")
    assert (runner["status"], runner["pid"], runner["sessionId"]) == ("running", 13320, L.name)
    for root, expected in [(R, head), (C.parent / "kanji-cards-android", APP)]:
        assert git("rev-parse", "HEAD", root=root) == expected
        assert git("log", "-1", "--format=%G?", root=root) == "G"
        if clean or root != R:
            assert not git("status", "--porcelain", "--untracked-files=all", root=root)
    return p


def prepare():
    p = verify(BASE, False)
    assert not git("diff", "--name-only", BASE)
    assert all(x.startswith("docs/n1-reviews/batch-105-native-labels-814/")
               for x in git("ls-files", "--others", "--exclude-standard").splitlines())
    assert "0 error(s)" in (L / "validate-814.txt").read_text(encoding="utf-8-sig")
    runtime = module.runtime()
    selection = load(D / "sampled-source-selection.json")
    samples = load(D / "native-samples.json")
    disposition = load(D / "finite-semantic-disposition.json")
    assert selection["runtime"] == runtime
    assert selection["completeFamilies"] == 23 and selection["completeArticleBodies"] == 10
    assert (samples["samples"], samples["uniqueOrderedSets"]) == (64, 52)
    assert not disposition["runtimeCorrectionNeeded"] and not disposition["independentRenderedReviewClosed"]
    assert sum(len(x["seeds"]) for x in samples["orderedOptionSetsAndSeeds"]) == 64
    for pool in samples["poolMembershipInOrder"]:
        rows = [x for x in samples["orderedOptionSetsAndSeeds"] if x["pool"] == pool]
        assert sorted(s for row in rows for s in row["seeds"]) == list(range(16))
    for row in samples["orderedOptionSetsAndSeeds"]:
        assert len(row["orderedOptions"]) == 4
        assert len({x[0] for x in row["orderedOptions"]}) == 4
        assert ["勁", "strong; taut"] in row["orderedOptions"]
    receipts = D / "receipts"
    receipts.mkdir()
    for source in [C / name for name in (
            "preflight-814.ps1", "start-sources-814.py", "prepare-native-label-sources-814.py",
            "finish-native-label-sources-814.py", "post-native-label-sources-814.ps1"
    )] + [L / name for name in ("preflight-814.json", "starting-state-814.json",
                                "validate-814.txt", "manifest-814.txt")]:
        target = receipts / (source.name + ".gz")
        target.write_bytes(gzip.compress(source.read_bytes(), mtime=0))
        assert gzip.decompress(target.read_bytes()) == source.read_bytes()
    index = []
    for path in sorted(D.rglob("*")):
        if path.is_file():
            index.append({"file": path.relative_to(D).as_posix(), "bytes": path.stat().st_size,
                          "sha256": digest(path.read_bytes())})
    save(D / "artifact-index.json", index)
    save(E, {
        "schemaVersion": 1, "execution": 814, "batch": "105",
        "recordedAt": datetime.now(timezone.utc).isoformat(),
        "stage": "five-new-native-label-sources-inspected-awaiting-original-family-rendered-confirmations",
        "startingState": p["execution814StartingState"], "sourceSnapshot": BASE,
        "qualifiedAndroidHead": APP, "archiveContentSnapshot": "303a8cf752f70c024626c9e4e56b9b7b317a41e4",
        "sourcePacket": "docs/n1-reviews/batch-105-native-labels-814",
        "sourceSelection": selection, "finiteDisposition": disposition,
        "sourcePacketArtifacts": index, "nativeSamples": 64, "nativeOrderedOptionSets": 52,
        "nativeFilteredPool": {
            "membersInOrder": samples["poolMembershipInOrder"]["randomN1Subset"],
            "curatedRetained": ["功", "劾"], "curatedMissing": ["剖"],
            "fallbackOptionsPerSet": 1,
            "contrast": "Different from HOST811 randomN1Subset811, which retained none of the curated choices."},
        "runtime": runtime,
        "automatedValidation": {
            "validatorErrors": 0, "manifestRegenerated": True, "manifestUnchanged": True,
            "whitespaceDiffCheckPassed": True, "allRuntimeHashesVerified": True,
            "nativeSamplesExactOrderedSetsAndSeedCoverageVerified": True,
            "fullPublicationValidation": "pending; not claimed at this docs-only source checkpoint"},
        "diagnostic": {
            "initialAttempt": "Source preparation asserted normalized checkout bytes equalled unnormalized Git blobs; it failed before comparison-body archive or evidence commit. All ten previously published article blobs actually contain CRLF and exactly equal their checkout bytes.",
            "disposition": "Corrected the helper to accept exact bytes or normalize BOTH sides, recorded exact checkout/blob hashes and CRLF line counts, and resumed only after asserting byte equality of the three already generated source files. No runtime, source input, accepted record, signing, permission or guard changed.",
            "originalFailureEvidence": str(L / "output.jsonl"),
            "limits": "Final corrected helper archived; no claim to a separately preserved pre-fix helper file."},
        "independentReviewersLaunched": 0, "nativeExecuted": False,
        "inheritedNativeEvidence": "docs/n1-sources/execution-813.json",
        "independentRenderedReviewClosed": False,
        "newNativeOrdinarySenseFallbackSemanticAcceptance": "UNVERIFIED pending two serial original-family rendered confirmations",
        "runtimeChanged": False, "manifestChanged": False, "runtimeAccepted": False, "runtimePublished": False,
        "reviewClosed": [], "published": [], "nextBatchStarted": False,
        "parentLockTouched": False, "optionalHistoricalHelpersAccessed": False, "actualNewPermissionDenials": [],
        "publishedAdditions": 131, "remainingAdditions": 1097,
        "lastPublishedCommit": p["lastPublishedCommit"],
        "physicalPhoneAcceptance": "outstanding", "generalReleaseAcceptance": "outstanding",
        "wholeProjectComplete": False,
        "nextAction": "SAME105 two serial ORIGINAL-session family rendered confirmations on a frozen identified snapshot, using complete original reports, native813 images/ordered options, original810 textual and811 HOST evidence, and this five-label source supplement. No new blind initial reviews or native rerun required absent a new defect. All prior source/review/read-depth/process/history and current-main/validation/signing/publication gates remain unchanged."})
    print("Source packet, exact samples/seed coverage, all8469 runtime hashes and evidence provenance verified.")


def finish():
    before = load(L / "progress-before-814.json")
    head = git("rev-parse", "HEAD")
    current = verify(head, True)
    assert git("rev-parse", "HEAD^") == BASE
    changed = git("diff", "--name-only", BASE, head).splitlines()
    assert changed and all(x.startswith("docs/n1-reviews/batch-105-native-labels-814/")
                           or x == "docs/n1-sources/execution-814.json" for x in changed)
    runtime = module.runtime()
    e = load(E)
    assert e["runtime"] == runtime
    for row in load(D / "artifact-index.json"):
        path = (D / row["file"]).relative_to(R).as_posix()
        blob = subprocess.check_output(["git", "-C", str(R), "show", head + ":" + path])
        assert digest(blob) == row["sha256"], path
    posted, reread = load(L / "issue-814-posted.json"), load(L / "issue-814-reread.json")
    body = C / "batch-105-native-label-sources-814-issue-body.txt"
    assert posted["author"] == reread["user"]["login"] == "stop-cran"
    assert posted["bodySha256"] == digest(body.read_bytes())
    assert body.read_bytes().decode("utf-8") == reread["body"]
    assert posted["url"] == reread["html_url"]
    next_action = (
        f"SAME105 checkpoint814 signed LOCAL source supplement HEAD{head}; qualifiedAndroid{APP}. "
        "Read docs/n1-sources/execution-814.json and docs/n1-reviews/batch-105-native-labels-814/. "
        "FIVE new native fallback labels亥/巳/彗/柚/鵬: complete5rawKANJIDIC2records/allEnglishmeanings+"
        "23completeJMdictfamilies/allrestrictionsandsenses+10actualcompletekanji/supportbodies source-inspected. "
        "Pinned compressedANDXMLhashes verified; exact fullfamilies/rawrecords/bodyblobhashes/CRLFlines preserved. "
        "Kanaほうきhomophones preservedbutNOT彗senses; broadcitron/phoenixglosses NOT unrestrictedidentity. "
        "Coordinator no target-relativeambiguity established/no teachingchange; NOTindependentreviewcredit. "
        "All64native samples returnedas52exactorderedsets/seeds; exactpoolmembers preserved. Actualnative"
        "randomN1Subset16 retainsTWOcurated功劾/missing剖/ONEfallbackperseed, unlikeHOST811subsetwithNONE. "
        "DefaultN1/All/customallTHREEcurated功劾剖/ZEROfallback; five newlabels+凌sampledfallback. "
        "NEXT SAME105 TWO SERIAL ORIGINAL-family renderedconfirmations from batch-105-reconciliation.json/"
        "batch-105-initial-executions-810.json, originalcomplete reports, actual813PNG/route/rasters/"
        "orderedoptions, original810textualand811HOSTfiniteevidence plus814sources. "
        "Use samefrozenidentifiedsnapshot/serialpertoolaccess; eachreviewerprocessexitverifiedbeforenext; "
        "noeditfrozensnapshot/no newblindinitials/no unnecessarynative rerun. Actualmodelcatalog/identity/"
        "supportedresume/tools restriction/evidence mandatory. Newnativeordinarysecondarysensesemantic"
        "acceptance remainsUNVERIFIED until BOTH original-family rendered confirmations; sourcepacketand"
        "native mechanicsNOTwholebatchacceptance. Preserveoriginalfindings/withdrawnhypotheses/optional/"
        "readdepth/process/source/historylimitswithoutretroacceptance. Anyconsequentialdefect:exactsource/"
        "minimalcorrection/audits/manifest/normalsignednewfreeze/BOTHoriginalfamilyconfirmations. "
        "All8469runtimehashes/version5572c6c467e6b73b/manifestunchanged;validator0errors/regeneratedmanifestunchanged. "
        "Freshnative813BOTHterminalcase0/116.338s/fullproductionContentSyncONCE signed303a8cf7/"
        "1128kanji5079words137N1/0problems/896directguards192NONTRANSITIVE384wordguards64builderchoices/"
        "soleけいdisplayケイpersisted1of1/nineungradedreferencetouchstrokes/modelunavailable/Back/offline/"
        "onepairtwodirections/ownedemulatorANDQEMUstopped inheritedNOTrepeated. Fullon[ケイ]/kun[つよ.い]"
        "preserved/selected[ケイ]/[];legacyfeedbackrawつよいvisible/curationnotallreferencedisplay. "
        "Actualall14Han/fourfonts-default/56probes4wordrasters3panels;813coordinator17of37PNGat"
        "900x2000renditionsof1080x2400/20notfreshlyviewed/duplicatearticle08-09/partialhorizontaltable/"
        "actualfallbackfaceunknown limitations preserved. Physicalphone/generalrelease/whole-setoutstanding. "
        "All priorgates retained verbatim in historicalExecution813Before814Sources.nextAction and"
        "execution813CoordinatorCheckpoint: combinedcurrentmain/nonrewritingmerge/changedteachingreview/"
        "fullrequiredPython/vocabulary/baseline-membership-links/manifestbudget/normalsigning/"
        "ownerfastforward/terminalgreenCI/EVERYimmutableGitHubZIPmanifesthash/unchanged18000entries"
        "42MiBcompressed80MiBinflated56MiBretained/perfilepathmedia/verifiedownerissue remainMANDATORY. "
        "No106/unreviewedpush/authoragents/concurrentheavywork/secondrunner/signingretry/guardincrease. "
        "Freshsignedheads/checkpoint/whollyclean/freshmain/liveparentancestry/decodedlauncher/exactsession"
        "required;parent13320ownsrunner.lock:nochildacquire/delete/unlock/readprobe. "
        "Approvedcontrol/committedsource/frozeninputs only;preserve/report/yield actualnewdenial/signinghang/"
        "uncertainownership. QualifiedAndroidapprovedpairguard+schemaonly NOTlatestappmain. "
        "Published131/1228/remainder1097unchanged;unaccepted勁/ONEsupport雄勁 notdeliveredN1vocabulary. "
        "CompatibleAndroid125+132required;oldclientsignore. Projectincomplete."
    )
    checkpoint = {
        "schemaVersion": 1, "execution": 814, "checkpoint": 814, "batch": "105",
        "status": "continue", "stage": "batch-105-new-native-label-sources-inspected-awaiting-original-family-rendered-confirmations",
        "recordedAt": datetime.now(timezone.utc).isoformat(), "savedCommit": head, "signature": "G",
        "qualifiedAndroidHead": APP, "sourceSnapshot": BASE,
        "evidence": "docs/n1-sources/execution-814.json",
        "sourcePacket": "docs/n1-reviews/batch-105-native-labels-814",
        "issueUpdate": posted["url"], "ownerIssueAuthorAndExactBodyVerified": True,
        "fullCharacterRecords": 5, "completeLexicalFamilies": 23, "completeArticleBodies": 10,
        "nativeSamples": 64, "exactOrderedOptionSets": 52,
        "freshSourceHashesVerified": True, "coordinatorTargetAmbiguityEstablished": False,
        "nativeFilteredPoolCuratedRetained": 2, "nativeFilteredPoolFallbackPerSet": 1,
        **runtime, "validatorErrors": 0, "manifestRegenerated": True,
        "runtimeChanged": False, "manifestChanged": False, "runtimeAccepted": False, "runtimePublished": False,
        "independentReviewersLaunched": 0, "nativeExecuted": False,
        "independentRenderedReviewClosed": False,
        "newNativeOrdinarySenseFallbackSemanticAcceptance": "UNVERIFIED pending two serial original-family rendered confirmations",
        "reviewClosed": [], "published": [], "dedicatedWorktreesClean": True,
        "parentLockTouched": False, "optionalHistoricalHelpersAccessed": False, "actualNewPermissionDenials": [],
        "publishedAdditions": 131, "remainingAdditions": 1097, "lastPublishedCommit": before["lastPublishedCommit"],
        "physicalPhoneAcceptance": "outstanding", "generalReleaseAcceptance": "outstanding",
        "wholeProjectComplete": False, "nextBatchStarted": False,
        "finalRunnerPreflight": load(L / "preflight-814-before-issue.json"),
        "nextAction": next_action, "blocker": None,
        "historicalRootKeysCompared": len(before), "allOriginalHistoricalValuesPreserved": True,
    }
    after = copy.deepcopy(current)
    assert "execution814CoordinatorCheckpoint" not in after
    after["execution814CoordinatorCheckpoint"] = checkpoint
    after["execution814StartingState"]["status"] = "signed-local-source-supplement-checkpoint-complete"
    fields = {"checkpoint", "status", "stage", "nextAction", "blocker"}
    for key in fields:
        after[key] = checkpoint[key]
    for key, value in before.items():
        if key not in fields:
            assert after[key] == value, key
    assert after["remainingAdditions"] == 1097 and after["lastPublishedCommit"] == before["lastPublishedCommit"]
    save(L / "checkpoint-814-summary.json", checkpoint)
    temp = C / "progress.json.814-final.tmp"
    save(temp, after)
    assert load(C / "progress.json") == current
    os.replace(temp, C / "progress.json")
    assert load(C / "progress.json") == after
    save(L / "checkpoint-814-final-verification.json", {
        "checkpoint": 814, "savedCommit": head, "signature": "G",
        "allOriginalHistoricalValuesPreserved": True, "originalRootKeysCompared": len(before),
        "dedicatedWorktreesClean": True, "runtimeHashesVerified": 8469,
        "ownerIssueAuthorAndExactBodyVerified": True, "parentLockTouched": False})
    print(json.dumps({"checkpoint": 814, "status": "continue", "savedCommit": head,
                      "historicalKeysPreserved": len(before), "issueUpdate": posted["url"]}, ensure_ascii=True))


if __name__ == "__main__":
    {"prepare": prepare, "finish": finish}[sys.argv[1]]()
