from collections import defaultdict
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

C = Path(__file__).resolve().parent
R = C.parent / "learning-japanese"
L = C / "logs" / "e5915513-68ba-4635-b817-0d21a17918c3"
D = R / "docs" / "n1-reviews" / "batch-105-native-labels-814"
BASE = "2c2075516ea14b0002eade568fefd8b21ae025b6"
APP = "bf30cdead8515739bc0e671d57a54b9a3109dd46"


def load(path):
    return json.loads(path.read_bytes())


def digest(data):
    return hashlib.sha256(data).hexdigest()


def save(path, value):
    assert not path.exists(), path
    path.write_bytes((json.dumps(value, ensure_ascii=True, indent=2) + "\n").encode())


def git(*args, root=R):
    return subprocess.check_output(["git", "--no-pager", "-C", str(root), *args], encoding="utf-8").strip()


def runtime():
    manifest = load(R / "manifest.json")
    assert manifest == json.loads(git("show", BASE + ":manifest.json"))
    count = 0
    for section, entries in manifest.items():
        if not isinstance(entries, dict):
            continue
        for path, expected in entries.items():
            raw = (R / path).read_bytes()
            if section not in {"images", "audio", "listeningTaskAudio", "listeningTaskImages"}:
                raw = raw.replace(b"\r\n", b"\n")
            assert digest(raw) == expected, path
            count += 1
    assert count == 8469 and manifest["contentVersion"] == "5572c6c467e6b73b"
    return {"contentVersion": manifest["contentVersion"], "runtimeHashesVerified": count,
            "manifestSha256": digest((R / "manifest.json").read_bytes()),
            "runtimeUnchanged": True}


def prepare():
    if D.exists():
        assert {x.name for x in D.iterdir()} == {
            "sampled-jmdict.xml", "sampled-kanjidic2.xml", "source-reading.jsonl"}
    p = load(C / "progress.json")
    assert (p["checkpoint"], p["status"], p["batch"]) == (813, "continue", "105")
    runner = load(C / "runner.json")
    assert (runner["status"], runner["pid"], runner["sessionId"]) == ("running", 13320, L.name)
    for root, head in [(R, BASE), (C.parent / "kanji-cards-android", APP)]:
        assert git("rev-parse", "HEAD", root=root) == head
        assert git("log", "-1", "--format=%G?", root=root) == "G"
        if root == R and D.exists():
            assert not git("diff", "--name-only", BASE, root=root)
            assert all(x.startswith("docs/n1-reviews/batch-105-native-labels-814/")
                       for x in git("ls-files", "--others", "--exclude-standard").splitlines())
        else:
            assert not git("status", "--porcelain", "--untracked-files=all", root=root)
    verified_runtime = runtime()
    snapshot = load(R / "docs" / "n1-source-snapshot.json")
    sources = {}
    for name, kind in [("n1-implementation-JMdict_e.gz", "jmdict"),
                       ("n1-planning-kanjidic2.xml.gz", "kanjidic2")]:
        raw = (C / "inputs" / name).read_bytes()
        assert digest(raw) == snapshot["inputs"][name]["sha256"]
        xml = gzip.decompress(raw)
        assert digest(xml) == snapshot[kind]["xmlSha256"]
        sources[kind] = {"input": str(C / "inputs" / name),
                         "compressedSha256": digest(raw), "xmlSha256": digest(xml),
                         "xml": xml}
    native_dir = R / "docs" / "n1-reviews" / "batch-105-native-813"
    route_path = native_dir / "native" / "n1-105-article-route.json.gz"
    index = {x["file"]: x for x in load(native_dir / "artifact-index.json")}
    route_raw = route_path.read_bytes()
    assert digest(route_raw) == index["native/n1-105-article-route.json.gz"]["storedSha256"]
    route_xml = gzip.decompress(route_raw)
    assert digest(route_xml) == index["native/n1-105-article-route.json.gz"]["sourceSha256"]
    route = json.loads(route_xml)
    labels = load(native_dir / "sampled-labels-and-host-delta.json")
    chars = {char for char, title in labels["newVersusHost811"]}
    assert chars == set("亥巳彗柚鵬")
    terms = {"亥", "辛亥", "亥年", "巳", "上巳", "巳年", "彗星", "ほうき",
             "柚", "柚子", "晩白柚", "柚香焼き", "鵬", "おおとり", "鳳凰", "大トリ"}
    jm, kd = ET.Element("JMdict"), ET.Element("kanjidic2")
    ids = {term: [] for term in sorted(terms)}
    for entry in ET.fromstring(sources["jmdict"]["xml"]).findall("entry"):
        matching = terms & {e.text for e in entry.findall("k_ele/keb") + entry.findall("r_ele/reb")}
        if matching:
            jm.append(entry)
            for term in matching:
                ids[term].append(entry.findtext("ent_seq"))
    assert all(ids.values()), ids
    for entry in ET.fromstring(sources["kanjidic2"]["xml"]).findall("character"):
        if entry.findtext("literal") in chars:
            kd.append(entry)
    assert len(kd) == 5
    D.mkdir(exist_ok=True)
    for name, tree in [("sampled-jmdict.xml", jm), ("sampled-kanjidic2.xml", kd)]:
        ET.indent(tree, space="  ")
        raw = ET.tostring(tree, encoding="utf-8", xml_declaration=True) + b"\n"
        target = D / name
        if target.exists():
            assert target.read_bytes() == raw
        else:
            target.write_bytes(raw)
    projection = []
    for entry in kd:
        projection.append({"kanji": entry.findtext("literal"),
                           "allEnglishMeanings": [m.text for m in entry.findall("reading_meaning/rmgroup/meaning")
                                                  if not m.attrib],
                           "allReadings": [(x.attrib, x.text)
                                           for x in entry.findall("reading_meaning/rmgroup/reading")]})
    for entry in jm:
        projection.append({"entry": entry.findtext("ent_seq"),
                           "spellings": [[(x.tag, x.text, x.attrib) for x in ke] for ke in entry.findall("k_ele")],
                           "readings": [[(x.tag, x.text, x.attrib) for x in re] for re in entry.findall("r_ele")],
                           "senses": [[(x.tag, x.text, x.attrib) for x in se] for se in entry.findall("sense")]})
    projection_raw = ("\n".join(json.dumps(x, ensure_ascii=False) for x in projection) + "\n").encode()
    if (D / "source-reading.jsonl").exists():
        assert (D / "source-reading.jsonl").read_bytes() == projection_raw
    else:
        (D / "source-reading.jsonl").write_bytes(projection_raw)
    article_paths = [f"kanji/{char}.md" for char in sorted(chars)]
    article_paths += [f"words/{word}.md" for word in ("亥", "巳", "彗星", "柚", "鵬")]
    provenance, bodies = [], []
    for path in article_paths:
        raw = (R / path).read_bytes()
        blob = subprocess.check_output(["git", "-C", str(R), "show", BASE + ":" + path])
        assert raw == blob or raw.replace(b"\r\n", b"\n") == blob.replace(b"\r\n", b"\n")
        bodies.append("FILE " + path + "\n" + blob.decode())
        provenance.append({"path": path, "checkoutSha256": digest(raw),
                           "gitBlobSha256": digest(blob), "snapshot": BASE,
                           "checkoutEqualsGitBlob": raw == blob,
                           "gitBlobCrlfLines": blob.count(b"\r\n")})
    article_raw = "\n\n".join(bodies).encode()
    (D / "comparison-bodies.txt.gz").write_bytes(gzip.compress(article_raw, mtime=0))
    samples = route["productionBuilderN1AndAllExactChoices"]
    assert len(samples) == 64
    actual_labels = sorted({(x["kanji"], x["title"]) for row in samples for x in row["options"]})
    assert [list(x) for x in actual_labels] == labels["nativeLabels"]
    grouped = defaultdict(list)
    for row in samples:
        grouped[(row["pool"], tuple((x["kanji"], x["title"]) for x in row["options"]))].append(row["seed"])
    pools = {}
    for row in samples:
        pool = row["pool"]
        members = row["poolMembershipInOrder"]
        if pool in pools:
            assert pools[pool] == members
        else:
            pools[pool] = members
    save(D / "native-samples.json", {
        "route": str(route_path.relative_to(R)), "routeStoredSha256": digest(route_raw),
        "routeRawSha256": digest(route_xml), "archiveContentSnapshot": route["contentSnapshot"],
        "exactDefaultMeaningOptions": route["exactDefaultMeaningOptions"],
        "actualN1CuratedAvailable": route["actualN1CuratedAvailable"],
        "actualN1FallbackOptions": route["actualN1FallbackOptions"],
        "poolMembershipInOrder": pools,
        "orderedOptionSetsAndSeeds": [{"pool": pool, "orderedOptions": options, "seeds": seeds}
                                     for (pool, options), seeds in grouped.items()],
        "samples": len(samples), "uniqueOrderedSets": len(grouped),
        "nativeLabels": labels["nativeLabels"], "newVersusHost811": labels["newVersusHost811"]})
    save(D / "sampled-source-selection.json", {
        "sourceSnapshot": "docs/n1-source-snapshot.json",
        "inputs": {kind: {k: v for k, v in data.items() if k != "xml"}
                   for kind, data in sources.items()},
        "kanji": sorted(chars), "fullCharacterRecords": len(kd), "termEntryIds": ids,
        "completeFamilies": len(jm), "allSensesAndRestrictionsPreserved": True,
        "sourceHashesVerified": True, "articles": provenance, "completeArticleBodies": len(provenance),
        "comparisonBodiesRawSha256": digest(article_raw),
        "comparisonBodiesStoredSha256": digest((D / "comparison-bodies.txt.gz").read_bytes()),
        "sourceProjectionLines": len(projection), "runtime": verified_runtime,
        "limits": "Bounded author/coordinator source preparation, not independent review, fresh upstream retrieval, frequency evidence, native rerun or whole-batch acceptance."})
    print(json.dumps({"characters": len(kd), "families": len(jm), "articles": len(provenance),
                      "sourceProjectionLines": len(projection), "samples": len(samples),
                      "orderedSets": len(grouped), "sourcePacket": str(D)}, ensure_ascii=True))


if __name__ == "__main__":
    prepare()
