$ErrorActionPreference = 'Stop'
$control = $PSScriptRoot
$log = "$control\logs\e5915513-68ba-4635-b817-0d21a17918c3"
$content = "$control\..\learning-japanese"
$bodyPath = "$control\batch-105-native-label-sources-814-issue-body.txt"
if ((Test-Path "$log\issue-814-posted.json") -or (Test-Path $bodyPath)) { throw 'Do not duplicate issue update' }
$head = git -C $content rev-parse HEAD
if ($LASTEXITCODE -ne 0) { throw 'HEAD lookup failed' }
& "$control\preflight-814.ps1" -ReceiptName 'preflight-814-before-issue.json' -ExpectedContentHead $head
if ((git -C $content rev-parse 'HEAD^') -ne '2c2075516ea14b0002eade568fefd8b21ae025b6' -or
    $LASTEXITCODE -ne 0) { throw 'Wrong evidence ancestry' }
$e = [IO.File]::ReadAllText("$content\docs\n1-sources\execution-814.json") | ConvertFrom-Json
if ($e.runtimeChanged -or $e.runtimePublished -or $e.independentRenderedReviewClosed -or
    $e.runtime.runtimeHashesVerified -ne 8469 -or $e.sourceSelection.completeFamilies -ne 23) {
    throw 'Source evidence mismatch'
}
$body = @"
Checkpoint814, SAME batch105: prepared and inspected the five newly sampled native fallback labels, 亥/巳/彗/柚/鵬. Signed LOCAL evidence $head preserves docs/n1-sources/execution-814.json and docs/n1-reviews/batch-105-native-labels-814/: FIVE complete raw KANJIDIC2 records,23 complete JMdict families with all senses/restrictions,10 actual complete kanji/support bodies, exact source/blob hashes, and all64 native samples grouped into52 exact ordered option-set/seed groups. Approved frozen compressed AND decompressed dictionary hashes verified; no optional historical-session helper access, lock operation, new denial, reviewer or native rerun.

Coordinator source inspection established no target-relative alternative answer to 勁 "strong; taut" among the five new labels, including obsolete calendar senses, broom/comet, the yuzu/pomelo distinction and the wider mythical/large-bird family. Broad "citron"/"phoenix" glosses are not unrestricted identity claims. Complete kanaほうき homophone results are preserved, NOT treated as 彗 spellings/senses. Actual previous public-dictionary qualifications are inherited, not fresh upstream retrieval. The original810 textual and811 HOST reports/findings/withdrawn hypotheses/optional dispositions and all813 native/PNG/read-depth limits remain intact, without new independent-review credit.

Exact native pool inspection: defaultN1/All/custom retain ALL THREE curated功/劾/剖 and have ZERO fallback. The native16-card randomN1Subset retains TWO, 功/劾, omits剖 and uses ONE fallback per sampled set. This differs from HOST811's separate randomN1Subset811, which retained NONE. All native order/seed/pool-membership bindings remain tied to original813 route bytes; no fixture rerun or substitution. An initial preparation-only assertion assumed normalized Git text; the ten inherited article Git blobs actually contain CRLF and exactly equal checkout bytes. Corrected the comparison, preserved exact hashes/line counts and asserted existing source-file byte equality before resuming; no runtime/source/signing/guard change.

All8,469 runtime hashes/version5572c6c467e6b73b unchanged; validator0 errors and regenerated manifest unchanged. This source checkpoint is NOT whole-batch acceptance. New native ordinary-secondary-sense semantic acceptance remains UNVERIFIED pending TWO SERIAL ORIGINAL-family rendered confirmations, using original sessions/reports, actual813 images/options and the bounded814 source supplement. Native813's two terminal successful cases are inherited, not repeated. No teaching/app changes, push or batch106.

Next: those original-session rendered confirmations on one frozen identified snapshot, with process-exit/per-tool serialization, actual model evidence and no snapshot edits. All combined-current-main/nonrewriting-merge/changed-teaching-review/full-required-validation/normal-signing/owner-fast-forward/terminal-green-CI/EVERY-immutable-GitHub-ZIP-hash/budget/per-file/media/path/publication gates remain mandatory;18,000entries/42MiBcompressed/80MiBinflated/56MiBretained unchanged. Published131/1,228; acceptance remainder1,097; last published047c2cef6b6a48b1738f2c5957de01be481c63e1. Batch105 not closed/published. Compatible stop-cran/kanji-cards-android#125 and stop-cran/kanji-cards-android#132 client required; old clients ignore curation/guards; qualified backport, not latest app main. Physical-phone, general-release and whole-set acceptance outstanding; project incomplete.
"@
[IO.File]::WriteAllText($bodyPath, $body + "`n", [Text.UTF8Encoding]::new($false))
$priorToken = $env:GH_TOKEN
try {
    $env:GH_TOKEN = (gh auth token --user stop-cran)
    if ($LASTEXITCODE -ne 0 -or -not $env:GH_TOKEN) { throw 'Owner credential unavailable' }
    $login = gh api user --jq .login
    if ($LASTEXITCODE -ne 0 -or $login -cne 'stop-cran') { throw 'Wrong command-scoped identity' }
    $url = gh issue comment 60 --repo stop-cran/learning-japanese --body-file $bodyPath
    if ($LASTEXITCODE -ne 0) { throw 'Issue update failed' }
    $url = $url.Trim()
    @{ url=$url; author=$login; bodySha256=(Get-FileHash $bodyPath).Hash.ToLowerInvariant() } |
        ConvertTo-Json | Set-Content "$log\issue-814-posted.json" -Encoding utf8NoBOM
    if ($url -notmatch '#issuecomment-(\d+)$') { throw 'Unexpected comment URL; preserve receipt' }
    $raw = gh api "repos/stop-cran/learning-japanese/issues/comments/$($Matches[1])"
    if ($LASTEXITCODE -ne 0) { throw 'Comment reread failed' }
    $raw | Set-Content "$log\issue-814-reread.json" -Encoding utf8NoBOM
    $comment = $raw | ConvertFrom-Json
    if ($comment.user.login -cne 'stop-cran' -or $comment.body -cne [IO.File]::ReadAllText($bodyPath) -or
        $comment.html_url -cne $url) { throw 'Exact owner/body verification failed' }
    Write-Output "Verified owner update: $url"
} finally {
    $env:GH_TOKEN = $priorToken
}
