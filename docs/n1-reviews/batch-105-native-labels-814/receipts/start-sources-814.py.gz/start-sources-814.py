from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess

C = Path(__file__).resolve().parent
L = C / "logs" / "e5915513-68ba-4635-b817-0d21a17918c3"
P = C / "progress.json"
original = P.read_bytes()
p = json.loads(original)
assert (p["checkpoint"], p["status"], p["batch"]) == (813, "continue", "105")
assert "execution814StartingState" not in p
assert not (L / "progress-before-814.json").exists()
(L / "progress-before-814.json").write_bytes(original)
request = (L / "request.txt").read_bytes()
text = request.decode("utf-8-sig")
json.loads(text.split("Current execution checkpoint (complete historical state remains at checkpointHistory paths):", 1)[1])
preflight = json.loads((L / "preflight-814.json").read_bytes())
R = C.parent / "learning-japanese"
subprocess.run(["git", "-C", str(R), "fetch", "--quiet", "origin", "main"], check=True)
main = subprocess.check_output(["git", "-C", str(R), "rev-parse", "origin/main"], text=True).strip()
state = {
    "execution": 814, "batch": "105", "startedAt": datetime.now(timezone.utc).isoformat(),
    "startingHead": preflight["contentHead"],
    "androidHead": "bf30cdead8515739bc0e671d57a54b9a3109dd46",
    "freshOriginMain": main,
    "scope": "SAME105 five new native fallback labels: bounded complete frozen source and comparison-body preparation/inspection; signed LOCAL evidence only, no reviewer/native rerun/publication/106.",
    "request": {"sha256": hashlib.sha256(request).hexdigest(), "bytes": len(request),
                "lines": len(text.splitlines()), "completeFileLoadedAndCheckpointParsed": True,
                "limits": "Entire request read/decoded and embedded checkpoint parsed; operative contract, complete approved issue and final813 directly inspected. Historical middle parsed, not freshly semantically re-reviewed. Initial full-load summary hit console encoding error after successful decode; bounded final read succeeded."},
    "runnerPreflight": preflight,
    "artifactPathPreflight": "Approved committed source packets and frozen workspace inputs only; reusable helpers in control; optional historical-session recipes not accessed.",
    "parentLockTouched": False, "actualNewPermissionDenials": [],
}
p["execution814StartingState"] = state
p["historicalExecution813Before814Sources"] = {k: p[k] for k in ("checkpoint", "stage", "status", "nextAction", "blocker")}
p["stage"] = "batch-105-new-native-label-source-preparation-in-progress"
assert P.read_bytes() == original
temp = C / "progress.json.814-start.tmp"
temp.write_text(json.dumps(p, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
os.replace(temp, P)
(L / "starting-state-814.json").write_text(json.dumps(state, ensure_ascii=True, indent=2) + "\n", encoding="utf-8")
print("Execution814 scope saved; historical checkpoint preserved; fresh main " + main)
