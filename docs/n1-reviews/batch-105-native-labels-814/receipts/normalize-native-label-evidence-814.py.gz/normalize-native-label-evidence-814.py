import gzip
import hashlib
import json
from pathlib import Path

C = Path(__file__).resolve().parent
R = C.parent / "learning-japanese"
D = R / "docs" / "n1-reviews" / "batch-105-native-labels-814"
E = R / "docs" / "n1-sources" / "execution-814.json"


def save(path, data):
    path.write_bytes((json.dumps(data, ensure_ascii=True, indent=2) + "\n").encode())


path = D / "finite-semantic-disposition.json"
raw = path.read_bytes()
assert b"\r\n" in raw
original = D / "receipts" / "finite-semantic-disposition.original-bytes.json.gz"
assert not original.exists()
original.write_bytes(gzip.compress(raw, mtime=0))
assert gzip.decompress(original.read_bytes()) == raw
path.write_bytes(raw.replace(b"\r\n", b"\n"))
assert json.loads(path.read_bytes()) == json.loads(raw)
helper = D / "receipts" / (Path(__file__).name + ".gz")
assert not helper.exists()
helper.write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
index = [{"file": p.relative_to(D).as_posix(), "bytes": p.stat().st_size,
          "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
         for p in sorted(D.rglob("*")) if p.is_file() and p.name != "artifact-index.json"]
save(D / "artifact-index.json", index)
e = json.loads(E.read_bytes())
e["sourcePacketArtifacts"] = index
e["stagingDiagnostic"] = {
    "initialAttempt": "Before any commit, the exact staged-artifact hash assertion caught CRLF-to-LF normalization of the manually written disposition JSON. Other generated text was already LF; binary archives were unchanged.",
    "disposition": "Preserved original disposition bytes losslessly in gzip, normalized only this contributor JSON, verified decoded equality, recomputed artifact hashes and archived the normalization helper. Runtime, original dictionary bytes and comparison article blobs remain unchanged.",
    "originalDispositionSha256": hashlib.sha256(raw).hexdigest(),
    "committedDispositionSha256": hashlib.sha256(path.read_bytes()).hexdigest()
}
save(E, e)
print("Contributor JSON LF staging normalization verified; original bytes preserved; runtime untouched.")
