package io.github.stopcran.kanji.ui

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.os.Build
import androidx.activity.ComponentActivity
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.junit4.createEmptyComposeRule
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.res.ResourcesCompat
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.room.withTransaction
import androidx.test.core.app.ActivityScenario
import androidx.test.platform.app.InstrumentationRegistry
import io.github.stopcran.kanji.KanjiApp
import io.github.stopcran.kanji.MainActivity
import io.github.stopcran.kanji.R
import io.github.stopcran.kanji.core.content.ContentParser
import io.github.stopcran.kanji.core.content.RepoSource
import io.github.stopcran.kanji.core.quiz.QuizBuilder
import io.github.stopcran.kanji.core.reading.ReadingKind
import io.github.stopcran.kanji.core.srs.KanjiFont
import io.github.stopcran.kanji.core.srs.StudyMode
import io.github.stopcran.kanji.core.words.WordDirection
import io.github.stopcran.kanji.core.words.WordQuizBuilder
import io.github.stopcran.kanji.data.*
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.File
import java.security.MessageDigest
import java.util.UUID


private fun disposable102() {
    assertEquals("true", InstrumentationRegistry.getArguments().getString("n1Disposable"))
    assertTrue(Build.HARDWARE in setOf("ranchu", "goldfish"))
}

class N1Batch102Glyph777Test {
    @get:Rule val rule = createAndroidComposeRule<ComponentActivity>()

    @Test fun inferiorityLookalikesAndAllThirtyOneHanAcrossFourProductionFamilies() {
        disposable102()
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val fonts = listOf(KanjiFont.Gothic, KanjiFont.Mincho, KanjiFont.Textbook, KanjiFont.Brush)
        val pages = listOf("下 二 人 低 俳 優 利 力 功 劣 努", "品 奴 害 少 工 弱 得 悪 損 比 目", "省 短 能 製 負 貧 質 較 長", "劣 少 力 努 奴 功 工 省 目 優劣 劣る")
        val page = mutableStateOf(0)
        rule.setContent {
            MaterialTheme {
                Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Batch 102: inferiority / look-alikes / all scoped Han")
                    Text("Panel ${page.value + 1} / ${pages.size}")
                    fonts.forEach { font ->
                        Text(font.name)
                        Text(pages[page.value], fontFamily = font.family(), fontSize = 18.sp, lineHeight = 26.sp)
                    }
                    Text("Inspect all 31 scoped Han; focus 劣/努/功/省, 少/奴 and 力/目. Cmap presence is not readability.", fontSize = 16.sp)
                }
            }
        }
        val typefaces = listOf(Typeface.DEFAULT,
            requireNotNull(ResourcesCompat.getFont(context, R.font.kanji_mincho)),
            requireNotNull(ResourcesCompat.getFont(context, R.font.kanji_textbook)),
            requireNotNull(ResourcesCompat.getFont(context, R.font.kanji_brush)))
        val rows = JSONArray()
        for ((index, typeface) in typefaces.withIndex()) {
            val hashes = mutableSetOf<String>()
            for (char in listOf("下", "二", "人", "低", "俳", "優", "利", "力", "功", "劣", "努", "品", "奴", "害", "少", "工", "弱", "得", "悪", "損", "比", "目", "省", "短", "能", "製", "負", "貧", "質", "較", "長")) {
                val paint = Paint(Paint.ANTI_ALIAS_FLAG).also {
                    it.typeface = typeface
                    it.textSize = 96f
                    it.textLocale = java.util.Locale.JAPAN
                }
                assertTrue("$char ${fonts[index]}", paint.hasGlyph(char))
                val image = Bitmap.createBitmap(if (char.length > 1) 256 else 128, 128, Bitmap.Config.ARGB_8888)
                Canvas(image).drawText(char, 8f, 104f, paint)
                val pixels = IntArray(image.width * image.height)
                image.getPixels(pixels, 0, image.width, 0, 0, image.width, image.height)
                assertTrue(pixels.any { it != 0 })
                val bytes = java.nio.ByteBuffer.allocate(pixels.size * 4)
                    .also { it.asIntBuffer().put(pixels) }.array()
                val hash = MessageDigest.getInstance("SHA-256").digest(bytes)
                    .joinToString("") { "%02x".format(it) }
                assertTrue("Indistinguishable raster ${fonts[index]}", hashes.add(hash))
                rows.put(JSONObject().put("character", char).put("font", fonts[index].name)
                    .put("hasGlyph", true).put("nativePaintRasterSha256", hash))
                image.recycle()
            }
            for (word in listOf("優劣", "劣る")) {
                val paint = Paint(Paint.ANTI_ALIAS_FLAG).also {
                    it.typeface = typeface
                    it.textSize = 96f
                    it.textLocale = java.util.Locale.JAPAN
                }
                // hasGlyph tests multi-character ligatures, not ordinary word coverage.
                val image = Bitmap.createBitmap(kotlin.math.ceil(paint.measureText(word)).toInt() + 16, 128, Bitmap.Config.ARGB_8888)
                Canvas(image).drawText(word, 8f, 104f, paint)
                val pixels = IntArray(image.width * image.height)
                image.getPixels(pixels, 0, image.width, 0, 0, image.width, image.height)
                for (position in word.indices) {
                    val left = (8f + paint.measureText(word, 0, position)).toInt()
                    val right = kotlin.math.ceil(8f + paint.measureText(word, 0, position + 1)).toInt()
                    assertTrue("Word raster bounds $word ${fonts[index]}", left >= 0 && right <= image.width && left < right)
                    assertTrue("Blank word character ${word[position]} ${fonts[index]}",
                        (0 until image.height).any { y -> (left until right).any { x -> pixels[y * image.width + x] != 0 } })
                }
                val bytes = java.nio.ByteBuffer.allocate(pixels.size * 4)
                    .also { it.asIntBuffer().put(pixels) }.array()
                val hash = MessageDigest.getInstance("SHA-256").digest(bytes)
                    .joinToString("") { "%02x".format(it) }
                rows.put(JSONObject().put("word", word).put("font", fonts[index].name)
                    .put("renderedCharactersNonblank", word.length).put("nativePaintRasterSha256", hash))
                image.recycle()
            }
        }
        assertEquals(132, rows.length())
        for (index in pages.indices) {
            rule.runOnIdle { page.value = index }
            rule.waitForIdle()
            rule.onAllNodesWithText(pages[index]).assertCountEquals(4)
            for (fontIndex in fonts.indices) rule.onAllNodesWithText(pages[index])[fontIndex].assertIsDisplayed()
            File(context.getExternalFilesDir(null), "n1-102-font-panel-${index + 1}.png").outputStream().use {
                assertTrue(rule.onRoot().captureToImage().asAndroidBitmap().compress(Bitmap.CompressFormat.PNG, 100, it))
            }
        }
        File(context.getExternalFilesDir(null), "n1-102-font-raster.json").writeText(JSONObject()
            .put("fingerprint", Build.FINGERPRINT).put("sdk", Build.VERSION.SDK_INT)
            .put("fontScale", context.resources.configuration.fontScale).put("rows", rows)
            .put("individualGlyphProbes", 124).put("wholeWordRasterProbes", 8).put("panels", 4)
            .put("limits", "31 actual scoped Han across four production families, four bounded Compose panels and eight whole-word rasters. All are present in bundled cmaps; that is not rendering acceptance. Hashes are not readability or fallback-face evidence. Actual PNG inspection required; emulator not phone.")
            .toString(2))
    }
}


class N1Batch102Article777Test {
    @get:Rule val rule = createEmptyComposeRule()
    private lateinit var app: KanjiApp
    private lateinit var scenario: ActivityScenario<MainActivity>

    @Test fun fullSingleImportInferiorityDirectGuardsTwoCuratedKeysThreePairsSixStrokesOfflineAndBack() {
        disposable102()
        val instrumentation = InstrumentationRegistry.getInstrumentation()
        app = instrumentation.targetContext.applicationContext as KanjiApp
        val source = RepoSource("acceptance-fixture", "n1-102-${UUID.randomUUID()}", "main")
        val head = "ae9d2df569471dfadc25388c3a664612b56a1fc6"
        assertTrue(app.settings.setSource("https://github.com/${source.id}", source.branch))
        var archiveRequests = 0
        val http = ContentHttp { url, _, _, _ ->
            val input = when (url) {
                "https://api.github.com/repos/${source.id}/commits/main" -> ByteArrayInputStream(head.toByteArray())
                source.commitZipUrl(head) -> {
                    archiveRequests++
                    instrumentation.context.assets.open("n1-batch-102-ae9d2df5-envelope.zip")
                }
                else -> error("Unexpected fixture request: $url")
            }
            object : ContentResponse {
                override val code = 200
                override val body = input
                override fun header(name: String): String? = null
                override fun close() = input.close()
            }
        }
        val result = runBlocking { ContentSync(app.db, app.settings.sync, http).sync(source, force = true) }
        assertTrue(result.toString(), result is SyncResult.Updated)
        val updated = result as SyncResult.Updated
        assertEquals(1, archiveRequests)
        assertEquals(1125, updated.kanji)
        assertEquals(5074, updated.words)
        assertTrue(updated.problems.toString(), updated.problems.isEmpty())
        val meta = requireNotNull(runBlocking { app.db.content().meta(source.id) })
        assertEquals("f376333b242ebb23", meta.contentVersion)
        assertEquals(0, meta.problems)
        assertNull(meta.grammarProblem)
        assertNull(meta.listeningProblem)
        assertNull(meta.grammarCurriculumProblem)
        assertEquals(1, ContentParser.KANJI_READING_PARSER_EPOCH)
        assertEquals(ContentParser.KANJI_READING_PARSER_EPOCH, meta.kanjiReadingParserEpoch)
        assertEquals(1, ContentParser.KANJI_MEANING_PARSER_EPOCH)
        assertEquals(ContentParser.KANJI_MEANING_PARSER_EPOCH, meta.kanjiMeaningParserEpoch)
        val all = runBlocking { app.db.content().kanjiLite(source.id) }
        val n1 = all.filter { it.jlpt == 1 }
        assertEquals(134, n1.size)
        assertEquals(n1.map { it.kanji }.toSet(),
            all.filter { "jlpt-n1" in it.tags.splitSep() }.map { it.kanji }.toSet())
        val target = n1.single { it.kanji == "劣" }
        val guards = listOf("弱", "悪", "下", "低", "貧", "負", "少")
        assertEquals(guards, target.quizExclusions.splitSep())
        val observed = runBlocking { app.db.content().observeKanjiLite(source.id).first() }.single { it.kanji == "劣" }
        assertEquals(guards, observed.toQuizCard().quizExclusions)
        val full = requireNotNull(runBlocking { app.db.content().kanjiCard(source.id, "劣") })
        assertEquals(guards, full.quizExclusions.splitSep())
        assertEquals(guards, full.toQuizCard().quizExclusions)
        assertEquals(guards, runBlocking { app.db.content().kanji(source.id) }
            .single { it.kanji == "劣" }.toQuizCard().quizExclusions)
        assertEquals(listOf("努", "功", "省"), target.distractors.splitSep())
        assertEquals(listOf("レツ"), target.onyomi.splitSep())
        assertEquals(listOf("おと.る"), target.kunyomi.splitSep())
        assertEquals(listOf("レツ"), target.quizOnyomi?.splitSep())
        assertEquals(listOf("おと.る"), target.quizKunyomi?.splitSep())
        assertEquals(listOf("れつ"), target.toReadingCard().quizKeys(ReadingKind.On))
        assertEquals(listOf("おとる"), target.toReadingCard().quizKeys(ReadingKind.Kun))
        val expectedMeanings = mapOf("劣" to "inferior; worse", "努" to "make an effort",
            "功" to "merit; achievement", "省" to "ministry; omit")
        val curatedIds = listOf("努", "功", "省")
        assertEquals(mapOf("努" to 3, "功" to 1, "省" to 2),
            all.filter { it.kanji in curatedIds }.associate { it.kanji to it.jlpt })
        assertEquals(setOf("功"), n1.filter { it.kanji in curatedIds }.map { it.kanji }.toSet())
        val custom = all.filter { it.kanji in expectedMeanings }
        val randomSubset = listOf(target) +
            n1.filter { it.kanji != "劣" }.shuffled(kotlin.random.Random(777)).take(15)
        val choices = JSONArray()
        for ((poolName, pool) in listOf("N1" to n1, "All" to all,
            "boundedCustom" to custom, "randomN1Subset" to randomSubset)) {
            val cards = pool.map { it.toQuizCard() }
            val quizTarget = cards.single { it.kanji == "劣" }
            val available = curatedIds.filter { id -> cards.any { it.kanji == id } }
            repeat(16) { seed ->
                val options = QuizBuilder.options(quizTarget, cards, kotlin.random.Random(seed))
                assertEquals(4, options.size)
                assertEquals(4, options.map { it.title }.toSet().size)
                assertEquals(1, options.count { it.kanji == "劣" })
                for (left in options) for (right in options.filter { it.kanji != left.kanji })
                    assertFalse(right.kanji in left.quizExclusions || left.kanji in right.quizExclusions)
                assertTrue(options.none { it.kanji in guards })
                assertTrue(available.all { id -> options.any { it.kanji == id } })
                assertTrue(options.all { o -> pool.any { it.kanji == o.kanji && it.title == o.title } })
                if (available.size == 3) assertEquals(expectedMeanings, options.associate { it.kanji to it.title })
                choices.put(JSONObject().put("pool", poolName).put("seed", seed)
                    .put("poolMembershipInOrder", JSONArray(pool.map { it.kanji }))
                    .put("options", JSONArray().also { rows ->
                        options.forEach { rows.put(JSONObject().put("kanji", it.kanji).put("title", it.title)) }
                    }))
            }
        }
        assertEquals(64, choices.length())
        val allCards = all.map { it.toQuizCard() }
        val guardChecks = JSONArray()
        for (excludedId in guards) {
            val pair = allCards.filter { it.kanji in setOf("劣", excludedId) }
            assertEquals(2, pair.size)
            for (quizTarget in pair) {
                val excluded = pair.single { it.kanji != quizTarget.kanji }
                repeat(16) { seed ->
                    val sampled = pair + allCards.filter { it.kanji !in setOf("劣", excludedId) }
                        .shuffled(kotlin.random.Random(777 + seed)).take(seed)
                    for ((poolName, pool) in listOf(
                        "N1" to n1.map { it.toQuizCard() }, "All" to allCards,
                        "boundedCustom" to (pair + allCards.filter { it.kanji in curatedIds }),
                        "randomN1Subset777" to (pair + randomSubset.map { it.toQuizCard() }
                            .filter { it.kanji !in setOf("劣", excludedId) }),
                        "sampledFiltered" to sampled, "pairOnly" to pair,
                        "targetOutsidePool" to sampled.filter { it.kanji != quizTarget.kanji },
                    )) {
                        val options = QuizBuilder.options(quizTarget, pool, kotlin.random.Random(seed))
                        assertEquals(1, options.count { it.kanji == quizTarget.kanji })
                        assertFalse("Direct guard leaked $excludedId $poolName", options.any { it.kanji == excluded.kanji })
                        assertTrue(options.size in 1..4)
                        for (left in options) for (right in options.filter { it.kanji != left.kanji })
                            assertFalse(right.kanji in left.quizExclusions || left.kanji in right.quizExclusions)
                        assertEquals(options.size, options.map { it.title }.toSet().size)
                        assertTrue(options.all { it.kanji == quizTarget.kanji || pool.any { p -> p.kanji == it.kanji } })
                        if (poolName == "pairOnly") assertEquals(1, options.size)
                        guardChecks.put(JSONObject().put("target", quizTarget.kanji).put("excluded", excluded.kanji)
                            .put("pool", poolName).put("seed", seed)
                            .put("poolMembershipInOrder", JSONArray(pool.map { it.kanji }))
                            .put("options", JSONArray(options.map { it.kanji })))
                    }
                }
            }
        }
        assertEquals(1568, guardChecks.length())
        val nontransitiveChecks = JSONArray()
        for (left in guards) for (right in guards.filter { it != left }) repeat(16) { seed ->
            val pair = allCards.filter { it.kanji in setOf(left, right) }
            val leftCard = pair.single { it.kanji == left }
            val rightCard = pair.single { it.kanji == right }
            assertFalse(right in leftCard.quizExclusions || left in rightCard.quizExclusions)
            val options = QuizBuilder.options(leftCard, pair, kotlin.random.Random(seed))
            assertEquals(setOf(left, right), options.map { it.kanji }.toSet())
            nontransitiveChecks.put(JSONObject().put("target", left).put("neighbor", right).put("seed", seed)
                .put("options", JSONArray(options.map { it.kanji })))
        }
        assertEquals(672, nontransitiveChecks.length())
        val words = runBlocking { app.db.content().wordsLite(source.id) }.map { it.toCard() }
        val preserved = mapOf(
            "優劣" to listOf("質", "長短", "利害", "損得"), "劣る" to emptyList())
        assertEquals("ゆうれつ", words.single { it.word == "優劣" }.reading)
        assertNull(words.single { it.word == "優劣" }.jlpt)
        assertEquals("おとる", words.single { it.word == "劣る" }.reading)
        assertEquals(3, words.single { it.word == "劣る" }.jlpt)
        val wordChecks = JSONArray()
        for ((id, excludedIds) in preserved) {
            val left = words.single { it.word == id }
            assertEquals(excludedIds, left.quizExclusions)
            for (excludedId in excludedIds) {
                val right = words.single { it.word == excludedId }
                for ((wordTarget, excluded) in listOf(left to right, right to left)) {
                    val pool = listOf(wordTarget, excluded) + words.filter {
                        it.word !in setOf(wordTarget.word, excluded.word) && it.title !in setOf(wordTarget.title, excluded.title) &&
                            it.word !in wordTarget.quizExclusions && wordTarget.word !in it.quizExclusions
                    }.take(12)
                    for ((poolName, selected) in listOf("All" to words, "boundedCustom" to pool))
                        for (direction in listOf(WordDirection.JpToEn, WordDirection.EnToJp)) repeat(16) { seed ->
                            val options = WordQuizBuilder.options(wordTarget, selected, direction, kotlin.random.Random(seed))
                            assertEquals(4, options.size)
                            assertEquals(1, options.count { it.word == wordTarget.word })
                            assertFalse(options.any { it.word == excluded.word })
                            wordChecks.put(JSONObject().put("target", wordTarget.word).put("excluded", excluded.word)
                                .put("pool", poolName).put("direction", direction.name).put("seed", seed)
                                .put("options", JSONArray().also { rows ->
                                    options.forEach { rows.put(JSONObject().put("word", it.word).put("label", it.label)) }
                                }))
                        }
                }
            }
        }
        assertEquals(512, wordChecks.length())
        val now = System.currentTimeMillis()
        app.settings.sync.lastCheckMs = now
        app.settings.setStartingGuideVisible(false)
        app.settings.setDailyNewCards(50)
        app.settings.setWeekPlan("FFFFFFF")
        app.settings.setTraceNew(true)
        app.settings.setVaryFonts(true)
        app.settings.setStack("jlpt-n5")
        runBlocking {
            app.db.withTransaction {
                n1.forEach { card ->
                    app.db.reviews().putState(ReviewStateEntity(
                        source.id, "jlpt-n1", card.kanji, StudyMode.Quiz.name, "Review", 30.0, 5.0,
                        if (card.kanji == "劣") now - 60_000 else now + 30L * 86_400_000,
                        now - 2L * 86_400_000, 3, 0,
                    ))
                    for (kind in ReadingKind.entries) for (key in card.toReadingCard().quizKeys(kind))
                        app.db.reviews().putState(ReviewStateEntity(
                            source.id, "jlpt-n1", card.kanji, kind.mode.name, "Review", 30.0, 5.0,
                            if (card.kanji == "劣") now - 60_000 else now + 30L * 86_400_000,
                            now - 2L * 86_400_000, 3, 0, reading = key,
                        ))
                }
                for (days in 1..2) app.db.reviews().putLog(ReviewLogEntity(
                    0, source.id, "jlpt-n1", "劣", StudyMode.Quiz.name, 3, now - days * 86_400_000L,
                ))
            }
        }
        val connectivity = app.getSystemService(ConnectivityManager::class.java)
        assertNull("Disable owned emulator Wi-Fi/data before offline acceptance", connectivity.activeNetwork)
        val evidence = JSONObject().put("contentSnapshot", head).put("contentVersion", meta.contentVersion)
            .put("archiveRequests", archiveRequests).put("importedKanji", updated.kanji).put("importedWords", updated.words)
            .put("problems", updated.problems.size).put("n1Cards", n1.size)
            .put("acceptedReadingParserEpoch", meta.kanjiReadingParserEpoch)
            .put("acceptedMeaningParserEpoch", meta.kanjiMeaningParserEpoch)
            .put("productionBuilderN1AndAllExactChoices", choices).put("kanjiDirectGuardChecks", guardChecks)
            .put("nontransitiveNeighborChecks", nontransitiveChecks).put("preservedWordGuardChecks", wordChecks)
            .put("fullOnyomi", JSONArray(target.onyomi.splitSep())).put("fullKunyomi", JSONArray(target.kunyomi.splitSep()))
            .put("quizOnKeys", JSONArray(target.toReadingCard().quizKeys(ReadingKind.On)))
            .put("quizKunKeys", JSONArray(target.toReadingCard().quizKeys(ReadingKind.Kun)))
            .put("kanjiQuizExclusions", JSONArray(guards))
            .put("fingerprint", Build.FINGERPRINT).put("sdk", Build.VERSION.SDK_INT)
            .put("transport", "Exact full git archive through production ContentSync ONCE; synthetic source/HEAD")
            .put("fixture", "Other N1 meanings/readings postponed; only劣 meaning andれつ/おとる due. Two historical good meaning logs unlock drawing. No drawing state seeded. Disposable source, not owner progress.")
            .put("limits", "Sampled pools, not exhaustive future semantics. Direct conservative guards are not unrestricted synonyms. Sampled fallback ordinary-sense semantic acceptance remains UNVERIFIED until source-backed rendered review. Raster hashes are not readability. Emulator, not phone.")
            .put("phoneEvidence", false).put("passed", false)
        scenario = ActivityScenario.launch(MainActivity::class.java)
        try {
            click("Kanji")
            click("N1")
            rule.waitUntil(30_000) { app.settings.stack.value == "jlpt-n1" }
            await("N1 · 134 cards").performScrollTo().assertIsDisplayed()
            capture("selection")
            click("Browse all kanji")
            rule.onNode(hasSetTextAction()).performTextReplacement("劣")
            click("inferior; worse")
            await("劣 — inferior; worse")
            show(articleBullet("Strokes: 6 · Key (radical): 力 (no. 19), at the bottom · JLPT: N1 (community list)"), "article-00")
            section("Meaning and origin")
            show(articleBullet("劣 expresses being inferior or worse in a comparison of ability, quality or another specified dimension. 劣る おとる means \"be inferior; fall short.\" 優劣 ゆうれつ covers both superiority and inferiority, not inferiority alone."), "article-02")
            show(articleBullet("The comparison need not involve a contest or a completed defeat. 劣らない (おとらない), \"not inferior; no worse,\" can make a favorable comparison without saying that two things are identical."), "article-03")
            show(articleBullet("Modern-shape mnemonic, not etymology: Picture 少-shaped \"less\" above 力-shaped strength as a reminder of falling short in one respect. This is a visual memory aid, not a historical derivation or a judgment of anyone's inherent worth."), "article-04")
            section("Readings")
            show(readingExample("レツ"), "article-06")
            show(readingExample("優劣 ゆうれつ — superiority or inferiority; relative merits"), "article-07")
            show(readingExample("おと.る"), "article-08")
            show(readingExample("劣る おとる — be inferior; fall short"), "article-09")
            show(articleBullet("Both sourced readings are selected for reading questions. In 優劣, 優 supplies ユウ and 劣 supplies レツ."), "article-10")
            section("Common words")
            show(articleBullet("劣る おとる — be inferior; fall short"), "article-12")
            show(articleBullet("優劣 ゆうれつ — superiority or inferiority; relative merits"), "article-13")
            section("Notes")
            show(articleBullet("努, \"make an effort,\" also has 力 below, but its upper part is 奴 rather than 少. Effort does not itself say whether the result is better or worse."), "article-15")
            show(articleBullet("功, \"merit; achievement,\" places 工 beside 力 rather than 少 above it. An achievement is not the same as inferiority."), "article-16")
            show(articleBullet("省, \"ministry; omit,\" has a similar upper 少-like outline but 目 below instead of 力."), "article-17")
            show(articleBullet("State the dimension of comparison when possible. A product can be inferior in one respect without being worse in every way; 劣 does not make every comparison a judgment of moral character."), "article-18")
            show(articleBullet("Metadata: KANJIDIC2, 2026-11-02 snapshot. Word identities: JMdict, entries 1558400 and 1539620. Character senses and reading allocation: Digital Daijisen, 劣."), "article-19")
            section("Common words")
            val nativeWord = "劣る おとる — be inferior; fall short"
            val nativeParts = "劣 expresses inferiority in this native verb. The dictionary-form ending is る, but its godan negative is 劣らない, not 劣ない."
            inline(await(articleBullet(nativeWord)), "劣る", 0)
            await("劣る (おとる) - be inferior; fall short")
            section("How the kanji combine")
            show(articleBullet(nativeParts), "otoru-components")
            inline(await(articleBullet(nativeParts)), "劣", 0)
            await("劣 — inferior; worse")
            back()
            await(articleBullet(nativeParts)).assertIsDisplayed()
            back()
            await(articleBullet(nativeWord)).assertIsDisplayed()
            val relativeWord = "優劣 ゆうれつ — superiority or inferiority; relative merits"
            val relativeParts = "優 contributes superiority here, rather than gentleness; 劣 contributes inferiority. This opposite pair spans both sides of the evaluation. The on readings are ユウ + レツ: keep the long ゆう in ゆうれつ."
            inline(await(articleBullet(relativeWord)), "優劣", 0)
            await("優劣 (ゆうれつ) - superiority or inferiority; relative merits")
            section("Meaning")
            show(articleBullet("優劣 is a noun for superiority or inferiority, or relative merits: whether one side is better or worse than another in a relevant respect. It does not mean inferiority alone."), "yuuretsu-01")
            show(articleBullet("二人の能力に優劣はない。 (ふたりののうりょくにゆうれつはない。) — Neither person's ability is superior to the other's."), "yuuretsu-02")
            show(articleBullet("どちらの製品もよくできていて、優劣をつけがたいです。 (どちらのせいひんもよくできていて、ゆうれつをつけがたいです。) — Both products are well made, and it is hard to say which is better."), "yuuretsu-03")
            show(articleBullet("優劣をつける (ゆうれつをつける) means deciding which is better. 優劣をつけがたい says that this is difficult; the second example explicitly describes both products favorably."), "yuuretsu-04")
            section("How the kanji combine")
            show(articleBullet("優 contributes superiority here, rather than gentleness; 劣 contributes inferiority. This opposite pair spans both sides of the evaluation. The on readings are ユウ + レツ: keep the long ゆう in ゆうれつ."), "yuuretsu-06")
            section("Synonyms and antonyms")
            show(articleBullet("比較 (ひかく), \"comparison,\" names the act of comparing, which need not rank things as better or worse."), "yuuretsu-08")
            show(articleBullet("質 (しつ), \"quality; inherent nature,\" can neutrally describe what something is like. 優劣 foregrounds relative superiority or inferiority; 質 can also be evaluated as good or bad, so these are not mutually exclusive categories."), "yuuretsu-09")
            section("Distinctive meaning")
            show(articleBullet("Specify the relevant dimension, such as ability or product performance. 優劣はない says that neither side is superior in the relevant comparison, not that two people or products are identical in every respect. Avoid using the word as an unqualified judgment of a person's worth."), "yuuretsu-11")
            show(articleBullet("Dictionary: JMdict, entries 1539620 and 2108410; Digital Daijisen and Seisenban Nihon Kokugo Daijiten, 優劣. The first example is from Digital Daijisen; the second is an original teaching example."), "yuuretsu-12")
            section("How the kanji combine")
            show(articleBullet(relativeParts), "yuuretsu-components")
            inline(await(articleBullet(relativeParts)), "劣", relativeParts.indexOf("劣"))
            await("劣 — inferior; worse")
            back()
            await(articleBullet(relativeParts)).assertIsDisplayed()
            inline(await(articleBullet(relativeParts)), "優", 0)
            await("優 — gentle; superior")
            section("Common words")
            show(articleBullet(relativeWord), "yuu-new-reciprocal")
            inline(await(articleBullet(relativeWord)), "優劣", 0)
            await("優劣 (ゆうれつ) - superiority or inferiority; relative merits")
            back()
            await(articleBullet(relativeWord)).assertIsDisplayed()
            back()
            await(articleBullet(relativeParts)).assertIsDisplayed()
            back()
            await(articleBullet(relativeWord)).assertIsDisplayed()
            back()
            await("Search kanji, meaning or reading")
            back()
            await("Meaning quiz")
            evidence.put("mappedReciprocalPairs", 3).put("directedLinkTransitions", 6)
                .put("activatedBaselinePairs", 1).put("changedReusedArticles", 2).put("reciprocalLinkAndSystemBack", true)
            click(rule.onNode(hasText("Start") and hasAnyAncestor(hasText("Meaning quiz"))))
            rule.waitUntil(30_000) { (model("quiz:") as? QuizViewModel)?.ui is QuizUi.Question }
            val quiz = model("quiz:") as QuizViewModel
            val meaning = quiz.ui as QuizUi.Question
            assertEquals("劣", meaning.card.kanji)
            val n1Curated = curatedIds.filter { id -> n1.any { it.kanji == id } }
            assertEquals(setOf("功"), n1Curated.toSet())
            assertEquals(4, meaning.options.size)
            assertEquals(4, meaning.options.map { it.title }.toSet().size)
            assertEquals(1, meaning.options.count { it.kanji == "劣" })
            assertTrue(n1Curated.all { id -> meaning.options.any { it.kanji == id && it.title == expectedMeanings[id] } })
            assertTrue(meaning.options.all { option -> n1.any { it.kanji == option.kanji && it.title == option.title } })
            assertFalse(meaning.options.any { it.kanji in setOf("努", "省") })
            val fallback = meaning.options.filter { it.kanji != "劣" && it.kanji !in curatedIds }
            assertEquals(2, fallback.size)
            assertEquals(guards, meaning.card.toQuizCard().quizExclusions)
            assertTrue(meaning.options.none { it.kanji in guards })
            val actualCards = meaning.options.map { option -> n1.single { it.kanji == option.kanji }.toQuizCard() }
            for (left in actualCards) for (right in actualCards.filter { it.kanji != left.kanji })
                assertFalse(right.kanji in left.quizExclusions || left.kanji in right.quizExclusions)
            for (option in meaning.options) await(option.title).assertIsDisplayed()
            evidence.put("exactDefaultMeaningOptions", JSONArray().also { rows ->
                meaning.options.forEach { rows.put(JSONObject().put("kanji", it.kanji).put("title", it.title)) }
            }).put("actualN1CuratedAvailable", 1).put("actualN1FallbackOptions", 2)
                .put("curatedDistractorLevels", JSONObject().put("努", 3).put("功", 1).put("省", 2))
                .put("meaningFallbackNeedsSemanticReview", true)
            capture("meaning-question")
            click("inferior; worse")
            await("Correct!")
            capture("meaning-feedback")
            back()
            await("Meaning quiz")
            click(rule.onNode(hasText("Start") and hasAnyAncestor(hasText("Readings (on'yomi and kun'yomi)"))))
            val answeredKeys = mutableSetOf<String>()
            repeat(2) {
                rule.waitUntil(30_000) { (model("kreading:") as? KanjiReadingViewModel)?.ui is ReadingUi.Question }
                val reading = model("kreading:") as KanjiReadingViewModel
                val question = reading.ui as ReadingUi.Question
                assertEquals("劣", question.card.kanji)
                val expectedKey = when (question.question.kind) {
                    ReadingKind.On -> "れつ"
                    ReadingKind.Kun -> "おとる"
                }
                assertEquals(expectedKey, question.question.correctKey)
                assertTrue(answeredKeys.add(expectedKey))
                assertEquals(1, question.question.options.count { it.key == expectedKey })
                val kind = if (question.question.kind == ReadingKind.On) "on" else "kun"
                capture("curated-$kind-question")
                click(question.question.options.single { it.key == expectedKey }.label)
                await(if (question.question.kind == ReadingKind.On) "Correct! — on'yomi" else "Correct! — kun'yomi")
                assertTrue((reading.ui as ReadingUi.Answer).correct)
                capture("curated-$kind-feedback")
                click("Next")
            }
            assertEquals(setOf("れつ", "おとる"), answeredKeys)
            rule.waitUntil(30_000) { (model("kreading:") as? KanjiReadingViewModel)?.ui is ReadingUi.Done }
            val done = (model("kreading:") as KanjiReadingViewModel).ui as ReadingUi.Done
            assertEquals(2, done.answered)
            assertEquals(2, done.correct)
            rule.waitUntil(30_000) { runBlocking {
                app.db.reviews().allLog().count { log -> log.sourceId == source.id && log.kanji == "劣" &&
                    log.mode in setOf(ReadingKind.On.mode.name, ReadingKind.Kun.mode.name) && log.grade == 3 } == 2
            } }
            val logs = runBlocking { app.db.reviews().allLog().filter {
                it.sourceId == source.id && it.kanji == "劣" &&
                    it.mode in setOf(ReadingKind.On.mode.name, ReadingKind.Kun.mode.name)
            } }
            assertEquals(2, logs.size)
            assertEquals(setOf("れつ", "おとる"), logs.map { it.reading }.toSet())
            assertTrue(logs.all { it.grade == 3 })
            assertEquals(ReadingKind.On.mode.name, logs.single { it.reading == "れつ" }.mode)
            assertEquals(ReadingKind.Kun.mode.name, logs.single { it.reading == "おとる" }.mode)
            capture("curated-two-keys-done")
            back()
            await("Meaning quiz")
            click(rule.onNode(hasText("Start") and hasAnyAncestor(hasText("Drawing"))))
            await("Trace the kanji for")
            await("inferior; worse").assertIsDisplayed()
            val card = requireNotNull(runBlocking { app.db.content().kanjiCard(source.id, "劣") })
            assertEquals(listOf("レツ"), card.onyomi.splitSep())
            assertEquals(listOf("おと.る"), card.kunyomi.splitSep())
            assertEquals(listOf("レツ"), card.quizOnyomi?.splitSep())
            assertEquals(listOf("おと.る"), card.quizKunyomi?.splitSep())
            assertEquals(guards, card.quizExclusions.splitSep())
            evidence.put("fullProjectionOnyomi", JSONArray(card.onyomi.splitSep()))
                .put("fullProjectionKunyomi", JSONArray(card.kunyomi.splitSep()))
                .put("fullProjectionQuizOnyomi", JSONArray(requireNotNull(card.quizOnyomi).splitSep()))
                .put("fullProjectionQuizKunyomi", JSONArray(requireNotNull(card.quizKunyomi).splitSep()))
            val strokes = JSONObject(requireNotNull(card.strokesJson)).getJSONArray("strokes")
            assertEquals(6, strokes.length())
            capture("drawing-trace")
            val pad = rule.onNode(hasContentDescription("Drawing area for the kanji", substring = true))
            pad.performScrollTo()
            for (index in 0 until strokes.length()) {
                val points = strokes.getJSONObject(index).getJSONArray("points")
                pad.performTouchInput {
                    fun point(i: Int): Offset {
                        val pair = points.getJSONArray(i)
                        return Offset(pair.getDouble(0).toFloat() * width / 109f,
                            pair.getDouble(1).toFloat() * height / 109f)
                    }
                    down(point(0))
                    for (i in 1 until points.length()) moveTo(point(i), delayMillis = 16)
                    up()
                }
            }
            rule.onNode(hasContentDescription("6 strokes drawn", substring = true)).assertExists()
            click("Check")
            await("Practice only: this attempt is not graded.")
            assertFalse(runBlocking { app.db.reviews().allLog().any {
                it.sourceId == source.id && it.kanji == "劣" && it.mode == StudyMode.Draw.name
            } })
            await("Correct strokes").performScrollTo().assertIsDisplayed()
            capture("drawing-feedback")
            click("Next")
            await("Draw the kanji for")
            click("I don't remember")
            await("Here is the kanji")
            capture("drawing-recall-feedback")
            click("Next")
            rule.waitUntil(30_000) { runBlocking { app.db.reviews().allLog().any {
                it.sourceId == source.id && it.kanji == "劣" && it.mode == StudyMode.Draw.name && it.grade == 1
            } } }
            back()
            await("Meaning quiz")
            assertEquals("jlpt-n1", app.settings.stack.value)
            assertNull(connectivity.activeNetwork)
            assertEquals(1, archiveRequests)
            evidence.put("meaningQuestionAndFeedback", true).put("twoCuratedKeysPersistedGoodAndDone", true)
                .put("touchInjectedReferenceStrokes", strokes.length()).put("drawingTraceThenRecall", true)
                .put("drawingGradeRecordedOnNext", true).put("offline", true).put("passed", true)
        } finally {
            File(app.getExternalFilesDir(null), "n1-102-article-route.json").writeText(evidence.toString(2))
            File(app.getExternalFilesDir(null), "n1-102-article-tree.txt").writeText(rule.onRoot().printToString())
            scenario.close()
        }
    }

    private fun model(prefix: String): ViewModel? {
        var result: ViewModel? = null
        scenario.onActivity { activity ->
            result = activity.viewModelStore.keys().lastOrNull { it.startsWith(prefix) }?.let { activity.viewModelStore[it] }
        }
        return result
    }

    private fun await(text: String, substring: Boolean = false): SemanticsNodeInteraction {
        return await(hasText(text, substring = substring))
    }

    private fun await(matcher: SemanticsMatcher): SemanticsNodeInteraction {
        rule.waitUntil(30_000) { rule.onAllNodes(matcher).fetchSemanticsNodes().isNotEmpty() }
        rule.onAllNodes(matcher).assertCountEquals(1)
        return rule.onNode(matcher)
    }

    private fun readingExample(text: String): SemanticsMatcher {
        return hasText(text) and hasAnyAncestor(hasTestTag("article-body")) and
            hasAnyAncestor(SemanticsMatcher.keyIsDefined(SemanticsProperties.HorizontalScrollAxisRange))
    }

    private fun articleBullet(text: String): SemanticsMatcher {
        return hasText(text) and hasAnyAncestor(hasTestTag("article-body")) and
            !hasAnyAncestor(SemanticsMatcher.keyIsDefined(SemanticsProperties.HorizontalScrollAxisRange))
    }

    private fun click(text: String) = click(await(text))

    private fun click(node: SemanticsNodeInteraction) {
        rule.waitUntil(30_000) { !node.fetchSemanticsNode().config.contains(SemanticsProperties.Disabled) }
        if (node.onAncestors().filter(hasScrollAction()).fetchSemanticsNodes().isNotEmpty()) node.performScrollTo()
        node.assertIsDisplayed().assertIsEnabled().performClick()
    }

    private fun section(title: String) {
        rule.onNodeWithTag("article-body").performScrollToIndex(0)
        click("Article contents")
        rule.onNode(hasText(title, substring = true) and hasClickAction()).performScrollTo().performClick()
        rule.waitForIdle()
    }

    private fun show(selector: String, step: String) {
        show(hasText(selector, substring = true), step)
    }

    private fun show(matcher: SemanticsMatcher, step: String, occurrence: Int = 0, expectedCount: Int = 1) {
        val body = rule.onNodeWithTag("article-body")
        body.performScrollToNode(matcher)
        rule.onAllNodes(matcher).assertCountEquals(expectedCount)
        val target = rule.onAllNodes(matcher)[occurrence]
        target.performScrollTo()
        val viewport = body.fetchSemanticsNode()
        val cell = target.fetchSemanticsNode()
        val top = viewport.positionInRoot.y
        val bottom = top + viewport.size.height
        if (cell.positionInRoot.y < top || cell.positionInRoot.y + cell.size.height > bottom) {
            body.performSemanticsAction(SemanticsActions.ScrollBy) {
                it(0f, cell.positionInRoot.y - top - 16f)
            }
            rule.waitForIdle()
        }
        target.assertIsDisplayed()
        capture(step)
    }

    private fun inline(node: SemanticsNodeInteraction, label: String, offset: Int) {
        node.performScrollTo().assertIsDisplayed()
        val text = node.fetchSemanticsNode().config[SemanticsProperties.Text].joinToString("") { it.text }
        val layouts = mutableListOf<TextLayoutResult>()
        node.performSemanticsAction(SemanticsActions.GetTextLayoutResult) { it(layouts) }
        assertTrue("Wrong linked offset $offset for $label in $text", offset >= 0 && text.substring(offset).startsWith(label))
        node.performTouchInput { click(layouts.single().getBoundingBox(offset).center) }
    }

    private fun back() {
        InstrumentationRegistry.getInstrumentation().uiAutomation.performGlobalAction(
            android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
        rule.waitForIdle()
    }

    private fun capture(step: String) {
        rule.waitForIdle()
        val automation = InstrumentationRegistry.getInstrumentation().uiAutomation
        automation.waitForIdle(500, 5_000)
        android.os.SystemClock.sleep(1_000)
        rule.waitForIdle()
        val bitmap = requireNotNull(automation.takeScreenshot())
        File(app.getExternalFilesDir(null), "n1-102-$step.png").outputStream().use {
            assertTrue(bitmap.compress(Bitmap.CompressFormat.PNG, 100, it))
        }
        bitmap.recycle()
    }
}
