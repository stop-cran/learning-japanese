import copy
import hashlib
import json
from pathlib import Path
import zipfile

CONTROL = Path(__file__).resolve().parent
RETRY = CONTROL / "batch-102-native-778-retry-1"
LOG = CONTROL / "logs" / "1e5c8899-b153-4fd1-a82e-eae2746c6163"
packet = json.loads((RETRY / "preparation.json").read_text(encoding="utf-8"))
prep = packet["preparation"]
app = CONTROL / "artifacts" / "n1-batch-102-778-retry-1-app.apk"
test = CONTROL / "artifacts" / "n1-batch-102-778-retry-1-test.apk"
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert (LOG / "native-778-retry-compile-exit.txt").read_text().strip() == "0"
assert "BUILD SUCCESSFUL" in (LOG / "native-778-retry-compile.txt").read_text(encoding="utf-8-sig")
assert sha(app) == packet["preservedOriginal777Compilation"]["appApkSha256"]
with zipfile.ZipFile(test) as apk:
    asset = "assets/" + Path(prep["archive"]).name
    assert hashlib.sha256(apk.read(asset)).hexdigest() == prep["archiveSha256"]
    dex = b"\n".join(apk.read(n) for n in apk.namelist() if n.startswith("classes") and n.endswith(".dex"))
    for key in ("glyphClass", "glyphMethod", "articleClass", "articleMethod"):
        assert prep[key].replace(".", "/").encode() in dex, key
packet["compilation"] = {
    "execution": 778, "status": "compiled-fixture-only-repair-not-executed",
    "command": json.loads((LOG / "native-778-retry-compile-command.json").read_text(encoding="utf-8-sig")),
    "appApk": str(app), "appApkSha256": sha(app),
    "testApk": str(test), "testApkSha256": sha(test),
    "fixtureSha256": prep["fixtureSha256"], "archiveSha256": prep["archiveSha256"],
    "packagedArchiveHashVerified": True, "bothClassesAndMethodsVerified": True,
    "productionAppApkIdenticalToOriginal777": True,
    "temporaryAndroidSourceAndAssetRemoved": True,
    "nativeExecuted": False, "nativeOrVisualAccepted": False,
}
out = RETRY / "compiled-packet.json"
assert not out.exists()
out.write_text(json.dumps(packet, ensure_ascii=True, indent=2) + "\n", encoding="utf-8")
source = (CONTROL / "run-778-native.ps1").read_text(encoding="utf-8")
runner = source.replace(
    '"$control\\..\\learning-japanese\\docs\\n1-reviews\\batch-102-native-777\\compiled-packet.json"',
    '"$control\\batch-102-native-778-retry-1\\compiled-packet.json"',
)
runner = runner.replace('batch-102-native-778"', 'batch-102-native-778-retry-1"')
runner = runner.replace('batch-102-native-778-execution.json"', 'batch-102-native-778-retry-1-execution.json"')
runner = runner.replace("'preflight-778-native.json'", "'preflight-778-native-retry-1.json'")
runner = runner.replace('\\preflight-778-native.json"', '\\preflight-778-native-retry-1.json"')
assert runner != source and "batch-102-native-778-retry-1" in runner
assert r"jdk-17.0.20.101-hotspot" in runner
target = CONTROL / "run-778-native-retry-1.ps1"
assert not target.exists()
target.write_text(runner, encoding="utf-8")
print("Retry APK binds identical production app/full archive; both cases present; original failed attempt preserved.")
