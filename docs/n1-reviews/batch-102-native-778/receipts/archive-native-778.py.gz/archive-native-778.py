from datetime import datetime, timezone
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import shutil

CONTROL = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("native778", CONTROL / "native-778-state.py")
state = importlib.util.module_from_spec(spec)
spec.loader.exec_module(state)
ROOT, LOG, RAW, DEST = state.ROOT, state.LOG, state.RAW, state.DEST
RETRY = CONTROL / "batch-102-native-778-retry-1"
HELD = CONTROL / "artifacts" / "batch-102-native-778-retry-1"


def verify_attempts():
    attempt = state.load(RAW / "execution.json")
    assert attempt["nativeExecuted"] and not attempt["passed"]
    assert attempt["terminalSuccessCases"] == 1 and attempt["adbExitCode"] == 0
    assert attempt["ownedHelperStopped"] and attempt["ownedQemuStopped"]
    assert attempt["heapGrowth"] == "192m" and attempt["heapSize"] == "576m"
    assert attempt["network"] == "Active default network: none"
    assert attempt["coordinatorHead"] == state.BASE and attempt["androidSnapshot"] == state.APP
    assert not attempt["parentLockTouched"] and not attempt["guestOrAppHeapChanged"] and not attempt["guardsChanged"]
    raw = (RAW / "instrumentation.txt").read_text(encoding="utf-8-sig")
    assert len(re.findall(r"(?m)^INSTRUMENTATION_STATUS_CODE: 0\s*$", raw)) == 1
    assert len(re.findall(r"(?m)^INSTRUMENTATION_STATUS_CODE: -2\s*$", raw)) == 1
    assert "N1Batch102Native777Test.kt:436" in raw and "Tests run: 2,  Failures: 1" in raw
    route = state.load(RAW / "n1-102-article-route.json")
    assert not route["passed"] and route["archiveRequests"] == 1
    assert (route["importedKanji"], route["importedWords"], route["n1Cards"], route["problems"],
            route["acceptedReadingParserEpoch"], route["acceptedMeaningParserEpoch"]) == (1125, 5074, 134, 0, 1, 1)
    assert route["fullOnyomi"] == ["レツ"] and route["fullKunyomi"] == ["おと.る"]
    assert route["quizOnKeys"] == ["れつ"] and route["quizKunKeys"] == ["おとる"]
    assert len(route["productionBuilderN1AndAllExactChoices"]) == 64
    assert len(route["kanjiDirectGuardChecks"]) == 1568
    assert len(route["nontransitiveNeighborChecks"]) == 672
    assert len(route["preservedWordGuardChecks"]) == 512
    assert "exactDefaultMeaningOptions" not in route
    for row in route["kanjiDirectGuardChecks"]:
        assert row["target"] in row["options"] and row["excluded"] not in row["options"]
        assert len(row["options"]) == len(set(row["options"]))
    assert all(set(r["options"]) == {r["target"], r["neighbor"]} for r in route["nontransitiveNeighborChecks"])
    raster = state.load(RAW / "n1-102-font-raster.json")
    assert (raster["individualGlyphProbes"], raster["wholeWordRasterProbes"], raster["panels"],
            len(raster["rows"]), raster["sdk"], raster["fontScale"]) == (124, 8, 4, 132, 35, 1)
    assert len(list(RAW.glob("*.png"))) == 22
    held = state.load(HELD / "execution.json")
    assert not held["nativeExecuted"] and not held["passed"]
    assert held["failure"] == "5580/5581 occupied; no helper launched."
    assert "parentEmulatorPid" not in held and not held["preexistingEmulators"]
    assert len(held["prelaunch"]["connections"]) == 1
    connection = held["prelaunch"]["connections"][0]
    assert connection["RemotePort"] == 5581 and connection["OwningProcess"] == 9520
    compiled = state.load(RETRY / "compiled-packet.json")
    assert compiled["compilation"]["productionAppApkIdenticalToOriginal777"]
    for key in ("appApk", "testApk"):
        assert state.sha(Path(compiled["compilation"][key])) == compiled["compilation"][key + "Sha256"]
    return attempt, route, raster, held, compiled


def archive():
    progress = state.load(CONTROL / "progress.json")
    assert (progress["checkpoint"], progress["status"], progress["batch"]) == (777, "continue", "102")
    assert progress["stage"] == "batch-102-native-execution-in-progress"
    for root, head in [(ROOT, state.BASE), (state.ANDROID, state.APP)]:
        assert state.git("rev-parse", "HEAD", root=root) == head
        assert state.git("log", "-1", "--format=%G?", root=root) == "G"
        assert not state.git("status", "--porcelain", "--untracked-files=all", root=root)
    runtime = state.verify_runtime()
    attempt, route, raster, held, compiled = verify_attempts()
    DEST.mkdir(exist_ok=False)
    artifacts = []

    def preserve(source, destination):
        destination.parent.mkdir(exist_ok=True, parents=True)
        assert not destination.exists()
        if destination.suffix == ".gz":
            destination.write_bytes(gzip.compress(source.read_bytes(), mtime=0))
            assert gzip.decompress(destination.read_bytes()) == source.read_bytes()
        else:
            shutil.copyfile(source, destination)
        artifacts.append({
            "file": str(destination.relative_to(DEST)).replace("\\", "/"),
            "sourceBytes": source.stat().st_size,
            "sourceSha256": state.sha(source),
            "storedSha256": state.sha(destination),
        })

    for folder, name in [(RAW, "original-attempt"), (HELD, "retry-port-preflight"), (RETRY, "retry-fixture")]:
        for source in sorted(folder.iterdir()):
            if source.is_file():
                preserve(source, DEST / name / (source.name if source.suffix == ".png" else source.name + ".gz"))
    helpers = [
        "preflight-778.ps1", "native-778-state.py", "generate-native-wrapper-778.py",
        "run-778-native.ps1", "prepare-native-retry-778.py", "compile-native-retry-778.ps1",
        "bind-native-retry-778.py", "run-778-native-retry-1.ps1", "archive-native-778.py",
    ]
    for name in helpers:
        preserve(CONTROL / name, DEST / "receipts" / (name + ".gz"))
    for pattern in ("preflight-778*.json", "starting-state-778.json", "native-778-retry-compile*",
                    "native-wrapper-778.diff"):
        for source in sorted(LOG.glob(pattern)):
            preserve(source, DEST / "receipts" / (source.name + ".gz"))
    labels = sorted({(o["kanji"], o["title"]) for row in route["productionBuilderN1AndAllExactChoices"]
                     for o in row["options"]})
    host_labels = {(r["kanji"], r["title"]) for r in state.load(
        ROOT / "docs" / "n1-reviews" / "batch-102-host-776" / "sampled-labels.json")}
    comparison = {
        "nativeUniqueLabelCount": len(labels), "nativeLabels": [list(x) for x in labels],
        "newVersusHost776": [list(x) for x in sorted(set(labels) - host_labels)],
        "absentVersusHost776": [list(x) for x in sorted(host_labels - set(labels))],
        "liveDefaultLabels": "NOT REACHED; article case failed before live meaning session.",
        "limits": "Actual production-builder64 sampled options from failed route's completed pre-UI assertions only. Ordinary-sense semantic acceptance remains UNVERIFIED pending full frozen dictionary evidence and two original-family rendered confirmations.",
    }
    state.save(DEST / "artifact-index.json", artifacts)
    state.save(DEST / "sampled-labels-and-host-delta.json", comparison)
    inspection = {
        "reviewer": "Coordinator GPT-6.1 Sol (gpt-6.1-sol), not independent review",
        "viewedOriginalPngs": [f"n1-102-font-panel-{i}.png" for i in range(1, 5)],
        "observations": [
            "All31 scoped Han and the 劣/努/功/省, 少/奴, 力/目 look-alikes are readable and distinguishable in these captured panels across Gothic, Mincho, Textbook and Brush; no established blank/tofu or misleading glyph.",
            "優劣 and 劣る are readable in panel4. Cmap/raster hashes alone are not this readability observation.",
            "Actual terminal article tree shows 優劣 (ゆうれつ) followed by an em dash. Original777 fixture expected ASCII hyphen, causing timeout after successful navigation. Two exact heading assertions repaired without changing teaching/app or relaxing assertions.",
        ],
        "routePngs": 18, "originalNativePngs": 22,
        "limits": "Only four original font panels visually inspected; route screenshots preserved, not freshly fully inspected. Article/meaning/reading/drawing/complete reciprocal links/Back/offline acceptance NOT complete. No physical-phone or independent native-speaker certification.",
        "independentRenderedReviewClosed": False,
    }
    state.save(DEST / "coordinator-partial-inspection.json", inspection)
    evidence = {
        "schemaVersion": 1, "execution": 778, "batch": "102",
        "stage": "native-partial-failure-fixture-heading-repaired-compiled-retry-port-occupied",
        "recordedAt": datetime.now(timezone.utc).isoformat(),
        "startingState": progress["execution778StartingState"],
        "testedContentHead": state.BASE, "qualifiedAndroidHead": state.APP,
        "runtime": runtime,
        "originalAttempt": attempt,
        "originalResults": {
            "terminalSuccessCases": 1, "terminalFailureCases": 1, "skipped": 0,
            "glyphCasePassed": True, "articleCasePassed": False,
            "failedFixtureLine": 436, "failure": "ComposeTimeoutException: exact new word heading expected ASCII hyphen instead of actual em dash.",
            "productionContentSyncCalls": 1, "preparseCalls": 0,
            "importedCounts": {"kanji": 1125, "words": 5074, "n1": 134, "problems": 0},
            "acceptedReadingParserEpoch": 1, "acceptedMeaningParserEpoch": 1,
            "completedPreUiDirectGuardChecks": 1568, "completedPreUiNontransitiveNeighborChecks": 672,
            "completedPreUiPreservedWordGuardChecks": 512, "completedPreUiProductionBuilderChoices": 64,
            "individualGlyphProbes": 124, "wholeWordRasterProbes": 8, "fontPanels": 4,
            "scopedHan": 31, "nativePngs": 22,
            "selectedKeysTransported": ["れつ", "おとる"],
            "selectedKeysPersistedGoodAndDone": False,
            "fullLiveMeaningReadingDrawingAndLinksAccepted": False,
        },
        "fixtureOnlyRepair": {
            "changedHeadingAssertions": 2,
            "originalFixtureSha256": compiled["preparation"]["preservedOriginal777FixtureSha256"],
            "retryFixtureSha256": compiled["preparation"]["fixtureSha256"],
            "repair": compiled["preparation"]["retryReason"],
            "compileExitCode": 0, "productionAppApkUnchanged": True,
            "compilation": compiled["compilation"],
            "retryExecution": held,
            "retryDeviceLaunched": False, "retryNativeExecuted": False,
            "occupiedPidInspection": {"pid": 9520, "parentPid": 9360, "name": "adb.exe",
                                     "disposition": "Shared adb server not stopped/altered; exact connection receipt preserved. No ownership assumption, alternate port or retry bypass."},
            "helperDiagnostics": [
                "Initial generated wrapper broadly replaced101 in JDK path; caught during pre-execution diff inspection, corrected before native run. Generator narrowed; actual native shell used authorized17.0.20.101.",
                "Retry preparation first hit Python default cp1252 decoding error before writing artifacts/compiling; explicit UTF-8 fixed. Original logs remain supervisor session evidence.",
            ],
        },
        "coordinatorInspection": inspection, "sampledLabels": comparison,
        "priorTextual775AndHost776": "Inherited as recorded; not repeated.",
        "nativeAcceptanceComplete": False, "independentReviewersLaunched": 0,
        "independentRenderedReviewClosed": False,
        "runtimeChanged": False, "manifestChanged": False, "runtimeAccepted": False,
        "runtimePublished": False, "parentLockTouched": False,
        "optionalHistoricalHelpersAccessed": False, "actualNewPermissionDenials": [],
        "publishedAdditions": 128, "remainingAdditions": 1100,
        "lastPublishedCommit": progress["lastPublishedCommit"],
        "physicalPhoneAcceptance": "outstanding", "generalReleaseAcceptance": "outstanding",
        "wholeProjectComplete": False, "nextBatchStarted": False,
        "nextAction": "SAME102 freshly verify signed/checkpoint/liveparent/session/whollyclean/runtime equality and device+local/remote ports including TimeWait/PID. If safe and5580/5581 genuinely free, run exact separate778-retry1 compiled fixture/APKs using a NEW immutable execution folder/receipt. Never reuse failed/held attempt output names, kill shared adb, change port or weaken checks. Both terminalcase0 required before two SERIAL original-family rendered confirmations, then all original combined-main/publication gates. If ownership/authorization genuinely uncertain preserve/report/yield; no103 or unreviewed push.",
        "limits": "Original native article failure unresolved by execution: only fixture heading repair compiled. Held retry launched no device or cases. Partial mechanical successes are not whole-case/semantic/rendered acceptance. Physical phone/general release/whole set outstanding.",
    }
    state.save(ROOT / "docs" / "n1-sources" / "execution-778.json", evidence)
    print(json.dumps({"evidence": "docs/n1-sources/execution-778.json",
                      "nativeGlyphPassed": True, "nativeArticlePassed": False,
                      "repairCompiled": True, "retryHeldAtOccupiedPort": True,
                      "published": False, "runtimeHashesVerified": 8458}, indent=2))


if __name__ == "__main__":
    archive()
