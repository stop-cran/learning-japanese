import copy
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import zipfile

CONTROL = Path(__file__).resolve().parent
ROOT = CONTROL.parent / "learning-japanese"
ANDROID = CONTROL.parent / "kanji-cards-android"
SESSION = "1e5c8899-b153-4fd1-a82e-eae2746c6163"
LOG = CONTROL / "logs" / SESSION
BASE = "9fb5919b3bc325b6fe7c1089a1086bacc19947c8"
APP = "bf30cdead8515739bc0e671d57a54b9a3109dd46"
RAW = CONTROL / "artifacts" / "batch-102-native-778"
DEST = ROOT / "docs" / "n1-reviews" / "batch-102-native-778"


def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def save(path, data):
    assert not path.exists(), path
    path.write_text(json.dumps(data, ensure_ascii=True, indent=2) + "\n", encoding="utf-8")
    assert load(path) == data


def git(*args, root=ROOT):
    return subprocess.check_output(
        ["git", "--no-pager", "-C", str(root), *args], encoding="utf-8"
    ).strip()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_runtime():
    packet = load(ROOT / "docs" / "n1-reviews" / "batch-102-native-777" / "compiled-packet.json")
    prep, compiled = packet["preparation"], packet["compilation"]
    for path, digest in [
        (prep["archive"], prep["archiveSha256"]),
        (prep["fixture"], prep["fixtureSha256"]),
        (compiled["appApk"], compiled["appApkSha256"]),
        (compiled["testApk"], compiled["testApkSha256"]),
    ]:
        assert sha(Path(path)) == digest, path
    manifest_bytes = (ROOT / "manifest.json").read_bytes()
    manifest = json.loads(manifest_bytes)
    assert manifest["contentVersion"] == "f376333b242ebb23"
    assert sha(ROOT / "manifest.json") == prep["manifestSha256"]
    assert subprocess.check_output([
        "git", "-C", str(ROOT), "show", prep["contentSnapshot"] + ":manifest.json"
    ]) == manifest_bytes
    with zipfile.ZipFile(prep["archive"]) as archive:
        names = archive.namelist()
        prefix = "n1-batch-102/"
        assert len(names) == len(set(names)) == 8480 <= 18000
        assert all(n.startswith(prefix) and "\\" not in n and ".." not in n.split("/")
                   and not n.startswith("/") and not re.search(r"(^|/)[^/]*:", n) for n in names)
        assert not any("/docs/" in n or "/tools/" in n for n in names)
        assert archive.read(prefix + "manifest.json") == manifest_bytes
        retained = len(manifest_bytes)
        count = media = 0
        for section_name, section in manifest.items():
            if not isinstance(section, dict):
                continue
            for name, digest in section.items():
                assert len(name.split("/")) == 2 and ".." not in name.split("/")
                data = archive.read(prefix + name)
                local = (ROOT / name).read_bytes()
                binary = section_name in {"images", "audio", "listeningTaskAudio", "listeningTaskImages"}
                limit = 150 * 1024 if section_name in {"images", "listeningTaskImages"} else (
                    512 * 1024 if section_name in {"audio", "listeningTaskAudio"} else 2 * 1024 * 1024)
                assert len(data) <= limit, name
                normalized = data if binary else data.replace(b"\r\n", b"\n")
                assert hashlib.sha256(normalized).hexdigest() == digest, name
                assert normalized == (local if binary else local.replace(b"\r\n", b"\n")), name
                retained += len(data)
                count += 1
                if section_name in {"listeningTaskAudio", "listeningTaskImages"}:
                    media += len(data)
        inflated = sum(info.file_size for info in archive.infolist())
        compressed = Path(prep["archive"]).stat().st_size
        assert count == 8458 and retained == 44393356 <= 56 * 1024 * 1024
        assert inflated == 44661694 <= 80 * 1024 * 1024
        assert compressed == 30483598 <= 42 * 1024 * 1024
        assert media == 5893602 <= 20 * 1024 * 1024
    return {
        "runtimeHashesVerified": count, "contentVersion": manifest["contentVersion"],
        "manifestSha256": sha(ROOT / "manifest.json"), "manifestEqualsCompiledArchive": True,
        "archiveContentSnapshot": prep["contentSnapshot"], "archiveSha256": prep["archiveSha256"],
        "zipEntries": len(names), "compressedBytes": compressed, "inflatedBytes": inflated,
        "retainedBytes": retained, "listeningTaskMediaBytes": media,
        "allOriginalBudgetsAndPerFilePathMediaGuardsPassed": True,
    }


def start():
    original = load(CONTROL / "progress.json")
    assert (original["checkpoint"], original["status"], original["batch"]) == (777, "continue", "102")
    assert "execution778StartingState" not in original
    for root, head in [(ROOT, BASE), (ANDROID, APP)]:
        assert git("rev-parse", "HEAD", root=root) == head
        assert git("log", "-1", "--format=%G?", root=root) == "G"
        assert not git("status", "--porcelain", "--untracked-files=all", root=root)
    request = (LOG / "request.txt").read_bytes()
    text = request.decode("utf-8-sig")
    checkpoint = json.loads(text.split(
        "Current execution checkpoint (complete historical state remains at checkpointHistory paths):", 1
    )[1])
    assert checkpoint["execution777CoordinatorCheckpoint"]["savedCommit"] == BASE
    runtime = verify_runtime()
    state = {
        "execution": 778, "batch": "102",
        "startedAt": datetime.now(timezone.utc).isoformat(),
        "startingHead": BASE, "androidHead": APP,
        "freshOriginMain": git("rev-parse", "origin/main"),
        "scope": "SAME102 execute exact compiled NEW777 native APKs on freshly owned emulator and preserve signed LOCAL evidence; no reviewers/publication/103.",
        "request": {
            "sha256": hashlib.sha256(request).hexdigest(), "bytes": len(request),
            "characters": len(text), "lines": len(text.splitlines()),
            "completeFileLoadedAndCheckpointParsed": True,
            "limits": "Entire request decoded and checkpoint parsed; operative contract, complete issue and final777 inspected directly. Historical middle parsed, not freshly semantically rereviewed.",
        },
        "runnerPreflight": load(LOG / "preflight-778.json"),
        "artifactPathPreflight": "Approved committed packets, frozen workspace inputs and durable control helpers only; optional historical-session recipes not accessed.",
        "actualNewPermissionDenials": [],
        "runtime": runtime,
    }
    updated = copy.deepcopy(original)
    updated["execution778StartingState"] = state
    updated["stage"] = "batch-102-native-execution-in-progress"
    temporary = CONTROL / "progress.json.778-start.tmp"
    save(temporary, updated)
    assert load(CONTROL / "progress.json") == original
    os.replace(temporary, CONTROL / "progress.json")
    reread = load(CONTROL / "progress.json")
    assert all(reread[k] == v for k, v in original.items() if k != "stage")
    save(LOG / "starting-state-778.json", state)
    print("Starting scope persisted; complete request parsed; all8458 runtime hashes and exact compiled archive/APKs verified.")


if __name__ == "__main__":
    start()
