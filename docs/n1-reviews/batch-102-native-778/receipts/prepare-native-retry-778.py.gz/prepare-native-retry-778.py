import copy
import difflib
import hashlib
import json
from pathlib import Path

CONTROL = Path(__file__).resolve().parent
ROOT = CONTROL.parent / "learning-japanese"
LOG = CONTROL / "logs" / "1e5c8899-b153-4fd1-a82e-eae2746c6163"
RETRY = CONTROL / "batch-102-native-778-retry-1"
old = json.loads((ROOT / "docs" / "n1-reviews" / "batch-102-native-777" / "compiled-packet.json").read_text(encoding="utf-8"))
original = Path(old["preparation"]["fixture"]).read_text(encoding="utf-8")
fixed = (RETRY / "N1Batch102Native777Test.kt").read_text(encoding="utf-8")
before = 'await("優劣 (ゆうれつ) - superiority or inferiority; relative merits")'
after = 'await("優劣 (ゆうれつ) — superiority or inferiority; relative merits")'
assert original.count(before) == 2 and fixed == original.replace(before, after)
tree = (CONTROL / "artifacts" / "batch-102-native-778" / "n1-102-article-tree.txt").read_text(encoding="utf-8")
assert "優劣 (ゆうれつ) — superiority or inferiority; relative merits" in tree
packet = copy.deepcopy(old)
prep = packet["preparation"]
prep["fixture"] = str(RETRY / "N1Batch102Native777Test.kt")
prep["fixtureSha256"] = hashlib.sha256(Path(prep["fixture"]).read_bytes()).hexdigest()
prep["retryReason"] = "Original777 fixture expected ASCII hyphen twice, but signed new article and actual native semantics use an em dash. Exact heading match repaired; no assertion removed, timeout extended, production or teaching changed."
prep["preservedOriginal777FixtureSha256"] = old["preparation"]["fixtureSha256"]
prep["original778Attempt"] = str(CONTROL / "artifacts" / "batch-102-native-778" / "execution.json")
prep["nativeCompiled"] = False
prep["nativeExecuted"] = False
prep["status"] = "fixture-heading-corrected-awaiting-compilation"
packet["preservedOriginal777Compilation"] = packet.pop("compilation")
path = RETRY / "preparation.json"
assert not path.exists()
path.write_text(json.dumps(packet, ensure_ascii=True, indent=2) + "\n", encoding="utf-8")
diff = "".join(difflib.unified_diff(
    original.splitlines(keepends=True), fixed.splitlines(keepends=True),
    fromfile="preserved777/N1Batch102Native777Test.kt",
    tofile="retry778/N1Batch102Native777Test.kt",
))
(RETRY / "fixture.diff").write_text(diff, encoding="utf-8")
print("Exact two-heading fixture repair verified against actual native tree; original failure/777 artifacts unchanged.")
