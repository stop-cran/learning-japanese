import difflib
from pathlib import Path

CONTROL = Path(__file__).resolve().parent
source = (CONTROL / "run-768-native.ps1").read_text(encoding="utf-8-sig")
result = source
replacements = [
    ("b683cc5d-e782-4126-bed9-1748b95f8bdb", "1e5c8899-b153-4fd1-a82e-eae2746c6163"),
    ("batch-101", "batch-102"),
    ("batch='101'", "batch='102'"),
    ("$checkpoint.batch -ne '101'", "$checkpoint.batch -ne '102'"),
    ("n1-101-", "n1-102-"),
    ("768", "778"),
    ("767", "777"),
    ("223b227af1eb3220272346957f312bb829e9510e", "9fb5919b3bc325b6fe7c1089a1086bacc19947c8"),
    ('"$control\\batch-102-native-777\\compiled-packet.json"',
     '"$control\\..\\learning-japanese\\docs\\n1-reviews\\batch-102-native-777\\compiled-packet.json"'),
]
for old, new in replacements:
    assert old in result, old
    result = result.replace(old, new)
assert "File.Open" not in result and "runner.lock" not in result
assert r"jdk-17.0.20.101-hotspot" in result
target = CONTROL / "run-778-native.ps1"
assert not target.exists()
target.write_text(result, encoding="utf-8")
diff = "".join(difflib.unified_diff(
    source.splitlines(keepends=True), result.splitlines(keepends=True),
    fromfile="approved-control/run-768-native.ps1", tofile="control/run-778-native.ps1",
))
(CONTROL / "logs" / "1e5c8899-b153-4fd1-a82e-eae2746c6163" / "native-wrapper-778.diff").write_text(
    diff, encoding="utf-8"
)
print("Generated bounded wrapper from durable control template; parent lock untouched.")
