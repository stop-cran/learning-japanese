"""Archive and checkpoint rendered-confirmation preparation without acceptance credit."""
import copy
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

from importlib.util import module_from_spec, spec_from_file_location

C = Path(__file__).resolve().parent
spec = spec_from_file_location("prepare827", C / "prepare-rendered-827.py")
prep = module_from_spec(spec)
spec.loader.exec_module(prep)
R, L, D = prep.R, prep.L, prep.D
E = R / "docs" / "n1-sources" / "execution-827.json"
load, save, sha, git = prep.load, prep.save, prep.sha, prep.git


def archive():
    p = load(C / "progress.json")
    assert (p["checkpoint"], p["status"], p["batch"]) == (826, "continue", "106")
    assert git("rev-parse", "HEAD").decode().strip() == prep.BASE
    checks = load(D / "preparation-checks.json")
    assert checks["runtime"] == prep.verify_runtime()
    access = load(D / "source-access.json")
    packet = Path(access["commonPacket"]["reviewPath"]).read_bytes()
    assert gzip.decompress((D / "common-packet.txt.gz").read_bytes()) == packet
    assert sha(packet) == access["commonPacket"]["sha256"]
    for row in access["completeSourceResources"]:
        assert sha(Path(row["reviewPath"]).read_bytes()) == row["sha256"]
    for row in load(D / "image-manifest.json"):
        assert sha(Path(row["path"]).read_bytes()) == row["sha256"]
    for name in ("preflight-827.ps1", "prepare-rendered-827.py", "audit-rendered-827.py", "finish-rendered-827.py",
                 "post-rendered-827.ps1"):
        (D / (name + ".gz")).write_bytes(gzip.compress((C / name).read_bytes(), mtime=0))
    for name in ("preflight-827.json", "starting-state-827.json", "validate-827.txt",
                 "manifest-827.txt", "manifest-diff-827.txt", "packet-audit-827.txt"):
        (D / (name + ".gz")).write_bytes(gzip.compress((L / name).read_bytes(), mtime=0))
    index = [{"file": x.name, "sha256": sha(x.read_bytes()), "bytes": x.stat().st_size}
             for x in sorted(D.iterdir()) if x.is_file()]
    save(D / "artifact-index.json", index)
    save(E, {
        "schemaVersion": 1, "execution": 827, "batch": "106",
        "recordedAt": datetime.now(timezone.utc).isoformat(),
        "stage": "original-family-rendered-confirmation-inputs-frozen-not-executed",
        "sourceSnapshot": prep.BASE, "qualifiedAndroidHead": prep.APP,
        "startingState": p["execution827StartingState"],
        "packet": D.relative_to(R).as_posix(), "commonPacket": access["commonPacket"],
        "originalSessions": access["originalSessions"], "checks": checks,
        "validatorErrors": 0, "manifestRegeneratedUnchanged": True,
        "artifactIndexSha256": sha((D / "artifact-index.json").read_bytes()),
        "independentReviewersLaunched": 0, "independentRenderedReviewClosed": False,
        "newNativeOrdinarySenseFallbackSemanticAcceptance": "UNVERIFIED pending both original-family rendered confirmations",
        "runtimeChanged": False, "runtimeAccepted": False, "runtimePublished": False,
        "actualNewPermissionDenials": [], "parentLockTouched": False,
        "optionalHistoricalHelpersAccessed": False, "publishedAdditions": 132,
        "remainingAdditions": 1096, "lastPublishedCommit": p["lastPublishedCommit"],
        "physicalPhoneAcceptance": "outstanding", "generalReleaseAcceptance": "outstanding",
        "wholeProjectComplete": False, "nextBatchStarted": False,
        "limits": [
            "Preparation and exact byte/round-trip audits are not independent review, comprehension, source-language certification or native rerun.",
            "The original822 weak precept hypothesis stays unresolved nonblocking; no speculative guard or universal semantic safety claim.",
            "Native825 has42 original PNGs/26 distinct rasters; this preparation binds bytes, not new visual inspection or original-pixel/physical-phone evidence.",
            "Initial822, HOST823, native825 and source826 scope/read-depth/source/process/denial/OOM/history limits remain inherited without retroacceptance.",
            "All original combined-main/review/validation/signing/owner-publication/CI/immutableZIP and unchanged archive guard gates remain mandatory.",
        ],
    })
    print("Archived preparation evidence and recipes; no runtime or acceptance change.")


def finish():
    p, before = load(C / "progress.json"), load(L / "progress-before-827.json")
    assert (p["checkpoint"], p["status"], p["batch"]) == (826, "continue", "106")
    head = git("rev-parse", "HEAD").decode().strip()
    assert git("rev-parse", "HEAD^").decode().strip() == prep.BASE
    assert git("log", "-1", "--format=%G?").decode().strip() == "G"
    assert not git("status", "--porcelain", "--untracked-files=all").strip()
    changed = git("diff", "--name-only", prep.BASE, head).decode().splitlines()
    assert changed and all(x.startswith("docs/n1-reviews/batch-106-rendered-827/") or
                           x == "docs/n1-sources/execution-827.json" for x in changed)
    checks = load(D / "preparation-checks.json")
    assert checks["runtime"] == prep.verify_runtime()
    for row in load(D / "artifact-index.json"):
        raw = (D / row["file"]).read_bytes()
        assert sha(raw) == row["sha256"]
        path = (D / row["file"]).relative_to(R).as_posix()
        assert sha(git("show", head + ":" + path)) == row["sha256"]
    posted, comment = load(L / "issue-827-posted.json"), load(L / "issue-827-reread.json")
    body = (C / "batch-106-rendered-827-issue-body.txt").read_text(encoding="utf-8")
    assert comment["user"]["login"] == posted["author"] == "stop-cran"
    assert comment["body"] == body and comment["html_url"] == posted["url"]
    assert posted["bodySha256"] == sha(body.encode("utf-8"))
    mutable = {"checkpoint", "status", "stage", "nextAction", "blocker", "checkpointHistory"}
    assert all(p[k] == value for k, value in before.items() if k not in mutable)
    historical = {k: before.get(k) for k in (
        "checkpoint", "status", "stage", "nextAction", "blocker", "checkpointHistory")}
    next_action = (
        f"SAME106 checkpoint827 signed LOCAL rendered-confirmation preparation HEAD{head}, qualifiedAndroid{prep.APP}. "
        "Read docs/n1-sources/execution-827.json and docs/n1-reviews/batch-106-rendered-827/. "
        "Prepared common-task.txt/common-packet.txt.gz/source-access.json/image-manifest.json/exact-native-options.json; "
        "common packet293233bytes6123lines SHA256854d3c66d3c635ee874f96dc44529eb141053938ec5c12f8aefc85eb7fb6dadb "
        "also durablecontrol/batch-106-rendered-827-common-packet.txt. Full original822packet and completeHOST823 "
        "32families44characterrecords plus82621families5records decoded to exactcontrol paths listedsource-access; "
        "all committed bytes matched.42originalPNGbindings/26distinctrasters; full825artifactindex/826indexverified. "
        "64nativeexactorderedoption samples/seeds and4exactorderedpoolmemberships losslesslyinterned/roundtripchecked; "
        "32explicitunguardedhypothesis samples retained. Entire common packet includes unchangedtarget/support/reused "
        "articles/exactdiff, originalfindingsreconciliation, HOSTfinitealloptions/BOTHworddirections, fivenativelabel "
        "source/body supplement, routefields and actualPNGscope/limits. Teaching/runtime unchangedsince822. "
        "NEXT SAME106 EXECUTE TWO SERIAL ORIGINAL-family rendered confirmations, NOT newblindinitials: "
        "Claude session4304295f-1fe0-4f7a-a8c4-2db9b547857d actualclaude-opus-5.5; "
        "GPT session4d834a27-eaf4-47ea-a4d6-32f583e4ed4c actualgpt-6.1-sol. "
        "Refresh actual installed CLI help/catalog and use supported originalsessionresume/viewonly flags; "
        "record ACTUAL returnedmodel/configuration/usage/toolranges/PNGscope/exit. SAMEcommon task/packet/sources/PNGmanifest "
        "plus OWN original report. OnlyONEreviewerprocessatonce, actualexitbeforethenext; serialpertool, "
        "noeditfrozensnapshot/noauthoragents/nestedtasks. Source-access resources contain ALLcomplete relevant "
        "families/restrictions; inspect especially1956150/1236890and1430550/1604470. Newnativefive labels "
        "剰/扱/獣/矛/芋; exactdefault畔paddyboundary-waterside/剰remainder-surplusamount/俸salary-stipend/勅imperialorder. "
        "Original822勅訓weak hypothesis remainsUNRESOLVED NONBLOCKING, notforcedwithdrawal/establisheddefect/"
        "speculativeguard/universalsafety. Newnativeordinarysecondarysensefallbacksemanticacceptance UNVERIFIED "
        "until BOTHoriginalfamily rendered confirmations. Fullon[チョク]/kun[いまし.める,みことのり]preserved exactorder, "
        "selected[チョク]/[]; solekeyちょく/displayチョク; legacyfeedbackrawkunstillvisible; "
        "modernwrittenいまし.めるUNVERIFIED/outsideJoyoREADINGlistNOTfrequency-invalidity. "
        "Actual42PNGs/26distinct; all3fourfontpanels, wholeword/radical/lookalikes, articles/scrollcolumns/"
        "reused令line/meaning/reading/drawing/N1-All scope honest; 900x2000renditionsNOToriginalpixel/phone/"
        "nativespeaker/fallbackfacecertification. Drawingreferenceinjection/revealgradeNOTmastery. "
        "No reviewer launched827; no freshHOST/native/visualsemanticacceptance claim. Any consequentialdefect: "
        "exactsource/minimalcorrection/audits/manifest/normalsignednewfreeze/BOTHoriginalfamilies. "
        "All8472runtimehashes/version89809c00e1676979/manifestunchanged; validator0errors/regeneratedmanifestunchanged. "
        "Full previous826nextAction retained verbatim in historicalExecution826Before827RenderedPreparation.nextAction; "
        "ALL original acceptance/publication/source/reviewer/process/denial/OOM/history limits mandatory. "
        "Combinedcurrentmain/nonrewritingmerge/changedteachingreview/fullrequiredPython/vocabulary/baseline-membership-links/"
        "manifestbudget/normalsigning/ownerfastforward/terminalgreenCI/EVERYimmutableGitHubZIPmanifesthash/"
        "unchanged18000entries42MiBcompressed80MiBinflated56MiBretained/perfilepathmedia/verifiedownerissue. "
        "No107/unreviewedpush/concurrentheavywork/secondrunner/signingretry/guardincrease. Freshsignedheads/"
        "checkpoint/whollyclean/freshmain/liveparentancestry/decodedlauncher/exactsession required. "
        "Parent13320ownsrunner.lock:nochildacquire/delete/unlock/readprobe; approvedcontrol/committedsource/frozeninputs only. "
        "Preserve/report/yield actualnewdenial/signinghang/uncertainownership. Published132/1228/remainder1096unchanged; "
        "lastpublished0c582f18b31f65a5e1a908d92e37dde3d34f81ee; unaccepted勅/necessarysupport勅令notN1vocabularydelivery. "
        "CompatibleAndroid125+132 required;oldclientsignore. Physicalphone/generalrelease/whole-setoutstanding;projectincomplete."
    )
    checkpoint = {
        "schemaVersion": 1, "execution": 827, "checkpoint": 827, "batch": "106",
        "status": "continue", "stage": "batch-106-original-family-rendered-confirmation-inputs-frozen",
        "recordedAt": datetime.now(timezone.utc).isoformat(), "savedCommit": head, "signature": "G",
        "qualifiedAndroidHead": prep.APP, "sourceSnapshot": prep.BASE,
        "evidence": E.relative_to(R).as_posix(), "issueUpdate": posted["url"],
        "ownerIssueAuthorAndExactBodyVerified": True, "checks": checks,
        "independentReviewersLaunched": 0, "independentRenderedReviewClosed": False,
        "newNativeOrdinarySenseFallbackSemanticAcceptance": "UNVERIFIED pending both original-family rendered confirmations",
        "runtimeChanged": False, "runtimeAccepted": False, "runtimePublished": False,
        "dedicatedWorktreesClean": True, "parentLockTouched": False, "actualNewPermissionDenials": [],
        "publishedAdditions": 132, "remainingAdditions": 1096, "lastPublishedCommit": p["lastPublishedCommit"],
        "physicalPhoneAcceptance": "outstanding", "generalReleaseAcceptance": "outstanding",
        "wholeProjectComplete": False, "nextBatchStarted": False,
        "originalHistoricalRootKeysCompared": len(before),
        "allOriginalHistoricalValuesPreserved": True,
        "finalRunnerPreflight": load(L / "preflight-827-before-issue.json"),
        "nextAction": next_action, "blocker": None,
    }
    updated = copy.deepcopy(p)
    updated["historicalExecution826Before827RenderedPreparation"] = historical
    updated["execution827StartingState"]["status"] = "signed-local-rendered-confirmation-input-checkpoint-complete"
    updated["execution827CoordinatorCheckpoint"] = checkpoint
    for key in ("checkpoint", "status", "stage", "nextAction", "blocker"):
        updated[key] = checkpoint[key]
    updated["checkpointHistory"] = {
        "completeSnapshot": str(L / "checkpoint-full.json"), "liveProgressPath": str(C / "progress.json"),
        "invariant": "Preserve full live history; immutable snapshot is the observer input."}
    assert all(updated[k] == v for k, v in before.items() if k not in mutable)
    save(L / "checkpoint-827-summary.json", checkpoint)
    tmp = C / "progress.json.827.tmp"
    save(tmp, updated)
    assert load(tmp) == updated
    os.replace(tmp, C / "progress.json")
    reread = load(C / "progress.json")
    assert reread == updated
    assert all(reread[k] == v for k, v in before.items() if k not in mutable)
    save(L / "checkpoint-827-final-verification.json", {
        "checkpoint": 827, "head": head, "signed": "G", "whollyClean": True,
        "allOriginalHistoricalValuesPreserved": True, "rootKeysCompared": len(before),
        "runtimeHashesVerified": 8472, "independentReviewersLaunched": 0, "projectComplete": False})
    print(f"Checkpoint827 saved; full history preserved; signed local {head}; status continue.")


if __name__ == "__main__":
    {"archive": archive, "finish": finish}[sys.argv[1]]()
