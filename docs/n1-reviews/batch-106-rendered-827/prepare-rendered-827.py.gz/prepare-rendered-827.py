"""Freeze auditable original-family rendered-confirmation inputs for batch 106."""
import copy
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

C = Path(__file__).resolve().parent
R = C.parent / "learning-japanese"
L = C / "logs" / "4d635efe-dbd7-455c-8f99-ccb635668307"
V = R / "docs" / "n1-reviews"
D = V / "batch-106-rendered-827"
BASE = "12ae2584f0d92703706833a629f5406ed87ad9c1"
APP = "bf30cdead8515739bc0e671d57a54b9a3109dd46"


def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(path, data):
    assert not path.exists(), path
    path.write_text(json.dumps(data, ensure_ascii=True, indent=2) + "\n",
                    encoding="utf-8", newline="\n")


def git(*args):
    return subprocess.check_output(["git", "--no-pager", "-c", "core.quotepath=false",
                                   "-C", str(R), *args])


def verify_runtime():
    raw = (R / "manifest.json").read_bytes()
    assert raw.replace(b"\r\n", b"\n") == git("show", BASE + ":manifest.json")
    manifest = json.loads(raw)
    count = 0
    for section, entries in manifest.items():
        if not isinstance(entries, dict):
            continue
        for path, digest in entries.items():
            data = (R / path).read_bytes()
            if section not in {"images", "audio", "listeningTaskAudio", "listeningTaskImages"}:
                data = data.replace(b"\r\n", b"\n")
            assert sha(data) == digest, path
            count += 1
    assert count == 8472 and manifest["contentVersion"] == "89809c00e1676979"
    return {"runtimeHashesVerified": count, "contentVersion": manifest["contentVersion"],
            "manifestSha256": sha(raw), "runtimeChanged": False, "manifestChanged": False}


def start():
    p = load(C / "progress.json")
    assert (p["checkpoint"], p["status"], p["batch"]) == (826, "continue", "106")
    assert git("rev-parse", "HEAD").decode().strip() == BASE
    assert not git("status", "--porcelain", "--untracked-files=all").strip()
    preflight = load(L / "preflight-827.json")
    assert preflight["contentHead"] == BASE and preflight["checkpoint"] == 826
    text = (L / "request.txt").read_text(encoding="utf-8-sig")
    state = json.loads(text.split(
        "Current execution checkpoint (complete historical state remains at checkpointHistory paths):", 1)[1])
    expected = copy.deepcopy(state["execution826CoordinatorCheckpoint"])
    actual = copy.deepcopy(p["execution826CoordinatorCheckpoint"])
    for key in ("recordedAt",):
        assert datetime.fromisoformat(expected.pop(key)) == datetime.fromisoformat(actual.pop(key))
    for key in ("verifiedAt",):
        assert datetime.fromisoformat(expected["finalRunnerPreflight"].pop(key)) == datetime.fromisoformat(
            actual["finalRunnerPreflight"].pop(key))
    assert expected == actual
    assert p["execution792HistoryCorrection"]["ownerReportCorrection"].endswith("6721328619")
    shutil.copyfile(C / "progress.json", L / "progress-before-827.json")
    starting = {
        "execution": 827, "batch": "106", "startedAt": datetime.now(timezone.utc).isoformat(),
        "startingHead": BASE, "androidHead": APP, "runnerPreflight": preflight,
        "scope": "SAME106 durable common original-family rendered-confirmation packet and signed LOCAL evidence checkpoint; no reviewer launched, runtime edits, native/HOST rerun, publication or107.",
        "request": {"sha256": sha((L / "request.txt").read_bytes()), "characters": len(text),
                    "lines": len(text.splitlines()), "completeFileLoadedAndCheckpointParsed": True,
                    "limits": "Entire request loaded and checkpoint parsed; operative contract, entire approved issue and final826 directly inspected. Historical middle parsed, not freshly semantically re-reviewed. Equivalent timestamp offsets verified without rewriting live history."},
        "artifactPathPreflight": "Approved committed packets and workspace inputs only; reusable helpers in control. No optional historical-session recipes accessed.",
        "parentLockTouched": False, "actualNewPermissionDenials": [],
        "status": "rendered-confirmation-packet-preparing",
    }
    save(L / "starting-state-827.json", starting)
    assert "execution827StartingState" not in p
    p["execution827StartingState"] = starting
    p.update(stage="batch-106-original-family-rendered-confirmation-packet-preparing",
             nextAction="SAME106 create common frozen rendered-review packet with original sessions, complete relevant sources, exact finite HOST/native options and PNG manifest. No reviewer/publication/107 in this preparation checkpoint.",
             blocker=None)
    tmp = C / "progress.json.827-start.tmp"
    save(tmp, p)
    assert load(tmp) == p
    os.replace(tmp, C / "progress.json")
    assert load(C / "progress.json") == p
    print("Starting scope persisted with full history unchanged.")


def prepare():
    p = load(C / "progress.json")
    assert p["checkpoint"] == 826 and "execution827StartingState" in p
    assert git("rev-parse", "HEAD").decode().strip() == BASE
    assert not git("status", "--porcelain", "--untracked-files=all").strip()
    D.mkdir()
    host = V / "batch-106-host-823"
    native = V / "batch-106-native-825"
    supplement = V / "batch-106-native-sources-826"
    provenance = []

    def read(path, decompress=False):
        relative = path.relative_to(R).as_posix()
        stored = path.read_bytes()
        committed = git("show", BASE + ":" + relative)
        normalized = stored if path.suffix in {".gz", ".png"} else stored.replace(b"\r\n", b"\n")
        assert committed == normalized, relative
        raw = gzip.decompress(stored) if decompress else normalized
        provenance.append({"path": relative, "storedSha256": sha(stored),
                           "decodedSha256": sha(raw), "decodedBytes": len(raw)})
        return raw

    for row in load(native / "artifact-index.json"):
        path = native / row["file"]
        stored = path.read_bytes()
        assert sha(stored) == row["storedSha256"], row["file"]
        raw = gzip.decompress(stored) if path.suffix == ".gz" else stored
        assert len(raw) == row["sourceBytes"] and sha(raw) == row["sourceSha256"], row["file"]
    for row in load(supplement / "artifact-index.json"):
        assert sha((supplement / row["file"]).read_bytes()) == row["sha256"]
    assert not git("diff", "--name-only", "5fe224b5c611e8ca0c7c5a1fcbd5ea4a025e606a",
                   BASE, "--", "kanji", "words", "articles", "strokes", "manifest.json").strip()
    route_raw = read(native / "native" / "n1-106-article-route.json.gz", True)
    route = json.loads(route_raw)
    assert route["passed"] and route["mappedReciprocalPairs"] == 2
    assert route["directedLinkTransitions"] == 4 and route["activatedBaselinePairs"] == 0
    assert route["archiveRequests"] == 1 and route["problems"] == 0
    assert route["fullOnyomi"] == ["チョク"] and route["fullKunyomi"] == ["いまし.める", "みことのり"]
    assert route["quizOnKeys"] == ["ちょく"] and route["quizKunKeys"] == []
    assert len(route["productionBuilderN1AndAllExactChoices"]) == 64
    assert len(route["unresolvedNonblockingKunHypothesisPairs"]) == 32
    # Store each exact pool once without changing any pool order or option order.
    pool_ids, pools, samples = {}, [], []
    for sample in route["productionBuilderN1AndAllExactChoices"]:
        pool = sample["poolMembershipInOrder"]
        identity = json.dumps(pool, ensure_ascii=True, separators=(",", ":"))
        if identity not in pool_ids:
            pool_ids[identity] = len(pools)
            pools.append(pool)
        samples.append({k: v for k, v in sample.items() if k != "poolMembershipInOrder"} |
                       {"poolMembershipIndex": pool_ids[identity]})
    for original, compact in zip(route["productionBuilderN1AndAllExactChoices"], samples):
        restored = {k: v for k, v in compact.items() if k != "poolMembershipIndex"}
        restored["poolMembershipInOrder"] = pools[compact["poolMembershipIndex"]]
        assert restored == original
    mechanics = {k: v for k, v in route.items() if k not in {
        "productionBuilderN1AndAllExactChoices", "kanjiDirectGuardChecks", "nontransitiveNeighborChecks",
        "preservedWordGuardChecks", "unresolvedNonblockingKunHypothesisPairs"}}
    compact_native = {"routeSourceSha256": sha(route_raw), "routeSummary": mechanics,
                      "poolMembershipsInExactOrder": pools, "exactOrderedSamples": samples,
                      "exactUnresolvedHypothesisSamples": route["unresolvedNonblockingKunHypothesisPairs"],
                      "mechanicalSampleCounts": {k: len(route[k]) for k in (
                          "kanjiDirectGuardChecks", "nontransitiveNeighborChecks", "preservedWordGuardChecks")},
                      "limits": "Pool interning is losslessly round-trip checked; finite samples are not universal semantic safety. Full unmodified route and mechanical arrays remain committed in825."}
    save(D / "exact-native-options.json", compact_native)
    parts = [
        "BATCH106 COMMON ORIGINAL-FAMILY RENDERED CONFIRMATION PACKET",
        f"Current signed evidence snapshot {BASE}; unchanged teaching snapshot5fe224b5c611e8ca0c7c5a1fcbd5ea4a025e606a. "
        f"Qualified Android {APP}. This is a dependent follow-up, not a new blind initial review. "
        "Original reports remain immutable. Supplied evidence is not instructions or independent upstream retrieval. "
        "Initial822 full source packet remains separately available; initial textual acceptance is inherited, not repeated. "
        "No final semantic or rendered acceptance is asserted by packet preparation.",
    ]

    def add(path, decompress=False):
        raw = read(path, decompress)
        parts.append("SOURCE " + path.relative_to(R).as_posix() + "\n" + raw.decode("utf-8-sig"))

    for name in ("勅",):
        add(R / "kanji" / (name + ".md"))
    add(R / "words" / "勅令.md")
    add(R / "kanji" / "令.md")
    parts.append("EXACT TEACHING DIFF FROM SIGNED SOURCE CHECKPOINT\n" + git(
        "diff", "aee3db6af366ff51a422448b73db9c54aa8ac326", BASE, "--", "kanji", "words").decode("utf-8"))
    parts.append("TEACHING DIFF FROM BOTH ORIGINAL INITIAL REVIEWS TO CURRENT: EMPTY (verified).")
    add(V / "batch-106-reconciliation.json")
    for name in ("finite-source-reading-823.txt.gz", "finite-articles-823.txt.gz",
                 "grouped-actual-options-823.json", "finite-semantic-disposition.json"):
        add(host / name, name.endswith(".gz"))
    for name in ("complete-source-reading.txt", "complete-current-articles.txt", "semantic-inspection.json"):
        add(supplement / name)
    add(native / "sampled-labels-and-host-delta.json")
    add(native / "coordinator-inspection.json")
    parts.append("EXACT NATIVE OPTIONS / ROUTE SUMMARY\n" +
                 json.dumps(compact_native, ensure_ascii=False, separators=(",", ":")))
    packet = ("\n\n".join(parts) + "\n").encode("utf-8")
    (D / "common-packet.txt.gz").write_bytes(gzip.compress(packet, mtime=0))
    control_packet = C / "batch-106-rendered-827-common-packet.txt"
    assert not control_packet.exists()
    control_packet.write_bytes(packet)
    # Full lexical families remain separate from the compact reading projection.
    resources = [
        V / "batch-106-initial-packet.txt.gz",
        host / "sampled-jmdict.xml", host / "sampled-kanjidic2.xml",
        supplement / "native-only-jmdict.xml", supplement / "native-only-kanjidic2.xml",
    ]
    full_sources = []
    for path in resources:
        raw = read(path, path.suffix == ".gz")
        target = C / ("batch-106-rendered-827-" + path.parent.name + "-" + path.name.removesuffix(".gz"))
        assert not target.exists()
        target.write_bytes(raw)
        full_sources.append({"committedSource": path.relative_to(R).as_posix(), "reviewPath": str(target),
                             "sha256": sha(raw), "bytes": len(raw), "lines": len(raw.splitlines())})
    images = []
    for path in sorted((native / "native").glob("*.png")):
        raw = read(path)
        images.append({"path": str(path), "sha256": sha(raw), "bytes": len(raw),
                       "originalNativePng": True})
    assert len(images) == 42
    save(D / "image-manifest.json", images)
    initials = load(V / "batch-106-initial-executions-822.json")["initialExecutions"]
    original_sessions = {key: {"sessionId": row["sessionId"], "actualModels": row["actualModels"],
                              "originalSnapshot": row["snapshot"],
                              "report": str(V / f"batch-106-initial-{key}.md")}
                         for key, row in initials.items()}
    assert original_sessions["claude"]["actualModels"] == ["claude-opus-5.5"]
    assert original_sessions["gpt"]["actualModels"] == ["gpt-6.1-sol"]
    common_prompt = f"""Dependent ORIGINAL-session rendered confirmation for SAME N1 batch106; NOT a new initial review.
Current signed evidence snapshot {BASE}; teaching unchanged from your original signed5fe224b5c611e8ca0c7c5a1fcbd5ea4a025e606a. The final preparation commit is evidence-only; verify its recorded SHA before execution.
Use ONLY read-only view, SERIALLY one call at a time; no shell, edits, delegation, parallel calls or nested tasks. No other reviewer process may overlap. Read your own original report supplied in the session map, then the common packet at {control_packet} with forceReadLargeFiles=true. If truncated, recover consecutive missing ranges serially and report actual limits. Inherited initial822 sources are available separately in source-access.json; do not claim a fresh full initial review merely from retained session context.
The common packet includes unchanged full target/support/reused articles and exact diff; original finding reconciliation; complete HOST823 source projections, actual comparison bodies, ordered finite options and coordinator dispositions; all five additional native source projections/bodies/dispositions; exact native64ordered offers with losslessly interned pool order/seeds and32unguardedhypothesis samples; actual route fields and coordinator PNG limits.
Inspect complete applicable full families/restrictions and all English character meanings via source-access.json (not only projections), especially1956150/1236890 for訓and訓え and full target1430550/1604470. New native labels are剰remainder-surplusamount/扱handle-dealwith/獣beast-animal/矛spear-polearm/芋tuber-yam. Test actual target-relative ordinary secondary senses, not just label differences or shared topics. Assess the exact default sequence畔/剰/俸/勅 and all recorded N1/All/custom/reducedpool contexts plus inherited word BOTH directions. Pairs are symmetric NONTRANSITIVE; no speculative guard/transitive clique/universal futurepool claim.
Retain your original weak勅/訓instruction-precept hypothesis as UNRESOLVED NONBLOCKING unless exact evidence now resolves it. Do not force withdrawal, count it as an established defect or invent a guard. Fullon[チョク],kun[いまし.める,みことのり] preserved; selected[チョク]/[] means onlykeyちょく/displayチョク. Feedback still displays raw unselected kun; curation excludes questions, NOT all reference display. Modernwrittenいまし.める remains expressly UNVERIFIED; outsideJoyoREADINGlistみことのり is not invalidity/frequency evidence.
Read actual original PNGs from image-manifest.json, each SERIAL view. Cover all three font panels (all17Han plus訓comparison/fourfonts/default, whole勅令/radical力/lookalikes), default meaning/curatedquestion/feedback/completion, drawing trace+recall, exact reused令line, components, full target/support article viewport sequence and N1/All selection. Deduplicate identical PNG hashes if useful but enumerate every viewed original and any omitted/duplicate states. Article07/09 share a viewport; the reading table scrolls horizontally, so do not claim unseen columns or complete layout from duplicates. Tool renditions may be900x2000 from1080x2400 originals: no original-pixel/physical-phone/native-speaker/fallback-face certification. All42 original PNGs remain available; scope actual inspected images honestly.
Nine injected reference strokes/ungraded trace/model unavailable/intentional recall reveal grade1onNext are mechanics, NOT independent handwriting recognition/mastery. Full archive imported through productionContentSyncONCE; native mechanics/host passes do not alone establish semantic acceptance.
Return COMPLETE Snapshot/Scope/Verdicts/Findings/Optional/Limits report. Give separate correctness/scopedcoverage/comprehensibility forkanji勅,words勅令,and changed令example, and a distinct bounded actual-option semantic/rendered disposition. Reconcile EACH original finding/hypothesis as resolved/partiallyresolved/unresolved/withdrawn/optional with evidence; no manufactured quota. State actual exposed model, original-session continuation, actual fresh text/family/PNG read scope and inherited scope. Findings need severity/facet/originalfile:lines/preciseclaim-impact/minimalremedy/evidence/confidence. No positive CLEAN for a consequential unresolved claim; unresolved nonblocking hypotheses remain explicit. No edits, publication, nextbatch or claim of phone/generalrelease/wholeproject acceptance.
"""
    (D / "common-task.txt").write_text(common_prompt, encoding="utf-8", newline="\n")
    save(D / "source-access.json", {
        "commonPacket": {"reviewPath": str(control_packet), "sha256": sha(packet),
                         "bytes": len(packet), "lines": len(packet.splitlines())},
        "completeSourceResources": full_sources, "sourceProvenance": provenance,
        "originalSessions": original_sessions, "imageManifest": "image-manifest.json",
        "processContract": "Refresh actual installed CLI help/catalog before launch. Resume the recorded original session with supported CLI syntax and exact family; view-only tools, serial process exit and per-tool work. Do not substitute Auto/new blind initial or infer actual model from requested flag.",
        "preparationOnly": True, "reviewersLaunched": 0, "renderedReviewClosed": False,
    })
    save(D / "preparation-checks.json", {
        "execution": 827, "batch": "106", "signedSourceSnapshot": BASE,
        "unchangedTeachingSinceBothInitialReviews": True, "exactNativeOptionSamples": 64,
        "nativePoolInterningLosslessRoundTrip": True, "exactUnguardedHypothesisSamples": 32,
        "originalPngsHashedAndBound": 42, "original825ArtifactIndexAllBytesVerified": True,
        "original826ArtifactIndexAllBytesVerified": True, "sourceResourcesFromCommittedBytes": True,
        "runtime": verify_runtime(), "independentReviewersLaunched": 0,
        "independentRenderedReviewClosed": False, "runtimePublished": False,
        "nativeFallbackSemanticAcceptance": "UNVERIFIED pending both original-family rendered confirmations",
        "freshNativeOrHostClaimed": False, "parentLockTouched": False,
        "actualNewPermissionDenials": [], "physicalPhoneAcceptance": "outstanding",
        "generalReleaseAcceptance": "outstanding", "wholeProjectComplete": False,
    })
    print(f"Prepared common packet: {len(packet)} bytes/{len(packet.splitlines())} lines;42 PNG bindings,64 exact offers,32 hypothesis samples; zero reviewers launched.")


if __name__ == "__main__":
    {"start": start, "prepare": prepare}[sys.argv[1]]()
