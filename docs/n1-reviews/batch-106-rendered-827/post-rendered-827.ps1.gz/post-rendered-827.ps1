$ErrorActionPreference = 'Stop'
$control = $PSScriptRoot
$log = "$control\logs\4d635efe-dbd7-455c-8f99-ccb635668307"
$content = "$control\..\learning-japanese"
$bodyPath = "$control\batch-106-rendered-827-issue-body.txt"
if ((Test-Path "$log\issue-827-posted.json") -or (Test-Path $bodyPath)) {
    throw 'Do not duplicate owner issue update'
}
$head = git -C $content rev-parse HEAD
if ($LASTEXITCODE -ne 0) { throw 'HEAD lookup failed' }
& "$control\preflight-827.ps1" -ReceiptName 'preflight-827-before-issue.json' -ExpectedContentHead $head
if (-not $?) { throw 'Final preflight failed' }
if ((git -C $content rev-parse 'HEAD^') -ne '12ae2584f0d92703706833a629f5406ed87ad9c1' -or
    $LASTEXITCODE -ne 0) { throw 'Wrong evidence ancestry' }
$body = @"
Checkpoint 827, SAME batch 106: original-family rendered-confirmation inputs are now frozen at signed LOCAL evidence commit $head. See docs/n1-sources/execution-827.json and docs/n1-reviews/batch-106-rendered-827/.

The common packet binds unchanged teaching and exact diff, original findings, inherited complete HOST source projections/comparison bodies/finite options (including word quizzes in both directions), the five native-only label source/body supplement, and exact native route/ordered answers/pool memberships/seeds. All64native offers and32unguarded instruction/precept-hypothesis samples are retained; interning repeated pool lists is independently lossless-round-trip checked. Full original822source packet and complete HOST32JMdict/44character plus native-supplement21JMdict/5character records are available at durable approved control paths with exact hashes. All42 original native PNGs are bound (26distinct rasters); hashes do not claim new visual inspection. Both original model/session identities and their own complete reports are retained.

This checkpoint prepares execution; it does NOT count as either rendered confirmation. Zero reviewers launched. Next: refresh actual CLI help/catalog, resume BOTH ORIGINAL model-family sessions serially with view-only tools, inspect the same packet/full relevant families/actual PNG scope, preserve complete reports and model/read/process evidence, then reconcile. Each process must exit before the next, and tools must remain serial. The original weak instruction/precept hypothesis remains explicitly UNRESOLVED NONBLOCKING; no forced withdrawal, speculative guard, established-defect claim or universal future-pool safety. New native fallback semantic acceptance remains UNVERIFIED until both confirmations. Existing822textual/823HOST/825native/826source evidence and all its limits remain inherited, not repeated or retroaccepted.

All8472runtime hashes/contentVersion89809c00e1676979 unchanged; validator zero errors and regenerated manifest unchanged. No teaching edits, content push, runtime acceptance, delivery credit, Android/native rerun, next batch or phone claim. Parent runner lock untouched; full progress history preserved; committed packets and approved workspace inputs only, no optional historical-session recipes or actual new permission denial.

Published132/1228; remaining1096; last published0c582f18b31f65a5e1a908d92e37dde3d34f81ee. Combined-current-main integration, substantive-change review, all required Python/vocabulary/baseline-membership-links/manifest/per-file-media-safe-path checks, normal signed owner fast-forward publication, terminal green CI and EVERY immutable-ZIP runtime hash/budget check remain mandatory. Unchanged18000entries/42MiBcompressed/80MiBinflated/56MiBretained guards. Compatible Android reading-curation/kanji-exclusion client required; old clients ignore those fields. Unaccepted one-kanji/one-necessary-support batch is not N1 vocabulary delivery. Physical-phone/general-release/whole-set acceptance remains outstanding; project incomplete.
"@
[IO.File]::WriteAllText($bodyPath, ($body -replace "`r`n", "`n") + "`n", [Text.UTF8Encoding]::new($false))
$priorToken = $env:GH_TOKEN
try {
    $env:GH_TOKEN = (gh auth token --user stop-cran)
    if ($LASTEXITCODE -ne 0 -or -not $env:GH_TOKEN) { throw 'Owner credential unavailable' }
    $login = gh api user --jq .login
    if ($LASTEXITCODE -ne 0 -or $login -cne 'stop-cran') { throw 'Wrong command-scoped identity' }
    $url = gh issue comment 60 --repo stop-cran/learning-japanese --body-file $bodyPath
    if ($LASTEXITCODE -ne 0) { throw 'Issue update failed; preserve outcome without reposting' }
    $url = $url.Trim()
    @{url=$url; author=$login; bodySha256=(Get-FileHash $bodyPath).Hash.ToLowerInvariant()} |
        ConvertTo-Json | Set-Content "$log\issue-827-posted.json" -Encoding utf8NoBOM
    if ($url -notmatch '#issuecomment-(\d+)$') { throw 'Unexpected URL; preserve receipt' }
    $raw = gh api "repos/stop-cran/learning-japanese/issues/comments/$($Matches[1])"
    if ($LASTEXITCODE -ne 0) { throw 'Comment reread failed' }
    $raw | Set-Content "$log\issue-827-reread.json" -Encoding utf8NoBOM
    $comment = $raw | ConvertFrom-Json
    if ($comment.user.login -cne 'stop-cran' -or $comment.body -cne [IO.File]::ReadAllText($bodyPath) -or
        $comment.html_url -cne $url) { throw 'Exact owner/body verification failed' }
    Write-Output "Verified owner update: $url"
} finally {
    $env:GH_TOKEN = $priorToken
}
