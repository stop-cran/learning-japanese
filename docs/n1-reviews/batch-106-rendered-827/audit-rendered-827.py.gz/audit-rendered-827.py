"""Check the exact frozen review inputs, not linguistic acceptance."""
import gzip
import hashlib
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET

C = Path(__file__).resolve().parent
R = C.parent / "learning-japanese"
V = R / "docs" / "n1-reviews"
D = V / "batch-106-rendered-827"
access = json.loads((D / "source-access.json").read_text(encoding="utf-8"))
packet = Path(access["commonPacket"]["reviewPath"]).read_bytes()
assert gzip.decompress((D / "common-packet.txt.gz").read_bytes()) == packet
assert hashlib.sha256(packet).hexdigest() == access["commonPacket"]["sha256"]
assert len(packet) == access["commonPacket"]["bytes"]
assert len(packet.splitlines()) == access["commonPacket"]["lines"]
expected = [(None, None), (32, 0), (0, 44), (21, 0), (0, 5)]
family_ids = set()
for resource, counts in zip(access["completeSourceResources"], expected, strict=True):
    raw = Path(resource["reviewPath"]).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == resource["sha256"]
    if counts[0] is None:
        ids = re.findall(rb"<ent_seq>(\d+)</ent_seq>", raw)
        assert len(ids) == len(set(ids)) == 79
        family_ids.update(x.decode() for x in ids)
    else:
        root = ET.fromstring(raw)
        assert (len(root.findall("entry")), len(root.findall("character"))) == counts
        family_ids.update(e.findtext("ent_seq") for e in root.findall("entry"))
assert {"1956150", "1236890", "1430550", "1604470"} <= family_ids
route = json.loads(gzip.decompress(
    (V / "batch-106-native-825" / "native" / "n1-106-article-route.json.gz").read_bytes()))
compact = json.loads((D / "exact-native-options.json").read_text(encoding="utf-8"))
assert len(compact["exactOrderedSamples"]) == 64
for source, item in zip(route["productionBuilderN1AndAllExactChoices"], compact["exactOrderedSamples"], strict=True):
    rebuilt = {k: v for k, v in item.items() if k != "poolMembershipIndex"}
    rebuilt["poolMembershipInOrder"] = compact["poolMembershipsInExactOrder"][item["poolMembershipIndex"]]
    assert rebuilt == source
assert compact["exactUnresolvedHypothesisSamples"] == route["unresolvedNonblockingKunHypothesisPairs"]
assert len(compact["exactUnresolvedHypothesisSamples"]) == 32
assert compact["routeSummary"]["exactDefaultMeaningOptions"] == route["exactDefaultMeaningOptions"]
images = json.loads((D / "image-manifest.json").read_text(encoding="utf-8"))
assert len(images) == 42
hashes = set()
for image in images:
    raw = Path(image["path"]).read_bytes()
    assert raw[:8] == b"\x89PNG\r\n\x1a\n"
    assert hashlib.sha256(raw).hexdigest() == image["sha256"]
    hashes.add(image["sha256"])
assert len(hashes) == 26
assert access["originalSessions"]["claude"]["sessionId"] == "4304295f-1fe0-4f7a-a8c4-2db9b547857d"
assert access["originalSessions"]["gpt"]["sessionId"] == "4d834a27-eaf4-47ea-a4d6-32f583e4ed4c"
assert access["reviewersLaunched"] == 0 and not access["renderedReviewClosed"]
print("PASS: common packet bytes/lines/hash and compressed archive match.")
print("PASS: full initial79 families; HOST32families44characters; supplement21families5characters; all four required families available.")
print("PASS: all64 native ordered samples/seeds/pool memberships round-trip exactly; all32 hypothesis samples and live default labels exact.")
print("PASS:42 actual original PNG hashes/signatures,26 distinct rasters; exact original-family sessions.")
print("Limits: input audit only; zero reviewers, no fresh linguistic/native/phone acceptance.")
