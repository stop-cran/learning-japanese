import copy
from datetime import datetime, timezone
import gzip
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import sys

CONTROL = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("native778", CONTROL / "native-778-state.py")
state = importlib.util.module_from_spec(spec)
spec.loader.exec_module(state)
SESSION = "575ef251-1745-4e88-ad9c-eac7c714dcaf"
LOG = CONTROL / "logs" / SESSION
BASE = "19b6cacc1e9cacc7d76e9daef1eb8825064b239e"
RAW = CONTROL / "artifacts" / "batch-102-native-779"
DEST = state.ROOT / "docs" / "n1-reviews" / "batch-102-native-779"


def start():
    original = state.load(CONTROL / "progress.json")
    assert (original["checkpoint"], original["status"], original["batch"]) == (778, "continue", "102")
    assert "execution779StartingState" not in original
    request = (LOG / "request.txt").read_bytes()
    text = request.decode("utf-8-sig")
    checkpoint = json.loads(text.split(
        "Current execution checkpoint (complete historical state remains at checkpointHistory paths):", 1
    )[1])
    assert checkpoint["execution778CoordinatorCheckpoint"]["savedCommit"] == BASE
    runtime = state.verify_runtime()
    packet = state.load(CONTROL / "batch-102-native-778-retry-1" / "compiled-packet.json")
    for path, digest in [
        (packet["preparation"]["fixture"], packet["preparation"]["fixtureSha256"]),
        (packet["compilation"]["appApk"], packet["compilation"]["appApkSha256"]),
        (packet["compilation"]["testApk"], packet["compilation"]["testApkSha256"]),
    ]:
        assert state.sha(Path(path)) == digest, path
    record = {
        "execution": 779, "batch": "102", "startedAt": datetime.now(timezone.utc).isoformat(),
        "startingHead": BASE, "androidHead": state.APP,
        "freshOriginMain": state.git("rev-parse", "origin/main"),
        "scope": "SAME102 exact repaired778retry1 native APK execution and signed LOCAL evidence only; no reviewer/publication/103.",
        "request": {
            "sha256": state.sha(LOG / "request.txt"), "bytes": len(request), "lines": len(text.splitlines()),
            "completeFileLoadedAndCheckpointParsed": True,
            "limits": "Entire request loaded/decoded and checkpoint parsed; operative contract, complete issue and final778 inspected directly. Historical middle parsed, not freshly semantically rereviewed.",
        },
        "runnerPreflight": state.load(LOG / "preflight-779.json"),
        "runtime": runtime,
        "artifactPathPreflight": "Approved committed source packets, frozen inputs and durable control helpers only; optional historical session recipes not accessed.",
        "actualNewPermissionDenials": [],
    }
    updated = copy.deepcopy(original)
    updated["execution779StartingState"] = record
    updated["stage"] = "batch-102-native-repaired-retry-in-progress"
    temporary = CONTROL / "progress.json.779-start.tmp"
    state.save(temporary, updated)
    assert state.load(CONTROL / "progress.json") == original
    os.replace(temporary, CONTROL / "progress.json")
    assert state.load(CONTROL / "progress.json") == updated
    state.save(LOG / "starting-state-779.json", record)
    print("Starting scope persisted; complete request parsed; all8458 runtime hashes and exact repaired APKs verified.")


def wrapper():
    source = (CONTROL / "run-778-native-retry-1.ps1").read_text(encoding="utf-8-sig")
    replacements = {
        "'1e5c8899-b153-4fd1-a82e-eae2746c6163'": "'" + SESSION + "'",
        '$folder = "$control\\artifacts\\batch-102-native-778-retry-1"': '$folder = "$control\\artifacts\\batch-102-native-779"',
        '$receipt = "$control\\batch-102-native-778-retry-1-execution.json"': '$receipt = "$control\\batch-102-native-779-execution.json"',
        "execution=778;": "execution=779;",
        "coordinatorHead='9fb5919b3bc325b6fe7c1089a1086bacc19947c8'": "coordinatorHead='" + BASE + "'",
        'preflight-778.ps1': 'preflight-779.ps1',
        'preflight-778-native-retry-1.json': 'preflight-779-native.json',
        '$checkpoint.checkpoint -ne 777': '$checkpoint.checkpoint -ne 778',
        "'batch-102-native-execution-in-progress'": "'batch-102-native-repaired-retry-in-progress'",
    }
    for before, after in replacements.items():
        assert source.count(before) >= 1, before
        source = source.replace(before, after)
    path = CONTROL / "run-779-native.ps1"
    assert not path.exists()
    path.write_text(source, encoding="utf-8")
    print("Fresh native wrapper generated; immutable repaired input packet retained.")


def results():
    attempt = state.load(RAW / "execution.json")
    assert attempt["passed"] and attempt["nativeExecuted"] and attempt["failure"] is None
    assert attempt["terminalSuccessCases"] == 2 and attempt["adbExitCode"] == 0
    assert attempt["ownedHelperStopped"] and attempt["ownedQemuStopped"]
    assert attempt["coordinatorHead"] == BASE and attempt["androidSnapshot"] == state.APP
    assert attempt["prelaunch"]["connections"] == [] and not attempt["preexistingEmulators"]
    assert attempt["heapGrowth"] == "192m" and attempt["heapSize"] == "576m"
    assert attempt["network"] == "Active default network: none"
    assert not any(attempt[k] for k in ("parentLockTouched", "guestOrAppHeapChanged", "guardsChanged"))
    raw = (RAW / "instrumentation.txt").read_text(encoding="utf-8-sig")
    assert len(re.findall(r"(?m)^INSTRUMENTATION_STATUS_CODE: 0\s*$", raw)) == 2
    assert "OK (2 tests)" in raw
    assert not re.search(r"INSTRUMENTATION_STATUS_CODE: -[234]|FAILURES|INSTRUMENTATION_FAILED|ignored|assumptionFailure", raw)
    route = state.load(RAW / "n1-102-article-route.json")
    assert route["passed"] and route["archiveRequests"] == 1
    assert (route["importedKanji"], route["importedWords"], route["n1Cards"], route["problems"],
            route["acceptedReadingParserEpoch"], route["acceptedMeaningParserEpoch"]) == (1125, 5074, 134, 0, 1, 1)
    assert (route["mappedReciprocalPairs"], route["directedLinkTransitions"],
            route["activatedBaselinePairs"], route["changedReusedArticles"]) == (3, 6, 1, 2)
    assert all(route[k] for k in (
        "reciprocalLinkAndSystemBack", "meaningQuestionAndFeedback", "twoCuratedKeysPersistedGoodAndDone",
        "drawingTraceThenRecall", "drawingGradeRecordedOnNext", "offline"))
    assert route["touchInjectedReferenceStrokes"] == 6
    assert route["fullOnyomi"] == route["fullProjectionOnyomi"] == route["fullProjectionQuizOnyomi"] == ["レツ"]
    assert route["fullKunyomi"] == route["fullProjectionKunyomi"] == route["fullProjectionQuizKunyomi"] == ["おと.る"]
    assert route["quizOnKeys"] == ["れつ"] and route["quizKunKeys"] == ["おとる"]
    assert (route["actualN1CuratedAvailable"], route["actualN1FallbackOptions"]) == (1, 2)
    assert route["curatedDistractorLevels"] == {"努": 3, "功": 1, "省": 2}
    assert len(route["productionBuilderN1AndAllExactChoices"]) == 64
    assert len(route["kanjiDirectGuardChecks"]) == 1568
    assert len(route["nontransitiveNeighborChecks"]) == 672
    assert len(route["preservedWordGuardChecks"]) == 512
    for row in route["kanjiDirectGuardChecks"]:
        assert row["target"] in row["options"] and row["excluded"] not in row["options"]
        assert len(row["options"]) == len(set(row["options"]))
    assert all(set(r["options"]) == {r["target"], r["neighbor"]} for r in route["nontransitiveNeighborChecks"])
    raster = state.load(RAW / "n1-102-font-raster.json")
    assert (raster["individualGlyphProbes"], raster["wholeWordRasterProbes"], raster["panels"],
            len(raster["rows"]), raster["sdk"], raster["fontScale"]) == (124, 8, 4, 132, 35, 1)
    assert len(list(RAW.glob("*.png"))) == 43
    return attempt, route, raster


def archive():
    progress = state.load(CONTROL / "progress.json")
    assert (progress["checkpoint"], progress["status"], progress["batch"]) == (778, "continue", "102")
    assert progress["stage"] == "batch-102-native-repaired-retry-in-progress"
    for root, head in [(state.ROOT, BASE), (state.ANDROID, state.APP)]:
        assert state.git("rev-parse", "HEAD", root=root) == head
        assert state.git("log", "-1", "--format=%G?", root=root) == "G"
        assert not state.git("status", "--porcelain", "--untracked-files=all", root=root)
    runtime = state.verify_runtime()
    attempt, route, raster = results()
    DEST.mkdir(exist_ok=False)
    artifacts = []

    def preserve(source, destination):
        destination.parent.mkdir(exist_ok=True, parents=True)
        assert not destination.exists()
        if destination.suffix == ".gz":
            destination.write_bytes(gzip.compress(source.read_bytes(), mtime=0))
            assert gzip.decompress(destination.read_bytes()) == source.read_bytes()
        else:
            shutil.copyfile(source, destination)
        artifacts.append({
            "file": str(destination.relative_to(DEST)).replace("\\", "/"),
            "sourceBytes": source.stat().st_size, "sourceSha256": state.sha(source),
            "storedSha256": state.sha(destination),
        })

    for source in sorted(RAW.iterdir()):
        assert source.is_file()
        preserve(source, DEST / "native" / (source.name if source.suffix == ".png" else source.name + ".gz"))
    for name in ("preflight-779.ps1", "native-779.py", "run-779-native.ps1"):
        preserve(CONTROL / name, DEST / "receipts" / (name + ".gz"))
    for name in ("preflight-779.json", "preflight-779-native.json", "starting-state-779.json"):
        preserve(LOG / name, DEST / "receipts" / (name + ".gz"))
    packet = CONTROL / "batch-102-native-778-retry-1" / "compiled-packet.json"
    preserve(packet, DEST / "receipts" / "repaired-778-compiled-packet.json.gz")
    state.save(DEST / "artifact-index.json", artifacts)
    labels = {(o["kanji"], o["title"]) for row in route["productionBuilderN1AndAllExactChoices"] for o in row["options"]}
    labels.update((o["kanji"], o["title"]) for o in route["exactDefaultMeaningOptions"])
    host = {(r["kanji"], r["title"]) for r in state.load(
        state.ROOT / "docs" / "n1-reviews" / "batch-102-host-776" / "sampled-labels.json")}
    comparison = {
        "nativeUniqueLabelCount": len(labels), "nativeLabels": [list(x) for x in sorted(labels)],
        "newVersusHost776": [list(x) for x in sorted(labels - host)],
        "absentVersusHost776": [list(x) for x in sorted(host - labels)],
        "exactLiveDefault": route["exactDefaultMeaningOptions"],
        "limits": "Actual production-builder64 sampled choices and actual live N1 default labels; ordinary-secondary-sense semantic acceptance UNVERIFIED pending full frozen dictionary evidence and both original-family rendered confirmations.",
    }
    state.save(DEST / "sampled-labels-and-host-delta.json", comparison)
    viewed = [f"n1-102-font-panel-{i}.png" for i in range(1, 5)] + [
        "n1-102-meaning-question.png", "n1-102-meaning-feedback.png",
        "n1-102-curated-on-question.png", "n1-102-curated-kun-question.png",
        "n1-102-curated-two-keys-done.png", "n1-102-drawing-recall-feedback.png",
        "n1-102-otoru-components.png", "n1-102-yuuretsu-components.png",
        "n1-102-yuu-new-reciprocal.png", "n1-102-article-18.png", "n1-102-drawing-feedback.png",
    ]
    inspection = {
        "reviewer": "Coordinator GPT-6.1 Sol (gpt-6.1-sol), not independent review",
        "viewedOriginalPngs": viewed, "viewedCount": len(viewed), "totalOriginalPngs": 43,
        "observations": [
            "All31 scoped Han and 劣/努/功/省, 少/奴 and 力/目 look-alikes readable and distinguishable across the four actual production-family panels; no established blank/tofu or misleading glyph. Actual fallback face not identified.",
            "Live meaning choices visibly match inferior; worse / superfluous; redundant / firefly / merit; achievement, with correct feedback. Whole sampled fallback ordinary-sense semantic review remains UNVERIFIED.",
            "Both レツ and おとる question screens are readable; two-of-two completion captured and distinct correct key logs asserted.",
            "Three selected component/reciprocal screens and the scoped kanji notes are readable at the captured device size; no clipping makes the selected target passage unreadable. Reading tables permit horizontal scrolling.",
            "Reference-stroke injected trace shows Well drawn, practice-only/ungraded feedback; recall intentionally uses I don't remember, reveals six correct strokes and persists grade1 on Next. This does not demonstrate human handwriting recognition or learning mastery.",
        ],
        "limits": "15 of43 native PNGs freshly visually inspected, including all4 font panels; remaining28 preserved, not freshly visually inspected. Assertions cover full route but do not replace independent visual/linguistic review. No physical phone, native-speaker certification or general-release claim.",
        "independentRenderedReviewClosed": False,
    }
    state.save(DEST / "coordinator-inspection.json", inspection)
    evidence = {
        "schemaVersion": 1, "execution": 779, "batch": "102",
        "stage": "native-two-terminal-cases-passed-awaiting-original-family-rendered-confirmations",
        "recordedAt": datetime.now(timezone.utc).isoformat(),
        "startingState": progress["execution779StartingState"],
        "testedContentHead": BASE, "archiveContentSnapshot": route["contentSnapshot"],
        "qualifiedAndroidHead": state.APP, "runtime": runtime, "nativeAttempt": attempt,
        "nativeResults": {
            "terminalSuccessCases": 2, "terminalFailureCases": 0, "skipped": 0,
            "productionContentSyncCalls": 1, "preparseCalls": 0,
            "importedCounts": {"kanji": 1125, "words": 5074, "n1": 134, "problems": 0},
            "acceptedReadingParserEpoch": 1, "acceptedMeaningParserEpoch": 1,
            "directSymmetricGuardChecks": 1568, "nontransitiveNeighborChecks": 672,
            "preservedWordGuardChecks": 512, "productionBuilderChoices": 64,
            "individualGlyphProbes": 124, "wholeWordRasterProbes": 8, "fontPanels": 4,
            "scopedHan": 31, "nativePngs": 43, "twoCuratedKeysPersistedGoodAndDone": True,
            "selectedKeys": route["quizOnKeys"] + route["quizKunKeys"],
            "mappedReciprocalPairs": 3, "directedLinkTransitions": 6,
            "activatedBaselinePairs": 1, "changedReusedArticles": 2,
            "meaningQuestionAndFeedback": True, "drawingTraceThenRecall": True,
            "drawingRecallDeliberatelyRevealedThenGrade1OnNext": True,
            "touchInjectedReferenceStrokes": 6, "offline": True, "systemBack": True,
        },
        "prior778FailureAndHeldRetry": "Preserved unchanged under docs/n1-reviews/batch-102-native-778/; exact separate repaired778retry1 APKs reused, no rebuilt archive/app or content change.",
        "prior775TextualAnd776Host": "Inherited as recorded; not repeated.",
        "coordinatorInspection": inspection, "sampledLabels": comparison,
        "nativeExecutionComplete": True, "independentReviewersLaunched": 0,
        "independentRenderedReviewClosed": False, "ordinarySenseFallbackSemanticAcceptance": "UNVERIFIED",
        "runtimeChanged": False, "manifestChanged": False, "runtimeAccepted": False, "runtimePublished": False,
        "parentLockTouched": False, "optionalHistoricalHelpersAccessed": False, "actualNewPermissionDenials": [],
        "publishedAdditions": 128, "remainingAdditions": 1100, "lastPublishedCommit": progress["lastPublishedCommit"],
        "physicalPhoneAcceptance": "outstanding", "generalReleaseAcceptance": "outstanding",
        "wholeProjectComplete": False, "nextBatchStarted": False,
        "nextAction": "SAME102 TWO SERIAL original-family rendered confirmations on this unchanged teaching/runtime snapshot. Supply actual full native PNGs, exact native/HOST sampled labels and complete applicable frozen dictionary evidence, preserving original775 reports and read limits. No fresh blind credit. Semantic sample coverage is not exhaustive. Then reconcile and finish all original current-main/integration/validation/signing/owner-fast-forward/CI/immutableZIP gates before publication or103.",
        "limits": "Passed bounded emulator mechanics, not all semantic/independent rendered/physical-phone acceptance. Progress fixture postpones other N1 questions and seeds two old meaning logs, but no drawing state. Trace touch-injects exact reference points; recall deliberately reveals. All original acceptance gates/history remain.",
    }
    state.save(state.ROOT / "docs" / "n1-sources" / "execution-779.json", evidence)
    print("Both terminal cases verified; full immutable native evidence archived; independent rendered acceptance pending.")


if __name__ == "__main__":
    {"start": start, "wrapper": wrapper, "archive": archive}[sys.argv[1]]()
