$ErrorActionPreference = 'Stop'
$control = $PSScriptRoot
$log = "$control\logs\3f0d3ca8-b16f-4a15-a909-f4e879a55b50"
$content = "$control\..\learning-japanese"
$bodyPath = "$control\batch-106-rendered-829-issue-body.txt"
if ((Test-Path "$log\issue-829-posted.json") -or (Test-Path $bodyPath)) {
    throw 'Do not duplicate owner issue update'
}
$head = git -C $content rev-parse HEAD
if ($LASTEXITCODE -ne 0) { throw 'HEAD lookup failed' }
& "$control\preflight-829.ps1" -ReceiptName 'preflight-829-before-issue.json' -ExpectedContentHead $head
if (-not $?) { throw 'Final preflight failed' }
if ((git -C $content rev-parse 'HEAD^') -ne '99522a889cdbd8d04f4a185d2fcfd69d5c7302bb' -or
    $LASTEXITCODE -ne 0) { throw 'Wrong evidence ancestry' }
$body = @"
Checkpoint 829, SAME batch 106: obtained a NEW compliant ORIGINAL-Claude bounded rendered confirmation at signed LOCAL evidence commit $head. Full new report/execution/read-and-process audit/disposition: docs/n1-reviews/batch-106-rendered-829/ and docs/n1-sources/execution-829.json.

Actual claude-opus-5.5 resumed original session4304295f-1fe0-4f7a-a8c4-2db9b547857d, exited0 and PID17008 is absent. Ten successful view calls, each in its own assistant response: ZERO overlaps/multi-tool responses. Fresh complete raw HOST/native KANJIDIC2 and JMdict extracts; exact initial-packet1815-1895 covers full1430550/1430560/1597670/1604470, including all restrictions; all THREE affected font panels inspected separately. Common6123line packet and23nonfont PNG reads are explicitly INHERITED serial scope, independently checked against the prior execution. Of42original PNGs,26distinct rasters are covered across fresh/inherited scope;16byte-identical duplicate paths were not opened. Access receipts do not certify comprehension, independent upstream retrieval or original pixels.

The original828attempt/report remains REJECTED, immutable and NOT retroaccepted. The NEW compliant Claude report establishes no actionable defect in the three teaching units or bounded actual HOST/native/defaultN1/All/custom/reduced-pool options and both inherited word directions. This is ONE accepted original-family confirmation only: GPT was NOT launched; new native fallback semantic acceptance remains UNVERIFIED pending the compliant original-GPT confirmation. Original instruction/precept hypothesis stays UNRESOLVED NONBLOCKING; no forced withdrawal, speculative guard, established-defect claim or universal future-pool guarantee. Optional wording/expansion/footer suggestions stay optional.

The reviewer correctly caught a coordinator prompt typo: the intervening source entry is1430560, not1432920. The supplied exact original range and target1604470 were correct and fully returned; no source or report was rewritten. The report's broad supplied-projection limitation is qualified by exact complete RAW-XML extract returns, still not independent upstream retrieval. An initial checkpoint-comparison assertion stopped before writes on equivalent timestamp-offset strings; UTC-normalized comparison verified the only differences, preserving live history.

Next bounded checkpoint: ORIGINALGPT4d834a27-eaf4-47ea-a4d6-32f583e4ed4c, availablegpt-6.1-sol, SAME frozen common827task/packet/full-source access/image manifest and OWN original report, without Claude rendered findings. Enforce one view call per assistant response and inspect actual model/ranges/PNGs/serialization/exit. Only one reviewer process at once.

All8472runtime hashes/contentVersion89809c00e1676979/manifest unchanged. No teaching edits, fresh HOST/native check, content push, runtime acceptance, delivery credit or next batch. Parent runner lock untouched; full progress history preserved; committed packets/approved workspace inputs only. No actual new permission denial. Published132/1228; remaining1096; last published0c582f18b31f65a5e1a908d92e37dde3d34f81ee. All inherited source/reviewer/process limits and combined-current-main/full-validation/baseline-membership-links/normal-signing/owner-fast-forward/terminal-green-CI/EVERY-immutable-ZIP-manifest-hash publication gates remain mandatory. Unchanged18000entries/42MiBcompressed/80MiBinflated/56MiBretained/per-file/media/path guards. Compatible Android reading-curation/kanji-exclusion client required; old clients ignore those fields. This unaccepted kanji/necessary-support batch is not N1 vocabulary delivery. Physical-phone/general-release/whole-set acceptance remains outstanding; project incomplete.
"@
[IO.File]::WriteAllText($bodyPath, ($body -replace "`r`n", "`n") + "`n", [Text.UTF8Encoding]::new($false))
$priorToken = $env:GH_TOKEN
try {
    $env:GH_TOKEN = (gh auth token --user stop-cran)
    if ($LASTEXITCODE -ne 0 -or -not $env:GH_TOKEN) { throw 'Owner credential unavailable' }
    $login = gh api user --jq .login
    if ($LASTEXITCODE -ne 0 -or $login -cne 'stop-cran') { throw 'Wrong command-scoped identity' }
    $url = gh issue comment 60 --repo stop-cran/learning-japanese --body-file $bodyPath
    if ($LASTEXITCODE -ne 0) { throw 'Issue update failed; preserve outcome without reposting' }
    $url = $url.Trim()
    @{url=$url; author=$login; bodySha256=(Get-FileHash $bodyPath).Hash.ToLowerInvariant()} |
        ConvertTo-Json | Set-Content "$log\issue-829-posted.json" -Encoding utf8NoBOM
    if ($url -notmatch '#issuecomment-(\d+)$') { throw 'Unexpected URL; preserve receipt' }
    $raw = gh api "repos/stop-cran/learning-japanese/issues/comments/$($Matches[1])"
    if ($LASTEXITCODE -ne 0) { throw 'Comment reread failed' }
    $raw | Set-Content "$log\issue-829-reread.json" -Encoding utf8NoBOM
    $comment = $raw | ConvertFrom-Json
    if ($comment.user.login -cne 'stop-cran' -or $comment.body -cne [IO.File]::ReadAllText($bodyPath) -or
        $comment.html_url -cne $url) { throw 'Exact owner/body verification failed' }
    Write-Output "Verified owner update: $url"
} finally {
    $env:GH_TOKEN = $priorToken
}
