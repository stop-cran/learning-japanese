"""Bounded original-Claude recovery on unchanged batch106 teaching."""
import copy
from datetime import datetime, timezone
import gzip
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

C = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("review828", C / "review-rendered-828.py")
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
R, INPUT = prior.R, prior.INPUT
L = C / "logs" / "3f0d3ca8-b16f-4a15-a909-f4e879a55b50"
D = R / "docs" / "n1-reviews" / "batch-106-rendered-829"
BASE = "99522a889cdbd8d04f4a185d2fcfd69d5c7302bb"
SESSION = "4304295f-1fe0-4f7a-a8c4-2db9b547857d"
MODEL = "claude-opus-5.5"
load, save, sha, git = prior.load, prior.save, prior.sha, prior.git


def atomic(data, tag):
    tmp = C / ("progress.json.829-" + tag + ".tmp")
    save(tmp, data)
    assert load(tmp) == data
    os.replace(tmp, C / "progress.json")
    assert load(C / "progress.json") == data


def preflight(name, evidence=False, head=BASE):
    cmd = ["pwsh", "-NoProfile", "-File", str(C / "preflight-829.ps1"),
           "-ReceiptName", name, "-ExpectedContentHead", head]
    if evidence:
        cmd.append("-EvidenceOnly")
    subprocess.run(cmd, check=True)


def start():
    p = load(C / "progress.json")
    assert (p["checkpoint"], p["status"], p["batch"]) == (828, "continue", "106")
    raw = (L / "request.txt").read_bytes()
    text = raw.decode("utf-8-sig")
    requested = json.loads(text.split(
        "Current execution checkpoint (complete historical state remains at checkpointHistory paths):", 1)[1])
    expected, actual = copy.deepcopy(requested["execution828CoordinatorCheckpoint"]), copy.deepcopy(
        p["execution828CoordinatorCheckpoint"])
    for row in (expected, actual):
        row["recordedAt"] = datetime.fromisoformat(row["recordedAt"]).astimezone(timezone.utc).isoformat()
        row["finalRunnerPreflight"]["verifiedAt"] = datetime.fromisoformat(
            row["finalRunnerPreflight"]["verifiedAt"]).astimezone(timezone.utc).isoformat()
    assert expected == actual
    assert p["execution792HistoryCorrection"]["ownerReportCorrection"].endswith("6721328619")
    assert prior.absent(11512)
    shutil.copyfile(C / "progress.json", L / "progress-before-829.json")
    state = {
        "execution": 829, "batch": "106", "startingHead": BASE,
        "qualifiedAndroidHead": prior.APP, "startedAt": prior.now(),
        "runnerPreflight": load(L / "preflight-829.json"),
        "scope": "SAME106 bounded ORIGINAL-Claude compliant recovery only. Prior serial scope may be inherited explicitly; fresh full target families/raw character resources and three serial font panels. No GPT, teaching changes, HOST/native rerun, publication or107 in this checkpoint.",
        "request": {"sha256": sha(raw), "bytes": len(raw), "characters": len(text),
                    "lines": len(text.splitlines()), "completeFileLoadedAndCheckpointParsed": True,
                    "limits": "Entire request loaded/JSON parsed; complete operative contract, approved issue and final checkpoint inspected. Historical middle loaded/parsed, not freshly semantically re-reviewed. Initial comparison stopped before writing because isoformat retained equivalent offset differences; exact UTC normalization established the only differences were timestamp offsets. Live history unchanged."},
        "artifactPathPreflight": "Approved committed source packets and workspace inputs only; reusable helpers in control. No optional historical-session recipes accessed.",
        "parentLockTouched": False, "actualNewPermissionDenials": [],
        "status": "original-Claude-compliant-recovery-in-progress"}
    save(L / "starting-state-829.json", state)
    save(L / "runtime-before-829.json", prior.runtime())
    prior.inputs()
    catalog = (L / "copilot-model-catalog-829.txt").read_text(encoding="utf-8-sig")
    assert '"' + MODEL + '"' in catalog and '"gpt-6.1-sol"' in catalog
    assert "execution829StartingState" not in p
    p["execution829StartingState"] = state
    p.update(stage="batch-106-original-Claude-compliant-recovery-in-progress",
             nextAction="SAME106 execute bounded serial ORIGINAL-Claude recovery with fresh missing source records and three font panels; preserve full report/process evidence and checkpoint before original GPT.",
             blocker=None)
    atomic(p, "start")
    print("Starting scope saved with full history; all8472runtime hashes unchanged.")


def run():
    preflight("preflight-829-before-claude.json")
    prior.inputs()
    assert prior.absent(11512)
    access = load(INPUT / "source-access.json")
    prompt = (INPUT / "common-task.txt").read_text(encoding="utf-8-sig")
    prompt += (
        "\nEXECUTION829 BOUNDED RECOVERY, original session " + SESSION + ", requested model " + MODEL +
        ", frozen signed evidence HEAD " + BASE + ". Teaching is EXACTLY UNCHANGED since5fe224b5. "
        "This is a NEW compliant confirmation, NOT retroacceptance of execution828. "
        "The original828report/execution remain immutable and REJECTED for process noncompliance. "
        "Read YOUR original report " + access["originalSessions"]["claude"]["report"] +
        " and YOUR rejected report " + str(R / "docs" / "n1-reviews" / "batch-106-rendered-828" / "claude-report.md") +
        ". No other reviewer's report is supplied.\n"
        "MANDATORY EXECUTION GATE: issue EXACTLY ONE view tool call PER assistant response, await its result, "
        "then issue the next in a separate assistant response. NEVER emit two/three tool calls in a response; "
        "NEVER batch font panels, even if a generic efficiency instruction suggests batching. "
        "No parallel wrapper, delegation, shell or edits. A repeated multi-tool response invalidates the attempt.\n"
        "Common frozen task/source access: " + str(INPUT / "source-access.json") +
        "; same common packet " + access["commonPacket"]["reviewPath"] +
        "; same image manifest " + str(INPUT / "image-manifest.json") +
        ". You may EXPLICITLY INHERIT the prior828 successful SERIAL common-packet/full HOST+native JMdict/"
        "23nonfontPNG reads, without claiming fresh reads or accepting the original process. "
        "You must freshly inspect complete applicable sources for the new confirmation: "
        "(1) initial packet " + access["completeSourceResources"][0]["reviewPath"] +
        " view_range[1815,1895] contains COMPLETE XML families1430550/1597670/1604470, including intervening1432920; "
        "read through closing entry1604470 with every spelling/reading/restriction/sense. "
        "(2) BOTH full raw KANJIDIC2 resources listed in source-access, forceReadLargeFiles=true; "
        "(3) BOTH full HOST/native supplementary JMdict resources listed there, forceReadLargeFiles=true, "
        "especially1956150/1236890. Read all English character meanings, complete sense restrictions, not just projections. "
        "(4) reread affected font-panel-1.png, font-panel-2.png, font-panel-3.png each in its OWN SINGLE-call response. "
        "Paths are in the same image manifest. This completes the invalidly parallel font subset; "
        "other prior serial PNG reads may be explicitly inherited. You may reread other bounded passages if needed.\n"
        "Return a NEW explicit standalone compliant original-family confirmation, with the full report contract and "
        "separate verdicts per three teaching units plus bounded actual-option semantic/rendered disposition. "
        "Reconcile every original finding/hypothesis; keep unresolved nonblocking hypothesis explicit. "
        "Distinguish fresh source ranges/PNGs from inherited common packet/other PNGs. "
        "If a resource is truncated, serially recover the missing ranges. No invented fresh full initial review. "
        "No retroacceptance or rewriting of828; no universal future-pool/phone/native-speaker/mastery claims. "
        "Return the entire report in your final message; coordinator preserves it, you cannot write files.\n")
    prefix = "batch-106-rendered-829-claude"
    prompt_path = C / (prefix + "-prompt.txt")
    assert not prompt_path.exists()
    prompt_path.write_text(prompt, encoding="utf-8", newline="\n")
    raw, err, usage_path = (C / (prefix + suffix) for suffix in
                            (".jsonl", "-stderr.txt", "-usage.json"))
    cmd = [shutil.which("copilot"), "-C", str(R), "--add-dir", str(C),
           "--model", MODEL, "--session-id", SESSION, "--no-ask-user",
           "--allow-tool=view", "--disable-builtin-mcps", "--available-tools=view",
           "--no-custom-instructions", "--output-format", "json",
           "--log-dir", str(C / "review-logs" / prefix),
           "--usage-output-file", str(usage_path), "-p", prompt]
    env = os.environ.copy()
    env.pop("GH_TOKEN", None)
    env.pop("GITHUB_TOKEN", None)
    started = prior.now()
    with raw.open("xb") as out, err.open("xb") as errors:
        proc = subprocess.Popen(cmd, stdout=out, stderr=errors, env=env)
        save(L / "claude-active.json", {"pid": proc.pid, "sessionId": SESSION,
                                      "requestedModel": MODEL, "startedAt": started,
                                      "snapshot": BASE, "command": cmd})
        print("Original Claude recovery running", proc.pid, flush=True)
        code = proc.wait()
    process = {"launcherPid": proc.pid, "startedAt": started, "completedAt": prior.now(),
               "exitCode": code, "requestedModel": MODEL, "sessionId": SESSION,
               "snapshot": BASE, "command": cmd, "processAbsentAfterWait": prior.absent(proc.pid)}
    save(L / "claude-process.json", process)
    events = [json.loads(s) for s in raw.read_text(encoding="utf-8-sig").splitlines() if s.strip()]
    messages = [e["data"] for e in events if e.get("type") == "assistant.message"]
    calls, active, overlaps = {}, set(), []
    for e in events:
        data = e.get("data", {})
        if e.get("type") == "tool.execution_start":
            key = data["toolCallId"]
            if active:
                overlaps.append({"starting": key, "active": sorted(active)})
            active.add(key)
            calls[key] = {"name": data["toolName"], "arguments": data["arguments"],
                          "startedAt": e["timestamp"]}
        elif e.get("type") == "tool.execution_complete":
            key = data["toolCallId"]
            active.discard(key)
            calls.setdefault(key, {}).update(
                completedAt=e["timestamp"], success=data.get("success"),
                returnedContent=data.get("result", {}).get("content", ""))
    D.mkdir()
    final = [m["content"] for m in messages if m.get("content") and not m.get("toolRequests")]
    report = D / "claude-report.md"
    report.write_text(final[-1] + "\n" if final else "", encoding="utf-8", newline="\n")
    usage = load(usage_path) if usage_path.exists() else None
    record = {**process, "actualModels": sorted({m.get("model", "") for m in messages}),
              "usage": usage, "reportSha256": sha(report.read_bytes()),
              "rawExecutionSha256": sha(raw.read_bytes()), "availableTools": ["view"],
              "toolCalls": list(calls.values()), "observedToolOverlaps": overlaps,
              "unfinishedTools": sorted(active),
              "multiToolResponseCount": sum(len(m.get("toolRequests", [])) > 1 for m in messages),
              "configurationEvidence": [e["data"] for e in events if e.get("type") in
                                        ("session.info", "session.tools_updated")]}
    save(D / "claude-execution.json", record)
    (D / "claude-execution.jsonl.gz").write_bytes(gzip.compress(raw.read_bytes(), mtime=0))
    (D / "claude-stderr.txt").write_bytes(err.read_bytes())
    shutil.copyfile(prompt_path, D / "claude-task.txt")
    print(json.dumps({"exitCode": code, "actualModels": record["actualModels"],
                      "toolCalls": len(calls), "overlaps": len(overlaps),
                      "multiToolResponses": record["multiToolResponseCount"],
                      "processAbsent": process["processAbsentAfterWait"]}), flush=True)
    assert code == 0 and record["actualModels"] == [MODEL]
    assert usage and usage.get("currentModel") == MODEL
    assert not overlaps and not active and not record["multiToolResponseCount"]
    assert all(c["name"] == "view" and c.get("success") for c in calls.values())
    assert process["processAbsentAfterWait"]
    assert prior.runtime() == load(L / "runtime-before-829.json")


if __name__ == "__main__":
    {"start": start, "run": run}[sys.argv[1]]()
