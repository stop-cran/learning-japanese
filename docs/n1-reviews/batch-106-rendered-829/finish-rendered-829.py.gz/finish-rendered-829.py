"""Audit and checkpoint the bounded original-family recovery, not the batch."""
import copy
from datetime import datetime, timezone
import gzip
import importlib.util
import json
from pathlib import Path
import sys

C = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("review829", C / "review-rendered-829.py")
review = importlib.util.module_from_spec(spec)
spec.loader.exec_module(review)
R, L, D = review.R, review.L, review.D
load, save, sha, git = review.load, review.save, review.sha, review.git
E = R / "docs" / "n1-sources" / "execution-829.json"


def archive():
    record = load(D / "claude-execution.json")
    assert record["exitCode"] == 0 and record["actualModels"] == [review.MODEL]
    assert record["usage"]["currentModel"] == review.MODEL
    assert record["processAbsentAfterWait"] and review.prior.absent(record["launcherPid"])
    assert not record["observedToolOverlaps"] and not record["unfinishedTools"]
    assert record["multiToolResponseCount"] == 0
    calls = record["toolCalls"]
    assert len(calls) == 10 and all(c["name"] == "view" and c.get("success") for c in calls)
    access = review.prior.inputs()
    full_sources = []
    for row in access["completeSourceResources"][1:]:
        call = next(c for c in calls if c["arguments"]["path"] == row["reviewPath"])
        assert call["arguments"].get("forceReadLargeFiles")
        expected = Path(row["reviewPath"]).read_bytes().decode("utf-8")
        assert call["returnedContent"] == expected
        full_sources.append({**row, "completeExactRawTextReturned": True,
                             "returnedCharacters": len(expected),
                             "startedAt": call["startedAt"], "completedAt": call["completedAt"]})
    initial = access["completeSourceResources"][0]
    target_call = next(c for c in calls if c["arguments"]["path"] == initial["reviewPath"])
    assert target_call["arguments"]["view_range"] == [1815, 1895]
    source_lines = Path(initial["reviewPath"]).read_bytes().decode("utf-8").split("\n")
    target_text = "\n".join(source_lines[1814:1895]).rstrip("\r\n")
    assert target_call["returnedContent"] == target_text
    assert all("<ent_seq>" + key + "</ent_seq>" in target_text
               for key in ("1430550", "1430560", "1597670", "1604470"))
    assert target_text.count("<entry>") == target_text.count("</entry>") == 4
    images = load(review.INPUT / "image-manifest.json")
    image_by_path = {row["path"]: row for row in images}
    fresh_images = [c["arguments"]["path"] for c in calls if c["arguments"]["path"].endswith(".png")]
    assert len(fresh_images) == 3 and all(
        Path(path).name == "n1-106-font-panel-" + str(i) + ".png"
        for i, path in enumerate(fresh_images, 1))
    for path in fresh_images:
        assert sha(Path(path).read_bytes()) == image_by_path[path]["sha256"]
    old_dir = R / "docs" / "n1-reviews" / "batch-106-rendered-828"
    old_record = load(old_dir / "claude-execution.json")
    old_audit = load(old_dir / "read-and-process-audit.json")
    old_events = [json.loads(s) for s in gzip.decompress(
        (old_dir / "claude-execution.jsonl.gz").read_bytes()).decode("utf-8-sig").splitlines() if s.strip()]
    multi = [e["data"]["toolRequests"] for e in old_events
             if e.get("type") == "assistant.message" and len(e["data"].get("toolRequests", [])) > 1]
    assert len(multi) == 1 and len(multi[0]) == 3
    assert {row["arguments"]["path"] for row in multi[0]} == set(fresh_images)
    overlaps = old_record["observedToolOverlaps"]
    assert len(overlaps) == 2
    old_calls = old_record["toolCalls"]
    inherited_images = [path for path in old_audit["freshlyViewedOriginalImages"] if path not in fresh_images]
    assert len(inherited_images) == 23
    for path in inherited_images:
        call = next(c for c in old_calls if c["arguments"]["path"] == path)
        assert call["success"]
        start, end = datetime.fromisoformat(call["startedAt"]), datetime.fromisoformat(call["completedAt"])
        assert not any(
            c is not call and datetime.fromisoformat(c["startedAt"]) < end
            and datetime.fromisoformat(c["completedAt"]) > start for c in old_calls)
    packet_call = next(c for c in old_calls
                       if c["arguments"]["path"] == access["commonPacket"]["reviewPath"])
    assert packet_call["returnedContent"] == Path(access["commonPacket"]["reviewPath"]).read_bytes().decode("utf-8")
    runtime = review.prior.runtime()
    assert runtime == load(L / "runtime-before-829.json")
    for path in (old_dir / "claude-report.md", old_dir / "claude-execution.json",
                 old_dir / "claude-execution.jsonl.gz", old_dir / "read-and-process-audit.json"):
        assert path.read_bytes() == git("show", review.BASE + ":" + path.relative_to(R).as_posix())
    audit = {
        "snapshot": review.BASE, "actualModel": review.MODEL, "originalSessionId": review.SESSION,
        "processExitCode": 0, "reviewerPid": record["launcherPid"], "processAbsent": True,
        "successfulViewCalls": 10, "multiToolResponses": 0, "overlappingToolStarts": 0,
        "unfinishedTools": 0, "processAuditPassed": True,
        "freshExactCompleteSourceResources": full_sources,
        "freshInitialSourceRange": {
            **initial, "viewRange": [1815, 1895], "returnedCharacters": len(target_text),
            "exactRangeReturned": True, "completeFamilies": ["1430550", "1430560", "1597670", "1604470"],
            "notFreshFullInitialPacket": True},
        "freshOriginalImages": [image_by_path[path] for path in fresh_images],
        "inheritedSourceSnapshot": review.BASE,
        "inheritedPacket": {"source": "docs/n1-reviews/batch-106-rendered-828/claude-execution.json",
                            "allCommonPacketCharactersOriginallyReturned": True,
                            "freshThisExecution": False},
        "inheritedSerialImagePaths": inherited_images,
        "inheritedSerialImageCallsCheckedForNoOverlap": True,
        "inheritedReportNotRetroaccepted": True,
        "manifestImages": 42, "distinctRasterScope": 26,
        "byteIdenticalDuplicatePathsNotOpened": old_audit["notFreshlyViewedByteIdenticalImages"],
        "freshOriginalOwnReports": [
            "docs/n1-reviews/batch-106-initial-claude.md",
            "docs/n1-reviews/batch-106-rendered-828/claude-report.md"],
        "limits": [
            "Three font panels and four full XML resources plus81initial-packet lines fresh; common packet/23other PNGs inherited serial scope.",
            "A successful full returned range is access evidence, not comprehension or independent upstream retrieval.",
            "Original42PNGs have26distinct rasters;16duplicate paths not opened. Report lists absent indices as unviewed, not missing provided originals.",
            "900x2000 tool renditions of1080x2400 emulator captures; no original-pixel/phone/native-speaker/fallback-face certification.",
            "Original828remains rejected for process noncompliance. This is a new bounded original-family confirmation.",
        ],
    }
    save(D / "read-and-process-audit.json", audit)
    disposition = {
        "status": "new-compliant-original-Claude-bounded-confirmation",
        "original828Attempt": "preserved rejected unchanged; not retroaccepted",
        "process": "actualclaude-opus-5.5 original session;10successful single serial views,0overlaps,0multi-tool responses;exit0and PID absent",
        "teachingUnits": {
            "kanji/勅.md": {"correctness": "CLEAN", "scopedCoverage": "CLEAN", "comprehensibility": "CLEAN"},
            "words/勅令.md": {"correctness": "CLEAN", "scopedCoverage": "CLEAN", "comprehensibility": "CLEAN"},
            "kanji/令.md:37": {"correctness": "CLEAN", "scopedCoverage": "CLEAN", "comprehensibility": "CLEAN"}},
        "actualOptionSemanticRenderedDisposition": "No established defect in recorded finite HOST/native/defaultN1/All/custom/reduced contexts and inherited BOTH word directions. Claude confirmation only; not universal future-pool safety.",
        "originalFindings": [
            {"item": "storedちょく/displayチョク wording", "status": "optional", "reviewerStatus": "partially resolved / optional",
             "reason": "Actual display confirms katakana while stored key is hiragana; no incorrect teaching established."},
            {"item": "overlap comparison wording", "status": "optional", "reason": "Could explicitly add with勅; context already compares those command meanings."},
            {"item": "standalone勅/敕/relatedcompound expansion", "status": "optional", "reason": "Out-of-scope expansion not required for one selected on-compound."},
            {"item": "令source footer1430550", "status": "optional", "reason": "New linked compound is sourced in support/target; no contradictory claim established."},
            {"item": "勅/訓instruction-precept hypothesis", "status": "unresolved", "blocking": False,
             "reason": "Complete1956150/1236890and raw character records fresh; no command/sovereign sense established for訓. Only explicit32hypothesis fixtures, no actual offer; no guard or forced withdrawal."}],
        "rawUnselectedKunFeedback": "Observed legacy reference display, not question selection. Modernwrittenいまし.める remains UNVERIFIED, excluded from offered keys; no suitable written example claimed.",
        "diagnostics": [
            "Coordinator prompt incorrectly called the intervening1815-1895family1432920. Reviewer correctly identified1430560; exact original source range verifies1430550/1430560/1597670/1604470. No source bytes or report changed; typo does not change required target family1604470coverage.",
            "Report limit says dictionary text comes only from supplied projections; actual execution returned four complete bounded raw XML extracts plus four complete initial-packet families. These are frozen supplied-source extracts, not independent upstream retrieval or the entire dictionaries. Preserve report wording and exact access audit without overstating source access.",
            "Initial checkpoint comparison failed before writes because UTC-equivalent offsets retained different isoformat strings. Exact UTC normalization verified only timestamp-offset differences; no live historical field changed.",
        ],
        "newConsequentialContentDefectEstablished": False,
        "acceptedRenderedOriginalFamilies": ["claude-opus-5.5"],
        "acceptedRenderedOriginalFamilyCount": 1,
        "gptLaunched": False,
        "newNativeOrdinarySenseFallbackSemanticAcceptance": "UNVERIFIED pending compliant original-GPT confirmation",
        "next": "Resume originalGPT4d834a27-eaf4-47ea-a4d6-32f583e4ed4c gpt-6.1-sol on identical common827packet/source-access/image-manifest and OWN original report. No Claude findings supplied. Single view per response; inspect actual model/ranges/images/exit. Keep all source/host/native/publication gates.",
        "runtimeChanged": False, "runtimeAccepted": False, "runtimePublished": False,
        "phoneAcceptance": "outstanding", "generalReleaseAcceptance": "outstanding",
    }
    save(D / "coordinator-disposition.json", disposition)
    for path in (C / "preflight-829.ps1", C / "review-rendered-829.py",
                 C / "finish-rendered-829.py", C / "post-rendered-829.ps1",
                 L / "copilot-help-829.txt", L / "copilot-model-catalog-829.txt",
                 L / "preflight-829.json", L / "preflight-829-before-claude.json",
                 L / "starting-state-829.json", L / "runtime-before-829.json",
                 L / "claude-process.json", C / "batch-106-rendered-829-claude-usage.json"):
        (D / (path.name + ".gz")).write_bytes(gzip.compress(path.read_bytes(), mtime=0))
    save(D / "artifact-index.json", [
        {"file": path.name, "sha256": sha(path.read_bytes()), "bytes": path.stat().st_size}
        for path in sorted(D.iterdir()) if path.is_file()])
    save(E, {
        "schemaVersion": 1, "execution": 829, "batch": "106", "recordedAt": review.prior.now(),
        "stage": "original-Claude-compliant-rendered-confirmation-awaiting-original-GPT",
        "sourceSnapshot": review.BASE, "teachingSnapshot": "5fe224b5c611e8ca0c7c5a1fcbd5ea4a025e606a",
        "qualifiedAndroidHead": review.prior.APP, "packet": D.relative_to(R).as_posix(),
        "actualModel": review.MODEL, "originalSessionId": review.SESSION,
        "reviewerExitCode": 0, "reviewerPid": record["launcherPid"], "reviewerProcessAbsent": True,
        "independentReviewerProcessesLaunched": 1, "successfulViewCalls": 10,
        "processAuditPassed": True, "overlappingToolStarts": 0, "multiToolResponses": 0,
        "acceptedRenderedOriginalFamilyCount": 1, "gptLaunched": False,
        "newNativeOrdinarySenseFallbackSemanticAcceptance": disposition["newNativeOrdinarySenseFallbackSemanticAcceptance"],
        "coordinatorDisposition": disposition, "runtime": runtime,
        "artifactIndexSha256": sha((D / "artifact-index.json").read_bytes()),
        "runtimeChanged": False, "runtimeAccepted": False, "runtimePublished": False,
        "parentLockTouched": False, "actualNewPermissionDenials": [],
        "publishedAdditions": 132, "remainingAdditions": 1096,
        "physicalPhoneAcceptance": "outstanding", "generalReleaseAcceptance": "outstanding",
        "wholeProjectComplete": False, "nextBatchStarted": False,
    })
    print("New compliant Claude confirmation archived; original828rejected unchanged; GPT gate remains.")


def finish():
    p, before = load(C / "progress.json"), load(L / "progress-before-829.json")
    assert (p["checkpoint"], p["status"], p["batch"]) == (828, "continue", "106")
    head = git("rev-parse", "HEAD").decode().strip()
    assert git("rev-parse", "HEAD^").decode().strip() == review.BASE
    assert git("log", "-1", "--format=%G?").decode().strip() == "G"
    assert not git("status", "--porcelain", "--untracked-files=all").strip()
    changed = git("diff", "--name-only", review.BASE, head).decode().splitlines()
    assert changed and all(s.startswith("docs/n1-reviews/batch-106-rendered-829/") or
                           s == "docs/n1-sources/execution-829.json" for s in changed)
    runtime = review.prior.runtime()
    assert runtime == load(L / "runtime-before-829.json")
    for row in load(D / "artifact-index.json"):
        assert sha((D / row["file"]).read_bytes()) == row["sha256"]
        assert sha(git("show", head + ":" + (D / row["file"]).relative_to(R).as_posix())) == row["sha256"]
    posted, comment = load(L / "issue-829-posted.json"), load(L / "issue-829-reread.json")
    body = (C / "batch-106-rendered-829-issue-body.txt").read_text(encoding="utf-8")
    assert comment["user"]["login"] == posted["author"] == "stop-cran"
    assert comment["body"] == body and comment["html_url"] == posted["url"]
    assert posted["bodySha256"] == sha(body.encode("utf-8"))
    assert review.prior.absent(load(L / "claude-process.json")["launcherPid"])
    mutable = {"checkpoint", "status", "stage", "nextAction", "blocker", "checkpointHistory"}
    assert all(p[k] == v for k, v in before.items() if k not in mutable)
    action = (
        f"SAME106 checkpoint829 signed LOCAL compliant original-Claude recovery HEAD{head}, qualifiedAndroid{review.prior.APP}. "
        "Read docs/n1-sources/execution-829.json and docs/n1-reviews/batch-106-rendered-829/ FULL newreport,execution,"
        "read-and-process-audit,coordinator-disposition. ORIGINALClaude4304295f-1fe0-4f7a-a8c4-2db9b547857d "
        "actualclaude-opus-5.5 exited0/PID17008absent;10successfulviewcalls,0overlaps,0multi-toolresponses. "
        "Fresh COMPLETE raw HOST3032/native343 KANJIDIC2 and HOST885/native701 JMdictresources; exactinitial1815-1895 "
        "FULL1430550/1430560/1597670/1604470; all3fontpanelsSERIAL. Previous common6123linepacket+23nonfontPNGs "
        "explicitlyINHERITEDserialscope, audited. 42originals/26distinctrasters/16identicalduplicatesnotopened. "
        "Original828noncompliantattempt remainsREJECTED/UNCHANGED,NOTretroaccepted. NewClaude bounded no-established-defect "
        "confirmation accepted as ONE originalfamily ONLY. GPT NOTlaunched; newnativefallbacksemanticacceptance "
        "UNVERIFIED until originalGPT. NEXT bounded SAME106 ORIGINALGPT4d834a27-eaf4-47ea-a4d6-32f583e4ed4c "
        "actualavailablegpt-6.1-sol SAMEcommon827task/packet/fullsource-access/image-manifest and OWNoriginal822report "
        "only; NOClaude renderedfindings supplied. OneSINGLEviewcall perassistantresponse, freshfullapplicablefamilies/"
        "rawrecords especially1604470/1956150/1236890, allrelevantoriginalPNGs; auditactualmodel/returnedranges/PNGs/"
        "serialization/actualexit. OnlyONEreviewerprocessatonce;noeditfrozensnapshot/noauthors/nestedtasks. "
        "Originalweak勅訓hypothesis UNRESOLVEDNONBLOCKING; noforcedwithdrawal/establisheddefect/speculativeguard/"
        "universalpoolclaim. Optionalstoredちょく/displayチョク/comparisonwording/expansion/令footer remainoptional. "
        "Reviewer correctly caught coordinatorpromptinterveningIDtypo1432920->ACTUAL1430560; fullsourceunchanged. "
        "Reviewerlimit suppliedprojections qualified by exactfreshRAWextractreturns;NOTupstreamretrieval/fullglobaldict. "
        "Five新labels剰扱獣矛芋/fullrawEnglishmeanings/fullJMdictrestrictions; exactdefault畔剰俸勅;64nativeorderedoffers/"
        "pools/seeds/32unguardedsamples; inheritedHOSTbothworddirections. Fullon[チョク]/kun[いまし.める,みことのり]"
        "preservedorder,selected[チョク]/[]; solekeyちょく/displayチョク; legacyfeedbackrawkunvisible/curationNOTallreference"
        "display. Modernwrittenいまし.めるUNVERIFIED;outsideJoyoREADINGlistNOTfrequency/invalidity. "
        "900x2000toolrenditionsNOToriginalpixels/phone/nativespeaker/fallbackface; drawingreferenceinjection/revealgrade"
        "NOTmastery. All8472runtimehashes/version89809c00e1676979/manifestunchanged; nofreshHOST/native/contentacceptance/"
        "publication/107. Completeprevious828nextAction retained in historicalExecution828Before829Recovery.nextAction; "
        "ALLoriginalsource/reviewer/process/denial/OOM/historylimits remainmandatory. Combinedcurrentmain/"
        "nonrewritingmerge/changedteachingreview/fullrequiredPython/vocabulary/baseline-membership-links/"
        "manifestbudget/normalsigning/ownerfastforward/terminalgreenCI/EVERYimmutableGitHubZIPmanifesthash/"
        "unchanged18000entries42MiBcompressed80MiBinflated56MiBretained/perfilepathmedia/verifiedownerissue MANDATORY. "
        "No107/unreviewedpush/concurrentheavywork/secondrunner/signingretry/guardincrease. Freshsignedheads/checkpoint/"
        "whollyclean/freshmain/liveparentancestry/decodedlauncher/exactsession required. Parent13320ownsrunner.lock:"
        "nochildacquire/delete/unlock/readprobe. Approvedcontrol/committedsource/frozeninputs only;preserve/report/yield "
        "actualnewdenial/signinghang/uncertainownership. Published132/1228/remainder1096unchanged;lastpublished"
        "0c582f18b31f65a5e1a908d92e37dde3d34f81ee; unaccepted勅/necessarysupport勅令notN1vocabularydelivery. "
        "CompatibleAndroid125+132 required;oldclientsignore. Physicalphone/generalrelease/whole-setoutstanding;projectincomplete."
    )
    checkpoint = {
        "schemaVersion": 1, "execution": 829, "checkpoint": 829, "batch": "106",
        "status": "continue", "stage": "batch-106-Claude-rendered-confirmed-awaiting-original-GPT",
        "recordedAt": review.prior.now(), "savedCommit": head, "signature": "G",
        "qualifiedAndroidHead": review.prior.APP, "sourceSnapshot": review.BASE,
        "evidence": E.relative_to(R).as_posix(), "issueUpdate": posted["url"],
        "ownerIssueAuthorAndExactBodyVerified": True, "reviewerProcessesLaunched": 1,
        "actualModel": review.MODEL, "originalSessionId": review.SESSION,
        "reviewerExitCode": 0, "reviewerPid": 17008, "reviewerProcessAbsent": True,
        "gptLaunched": False, "successfulViewCalls": 10, "overlappingToolStarts": 0, "multiToolResponses": 0,
        "acceptedRenderedOriginalFamilyCount": 1, "processAuditPassed": True,
        "newNativeOrdinarySenseFallbackSemanticAcceptance": "UNVERIFIED pending compliant original-GPT confirmation",
        "runtime": runtime, "runtimeChanged": False, "runtimeAccepted": False, "runtimePublished": False,
        "dedicatedWorktreesClean": True, "parentLockTouched": False, "actualNewPermissionDenials": [],
        "publishedAdditions": 132, "remainingAdditions": 1096, "lastPublishedCommit": p["lastPublishedCommit"],
        "physicalPhoneAcceptance": "outstanding", "generalReleaseAcceptance": "outstanding",
        "wholeProjectComplete": False, "nextBatchStarted": False,
        "originalHistoricalRootKeysCompared": len(before), "allOriginalHistoricalValuesPreserved": True,
        "finalRunnerPreflight": load(L / "preflight-829-before-issue.json"), "nextAction": action, "blocker": None}
    updated = copy.deepcopy(p)
    updated["historicalExecution828Before829Recovery"] = {key: before.get(key) for key in mutable}
    updated["execution829StartingState"]["status"] = "signed-local-compliant-Claude-confirmation-complete-awaiting-original-GPT"
    updated["execution829CoordinatorCheckpoint"] = checkpoint
    for key in ("checkpoint", "status", "stage", "nextAction", "blocker"):
        updated[key] = checkpoint[key]
    updated["checkpointHistory"] = {
        "completeSnapshot": str(L / "checkpoint-full.json"), "liveProgressPath": str(C / "progress.json"),
        "invariant": "Preserve full live history; immutable snapshot is the observer input."}
    assert all(updated[key] == value for key, value in before.items() if key not in mutable)
    save(L / "checkpoint-829-summary.json", checkpoint)
    review.atomic(updated, "finish")
    reread = load(C / "progress.json")
    assert all(reread[key] == value for key, value in before.items() if key not in mutable)
    save(L / "checkpoint-829-final-verification.json", {
        "checkpoint": 829, "head": head, "signature": "G", "whollyClean": True,
        "historicalRootKeysCompared": len(before), "allOriginalHistoricalValuesPreserved": True,
        "runtimeHashesVerified": 8472, "acceptedRenderedOriginalFamilyCount": 1, "projectComplete": False})
    print("Checkpoint829 saved with full history; compliant Claude confirmation only, GPT and batch acceptance pending.")


if __name__ == "__main__":
    {"archive": archive, "finish": finish}[sys.argv[1]]()
