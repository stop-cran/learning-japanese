$ErrorActionPreference = 'Stop'
$control = $PSScriptRoot
$log = "$control\logs\9e6d2be9-2d35-4689-86cc-b3238a2a98f4"
$content = "$control\..\learning-japanese"
$bodyPath = "$control\batch-106-rendered-828-issue-body.txt"
if ((Test-Path "$log\issue-828-posted.json") -or (Test-Path $bodyPath)) {
    throw 'Do not duplicate owner issue update'
}
$head = git -C $content rev-parse HEAD
if ($LASTEXITCODE -ne 0) { throw 'HEAD lookup failed' }
& "$control\preflight-828.ps1" -ReceiptName 'preflight-828-before-issue.json' -ExpectedContentHead $head
if (-not $?) { throw 'Final preflight failed' }
if ((git -C $content rev-parse 'HEAD^') -ne 'bef71a87216e8a220b5e0699547237d6d66fdb4a' -or
    $LASTEXITCODE -ne 0) { throw 'Wrong evidence ancestry' }
$body = @"
Checkpoint 828, SAME batch 106: preserved one ORIGINAL Claude rendered-review attempt at signed LOCAL evidence commit $head. See docs/n1-sources/execution-828.json and docs/n1-reviews/batch-106-rendered-828/.

Actual claude-opus-5.5 resumed original session4304295f-1fe0-4f7a-a8c4-2db9b547857d and exited0; PID11512 is absent. Complete original report, raw execution, configuration/usage, prompt and read/image/process audit are retained. The common packet returned in full; 33 successful view calls included26distinct original PNG rasters (16byte-identical duplicate paths not opened), full HOST/native supplementary JMdict resources and the complete source/image manifests. The initial822packet, target1604470 and both raw KANJIDIC2 resources were inherited/projection-only, not freshly read.

The attempt is NOT ACCEPTED: despite explicit per-tool serial-only instructions, the three font panels were requested in ONE assistant response with TWO overlapping starts. The reviewer acknowledged this breach. The coordinator audit failed AFTER preserving the original evidence; no original report was rewritten or retroaccepted. ZERO compliant rendered confirmations; GPT was NOT launched. The reviewer's no-established-defect/optional observations are retained as observations, not batch semantic/rendered acceptance. The original instruction/precept hypothesis remains UNRESOLVED NONBLOCKING; no forced withdrawal, speculative guard, established-defect claim or universal future-pool safety.

Next bounded checkpoint: resume the same original Claude for an explicitly serial compliant confirmation, reinspection of the affected three panels one at a time and complete required source-family/raw-record inspection (especially1604470); keep earlier serial reads explicitly inherited and the noncompliant attempt intact. Audit actual returned model/ranges/images/serialization/exit before the original GPT follow-up on the same frozen common packet/source/image scope and its own original report. Only one reviewer process may run at once. New native fallback semantic acceptance stays UNVERIFIED until BOTH compliant original-family confirmations.

All8472runtime hashes/contentVersion89809c00e1676979/manifest unchanged. No teaching edits, fresh HOST/native check, content push, runtime acceptance, delivery credit or next batch. Parent runner lock untouched; full progress history preserved; approved workspace/committed packets only. No actual new permission denial. An initial unsupported catalog invocation was corrected to supported help syntax without changing configuration.

Published132/1228; remaining1096; last published0c582f18b31f65a5e1a908d92e37dde3d34f81ee. All inherited review/source/process limits and combined-current-main/full-validation/baseline-membership-links/normal-signing/owner-fast-forward/terminal-green-CI/EVERY-immutable-ZIP-manifest-hash publication gates remain mandatory. Unchanged18000entries/42MiBcompressed/80MiBinflated/56MiBretained and per-file/media/path guards. Compatible Android reading-curation/kanji-exclusion client required; old clients ignore those fields. Unaccepted one-kanji/necessary-support batch is not N1 vocabulary delivery. Physical-phone/general-release/whole-set acceptance remains outstanding; project incomplete.
"@
[IO.File]::WriteAllText($bodyPath, ($body -replace "`r`n", "`n") + "`n", [Text.UTF8Encoding]::new($false))
$priorToken = $env:GH_TOKEN
try {
    $env:GH_TOKEN = (gh auth token --user stop-cran)
    if ($LASTEXITCODE -ne 0 -or -not $env:GH_TOKEN) { throw 'Owner credential unavailable' }
    $login = gh api user --jq .login
    if ($LASTEXITCODE -ne 0 -or $login -cne 'stop-cran') { throw 'Wrong command-scoped identity' }
    $url = gh issue comment 60 --repo stop-cran/learning-japanese --body-file $bodyPath
    if ($LASTEXITCODE -ne 0) { throw 'Issue update failed; preserve outcome without reposting' }
    $url = $url.Trim()
    @{url=$url; author=$login; bodySha256=(Get-FileHash $bodyPath).Hash.ToLowerInvariant()} |
        ConvertTo-Json | Set-Content "$log\issue-828-posted.json" -Encoding utf8NoBOM
    if ($url -notmatch '#issuecomment-(\d+)$') { throw 'Unexpected URL; preserve receipt' }
    $raw = gh api "repos/stop-cran/learning-japanese/issues/comments/$($Matches[1])"
    if ($LASTEXITCODE -ne 0) { throw 'Comment reread failed' }
    $raw | Set-Content "$log\issue-828-reread.json" -Encoding utf8NoBOM
    $comment = $raw | ConvertFrom-Json
    if ($comment.user.login -cne 'stop-cran' -or $comment.body -cne [IO.File]::ReadAllText($bodyPath) -or
        $comment.html_url -cne $url) { throw 'Exact owner/body verification failed' }
    Write-Output "Verified owner update: $url"
} finally {
    $env:GH_TOKEN = $priorToken
}
