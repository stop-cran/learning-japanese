"""Resume original batch106 reviewers serially against durable frozen inputs."""
import copy
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

C = Path(__file__).resolve().parent
R = C.parent / "learning-japanese"
L = C / "logs" / "9e6d2be9-2d35-4689-86cc-b3238a2a98f4"
V = R / "docs" / "n1-reviews"
D = V / "batch-106-rendered-828"
INPUT = V / "batch-106-rendered-827"
BASE = "bef71a87216e8a220b5e0699547237d6d66fdb4a"
APP = "bf30cdead8515739bc0e671d57a54b9a3109dd46"
MODELS = {"claude": "claude-opus-5.5", "gpt": "gpt-6.1-sol"}


def now():
    return datetime.now(timezone.utc).isoformat()


def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(path, data):
    assert not path.exists(), path
    path.write_text(json.dumps(data, ensure_ascii=True, indent=2) + "\n", encoding="utf-8", newline="\n")


def git(*args):
    return subprocess.check_output(["git", "--no-pager", "-c", "core.quotepath=false",
                                   "-C", str(R), *args])


def atomic(data, tag):
    tmp = C / ("progress.json.828-" + tag + ".tmp")
    save(tmp, data)
    assert load(tmp) == data
    os.replace(tmp, C / "progress.json")
    assert load(C / "progress.json") == data


def runtime():
    raw = (R / "manifest.json").read_bytes()
    assert raw.replace(b"\r\n", b"\n") == git("show", BASE + ":manifest.json")
    manifest = json.loads(raw)
    count = 0
    for section, entries in manifest.items():
        if not isinstance(entries, dict):
            continue
        for path, digest in entries.items():
            data = (R / path).read_bytes()
            if section not in {"images", "audio", "listeningTaskAudio", "listeningTaskImages"}:
                data = data.replace(b"\r\n", b"\n")
            assert sha(data) == digest, path
            count += 1
    assert count == 8472 and manifest["contentVersion"] == "89809c00e1676979"
    return {"runtimeHashesVerified": count, "contentVersion": manifest["contentVersion"],
            "manifestSha256": sha(raw), "runtimeChanged": False, "manifestChanged": False}


def inputs():
    for row in load(INPUT / "artifact-index.json"):
        assert sha((INPUT / row["file"]).read_bytes()) == row["sha256"]
    access = load(INPUT / "source-access.json")
    assert sha(Path(access["commonPacket"]["reviewPath"]).read_bytes()) == access["commonPacket"]["sha256"]
    for row in access["completeSourceResources"]:
        raw = Path(row["reviewPath"]).read_bytes()
        committed = git("show", BASE + ":" + row["committedSource"])
        if row["committedSource"].endswith(".gz"):
            committed = gzip.decompress(committed)
        assert sha(raw) == sha(committed) == row["sha256"]
    for row in load(INPUT / "image-manifest.json"):
        assert sha(Path(row["path"]).read_bytes()) == row["sha256"]
    assert not git("diff", "--name-only", "5fe224b5c611e8ca0c7c5a1fcbd5ea4a025e606a",
                   BASE, "--", "kanji", "words", "strokes", "manifest.json").strip()
    return access


def absent(pid):
    return subprocess.run(
        ["pwsh", "-NoProfile", "-Command",
         f"if (Get-Process -Id {int(pid)} -ErrorAction SilentlyContinue) {{ exit 1 }}"],
        capture_output=True).returncode == 0


def preflight(name, evidence=False):
    args = ["pwsh", "-NoProfile", "-File", str(C / "preflight-828.ps1"), "-ReceiptName", name]
    if evidence:
        args.append("-EvidenceOnly")
    subprocess.run(args, check=True)


def start():
    p = load(C / "progress.json")
    assert (p["checkpoint"], p["status"], p["batch"]) == (827, "continue", "106")
    request = (L / "request.txt").read_bytes()
    text = request.decode("utf-8-sig")
    state = json.loads(text.split(
        "Current execution checkpoint (complete historical state remains at checkpointHistory paths):", 1)[1])
    expected = copy.deepcopy(state["execution827CoordinatorCheckpoint"])
    actual = copy.deepcopy(p["execution827CoordinatorCheckpoint"])
    assert datetime.fromisoformat(expected.pop("recordedAt")) == datetime.fromisoformat(actual.pop("recordedAt"))
    assert datetime.fromisoformat(expected["finalRunnerPreflight"].pop("verifiedAt")) == datetime.fromisoformat(
        actual["finalRunnerPreflight"].pop("verifiedAt"))
    assert expected == actual
    assert p["execution792HistoryCorrection"]["ownerReportCorrection"].endswith("6721328619")
    assert not (L / "progress-before-828.json").exists()
    shutil.copyfile(C / "progress.json", L / "progress-before-828.json")
    starting = {
        "execution": 828, "batch": "106", "startedAt": now(), "startingHead": BASE,
        "androidHead": APP, "runnerPreflight": load(L / "preflight-828.json"),
        "scope": "SAME106 serial ORIGINAL-family rendered confirmations; no teaching edit, HOST/native rerun, publication or107. Preserve full reports, actual models/process/read/PNG limits before reconciliation.",
        "request": {"sha256": sha(request), "bytes": len(request), "characters": len(text),
                    "lines": len(text.splitlines()), "completeFileLoadedAndCheckpointParsed": True,
                    "limits": "Entire file loaded and final JSON parsed; operative contract, entire approved issue and final827 directly inspected. Historical middle parsed, not freshly semantically re-reviewed. Equivalent timestamp offsets verified without rewriting live history."},
        "artifactPathPreflight": "Approved committed packets and workspace inputs only; reusable helpers in control; optional historical-session recipes not accessed.",
        "parentLockTouched": False, "actualNewPermissionDenials": [],
        "status": "original-family-rendered-confirmations-in-progress"}
    save(L / "starting-state-828.json", starting)
    assert "execution828StartingState" not in p
    p["execution828StartingState"] = starting
    p.update(stage="batch-106-original-family-rendered-confirmations-in-progress",
             nextAction="SAME106 execute original Claude then GPT rendered confirmation serially on unchanged signed bef71a87; preserve actual exits, models, reports and read/PNG limits; no publication/107.",
             blocker=None)
    atomic(p, "start")
    inputs()
    save(L / "runtime-before-828.json", runtime())
    catalog = (L / "copilot-model-catalog-828.txt").read_text(encoding="utf-8-sig")
    assert all('"' + model + '"' in catalog for model in MODELS.values())
    print("Starting scope saved; durable inputs and all8472runtime hashes verified.")


def run(label):
    preflight("preflight-828-before-" + label + ".json", D.exists())
    assert git("rev-parse", "HEAD").decode().strip() == BASE
    access = inputs()
    if label == "gpt":
        prior = load(L / "claude-process.json")
        assert prior["exitCode"] == 0 and absent(prior["launcherPid"])
    prefix = "batch-106-rendered-828-" + label
    raw_path, err_path = C / (prefix + ".jsonl"), C / (prefix + "-stderr.txt")
    assert not raw_path.exists() and not err_path.exists()
    session = access["originalSessions"][label]
    prompt = (INPUT / "common-task.txt").read_text(encoding="utf-8-sig")
    prompt += (
        "\nExecution828 actual frozen signed evidence HEAD " + BASE +
        "; teaching unchanged since original822. This is a continuation of YOUR original session " +
        session["sessionId"] + " using requested model " + MODELS[label] +
        ". Own original report: " + session["report"] +
        ". Read it first, then the common packet and all applicable full-family records and original PNGs "
        "as instructed. Source-access: " + str(INPUT / "source-access.json") +
        "; image manifest: " + str(INPUT / "image-manifest.json") +
        ". Only view is available. Single serial calls, no parallel tool requests. "
        "Return the entire final report in your final message; do not write files. "
        "Disclose actual read ranges and images, duplicates and gaps. No other reviewer's rendered report is supplied.\n")
    prompt_path = C / (prefix + "-prompt.txt")
    assert not prompt_path.exists()
    prompt_path.write_text(prompt, encoding="utf-8", newline="\n")
    usage_path = C / (prefix + "-usage.json")
    cmd = [
        shutil.which("copilot"), "-C", str(R), "--add-dir", str(C),
        "--model", MODELS[label], "--session-id", session["sessionId"], "--no-ask-user",
        "--allow-tool=view", "--disable-builtin-mcps", "--available-tools=view",
        "--no-custom-instructions", "--output-format", "json",
        "--log-dir", str(C / "review-logs" / prefix),
        "--usage-output-file", str(usage_path), "-p", prompt]
    env = os.environ.copy()
    env.pop("GH_TOKEN", None)
    env.pop("GITHUB_TOKEN", None)
    started = now()
    with raw_path.open("xb") as out, err_path.open("xb") as err:
        proc = subprocess.Popen(cmd, stdout=out, stderr=err, env=env)
        save(L / (label + "-active.json"), {
            "pid": proc.pid, "sessionId": session["sessionId"], "startedAt": started,
            "requestedModel": MODELS[label], "command": cmd, "snapshot": BASE})
        print("Original reviewer running:", label, proc.pid, flush=True)
        code = proc.wait()
    process = {"launcherPid": proc.pid, "startedAt": started, "completedAt": now(),
               "exitCode": code, "requestedModel": MODELS[label], "sessionId": session["sessionId"],
               "snapshot": BASE, "command": cmd, "processAbsentAfterWait": absent(proc.pid)}
    save(L / (label + "-process.json"), process)
    events = [json.loads(x) for x in raw_path.read_text(encoding="utf-8-sig").splitlines() if x.strip()]
    messages = [e["data"] for e in events if e.get("type") == "assistant.message"]
    actual_models = sorted({m.get("model", "") for m in messages})
    usage = load(usage_path) if usage_path.exists() else None
    calls, active, overlaps = {}, set(), []
    for event in events:
        data = event.get("data", {})
        if event.get("type") == "tool.execution_start":
            key = data["toolCallId"]
            if active:
                overlaps.append({"starting": key, "active": sorted(active)})
            active.add(key)
            calls[key] = {"name": data["toolName"], "arguments": data["arguments"],
                          "startedAt": event["timestamp"]}
        elif event.get("type") == "tool.execution_complete":
            key = data["toolCallId"]
            active.discard(key)
            result = data.get("result", {}).get("content", "")
            calls.setdefault(key, {}).update(completedAt=event["timestamp"],
                success=data.get("success"), returnedContent=result)
    D.mkdir(exist_ok=True)
    report = D / (label + "-report.md")
    assert not report.exists()
    final = [m.get("content", "") for m in messages if not m.get("toolRequests") and m.get("content")]
    report.write_text(final[-1] + "\n" if final else "", encoding="utf-8", newline="\n")
    record = {
        **process, "actualModels": actual_models,
        "usageCurrentModel": usage.get("currentModel") if usage else None, "usage": usage,
        "reportSha256": sha(report.read_bytes()), "rawExecutionSha256": sha(raw_path.read_bytes()),
        "availableTools": ["view"], "toolCalls": list(calls.values()),
        "configurationEvidence": [e["data"] for e in events
                                  if e.get("type") in ("session.info", "session.tools_updated")],
        "observedToolOverlaps": overlaps, "unfinishedTools": sorted(active),
        "multiToolResponseCount": sum(len(m.get("toolRequests", [])) > 1 for m in messages),
        "limits": "Actual returned ranges/images/process evidence establishes access, not comprehension, independent upstream retrieval, original-pixel/phone certification or whole-batch acceptance."}
    save(D / (label + "-execution.json"), record)
    (D / (label + "-execution.jsonl.gz")).write_bytes(gzip.compress(raw_path.read_bytes(), mtime=0))
    (D / (label + "-stderr.txt")).write_bytes(err_path.read_bytes())
    shutil.copyfile(prompt_path, D / (label + "-task.txt"))
    print(json.dumps({"label": label, "exitCode": code, "actualModels": actual_models,
                      "toolCalls": len(calls), "overlaps": len(overlaps), "unfinished": len(active),
                      "processAbsent": process["processAbsentAfterWait"]}), flush=True)
    assert code == 0 and actual_models == [MODELS[label]]
    assert usage and usage.get("currentModel") == MODELS[label]
    assert not overlaps and not active and not record["multiToolResponseCount"]
    assert all(c["name"] == "view" and c.get("success") for c in calls.values())
    assert process["processAbsentAfterWait"]
    assert runtime() == load(L / "runtime-before-828.json")


if __name__ == "__main__":
    {"start": start, "run": lambda: run(sys.argv[2])}[sys.argv[1]]()
