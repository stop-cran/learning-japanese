"""Preserve a noncompliant reviewer attempt without granting acceptance."""
import copy
from datetime import datetime, timezone
import gzip
import importlib.util
import json
import os
from pathlib import Path
import sys

C = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("review828", C / "review-rendered-828.py")
review = importlib.util.module_from_spec(spec)
spec.loader.exec_module(review)
R, L, D = review.R, review.L, review.D
load, save, sha, git = review.load, review.save, review.sha, review.git
E = R / "docs" / "n1-sources" / "execution-828.json"


def archive():
    record = load(D / "claude-execution.json")
    assert record["actualModels"] == ["claude-opus-5.5"] and record["exitCode"] == 0
    assert record["processAbsentAfterWait"] and review.absent(record["launcherPid"])
    assert len(record["observedToolOverlaps"]) == 2 and record["multiToolResponseCount"] == 1
    assert not record["unfinishedTools"]
    assert not (L / "gpt-active.json").exists()
    runtime = review.runtime()
    assert runtime == load(L / "runtime-before-828.json")
    access = review.inputs()
    images = load(review.INPUT / "image-manifest.json")
    calls = record["toolCalls"]
    requested_images = [c["arguments"]["path"] for c in calls
                        if c["arguments"]["path"].endswith(".png")]
    assert len(requested_images) == 26 and len(set(requested_images)) == 26
    by_path = {r["path"]: r for r in images}
    viewed_hashes = {by_path[p]["sha256"] for p in requested_images}
    assert len(viewed_hashes) == 26 == len({r["sha256"] for r in images})
    packet_call = next(c for c in calls if c["arguments"]["path"] == access["commonPacket"]["reviewPath"])
    assert packet_call["returnedContent"] == Path(access["commonPacket"]["reviewPath"]).read_bytes().decode("utf-8")
    coverage = {
        "snapshot": review.BASE, "model": "claude-opus-5.5",
        "originalSessionId": record["sessionId"],
        "allCommonPacketCharactersReturned": True,
        "commonPacketSha256": access["commonPacket"]["sha256"],
        "packetReturnDiagnostic": "Initial exact-character audit compared view output with Python universal-newline read_text and failed before writing archive outputs. Exact raw UTF8 decode then matched all273141characters, including1434embeddedCRLFs; no packet or original execution bytes changed.",
        "toolCalls": len(calls), "successfulToolCalls": sum(bool(c.get("success")) for c in calls),
        "observedToolOverlaps": record["observedToolOverlaps"],
        "multiToolResponseCount": record["multiToolResponseCount"],
        "freshlyViewedOriginalImages": requested_images,
        "distinctViewedRasters": 26, "manifestImages": 42,
        "notFreshlyViewedByteIdenticalImages": [r for r in images if r["path"] not in requested_images],
        "completeSourceResourceAccess": [
            {**row, "freshFullView": any(c["arguments"]["path"] == row["reviewPath"] and
                                      c["arguments"].get("forceReadLargeFiles") for c in calls)}
            for row in access["completeSourceResources"]],
        "limits": [
            "The 26 original image views cover the 26 distinct recorded rasters; 16 duplicate paths were not opened.",
            "Three font panels were requested in one assistant response and overlapped; the attempt violates the mandatory per-tool serialization contract.",
            "The initial822 packet and both raw KANJIDIC2 resources were not freshly read. Target1604470 and raw character records were inherited/projection-only in this continuation.",
            "One source-access read returned a size-limit message; a subsequent forceReadLargeFiles call recovered the complete file.",
            "Byte/range/image access does not prove comprehension or equivalent sense-by-sense inspection.",
        ],
        "acceptedRenderedConfirmation": False,
    }
    save(D / "read-and-process-audit.json", coverage)
    disposition = {
        "status": "preserved-not-accepted-process-noncompliance",
        "cause": "Single three-tool assistant response concurrently viewed font panels1/2/3 despite explicit serial-only task. Two overlapping starts. Reviewer acknowledged the breach; coordinator assertion failed after preserving complete original report/execution.",
        "reviewerProcessExit": 0, "coordinatorAudit": "AssertionError at review-rendered-828.py:238",
        "mandatoryGate": "Independent rendered/finite-label semantic acceptance remains UNVERIFIED; this attempt is not retroaccepted.",
        "originalReportUnchanged": True, "gptLaunched": False,
        "substantiveReport": "The original report states no established defect for the three teaching units or bounded actual options and keeps the instruction/precept hypothesis unresolved nonblocking. These are preserved reviewer observations, not accepted batch verdicts.",
        "originalHypothesis": "unresolved nonblocking; no speculative guard, forced withdrawal or universal future-pool safety",
        "optional": "Original optional wording/expansion/footer suggestions and raw-unselected-kun feedback observation remain optional/unadjudicated, not defects established by the process audit.",
        "newConsequentialContentDefectEstablished": False,
        "recovery": "Resume the SAME original Claude session for a bounded explicitly serial compliant confirmation. Reinspect the three affected font panels one per response and complete required full source-family/raw-record inspection (especially1604470). Retain prior serial reads only as explicitly inherited scope, never rewrite or retroaccept this noncompliant attempt. Obtain a new explicit original-family confirmation with actual process/read evidence; then resume original GPT serially on the same frozen common packet/source/image scope and its own original report. Only one process at a time; actual exit before next. No repeat blind initial, speculative content fix or changed runtime.",
        "diagnostics": [
            "Initial catalog probe `copilot config help` was an unsupported settings invocation; `copilot help config` subsequently returned the actual catalog. Neither altered configuration nor constituted permission denial.",
            "All8472runtime hashes and manifest remain unchanged; no teaching, Android/native, publication or delivery credit.",
        ],
    }
    save(D / "coordinator-disposition.json", disposition)
    for path in (C / "preflight-828.ps1", C / "review-rendered-828.py", C / "finish-rendered-828.py",
                 C / "post-rendered-828.ps1", L / "copilot-help-828.txt",
                 L / "copilot-model-catalog-828.txt", L / "preflight-828.json",
                 L / "preflight-828-before-claude.json", L / "starting-state-828.json",
                 L / "runtime-before-828.json", L / "claude-process.json",
                 C / "batch-106-rendered-828-claude-usage.json"):
        (D / (path.name + ".gz")).write_bytes(gzip.compress(path.read_bytes(), mtime=0))
    index = [{"file": p.name, "sha256": sha(p.read_bytes()), "bytes": p.stat().st_size}
             for p in sorted(D.iterdir()) if p.is_file()]
    save(D / "artifact-index.json", index)
    save(E, {
        "schemaVersion": 1, "execution": 828, "batch": "106",
        "recordedAt": datetime.now(timezone.utc).isoformat(),
        "stage": "original-Claude-rendered-attempt-preserved-not-accepted",
        "sourceSnapshot": review.BASE, "qualifiedAndroidHead": review.APP,
        "packet": D.relative_to(R).as_posix(), "originalSessionId": record["sessionId"],
        "actualModels": record["actualModels"], "reviewerExitCode": 0,
        "reviewerProcessAbsent": True, "independentReviewerProcessesLaunched": 1,
        "acceptedRenderedConfirmations": 0, "gptLaunched": False,
        "processAuditPassed": False, "concurrentFontPanelStarts": 2,
        "runtime": runtime, "runtimeChanged": False, "runtimeAccepted": False, "runtimePublished": False,
        "newNativeOrdinarySenseFallbackSemanticAcceptance": "UNVERIFIED pending compliant original-family confirmations",
        "coordinatorDisposition": disposition,
        "artifactIndexSha256": sha((D / "artifact-index.json").read_bytes()),
        "parentLockTouched": False, "optionalHistoricalHelpersAccessed": False,
        "actualNewPermissionDenials": [], "publishedAdditions": 132, "remainingAdditions": 1096,
        "physicalPhoneAcceptance": "outstanding", "generalReleaseAcceptance": "outstanding",
        "wholeProjectComplete": False, "nextBatchStarted": False,
    })
    print("Original noncompliant report/process/read evidence archived without acceptance; GPT not launched.")


def finish():
    p, before = load(C / "progress.json"), load(L / "progress-before-828.json")
    assert (p["checkpoint"], p["status"], p["batch"]) == (827, "continue", "106")
    head = git("rev-parse", "HEAD").decode().strip()
    assert git("rev-parse", "HEAD^").decode().strip() == review.BASE
    assert git("log", "-1", "--format=%G?").decode().strip() == "G"
    assert not git("status", "--porcelain", "--untracked-files=all").strip()
    changed = git("diff", "--name-only", review.BASE, head).decode().splitlines()
    assert changed and all(s.startswith("docs/n1-reviews/batch-106-rendered-828/") or
                           s == "docs/n1-sources/execution-828.json" for s in changed)
    assert review.runtime() == load(L / "runtime-before-828.json")
    for row in load(D / "artifact-index.json"):
        assert sha((D / row["file"]).read_bytes()) == row["sha256"]
        relative = (D / row["file"]).relative_to(R).as_posix()
        assert sha(git("show", head + ":" + relative)) == row["sha256"]
    posted, comment = load(L / "issue-828-posted.json"), load(L / "issue-828-reread.json")
    body = (C / "batch-106-rendered-828-issue-body.txt").read_text(encoding="utf-8")
    assert comment["user"]["login"] == posted["author"] == "stop-cran"
    assert comment["body"] == body and comment["html_url"] == posted["url"]
    assert posted["bodySha256"] == sha(body.encode("utf-8"))
    assert review.absent(load(L / "claude-process.json")["launcherPid"])
    mutable = {"checkpoint", "status", "stage", "nextAction", "blocker", "checkpointHistory"}
    assert all(p[k] == v for k, v in before.items() if k not in mutable)
    prior = {k: before.get(k) for k in mutable}
    action = (
        f"SAME106 checkpoint828 signed LOCAL noncompliant-Claude-attempt receipt HEAD{head}, qualifiedAndroid{review.APP}. "
        "Read docs/n1-sources/execution-828.json and docs/n1-reviews/batch-106-rendered-828/ full original Claude report, "
        "execution.json/jsonl.gz, read-and-process-audit and coordinator-disposition. ORIGINALClaude4304295f-1fe0-4f7a-a8c4-"
        "2db9b547857d actualclaude-opus-5.5 exited0/PID11512absent.33viewcalls, common6123linepacket complete;26distinctPNGs "
        "of42originals fresh;16identicalduplicates notopened. BUT threefontpanels requested in ONEassistantresponse with "
        "TWOoverlappingstarts; explicitserializationcontract breached, revieweradmitted, coordinatorassertionFAILED "
        "after preservingoriginalreport. ZEROacceptedrenderedconfirmations. GPT NOTlaunched. No retroacceptance. "
        "Initial822packet/target1604470/bothrawKANJIDIC2resources NOTfreshlyread: inherited/projectiononly. "
        "NEXT bounded SAME106 ORIGINALClaude compliant followup: originalfindings/report/exactunchangeddiff and "
        "SAMEcommon827task/packet/fullsource-access/image-manifest. OneSINGLEviewcall perassistantresponse; reread "
        "affected3fontpanelsSERIAL and completefresh fullsourcefamily/rawrecordinspection especially1604470. "
        "Priorserialreads may be explicitlyINHERITEDscope, notrewrite/retroacceptoriginal828attempt. Obtain new explicit "
        "compliant originalfamily confirmation, auditactualtoolserialization/model/returnedranges/PNGs/exit; THEN "
        "originalGPT4d834a27-eaf4-47ea-a4d6-32f583e4ed4c gpt-6.1-sol samecommonpacket/sources/images/OWNoriginalreport. "
        "OnlyONEreviewerprocess atonce; ACTUALexitbefore next; noeditfrozensnapshot/noauthoragents/nestedtasks. "
        "Original822 weak勅訓hypothesis staysUNRESOLVEDNONBLOCKING; 1956150/1236890fullfamilies plus1430550/1604470; "
        "notforcedwithdrawal/establisheddefect/speculativeguard/universalsafety. Original828no-defect/optionalobservations "
        "preserved NOTacceptedsemantic/rendered verdict. Newnativefallbacksemanticacceptance UNVERIFIED untilBOTHcompliant "
        "originalfamilies. Five新labels剰扱獣矛芋/fullrawEnglishmeanings/fullJMdictrestrictions; exactdefault畔剰俸勅; "
        "64nativeorderedoffers/pools/seeds/32unguardedsamples; inheritedHOSTbothworddirections. "
        "Fullon[チョク]/kun[いまし.める,みことのり]preserved exactorder,selected[チョク]/[]; solekeyちょく/displayチョク; "
        "legacyfeedbackrawkunvisible/curationNOTallreferencedisplay. Modernwrittenいまし.めるUNVERIFIED;outsideJoyoREADINGlist "
        "NOTfrequency/invalidity. Actual42PNGs/26distinct/900x2000toolrenditionsNOToriginalpixels/phone/nativespeaker/"
        "fallbackface; drawingreferenceinjection/revealgradeNOTmastery. All8472runtimehashes/version89809c00e1676979/"
        "manifestunchanged; nofreshHOST/native/contentacceptance/publication/107. Completeprevious827nextAction retained "
        "in historicalExecution827Before828RenderedAttempt.nextAction; ALL originalacceptance/source/reviewer/process/"
        "denial/OOM/historylimits remainmandatory. Combinedcurrentmain/nonrewritingmerge/changedteachingreview/"
        "fullrequiredPython/vocabulary/baseline-membership-links/manifestbudget/normalsigning/ownerfastforward/"
        "terminalgreenCI/EVERYimmutableGitHubZIPmanifesthash/unchanged18000entries42MiBcompressed80MiBinflated56MiBretained/"
        "perfilepathmedia/verifiedownerissue remainMANDATORY. No107/unreviewedpush/concurrentheavywork/secondrunner/"
        "signingretry/guardincrease. Freshsignedheads/checkpoint/whollyclean/freshmain/liveparentancestry/"
        "decodedlauncher/exactsession required. Parent13320ownsrunner.lock:nochildacquire/delete/unlock/readprobe. "
        "Approvedcontrol/committedsource/frozeninputs only;preserve/report/yield actualnewdenial/signinghang/"
        "uncertainownership. Published132/1228/remainder1096unchanged;lastpublished0c582f18b31f65a5e1a908d92e37dde3d34f81ee; "
        "unaccepted勅/necessarysupport勅令notN1vocabularydelivery. CompatibleAndroid125+132 required;oldclientsignore. "
        "Physicalphone/generalrelease/whole-setoutstanding;projectincomplete."
    )
    checkpoint = {
        "schemaVersion": 1, "execution": 828, "checkpoint": 828, "batch": "106",
        "status": "continue", "stage": "batch-106-rendered-Claude-attempt-preserved-awaiting-compliant-confirmation",
        "recordedAt": datetime.now(timezone.utc).isoformat(), "savedCommit": head, "signature": "G",
        "qualifiedAndroidHead": review.APP, "sourceSnapshot": review.BASE,
        "evidence": E.relative_to(R).as_posix(), "issueUpdate": posted["url"],
        "ownerIssueAuthorAndExactBodyVerified": True, "reviewerProcessesLaunched": 1,
        "actualModel": "claude-opus-5.5", "originalSessionId": "4304295f-1fe0-4f7a-a8c4-2db9b547857d",
        "reviewerExitCode": 0, "reviewerProcessAbsent": True, "gptLaunched": False,
        "toolCalls": 33, "overlappingToolStarts": 2, "multiToolResponses": 1,
        "acceptedRenderedConfirmations": 0, "processAuditPassed": False,
        "newNativeOrdinarySenseFallbackSemanticAcceptance": "UNVERIFIED pending compliant original-family confirmations",
        "runtime": review.runtime(), "runtimeChanged": False, "runtimeAccepted": False, "runtimePublished": False,
        "dedicatedWorktreesClean": True, "parentLockTouched": False, "actualNewPermissionDenials": [],
        "publishedAdditions": 132, "remainingAdditions": 1096, "lastPublishedCommit": p["lastPublishedCommit"],
        "physicalPhoneAcceptance": "outstanding", "generalReleaseAcceptance": "outstanding",
        "wholeProjectComplete": False, "nextBatchStarted": False,
        "originalHistoricalRootKeysCompared": len(before), "allOriginalHistoricalValuesPreserved": True,
        "finalRunnerPreflight": load(L / "preflight-828-before-issue.json"), "nextAction": action, "blocker": None}
    updated = copy.deepcopy(p)
    updated["historicalExecution827Before828RenderedAttempt"] = prior
    updated["execution828StartingState"]["status"] = "signed-local-noncompliant-review-attempt-preserved-not-accepted"
    updated["execution828CoordinatorCheckpoint"] = checkpoint
    for k in ("checkpoint", "status", "stage", "nextAction", "blocker"):
        updated[k] = checkpoint[k]
    updated["checkpointHistory"] = {
        "completeSnapshot": str(L / "checkpoint-full.json"), "liveProgressPath": str(C / "progress.json"),
        "invariant": "Preserve full live history; immutable snapshot is the observer input."}
    assert all(updated[k] == v for k, v in before.items() if k not in mutable)
    save(L / "checkpoint-828-summary.json", checkpoint)
    review.atomic(updated, "finish")
    reread = load(C / "progress.json")
    assert all(reread[k] == v for k, v in before.items() if k not in mutable)
    save(L / "checkpoint-828-final-verification.json", {
        "checkpoint": 828, "head": head, "signature": "G", "whollyClean": True,
        "historicalRootKeysCompared": len(before), "allOriginalHistoricalValuesPreserved": True,
        "runtimeHashesVerified": 8472, "acceptedRenderedConfirmations": 0, "projectComplete": False})
    print("Checkpoint828 saved; original noncompliant attempt preserved, no acceptance/publication credit.")


if __name__ == "__main__":
    {"archive": archive, "finish": finish}[sys.argv[1]]()
