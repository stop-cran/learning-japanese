"""Original-GPT rendered confirmation on the unchanged batch106 snapshot."""
import copy
from datetime import datetime, timezone
import gzip
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

C = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("review829", C / "review-rendered-829.py")
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
R, INPUT = prior.R, prior.INPUT
L = C / "logs" / "fded2273-b562-43fd-9e56-fb76585e9d22"
D = R / "docs" / "n1-reviews" / "batch-106-rendered-830"
BASE = "edf14a85c7c2b6d7d7dda161d539fb2980778b9b"
APP = prior.prior.APP
SESSION = "4d834a27-eaf4-47ea-a4d6-32f583e4ed4c"
MODEL = "gpt-6.1-sol"
load, save, sha, git = prior.load, prior.save, prior.sha, prior.git
runtime, inputs, absent, now = prior.prior.runtime, prior.prior.inputs, prior.prior.absent, prior.prior.now


def atomic(data, tag):
    tmp = C / ("progress.json.830-" + tag + ".tmp")
    save(tmp, data)
    assert load(tmp) == data
    os.replace(tmp, C / "progress.json")
    assert load(C / "progress.json") == data


def preflight(name, evidence=False, head=BASE):
    cmd = ["pwsh", "-NoProfile", "-File", str(C / "preflight-830.ps1"),
           "-ReceiptName", name, "-ExpectedContentHead", head]
    if evidence:
        cmd.append("-EvidenceOnly")
    subprocess.run(cmd, check=True)


def start():
    p = load(C / "progress.json")
    assert (p["checkpoint"], p["status"], p["batch"]) == (829, "continue", "106")
    raw = (L / "request.txt").read_bytes()
    text = raw.decode("utf-8-sig")
    requested = json.loads(text.split(
        "Current execution checkpoint (complete historical state remains at checkpointHistory paths):", 1)[1])
    expected = copy.deepcopy(requested["execution829CoordinatorCheckpoint"])
    actual = copy.deepcopy(p["execution829CoordinatorCheckpoint"])
    for row in (expected, actual):
        row["recordedAt"] = datetime.fromisoformat(row["recordedAt"]).astimezone(timezone.utc).isoformat()
        row["finalRunnerPreflight"]["verifiedAt"] = datetime.fromisoformat(
            row["finalRunnerPreflight"]["verifiedAt"]).astimezone(timezone.utc).isoformat()
    assert expected == actual
    assert p["execution792HistoryCorrection"]["ownerReportCorrection"].endswith("6721328619")
    assert absent(17008)
    inputs()
    catalog = (L / "copilot-model-catalog-830.txt").read_text(encoding="utf-8-sig")
    assert '"' + MODEL + '"' in catalog
    shutil.copyfile(C / "progress.json", L / "progress-before-830.json")
    state = {
        "execution": 830, "batch": "106", "startingHead": BASE, "qualifiedAndroidHead": APP,
        "startedAt": now(), "runnerPreflight": load(L / "preflight-830.json"),
        "scope": "SAME106 bounded ORIGINAL-GPT rendered confirmation only, on identical common827packet/source-access/image-manifest and own original822report. No Claude rendered findings supplied. No teaching changes, HOST/native rerun, publication or107.",
        "request": {"sha256": sha(raw), "bytes": len(raw), "characters": len(text),
                    "lines": len(text.splitlines()), "completeFileLoadedAndCheckpointParsed": True,
                    "limits": "Entire request loaded/decoded and final JSON parsed before implementation. Complete operative contract, approved issue and final829 checkpoint inspected directly. Historical middle loaded/parsed, not freshly semantically re-reviewed; equivalent timestamp offsets normalized only for comparison, not live history."},
        "artifactPathPreflight": "Approved committed source packets and workspace inputs only; reusable helpers in control; optional historical session recipes not accessed.",
        "parentLockTouched": False, "actualNewPermissionDenials": [],
        "status": "original-GPT-rendered-confirmation-in-progress"}
    save(L / "starting-state-830.json", state)
    save(L / "runtime-before-830.json", runtime())
    assert "execution830StartingState" not in p
    p["execution830StartingState"] = state
    p.update(stage="batch-106-original-GPT-rendered-confirmation-in-progress",
             nextAction="SAME106 execute ORIGINAL-GPT rendered confirmation with identical frozen827inputs and own original report, single view per response; preserve complete process/report/read/PNG evidence and checkpoint. No publication/107.",
             blocker=None)
    atomic(p, "start")
    print("Starting scope persisted with full history; all8472runtime hashes unchanged.")


def run():
    preflight("preflight-830-before-gpt.json")
    access = inputs()
    assert absent(17008)
    session = access["originalSessions"]["gpt"]
    assert session["sessionId"] == SESSION
    prompt = (INPUT / "common-task.txt").read_text(encoding="utf-8-sig")
    prompt += (
        "\nEXECUTION830 ORIGINAL-GPT confirmation, frozen signed evidence HEAD " + BASE +
        "; teaching EXACTLY UNCHANGED since5fe224b5. Continue YOUR original session " + SESSION +
        " with requested model " + MODEL + ". Own original report: " + session["report"] +
        ". Read YOUR OWN report first. No other reviewer's rendered findings are supplied.\n"
        "MANDATORY EXECUTION GATE: issue EXACTLY ONE view tool call PER assistant response, await its result, "
        "then issue the next in a separate assistant response. NEVER emit two/three tool requests in one response; "
        "NEVER batch font panels. No parallel wrapper, delegation, shell or edits. "
        "A multi-tool response invalidates the process even if the underlying calls happen to finish serially.\n"
        "Read same source-access " + str(INPUT / "source-access.json") +
        ", same common packet " + access["commonPacket"]["reviewPath"] +
        ", and same image manifest " + str(INPUT / "image-manifest.json") +
        ". Read common packet in full with forceReadLargeFiles=true; recover any truncation serially. "
        "Freshly inspect BOTH complete HOST/native KANJIDIC2 raw resources and BOTH complete HOST/native JMdict raw "
        "resources listed there (forceReadLargeFiles=true), all English character meanings/restrictions/senses, "
        "especially1956150/1236890. Fresh target initial-packet range1815-1895 contains COMPLETE "
        "1430550/1430560/1597670/1604470; read through closing1604470. Full initial packet is available, "
        "but do not claim a fresh full initial review merely from retained session context. "
        "If a resource is truncated, recover consecutive missing ranges serially.\n"
        "Freshly view all relevant ORIGINAL PNGs, EACH in its own assistant response, including ALL THREE font panels, "
        "target/support article viewport sequence and exact reused line, default question/feedback, curated on/feedback/"
        "completion, drawing trace/feedback/recall, N1/All selections, components and whole word. "
        "Deduplicate byte-identical hashes if useful, enumerate every actually viewed original and omitted/duplicate path. "
        "No inherited rendered-GPT scope exists; own original review was textual only. "
        "Record the actual exposed model, actual read ranges and actual image renditions. "
        "Return a complete standalone Snapshot/Scope/Verdicts/Findings/Optional/Limits report, separate three facets "
        "per teaching unit plus bounded actual-option semantic/rendered disposition and original finding/hypothesis "
        "reconciliation. Preserve unresolved nonblocking hypotheses without forced withdrawal or speculative guards. "
        "No universal pool/phone/native-speaker/mastery/whole-project claim. "
        "Return the entire report in your final message; coordinator preserves it, you cannot write files.\n")
    prefix = "batch-106-rendered-830-gpt"
    prompt_path = C / (prefix + "-prompt.txt")
    assert not prompt_path.exists()
    prompt_path.write_text(prompt, encoding="utf-8", newline="\n")
    raw, err, usage_path = (C / (prefix + suffix) for suffix in
                            (".jsonl", "-stderr.txt", "-usage.json"))
    cmd = [shutil.which("copilot"), "-C", str(R), "--add-dir", str(C),
           "--model", MODEL, "--session-id", SESSION, "--no-ask-user",
           "--allow-tool=view", "--disable-builtin-mcps", "--available-tools=view",
           "--no-custom-instructions", "--output-format", "json",
           "--log-dir", str(C / "review-logs" / prefix),
           "--usage-output-file", str(usage_path), "-p", prompt]
    env = os.environ.copy()
    env.pop("GH_TOKEN", None)
    env.pop("GITHUB_TOKEN", None)
    started = now()
    with raw.open("xb") as out, err.open("xb") as errors:
        proc = subprocess.Popen(cmd, stdout=out, stderr=errors, env=env)
        save(L / "gpt-active.json", {"pid": proc.pid, "sessionId": SESSION,
                                  "requestedModel": MODEL, "startedAt": started,
                                  "snapshot": BASE, "command": cmd})
        print("Original GPT reviewer running", proc.pid, flush=True)
        code = proc.wait()
    process = {"launcherPid": proc.pid, "startedAt": started, "completedAt": now(),
               "exitCode": code, "requestedModel": MODEL, "sessionId": SESSION,
               "snapshot": BASE, "command": cmd, "processAbsentAfterWait": absent(proc.pid)}
    save(L / "gpt-process.json", process)
    events = [json.loads(s) for s in raw.read_text(encoding="utf-8-sig").splitlines() if s.strip()]
    messages = [e["data"] for e in events if e.get("type") == "assistant.message"]
    calls, active, overlaps = {}, set(), []
    for e in events:
        data = e.get("data", {})
        if e.get("type") == "tool.execution_start":
            key = data["toolCallId"]
            if active:
                overlaps.append({"starting": key, "active": sorted(active)})
            active.add(key)
            calls[key] = {"name": data["toolName"], "arguments": data["arguments"],
                          "startedAt": e["timestamp"]}
        elif e.get("type") == "tool.execution_complete":
            key = data["toolCallId"]
            active.discard(key)
            calls.setdefault(key, {}).update(
                completedAt=e["timestamp"], success=data.get("success"),
                returnedContent=data.get("result", {}).get("content", ""))
    D.mkdir()
    final = [m["content"] for m in messages if m.get("content") and not m.get("toolRequests")]
    report = D / "gpt-report.md"
    report.write_text(final[-1] + "\n" if final else "", encoding="utf-8", newline="\n")
    usage = load(usage_path) if usage_path.exists() else None
    record = {**process, "actualModels": sorted({m.get("model", "") for m in messages}),
              "usage": usage, "reportSha256": sha(report.read_bytes()),
              "rawExecutionSha256": sha(raw.read_bytes()), "availableTools": ["view"],
              "toolCalls": list(calls.values()), "observedToolOverlaps": overlaps,
              "unfinishedTools": sorted(active),
              "multiToolResponseCount": sum(len(m.get("toolRequests", [])) > 1 for m in messages),
              "configurationEvidence": [e["data"] for e in events if e.get("type") in
                                        ("session.info", "session.tools_updated")]}
    save(D / "gpt-execution.json", record)
    (D / "gpt-execution.jsonl.gz").write_bytes(gzip.compress(raw.read_bytes(), mtime=0))
    (D / "gpt-stderr.txt").write_bytes(err.read_bytes())
    shutil.copyfile(prompt_path, D / "gpt-task.txt")
    print(json.dumps({"exitCode": code, "actualModels": record["actualModels"],
                      "toolCalls": len(calls), "overlaps": len(overlaps),
                      "multiToolResponses": record["multiToolResponseCount"],
                      "processAbsent": process["processAbsentAfterWait"]}), flush=True)
    assert code == 0 and record["actualModels"] == [MODEL]
    assert usage and usage.get("currentModel") == MODEL
    assert not overlaps and not active and not record["multiToolResponseCount"]
    assert all(c["name"] == "view" and c.get("success") for c in calls.values())
    assert process["processAbsentAfterWait"]
    assert runtime() == load(L / "runtime-before-830.json")


if __name__ == "__main__":
    {"start": start, "run": run}[sys.argv[1]]()
