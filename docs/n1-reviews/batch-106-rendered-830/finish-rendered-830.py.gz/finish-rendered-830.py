"""Preserve the actual original-GPT denial and yield without gate acceptance."""
import copy
from datetime import datetime
import gzip
import importlib.util
import json
from pathlib import Path
import sys

C = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("review830", C / "review-rendered-830.py")
review = importlib.util.module_from_spec(spec)
spec.loader.exec_module(review)
R, L, D = review.R, review.L, review.D
load, save, sha, git = review.load, review.save, review.sha, review.git
E = R / "docs" / "n1-sources" / "execution-830.json"
DENIED_PATH = r"C:\Users\stop-\learning-japanese\.git\worktrees\learning-japanese\HEAD"


def archive():
    record = load(D / "gpt-execution.json")
    assert record["actualModels"] == [review.MODEL] and record["exitCode"] == 0
    assert record["usage"]["currentModel"] == review.MODEL
    assert record["sessionId"] == review.SESSION
    assert record["processAbsentAfterWait"] and review.absent(record["launcherPid"])
    assert not record["observedToolOverlaps"] and not record["unfinishedTools"]
    assert record["multiToolResponseCount"] == 0
    calls = record["toolCalls"]
    assert len(calls) == 43 and all(c["name"] == "view" for c in calls)
    failures = [c for c in calls if not c.get("success")]
    assert len(failures) == 2 and failures[1]["arguments"]["path"] == DENIED_PATH
    raw = (C / "batch-106-rendered-830-gpt.jsonl").read_bytes()
    events = [json.loads(s) for s in raw.decode("utf-8-sig").splitlines() if s.strip()]
    failed_events = [e for e in events if e.get("type") == "tool.execution_complete"
                     and not e["data"].get("success")]
    assert len(failed_events) == 2 and failed_events[1]["data"]["error"]["code"] == "denied"
    access = review.inputs()
    resources = []
    for row in access["completeSourceResources"][1:]:
        call = next(c for c in calls if c["arguments"]["path"] == row["reviewPath"])
        expected = Path(row["reviewPath"]).read_bytes().decode("utf-8")
        assert call["success"] and call["returnedContent"] == expected
        resources.append({**row, "completeExactRawTextReturned": True,
                          "returnedCharacters": len(expected)})
    packet = access["commonPacket"]
    packet_call = next(c for c in calls if c["arguments"]["path"] == packet["reviewPath"])
    assert packet_call["returnedContent"] == Path(packet["reviewPath"]).read_bytes().decode("utf-8")
    initial = access["completeSourceResources"][0]
    target_call = next(c for c in calls if c["arguments"]["path"] == initial["reviewPath"])
    assert target_call["arguments"]["view_range"] == [1815, 1895]
    lines = Path(initial["reviewPath"]).read_bytes().decode("utf-8").split("\n")
    target_text = "\n".join(lines[1814:1895]).rstrip("\r\n")
    assert target_call["returnedContent"] == target_text
    assert target_text.count("<entry>") == target_text.count("</entry>") == 4
    assert all("<ent_seq>" + key + "</ent_seq>" in target_text
               for key in ("1430550", "1430560", "1597670", "1604470"))
    images = load(review.INPUT / "image-manifest.json")
    viewed = [c["arguments"]["path"] for c in calls
              if c.get("success") and c["arguments"]["path"].endswith(".png")]
    assert len(viewed) == len(set(viewed)) == 25
    by_path = {row["path"]: row for row in images}
    viewed_hashes = {by_path[path]["sha256"] for path in viewed}
    omitted = [row for row in images if row["path"] not in viewed]
    duplicates = [row for row in omitted if row["sha256"] in viewed_hashes]
    setup = [row for row in omitted if row["sha256"] not in viewed_hashes]
    assert len(duplicates) == 16 and len(setup) == 1
    assert Path(setup[0]["path"]).name == "preinstrumentation.png"
    assert review.runtime() == load(L / "runtime-before-830.json")
    save(D / "failed-tool-events.json", failed_events)
    save(D / "read-and-process-audit.json", {
        "snapshot": review.BASE, "actualModel": review.MODEL, "originalSessionId": review.SESSION,
        "reviewerPid": record["launcherPid"], "reviewerExitCode": 0, "reviewerProcessAbsent": True,
        "toolCalls": 43, "successfulViewCalls": 41, "failedViewCalls": 2,
        "overlappingToolStarts": 0, "multiToolResponses": 0, "unfinishedTools": 0,
        "serializationAuditPassed": True, "overallReviewAcceptancePassed": False,
        "failedCalls": failures, "actualDenial": failed_events[1],
        "completeCommonPacketReturned": {**packet, "exactCompleteTextReturned": True},
        "freshExactCompleteSourceResources": resources,
        "freshInitialSourceRange": {**initial, "viewRange": [1815, 1895],
                                    "exactRangeReturned": True,
                                    "completeFamilies": ["1430550", "1430560", "1597670", "1604470"]},
        "freshOriginalImages": [by_path[path] for path in viewed],
        "notViewedByteIdenticalImages": duplicates, "notViewedSetupImage": setup,
        "limits": [
            "Preserved report and exact successful returns establish access, not authenticated independent review acceptance, comprehension or upstream retrieval.",
            "Reviewer continued its serial source/image work after the denied view. Coordinator learned the denial from terminal evidence and then preserved/report/yielded; no retry or further reviewer was launched.",
            "25originalPNGs freshly viewed,16identicalduplicates/setup1notviewed;900x2000toolrenditions not original pixels, phone/native-speaker/fallback-face evidence.",
            "Initial complete4833line textual review inherited; only1815-1895fresh. No fresh full initial review claimed.",
        ]})
    denial = {
        "path": DENIED_PATH, "timestamp": failed_events[1]["timestamp"],
        "tool": "view", "code": "denied", "message": failed_events[1]["data"]["error"]["message"],
        "operation": "Original reviewer followed the dedicated worktree .git pointer while trying to verify supplied HEAD.",
        "noDeniedContentReturned": True, "coordinatorDidNotAccessDeniedPath": True,
        "noRetryOrAuthorizationExpansion": True, "noPermissionPolicyOrLockChange": True,
    }
    disposition = {
        "status": "blocked-actual-reviewer-evidence-path-denial",
        "reportPreservedUnchanged": True, "acceptedGPTConfirmation": False,
        "acceptedRenderedOriginalFamilies": ["claude-opus-5.5"],
        "acceptedRenderedOriginalFamilyCount": 1,
        "newNativeOrdinarySenseFallbackSemanticAcceptance": "UNVERIFIED; original GPT attempt not accepted",
        "actualDenial": denial,
        "precedingFailure": "view of dedicated worktree .git\\HEAD returned Path does not exist; .git itself is a pointer file.",
        "wrapperFailure": "review-rendered-830.py run exited1 at assertion requiring every view success, after preserving complete original report/execution and reviewer exit0.",
        "process": "OriginalGPT4d834a27-eaf4-47ea-a4d6-32f583e4ed4c actualgpt-6.1-sol;43serialviews/41success/2failure/oneactualdenial/zerooverlap/zeroMultiTool;exit0/PID29408absent.",
        "substantiveReportNotAccepted": "Favorable bounded textual/rendered/finite-option observations are preserved, not used to close the original-GPT or batch gates. No established new teaching defect was reported.",
        "hypotheses": "Original weak勅/訓instruction-precept hypothesis remains UNRESOLVED NONBLOCKING; no forced withdrawal, speculative guard or universal safety claim.",
        "coordinatorSnapshotVerification": "Before execution the coordinator independently verified exact signed heads/clean worktrees/freshmain/runner ancestry and all8472runtime hashes. This does not substitute for or retroaccept the reviewer's denied evidence access.",
        "next": "Yield for explicit scoped disposition of the NEW reviewer denial. No automatic retry or canonical-repository access. After disposition, resume SAME106 original-GPT bounded confirmation using approved frozen packets and an explicitly supplied coordinator signed-head receipt, without claiming independent Git authentication or waiving any required source/review gate.",
        "runtimeChanged": False, "runtimeAccepted": False, "runtimePublished": False,
        "phoneAcceptance": "outstanding", "generalReleaseAcceptance": "outstanding",
    }
    save(D / "coordinator-disposition.json", disposition)
    for path in (C / "preflight-830.ps1", C / "review-rendered-830.py",
                 C / "finish-rendered-830.py", C / "post-rendered-830.ps1",
                 L / "copilot-help-830.txt", L / "copilot-model-catalog-830.txt",
                 L / "preflight-830.json", L / "preflight-830-before-gpt.json",
                 L / "starting-state-830.json", L / "runtime-before-830.json",
                 L / "gpt-process.json", C / "batch-106-rendered-830-gpt-usage.json"):
        (D / (path.name + ".gz")).write_bytes(gzip.compress(path.read_bytes(), mtime=0))
    save(D / "artifact-index.json", [
        {"file": path.name, "sha256": sha(path.read_bytes()), "bytes": path.stat().st_size}
        for path in sorted(D.iterdir()) if path.is_file()])
    save(E, {
        "schemaVersion": 1, "execution": 830, "batch": "106", "recordedAt": review.now(),
        "stage": disposition["status"], "sourceSnapshot": review.BASE,
        "teachingSnapshot": "5fe224b5c611e8ca0c7c5a1fcbd5ea4a025e606a",
        "qualifiedAndroidHead": review.APP, "packet": D.relative_to(R).as_posix(),
        "actualModel": review.MODEL, "originalSessionId": review.SESSION,
        "reviewerExitCode": 0, "reviewerPid": record["launcherPid"], "reviewerProcessAbsent": True,
        "reviewerProcessesLaunched": 1, "successfulViewCalls": 41, "failedViewCalls": 2,
        "overlappingToolStarts": 0, "multiToolResponses": 0,
        "serializationAuditPassed": True, "overallReviewAcceptancePassed": False,
        "acceptedRenderedOriginalFamilyCount": 1,
        "coordinatorDisposition": disposition, "actualNewPermissionDenials": [denial],
        "runtime": review.runtime(), "runtimeChanged": False,
        "runtimeAccepted": False, "runtimePublished": False, "parentLockTouched": False,
        "artifactIndexSha256": sha((D / "artifact-index.json").read_bytes()),
        "publishedAdditions": 132, "remainingAdditions": 1096,
        "physicalPhoneAcceptance": "outstanding", "generalReleaseAcceptance": "outstanding",
        "wholeProjectComplete": False, "nextBatchStarted": False,
        "coordinatorDiagnosticLimits": "Two read-only diagnostic prints failed/truncated (oversized ephemeral delta output, then cp1252 UnicodeEncodeError). Exact failed tool.execution_complete events and final25PNG/read inventory recovered from preserved workspace JSON; no denied path was reopened.",
    })
    print("Actual denial and full GPT attempt preserved; no GPT/batch acceptance; yield required.")


def finish():
    p, before = load(C / "progress.json"), load(L / "progress-before-830.json")
    assert (p["checkpoint"], p["status"], p["batch"]) == (829, "continue", "106")
    head = git("rev-parse", "HEAD").decode().strip()
    assert git("rev-parse", "HEAD^").decode().strip() == review.BASE
    assert git("log", "-1", "--format=%G?").decode().strip() == "G"
    assert not git("status", "--porcelain", "--untracked-files=all").strip()
    changed = git("diff", "--name-only", review.BASE, head).decode().splitlines()
    assert changed and all(s.startswith("docs/n1-reviews/batch-106-rendered-830/") or
                           s == "docs/n1-sources/execution-830.json" for s in changed)
    runtime = review.runtime()
    assert runtime == load(L / "runtime-before-830.json")
    for row in load(D / "artifact-index.json"):
        assert sha((D / row["file"]).read_bytes()) == row["sha256"]
        assert sha(git("show", head + ":" + (D / row["file"]).relative_to(R).as_posix())) == row["sha256"]
    posted, comment = load(L / "issue-830-posted.json"), load(L / "issue-830-reread.json")
    body = (C / "batch-106-rendered-830-issue-body.txt").read_text(encoding="utf-8")
    assert comment["user"]["login"] == posted["author"] == "stop-cran"
    assert comment["body"] == body and comment["html_url"] == posted["url"]
    assert posted["bodySha256"] == sha(body.encode("utf-8"))
    assert review.absent(load(L / "gpt-process.json")["launcherPid"])
    mutable = {"checkpoint", "status", "stage", "nextAction", "blocker", "checkpointHistory"}
    assert all(p[k] == v for k, v in before.items() if k not in mutable)
    disposition = load(D / "coordinator-disposition.json")
    blocker = {
        "kind": "actual-new-reviewer-permission-denial", "path": DENIED_PATH,
        "evidence": E.relative_to(R).as_posix(), "savedCommit": head,
        "report": (D / "gpt-report.md").relative_to(R).as_posix(),
        "actualError": disposition["actualDenial"],
        "ownerIssueUpdate": posted["url"], "noRetry": True,
    }
    action = (
        f"SAME106 checkpoint830 BLOCKED actual NEW ORIGINAL-GPT view permission denial. Signed LOCAL evidenceHEAD{head}, "
        f"qualifiedAndroid{review.APP}; no runtime publication. Read docs/n1-sources/execution-830.json and "
        "docs/n1-reviews/batch-106-rendered-830/ complete originalreport/execution/failed-tool-events/read-and-process-audit/"
        "coordinator-disposition. OriginalGPT4d834a27-eaf4-47ea-a4d6-32f583e4ed4c actualgpt-6.1-sol exited0/"
        "PID29408absent;43SERIALviewcalls41success2failure/zerooverlaps/zeroMultiTool. Dedicated.git\\HEAD missing, "
        "then reviewer followed.gitpointer to " + DENIED_PATH +
        " and actualtool errorcodeDENIED/nointeractiveapproval/no deniedcontent. Reviewercontinuedserialinspection;"
        "coordinatorlearnedatprocessor exit, wrapper assertionFAILEDafterpreservingoriginalreport. No retry/pathaccess/"
        "policychange/locktouch/secondreviewer. GPTconfirmationNOTACCEPTED; originalClaude829ONEacceptedfamilyonly;"
        "newnativefallbacksemanticacceptanceUNVERIFIED. Freshcompletecommon6123lines/fourrawHOSTnativeXMLresources/"
        "initial1815-1895families1430550/1430560/1597670/1604470/25relevantoriginalPNGs;16duplicatesand1setupomitted. "
        "Favorableobservations preserved NOTgateacceptance. Originalweak勅訓hypothesisUNRESOLVEDNONBLOCKING;"
        "noforcedwithdrawal/guard/universalsafety. NEXT yieldforEXPLICITSCOPEDdispositionofTHISNEWdenial,NOThistoricalrecipe. "
        "DoNOTretrycanonicalpath/requesthistoricalsessionhelper/accessoriginaldirtyrepositories. Afterdisposition,"
        "SAME106 boundedORIGINALGPTconfirmationfromapprovedfrozenpacketsplusEXPLICITcoordinatorsignedHEADreceipt,"
        "notclaimindependentGitverification/notwaiveactualsourcesorreviewgates. Completeprior829nextAction retainedverbatim "
        "in historicalExecution829Before830Denial.nextAction; ALL source/reviewer/process/denial/OOM/historylimits,"
        "combinedcurrentmain/nonrewritingmerge/changedteachingreview/fullrequiredPython/vocabulary/baseline-membership-links/"
        "manifestbudgets/normalsigning/ownerfastforward/terminalgreenCI/EVERYimmutableZIPmanifesthash/unchanged18000entries/"
        "42MiBcompressed80MiBinflated56MiBretained/perfilepathmedia/verifiedownerissue remainMANDATORY. "
        "All8472runtimehashes/version89809c00e1676979/manifestunchanged; nofreshHOST/native/contentacceptance/"
        "publication107. Parent13320ownsrunner.lock:nochildacquire/delete/unlock/readprobe; "
        "approvedcontrol/committedsource/frozeninputs only. Published132/1228/remainder1096unchanged;"
        "lastpublished0c582f18b31f65a5e1a908d92e37dde3d34f81ee; compatibleAndroid125+132required/oldclientsignore;"
        "physicalphone/generalrelease/whole-setoutstanding;projectincomplete."
    )
    checkpoint = {
        "schemaVersion": 1, "execution": 830, "checkpoint": 830, "batch": "106",
        "status": "blocked", "stage": "blocked-actual-original-GPT-evidence-path-denial",
        "recordedAt": review.now(), "savedCommit": head, "signature": "G",
        "qualifiedAndroidHead": review.APP, "sourceSnapshot": review.BASE,
        "evidence": E.relative_to(R).as_posix(), "issueUpdate": posted["url"],
        "ownerIssueAuthorAndExactBodyVerified": True, "reviewerProcessesLaunched": 1,
        "actualModel": review.MODEL, "originalSessionId": review.SESSION,
        "reviewerExitCode": 0, "reviewerPid": 29408, "reviewerProcessAbsent": True,
        "toolCalls": 43, "successfulViewCalls": 41, "failedViewCalls": 2,
        "overlappingToolStarts": 0, "multiToolResponses": 0,
        "serializationAuditPassed": True, "overallReviewAcceptancePassed": False,
        "acceptedGPTConfirmation": False, "acceptedRenderedOriginalFamilyCount": 1,
        "newNativeOrdinarySenseFallbackSemanticAcceptance": "UNVERIFIED",
        "runtime": runtime, "runtimeChanged": False, "runtimeAccepted": False, "runtimePublished": False,
        "dedicatedWorktreesClean": True, "parentLockTouched": False,
        "actualNewPermissionDenials": [disposition["actualDenial"]],
        "publishedAdditions": 132, "remainingAdditions": 1096, "lastPublishedCommit": p["lastPublishedCommit"],
        "physicalPhoneAcceptance": "outstanding", "generalReleaseAcceptance": "outstanding",
        "wholeProjectComplete": False, "nextBatchStarted": False,
        "originalHistoricalRootKeysCompared": len(before), "allOriginalHistoricalValuesPreserved": True,
        "finalRunnerPreflight": load(L / "preflight-830-before-issue.json"), "nextAction": action, "blocker": blocker}
    updated = copy.deepcopy(p)
    updated["historicalExecution829Before830Denial"] = {key: before.get(key) for key in mutable}
    updated["execution830StartingState"]["status"] = "blocked-actual-reviewer-denial-preserved-and-reported"
    updated["execution830CoordinatorCheckpoint"] = checkpoint
    for key in ("checkpoint", "status", "stage", "nextAction", "blocker"):
        updated[key] = checkpoint[key]
    updated["checkpointHistory"] = {
        "completeSnapshot": str(L / "checkpoint-full.json"), "liveProgressPath": str(C / "progress.json"),
        "invariant": "Preserve full live history; immutable snapshot is the observer input."}
    assert all(updated[key] == value for key, value in before.items() if key not in mutable)
    save(L / "checkpoint-830-summary.json", checkpoint)
    review.atomic(updated, "finish")
    reread = load(C / "progress.json")
    assert all(reread[key] == value for key, value in before.items() if key not in mutable)
    save(L / "checkpoint-830-final-verification.json", {
        "checkpoint": 830, "status": "blocked", "head": head, "signature": "G", "whollyClean": True,
        "historicalRootKeysCompared": len(before), "allOriginalHistoricalValuesPreserved": True,
        "runtimeHashesVerified": 8472, "acceptedRenderedOriginalFamilyCount": 1,
        "actualDenialPreservedAndReported": True, "projectComplete": False})
    print("Checkpoint830 BLOCKED saved with full history; actual denial reported; no retry/acceptance/publication.")


if __name__ == "__main__":
    {"archive": archive, "finish": finish}[sys.argv[1]]()
