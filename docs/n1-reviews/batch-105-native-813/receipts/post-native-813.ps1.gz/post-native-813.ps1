$ErrorActionPreference = 'Stop'
$control = $PSScriptRoot
$log = "$control\logs\3eb6b337-b7ef-470f-b18e-1b45ac3a2f6f"
$content = "$control\..\learning-japanese"
$bodyPath = "$control\batch-105-native-813-issue-body.txt"
if ((Test-Path "$log\issue-813-posted.json") -or (Test-Path $bodyPath)) { throw 'Do not duplicate issue update' }
$head = git -C $content rev-parse HEAD
if ($LASTEXITCODE -ne 0) { throw 'HEAD lookup failed' }
& "$control\preflight-813.ps1" -ReceiptName 'preflight-813-before-issue.json' -ExpectedContentHead $head
if ((git -C $content rev-parse 'HEAD^') -ne '5975e9f297dd7c58adb1ae822eb13e8e7e964ea0' -or
    $LASTEXITCODE -ne 0) { throw 'Wrong evidence ancestry' }
$e = [IO.File]::ReadAllText("$content\docs\n1-sources\execution-813.json") | ConvertFrom-Json
if (-not $e.nativeExecutionComplete -or $e.runtimeChanged -or $e.runtimePublished -or
    -not $e.nativeAttempt.ownedHelperStopped -or -not $e.nativeAttempt.ownedQemuStopped -or
    $e.runtime.runtimeHashesVerified -ne 8469 -or $e.nativeResults.terminalSuccessCases -ne 2) {
    throw 'Native evidence mismatch'
}
$body = @"
Checkpoint813, SAME batch105: BOTH exact prepared812 native cases passed terminal status0, zero failures/skips (116.338s). Signed LOCAL evidence $head preserves docs/n1-sources/execution-813.json and docs/n1-reviews/batch-105-native-813/: complete instrumentation/route/raster results, exact APK/fixture/archive bindings,36 native PNGs plus1 environment screenshot. No teaching/app changes, reviewer, push or batch106.

Fresh signed clean heads, live parent13320 ancestry/decoded launcher/current session/checkpoint, and local+remote5580/5581 including TimeWait/PID checks passed. Owned read-only API35 emulator5580 parent29300/QEMU28732 was responsive; BOTH stopped. Same AVD/host GPU/Vulkan disabled/2GiB guest/192m growth/576m max heap. Only unrelated Google Messages was force-stopped on the OWNED disposable emulator before instrumentation, grounded in preserved802 ANR interference; no package disable, target-error suppression or fixture changes. Parent runner.lock/shared adb/other devices untouched.

Full production ContentSync imported signed303a8cf7 archive ONCE:1,128kanji/5,079words/137N1/zero problems; reading+meaning parser epochs1. Actual Room/projections/builders passed896 direct symmetric kanji guard checks,192 NONTRANSITIVE neighbor checks,384 pair-only word guard checks and64 sampled meaning-option sets, every offered kanji set pairwise exclusion-checked. All THREE curated distractors 功/劾/剖 are N1; actual default N1 has ZERO fallback. Default labels: strong; taut / merit; achievement / dissect; split open / censure; impeach. Separately filtered sampled pools exercise fallback; finite mechanics do not certify every future pool's semantics.

Sole selected on-keyけい displaysケイ and persists correct/done1of1; full source on[ケイ]/kun[つよ.い] preserved, selected[ケイ]/[], no kun question. Legacy feedback still displays rawつよい; curation excludes questions, not all reference display. The article explains search-only勁い and ordinary強い. Nine reference-touch strokes passed ungraded trace, deliberate recall reveal/grade1-on-Next; ONE mapped reciprocal pair/TWO directions, system Back and offline route passed. Zero activated baseline pairs/reused edits. Other N1 questions postponed/two historical meaning logs seeded; no drawing state seeded. Shape-only feedback/model unavailable is not human handwriting recognition or mastery.

56 individual glyph probes/4 word rasters/3 panels passed for all14 scoped Han in four production families/default. Coordinator actually opened17of37 original PNGs, including all3 font panels: 勁U+52C1/巠U+5DE0/刂U+5202 are readable/distinguishable despite absence from all three bundled cmaps; no established blank/tofu/misleading glyph. Actual fallback face unknown. Tool displays900x2000 renditions of1080x2400 screenshots, not original pixels/phone/native-speaker certification;20 PNGs preserved but not freshly viewed. Horizontal table shows only a scrolled viewport; article08/09 are duplicate visible states, not extra visual coverage.

All8,469 runtime hashes/version5572c6c467e6b73b unchanged; exact compiled full archive d5939614eb02900b9191ec5e2b9fd8c9f8c1e2c4cfb9462cda50ca69281318f6 retained.8,491entries/30,499,181compressed/44,689,710inflated/44,421,372retained bytes and unchanged per-file/media/path limits verified. Validator0 errors; regenerated manifest unchanged. Exact812 APKs were executed without rebuilding; debug artifacts, not owner-signed release.

NEXT SAME105 bounded source packet for FIVE native fallback labels absent from HOST811: 亥 Boar zodiac sign, 巳 Snake zodiac sign, 彗 broom; comet, 柚 yuzu citrus, 鵬 peng; giant mythical bird. Preserve exact full frozen character records and applicable comparison bodies/senses, then TWO SERIAL ORIGINAL-family rendered confirmations using original sessions/reports and actual native images/labels. New native ordinary-secondary-sense semantic acceptance remains UNVERIFIED until this source-backed work; native mechanical success is NOT whole-batch acceptance. Original810 textual and811 HOST finite target-relative acceptance inherited, not repeated; all original findings, withdrawn hypotheses, optional dispositions and source/process/read-depth/history limits preserved.

All combined-current-main/nonrewriting-merge/changed-teaching-review/full-required-validation/normal-signing/owner-fast-forward/terminal-green-CI/EVERY-immutable-GitHub-ZIP-hash/budget/publication gates remain. Original guards18,000entries/42MiBcompressed/80MiBinflated/56MiBretained unchanged. Published131/1,228; acceptance remainder1,097; last published047c2cef6b6a48b1738f2c5957de01be481c63e1. Batch105 not closed/published. Compatible stop-cran/kanji-cards-android#125 and stop-cran/kanji-cards-android#132 client required; old clients ignore curation/guards; qualified backport, not latest app main. Physical-phone, general-release and whole-set acceptance outstanding; project incomplete. No new permission denial, optional historical-session helper access, second runner or lock acquisition.
"@
[IO.File]::WriteAllText($bodyPath, $body + "`n", [Text.UTF8Encoding]::new($false))
$priorToken = $env:GH_TOKEN
try {
    $env:GH_TOKEN = (gh auth token --user stop-cran)
    if ($LASTEXITCODE -ne 0 -or -not $env:GH_TOKEN) { throw 'Owner credential unavailable' }
    $login = gh api user --jq .login
    if ($LASTEXITCODE -ne 0 -or $login -cne 'stop-cran') { throw 'Wrong command-scoped identity' }
    $url = gh issue comment 60 --repo stop-cran/learning-japanese --body-file $bodyPath
    if ($LASTEXITCODE -ne 0) { throw 'Issue update failed' }
    $url = $url.Trim()
    @{ url=$url; author=$login; bodySha256=(Get-FileHash $bodyPath).Hash.ToLowerInvariant() } |
        ConvertTo-Json | Set-Content "$log\issue-813-posted.json" -Encoding utf8NoBOM
    if ($url -notmatch '#issuecomment-(\d+)$') { throw 'Unexpected comment URL; preserve receipt' }
    $raw = gh api "repos/stop-cran/learning-japanese/issues/comments/$($Matches[1])"
    if ($LASTEXITCODE -ne 0) { throw 'Comment reread failed' }
    $raw | Set-Content "$log\issue-813-reread.json" -Encoding utf8NoBOM
    $comment = $raw | ConvertFrom-Json
    if ($comment.user.login -cne 'stop-cran' -or $comment.body -cne [IO.File]::ReadAllText($bodyPath) -or
        $comment.html_url -cne $url) { throw 'Exact owner/body verification failed' }
    Write-Output "Verified owner update: $url"
} finally {
    $env:GH_TOKEN = $priorToken
}
