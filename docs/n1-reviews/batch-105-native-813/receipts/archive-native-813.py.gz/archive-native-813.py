from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import gzip
import hashlib
import json
import re
import shutil
import subprocess
import zipfile

C = Path(__file__).resolve().parent
R, A = C.parent / "learning-japanese", C.parent / "kanji-cards-android"
L = C / "logs" / "3eb6b337-b7ef-470f-b18e-1b45ac3a2f6f"
RAW = C / "artifacts" / "batch-105-native-813"
D = R / "docs" / "n1-reviews" / "batch-105-native-813"
BASE = "5975e9f297dd7c58adb1ae822eb13e8e7e964ea0"
APP = "bf30cdead8515739bc0e671d57a54b9a3109dd46"


def load(p):
    return json.loads(p.read_text(encoding="utf-8-sig"))


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def save(p, data):
    assert not p.exists(), p
    p.write_text(json.dumps(data, ensure_ascii=True, indent=2) + "\n", encoding="utf-8")
    assert load(p) == data


def git(*args, root=R):
    return subprocess.check_output(["git", "--no-pager", "-C", str(root), *args], encoding="utf-8").strip()


def runtime():
    packet = load(R / "docs" / "n1-reviews" / "batch-105-native-812" / "compiled-packet.json")
    prep, compiled = packet["preparation"], packet["compilation"]
    for path, digest in [(prep["archive"], prep["archiveSha256"]), (prep["fixture"], prep["fixtureSha256"]),
                         (compiled["appApk"], compiled["appApkSha256"]), (compiled["testApk"], compiled["testApkSha256"])]:
        assert sha(Path(path)) == digest, path
    manifest_bytes = (R / "manifest.json").read_bytes()
    assert manifest_bytes == subprocess.check_output(["git", "-C", str(R), "show", prep["contentSnapshot"] + ":manifest.json"])
    m = json.loads(manifest_bytes)
    assert m["contentVersion"] == "5572c6c467e6b73b"
    assert not git("diff", "--name-only", prep["contentSnapshot"], "HEAD", "--",
                   "kanji", "words", "articles", "strokes", "manifest.json", "grammar", "listening",
                   "listening-tasks", "audio", "task-audio", "task-images")
    with zipfile.ZipFile(prep["archive"]) as z:
        names = z.namelist()
        prefix = names[0].split("/")[0] + "/"
        assert len(names) == len(set(names)) == 8491 <= 18000
        assert all(n.startswith(prefix) and "\\" not in n and ".." not in PurePosixPath(n).parts
                   and not n.startswith("/") and not re.search(r"(^|/)[^/]*:", n) for n in names)
        assert not any("/docs/" in n or "/tools/" in n for n in names)
        assert z.read(prefix + "manifest.json") == manifest_bytes
        retained, media, count = len(manifest_bytes), 0, 0
        for section, entries in m.items():
            if not isinstance(entries, dict):
                continue
            for name, digest in entries.items():
                assert len(PurePosixPath(name).parts) == 2 and ".." not in PurePosixPath(name).parts
                assert not name.startswith("/") and "\\" not in name and ":" not in name
                data = z.read(prefix + name)
                local = (R / name).read_bytes()
                binary = section in {"images", "audio", "listeningTaskAudio", "listeningTaskImages"}
                limit = 150 * 1024 if section in {"images", "listeningTaskImages"} else (
                    512 * 1024 if section in {"audio", "listeningTaskAudio"} else 2 * 1024 * 1024)
                assert len(data) <= limit, name
                normalized = data if binary else data.replace(b"\r\n", b"\n")
                assert hashlib.sha256(normalized).hexdigest() == digest, name
                assert normalized == (local if binary else local.replace(b"\r\n", b"\n")), name
                retained += len(data)
                count += 1
                if section in {"listeningTaskAudio", "listeningTaskImages"}:
                    media += len(data)
        inflated = sum(i.file_size for i in z.infolist())
        compressed = Path(prep["archive"]).stat().st_size
        assert count == 8469
        assert retained == 44421372 <= 56 * 1024 * 1024
        assert inflated == 44689710 <= 80 * 1024 * 1024
        assert compressed == 30499181 <= 42 * 1024 * 1024
        assert media == 5893602 <= 20 * 1024 * 1024
    return {"contentVersion": m["contentVersion"], "runtimeHashesVerified": count,
            "manifestSha256": sha(R / "manifest.json"), "runtimeUnchanged": True,
            "manifestEqualsCompiledArchive": True, "archiveContentSnapshot": prep["contentSnapshot"],
            "archiveSha256": prep["archiveSha256"], "zipEntries": len(names), "compressedBytes": compressed,
            "inflatedBytes": inflated, "retainedBytes": retained, "listeningTaskMediaBytes": media,
            "allOriginalBudgetsAndPerFilePathMediaGuardsPassed": True}


def results():
    attempt = load(RAW / "execution.json")
    assert attempt["passed"] and attempt["nativeExecuted"] and attempt["failure"] is None
    assert attempt["terminalSuccessCases"] == 2 and attempt["adbExitCode"] == 0
    assert attempt["ownedHelperStopped"] and attempt["ownedQemuStopped"]
    assert attempt["coordinatorHead"] == BASE and attempt["androidSnapshot"] == APP
    assert attempt["prelaunch"]["connections"] == []
    assert attempt["heapGrowth"] == "192m" and attempt["heapSize"] == "576m"
    assert attempt["network"] == "Active default network: none"
    assert not any(attempt[k] for k in ("parentLockTouched", "guestOrAppHeapChanged", "guardsChanged"))
    raw = (RAW / "instrumentation.txt").read_text(encoding="utf-8-sig")
    assert len(re.findall(r"(?m)^INSTRUMENTATION_STATUS_CODE: 0\s*$", raw)) == 2
    assert "OK (2 tests)" in raw and "Time: 116.338" in raw
    assert not re.search(r"INSTRUMENTATION_STATUS_CODE: -[234]|FAILURES|INSTRUMENTATION_FAILED|ignored|assumptionFailure", raw)
    route = load(RAW / "n1-105-article-route.json")
    assert route["passed"] and route["archiveRequests"] == 1
    assert (route["importedKanji"], route["importedWords"], route["n1Cards"], route["problems"],
            route["acceptedReadingParserEpoch"], route["acceptedMeaningParserEpoch"]) == (1128, 5079, 137, 0, 1, 1)
    assert (route["mappedReciprocalPairs"], route["directedLinkTransitions"],
            route["activatedBaselinePairs"], route["changedReusedArticles"]) == (1, 2, 0, 0)
    assert all(route[k] for k in ("reciprocalLinkAndSystemBack", "meaningQuestionAndFeedback",
                                 "soleCuratedOnPersistedGoodAndDone", "drawingTraceThenRecall",
                                 "drawingGradeRecordedOnNext", "offline"))
    assert route["touchInjectedReferenceStrokes"] == 9
    assert route["fullOnyomi"] == route["fullProjectionOnyomi"] == route["fullProjectionQuizOnyomi"] == ["ケイ"]
    assert route["fullKunyomi"] == route["fullProjectionKunyomi"] == ["つよ.い"]
    assert route["fullProjectionQuizKunyomi"] == route["quizKunKeys"] == []
    assert route["quizOnKeys"] == ["けい"]
    assert (route["actualN1CuratedAvailable"], route["actualN1FallbackOptions"]) == (3, 0)
    assert route["curatedDistractorLevels"] == {"功": 1, "劾": 1, "剖": 1}
    for key, count in {"productionBuilderN1AndAllExactChoices": 64, "kanjiDirectGuardChecks": 896,
                       "nontransitiveNeighborChecks": 192, "preservedWordGuardChecks": 384}.items():
        assert len(route[key]) == count, key
    for row in route["kanjiDirectGuardChecks"]:
        assert row["target"] in row["options"] and row["excluded"] not in row["options"]
        assert len(row["options"]) == len(set(row["options"]))
    assert all(set(r["options"]) == {r["target"], r["neighbor"]} for r in route["nontransitiveNeighborChecks"])
    raster = load(RAW / "n1-105-font-raster.json")
    assert (raster["individualGlyphProbes"], raster["wholeWordRasterProbes"], raster["panels"],
            len(raster["rows"]), raster["sdk"], raster["fontScale"]) == (56, 4, 3, 60, 35, 1)
    for char in ("勁", "巠", "刂"):
        assert len([r for r in raster["rows"] if r.get("character") == char and r["hasGlyph"]]) == 4
    return attempt, route, raster


def main():
    progress = load(C / "progress.json")
    assert (progress["checkpoint"], progress["status"], progress["batch"]) == (812, "continue", "105")
    for root, expected in ((R, BASE), (A, APP)):
        assert git("rev-parse", "HEAD", root=root) == expected
        assert git("log", "-1", "--format=%G?", root=root) == "G"
        assert not git("status", "--porcelain", "--untracked-files=all", root=root)
    verified_runtime = runtime()
    attempt, route, raster = results()
    inspection = load(L / "coordinator-inspection-813.json")
    pngs = sorted(p.name for p in RAW.glob("*.png"))
    assert inspection["totalOriginalPngs"] == len(pngs) == 37
    assert inspection["viewedCount"] == len(set(inspection["viewedOriginalPngs"])) == 17
    assert set(inspection["viewedOriginalPngs"]) <= set(pngs)
    labels = {(o["kanji"], o["title"]) for r in route["productionBuilderN1AndAllExactChoices"] for o in r["options"]}
    labels.update((o["kanji"], o["title"]) for o in route["exactDefaultMeaningOptions"])
    host = {tuple(r) for r in load(R / "docs" / "n1-reviews" / "batch-105-host-811" / "sampled-labels.json")["kanji"]}
    delta = {"nativeUniqueLabelCount": len(labels), "nativeLabels": [list(x) for x in sorted(labels)],
             "newVersusHost811": [list(x) for x in sorted(labels - host)],
             "absentVersusHost811": [list(x) for x in sorted(host - labels)],
             "exactLiveDefault": route["exactDefaultMeaningOptions"],
             "limits": "Five new native fallback labels need complete frozen character families and actual applicable comparison articles before source-backed semantic acceptance/original-family rendered confirmations. Default N1 has THREE curated choices and ZERO fallback; do not generalize its safety to filtered pools."}
    assert len(labels) == 10 and {x[0] for x in labels - host} == set("鵬彗亥柚巳")
    D.mkdir(exist_ok=False)
    index = []

    def preserve(source, destination):
        destination.parent.mkdir(exist_ok=True, parents=True)
        assert not destination.exists()
        data = source.read_bytes()
        if destination.suffix == ".gz":
            destination.write_bytes(gzip.compress(data, mtime=0))
            assert gzip.decompress(destination.read_bytes()) == data
        else:
            shutil.copyfile(source, destination)
        index.append({"file": destination.relative_to(D).as_posix(), "sourceBytes": len(data),
                      "sourceSha256": sha(source), "storedSha256": sha(destination)})

    for source in sorted(RAW.iterdir()):
        assert source.is_file()
        preserve(source, D / "native" / (source.name if source.suffix == ".png" else source.name + ".gz"))
    for name in ("preflight-813.ps1", "start-native-813.py", "run-native-813.ps1", "archive-native-813.py"):
        preserve(C / name, D / "receipts" / (name + ".gz"))
    for name in ("preflight-813.json", "preflight-813-native.json", "starting-state-813.json"):
        preserve(L / name, D / "receipts" / (name + ".gz"))
    preserve(R / "docs" / "n1-reviews" / "batch-105-native-812" / "compiled-packet.json",
             D / "receipts" / "812-compiled-packet.json.gz")
    save(D / "artifact-index.json", index)
    save(D / "coordinator-inspection.json", inspection)
    save(D / "sampled-labels-and-host-delta.json", delta)
    evidence = {
        "schemaVersion": 1, "execution": 813, "batch": "105",
        "stage": "native-two-terminal-cases-passed-awaiting-new-label-sources-and-original-family-rendered-confirmations",
        "recordedAt": datetime.now(timezone.utc).isoformat(),
        "startingState": progress["execution813StartingState"], "testedContentHead": BASE,
        "qualifiedAndroidHead": APP, "runtime": verified_runtime, "nativeAttempt": attempt,
        "nativeResults": {
            "terminalSuccessCases": 2, "terminalFailureCases": 0, "skipped": 0, "seconds": 116.338,
            "productionContentSyncCalls": 1, "preparseCalls": 0,
            "importedCounts": {"kanji": 1128, "words": 5079, "n1": 137, "problems": 0},
            "acceptedReadingParserEpoch": 1, "acceptedMeaningParserEpoch": 1,
            "directSymmetricGuardChecks": 896, "nontransitiveNeighborChecks": 192,
            "preservedWordGuardChecks": 384, "productionBuilderChoices": 64,
            "individualGlyphProbes": 56, "wholeWordRasterProbes": 4, "fontPanels": 3, "scopedHan": 14,
            "explicitFallbackCodepoints": ["勁 U+52C1", "巠 U+5DE0", "刂 U+5202"],
            "nativePngs": 36, "preservedPngs": 37, "environmentPreflightPngs": 1,
            "soleCuratedOnPersistedGoodAndDone": True, "selectedSourceEntries": 1,
            "actualKeys": route["quizOnKeys"], "emptyKunQuestionExpectedNull": True,
            "drawingStrokes": 9, "mappedReciprocalPairs": 1, "directedLinkTransitions": 2,
            "activatedBaselinePairs": 0, "changedReusedArticles": 0, "offline": True, "systemBack": True,
            "actualN1CuratedAvailable": 3, "actualN1FallbackOptions": 0},
        "sampledLabels": delta, "coordinatorInspection": inspection,
        "nativeExecutionComplete": True, "independentReviewersLaunched": 0,
        "independentRenderedReviewClosed": False,
        "newNativeOrdinarySenseFallbackSemanticAcceptance": "UNVERIFIED",
        "runtimeChanged": False, "manifestChanged": False, "runtimeAccepted": False, "runtimePublished": False,
        "reviewClosed": [], "published": [], "nextBatchStarted": False,
        "publishedAdditions": 131, "remainingAdditions": 1097, "lastPublishedCommit": progress["lastPublishedCommit"],
        "physicalPhoneAcceptance": "outstanding", "generalReleaseAcceptance": "outstanding",
        "wholeProjectComplete": False, "actualNewPermissionDenials": [],
        "limits": [
            "Exact prepared812 APKs/fixture/archive executed without rebuild. Debug APKs, not an owner-signed release.",
            "One owned read-only API35 emulator; original ports were freshly free including local/remote/TimeWait. Both owned helper processes stopped; no shared adb restart or other device changes.",
            "Only unrelated Google Messages force-stopped on the owned disposable emulator based on prior802 ANR evidence; no package disable, target-error suppression or fixture/production changes.",
            "Other N1 meanings/readings postponed and two historical meaning logs seeded; disposable fixture, not owner progress. No drawing state seeded.",
            "Reference-stroke touch injection and deliberate recall failure are not human handwriting recognition, learning mastery or measured effectiveness; model unavailable and shape-only feedback.",
            "17of37 actual PNGs freshly inspected;900x2000 displayed renditions of1080x2400 screenshots, not original-pixel/equal-comprehension/native-speaker certification.20 original PNGs preserved but not freshly viewed.",
            "All14 scoped Han visible in three four-family/default panels, including three absent bundled-cmap targets. Actual fallback face unknown; cmap/raster hashes alone are not readability.",
            "Five new native sampled fallback labels require full frozen source inspection; semantic acceptance UNVERIFIED until evidence-based original-family rendered confirmation. Mechanical success is not whole-batch acceptance.",
            "Original810 textual and811 HOST finite target-relative acceptance inherited, not repeated; all original reports, withdrawn hypotheses, optional findings and source/read/process limits preserved.",
            "Compatible Android125/132 client required; old clients ignore curation/guards. Qualified backport, not latest app main.",
            "All combined-current-main/review/validation/signing/owner-fast-forward/terminal-CI/exact-immutable-GitHub-ZIP/per-file/media/path/publication gates remain mandatory. No publication, physical-phone, general-release or whole-set acceptance."]
    }
    save(R / "docs" / "n1-sources" / "execution-813.json", evidence)
    print(json.dumps({"archived": str(D), "nativeCases": 2, "pngs": len(pngs),
                      "newLabels": delta["newVersusHost811"]}, ensure_ascii=True))


if __name__ == "__main__":
    main()
