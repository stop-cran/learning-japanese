from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess

control = Path(__file__).resolve().parent
session = "3eb6b337-b7ef-470f-b18e-1b45ac3a2f6f"
logs = control / "logs" / session
path = control / "progress.json"
original = path.read_bytes()
progress = json.loads(original)
assert progress["checkpoint"] == 812 and progress["batch"] == "105"
assert progress["status"] == "continue"
assert "execution813StartingState" not in progress
(logs / "progress-before-813.json").write_bytes(original)
request = (logs / "request.txt").read_bytes()
text = request.decode("utf-8-sig")
json.loads(text.split("Current execution checkpoint (complete historical state remains at checkpointHistory paths):", 1)[1])
preflight = json.loads((logs / "preflight-813.json").read_text(encoding="utf-8-sig"))
content = control.parent / "learning-japanese"
subprocess.run(["git", "-C", str(content), "fetch", "--quiet", "origin", "main"], check=True)
main = subprocess.check_output(["git", "-C", str(content), "rev-parse", "origin/main"], text=True).strip()
state = {
    "execution": 813, "batch": "105", "startedAt": datetime.now(timezone.utc).isoformat(),
    "startingHead": preflight["contentHead"],
    "androidHead": "bf30cdead8515739bc0e671d57a54b9a3109dd46",
    "freshOriginMain": main,
    "scope": "SAME105 exact prepared812 full-archive ContentSync ONCE native execution and signed LOCAL evidence checkpoint only; no reviewer/publication/106.",
    "request": {"sha256": hashlib.sha256(request).hexdigest(), "characters": len(text),
                "lines": len(text.splitlines()), "completeFileLoadedAndCheckpointParsed": True,
                "limits": "Entire request loaded/decoded and embedded checkpoint parsed; operative contract, complete approved issue and final812 inspected directly. Historical middle parsed, not freshly semantically re-reviewed. Initial full-load summary had console encoding error after successful decode; bounded final read succeeded."},
    "runnerPreflight": preflight,
    "artifactPathPreflight": "Approved committed source packets and durable control helpers only; optional historical-session recipes not accessed.",
    "parentLockTouched": False, "actualNewPermissionDenials": [],
}
progress["execution813StartingState"] = state
progress["historicalExecution812Before813Native"] = {k: progress[k] for k in ("checkpoint", "stage", "status", "nextAction", "blocker")}
progress["stage"] = "batch-105-native-execution-in-progress"
assert path.read_bytes() == original
temp = control / "progress.json.813-start.tmp"
temp.write_text(json.dumps(progress, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
os.replace(temp, path)
(logs / "starting-state-813.json").write_text(json.dumps(state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print("Execution813 starting scope saved; historical checkpoint preserved; fresh main " + main)
