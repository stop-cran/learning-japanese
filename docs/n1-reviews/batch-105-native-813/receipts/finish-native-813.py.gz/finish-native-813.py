import copy
from datetime import datetime, timezone
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

C = Path(__file__).resolve().parent
R, A = C.parent / "learning-japanese", C.parent / "kanji-cards-android"
L = C / "logs" / "3eb6b337-b7ef-470f-b18e-1b45ac3a2f6f"
D = R / "docs" / "n1-reviews" / "batch-105-native-813"
E = R / "docs" / "n1-sources" / "execution-813.json"
BASE = "5975e9f297dd7c58adb1ae822eb13e8e7e964ea0"
APP = "bf30cdead8515739bc0e671d57a54b9a3109dd46"
spec = importlib.util.spec_from_file_location("archive813", C / "archive-native-813.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
load, save, sha, git = module.load, module.save, module.sha, module.git


def verify(head, clean=True):
    p = load(C / "progress.json")
    assert (p["checkpoint"], p["status"], p["batch"]) == (812, "continue", "105")
    runner = load(C / "runner.json")
    assert (runner["status"], runner["pid"], runner["sessionId"]) == ("running", 13320, L.name)
    for root, expected in ((R, head), (A, APP)):
        assert git("rev-parse", "HEAD", root=root) == expected
        assert git("log", "-1", "--format=%G?", root=root) == "G"
        if clean or root == A:
            assert not git("status", "--porcelain", "--untracked-files=all", root=root)
    for row in load(D / "artifact-index.json"):
        assert sha(D / row["file"]) == row["storedSha256"], row["file"]
    if (D / "finalization-helper-index.json").exists():
        for row in load(D / "finalization-helper-index.json"):
            assert sha(D / row["file"]) == row["storedSha256"], row["file"]
    return p


def prepare():
    verify(BASE, clean=False)
    assert not git("diff", "--name-only", BASE)
    untracked = git("ls-files", "--others", "--exclude-standard").splitlines()
    assert untracked and all(n.startswith("docs/n1-reviews/batch-105-native-813/")
                             or n == "docs/n1-sources/execution-813.json" for n in untracked)
    index = []
    for name in ("post-native-813.ps1", "finish-native-813.py"):
        source, target = C / name, D / "receipts" / (name + ".gz")
        assert not target.exists()
        target.write_bytes(gzip.compress(source.read_bytes(), mtime=0))
        index.append({"file": target.relative_to(D).as_posix(), "sourceSha256": sha(source),
                      "storedSha256": sha(target)})
    save(D / "finalization-helper-index.json", index)
    e = load(E)
    e["automatedValidation"] = {
        "validatorErrors": 0, "manifestRegenerated": True, "manifestUnchanged": True,
        "whitespaceDiffCheckPassed": True,
        "executionOutput": str(L / "output.jsonl"),
        "limits": "Fresh validator/build_manifest/diff checks executed during this native checkpoint. Full Python/vocabulary/current-main publication acceptance remains separate; no claim to rerun inherited811 HOST tests."}
    E.write_text(json.dumps(e, ensure_ascii=True, indent=2) + "\n", encoding="utf-8")
    assert e["runtime"] == module.runtime()
    module.results()
    print("Native artifact hashes, runtime equality and checkpoint helper provenance verified.")


def finish():
    before = load(L / "progress-before-813.json")
    head = git("rev-parse", "HEAD")
    current = verify(head)
    assert git("rev-parse", "HEAD^") == BASE
    assert not git("diff", "--name-only", BASE, head, "--", "manifest.json", "kanji", "words", "strokes", "articles")
    runtime = module.runtime()
    attempt, route, raster = module.results()
    posted, reread = load(L / "issue-813-posted.json"), load(L / "issue-813-reread.json")
    body = C / "batch-105-native-813-issue-body.txt"
    assert posted["author"] == reread["user"]["login"] == "stop-cran"
    assert posted["bodySha256"] == sha(body) and body.read_bytes().decode("utf-8") == reread["body"]
    assert posted["url"] == reread["html_url"]
    e = load(E)
    assert e["runtime"] == runtime and e["nativeExecutionComplete"]
    assert not e["runtimeChanged"] and not e["runtimePublished"]
    for row in load(D / "artifact-index.json") + load(D / "finalization-helper-index.json"):
        path = (D / row["file"]).relative_to(R).as_posix()
        assert hashlib.sha256(subprocess.check_output(["git", "-C", str(R), "show", head + ":" + path])).hexdigest() == row["storedSha256"]
    next_action = (
        f"SAME105 checkpoint813 signed LOCAL native evidence HEAD{head}, qualifiedAndroid{APP}. "
        "Read docs/n1-sources/execution-813.json and docs/n1-reviews/batch-105-native-813/. "
        "Exact prepared812 APKs/fixture/fullLFarchive executed WITHOUT rebuild; BOTH exact Glyph812/Article812 "
        "terminalcase0/zero failures/skips/116.338s. Full productionContentSyncONCE signed303a8cf7 "
        "archiveSHA256d5939614eb02900b9191ec5e2b9fd8c9f8c1e2c4cfb9462cda50ca69281318f6:1128kanji5079words137N1/"
        "0problems/reading+meaningepochs1. ActualRoom/projections896directsymmetricguards/192NONTRANSITIVEneighbors/"
        "384paironlywordguards/64builderchoices/everyofferedsetpairwiseexclusionchecked. "
        "DefaultN1 has THREEcurated功劾剖/allN1/ZERO fallback; separatelysampledfilteredpoolsexercisefallback. "
        "Fullon[ケイ]/kun[つよ.い]preserved,selected[ケイ]/[]; soleactualkeyけい/displayケイ persistedgood/done1of1/"
        "kunquestionnull. Legacyfeedbackrawつよいstillvisible: curationnotallreferencedisplay. "
        "Ninereferencetouchstrokes/ungradedtrace/modelunavailable/intentionalrecallrevealgrade1onNext, NOTmastery. "
        "ONEactualmappedpair/TWOdirections/zeroactivatedbaselinepairs/zeroreusedchanges/systemBack/offline/meaning passed. "
        "Freshfree5580/5581 localANDremote/TimeWait/PID/readonlyAVD/API35/2gguest192mgrowth576mmax verified; "
        f"ownedemulator5580parent{attempt['parentEmulatorPid']}/QEMU{attempt['qemuPid']} responsiveANDbothstopped. "
        "OnlyunrelatedMessagesforce-stoppedonOWNEDdisposableemulatorbasedonpreserved802ANR; no packagedisable/"
        "targeterrorsuppression/fixture/production/heap/guardchange. Sharedadb/otherdevices/parentrunner.lock untouched. "
        "56glyphprobes/4wordrasters/3panels/14actualHan; coordinatoropened17of37PNGsincludingALL3fontpanels. "
        "Actual勁U+52C1/巠U+5DE0/刂U+5202 fallbackreadabledistinguishableallfourfamilies/default; fallbackfaceunknown. "
        "900x2000toolrenditionsof1080x2400notoriginalpixel/phone/nativespeaker/equalcomprehensioncertification; "
        "20PNGspreservednotfreshlyviewed; article08/09duplicateviewport,readingtablehorizontalscrollnotallcolumns. "
        "NEXT SAME105 bounded complete-frozen-source preparation/inspection for FIVE native fallback labels "
        "absentHOST811:亥Boarzodiac/巳Snakezodiac/彗broom-comet/柚yuzucitrus/鵬peng-giantmythicalbird. "
        "Exact10native labels/order/poolmembers/seeds in sampled-labels-and-host-delta.json and native route JSON. "
        "Preserve complete actual raw character records/allEnglishmeanings/applicable fullJMdictfamilies/"
        "restrictionsandsenses/actualcomparisonbodies from committed packets or approvedfrozeninputs; no corpusdump/"
        "optionalhistoricalsessionrecipe. Newnativeordinarysecondarysensefallbacksemanticacceptance UNVERIFIED "
        "until exactsourceinspection and TWO SERIAL ORIGINAL-family rendered confirmations. "
        "Use originalsessions/reports from batch-105-reconciliation.json, notnewblindinitials; each process "
        "mustexitbeforethenext, reviewerpertoolserialization/noeditfrozensnapshot. "
        "Native mechanicsNOTwholebatchacceptance. Original810textualand811HOSTfinite10kanji22words26families "
        "inherited,notrepeated; retainall originalreports/readlimits/withdrawnhypotheses/optionaldispositions/"
        "process/source/historylimitswithoutretroacceptance. Any consequentialdefect:exactsource/minimalcorrection/"
        "audits/manifest/normalsignednewfreeze/BOTHoriginalfamilyconfirmations. "
        "All8469runtimehashes/version5572c6c467e6b73b/manifestunchanged;8491entries/30499181compressed/"
        "44689710inflated/44421372retainedbytes/perfilepathmedia originalguardsverified. Validator0errors/"
        "regeneratedmanifestunchanged. All priorgates/limitations retained verbatim in "
        "historicalExecution812Before813Native.nextAction and execution812CoordinatorCheckpoint. "
        "Combinedcurrentmain/nonrewritingmerge/changedteachingreview/fullrequiredPython/vocabulary/"
        "baseline-membership-links/manifestbudget/normalsigning/ownerfastforward/terminalgreenCI/"
        "EVERYimmutableGitHubZIPmanifesthash/unchanged18000entries42MiBcompressed80MiBinflated56MiBretained/"
        "perfilepathmedia/verifiedownerissue remainMANDATORY. No106/unreviewedpush/authoragents/"
        "concurrentheavywork/secondrunner/signingretry/guardincrease. Freshsignedheads/checkpoint/whollyclean/"
        "freshmain/liveparentancestry/decodedlauncher/exactsession required. Parent13320ownsrunner.lock:"
        "nochildacquire/delete/unlock/readprobe. Approvedcontrol/committedsource/frozeninputs only;preserve/report/"
        "yield actualnewdenial/signinghang/uncertainownership. QualifiedAndroidapprovedpairguard+schemaonly "
        "NOTlatestappmain. Published131/1228/remainder1097unchanged; unaccepted勁/ONEsupport雄勁 notdeliveredN1vocabulary. "
        "CompatibleAndroid125+132 required;oldclientsignore. Physicalphone/generalrelease/whole-setoutstanding;projectincomplete."
    )
    checkpoint = {
        "schemaVersion": 1, "execution": 813, "checkpoint": 813, "batch": "105",
        "status": "continue", "stage": "batch-105-native-passed-awaiting-new-label-sources-and-rendered-confirmations",
        "recordedAt": datetime.now(timezone.utc).isoformat(), "savedCommit": head, "signature": "G",
        "qualifiedAndroidHead": APP, "testedContentHead": BASE, "archiveContentSnapshot": route["contentSnapshot"],
        "evidence": "docs/n1-sources/execution-813.json", "issueUpdate": posted["url"],
        "ownerIssueAuthorAndExactBodyVerified": True, "nativeExecuted": True, "glyphCasePassed": True,
        "articleCasePassed": True, "terminalSuccessCases": 2, "terminalFailureCases": 0, "nativeSkipped": 0,
        "nativeExecutionComplete": True, "wholeBatchAcceptanceComplete": False, **runtime,
        "nativePngs": 36, "preservedPngs": 37, "coordinatorViewedOriginalPngs": 17,
        "directSymmetricGuardChecks": 896, "nontransitiveNeighborChecks": 192,
        "preservedWordGuardChecks": 384, "productionBuilderChoices": 64,
        "soleCuratedOnPersistedGoodAndDone": True, "actualKeys": ["けい"],
        "mappedReciprocalPairs": 1, "directedLinkTransitions": 2, "changedReusedArticles": 0,
        "ownedHelperStopped": True, "ownedQemuStopped": True, "sharedAdbTouched": False,
        "independentReviewersLaunched": 0, "independentRenderedReviewClosed": False,
        "newNativeOrdinarySenseFallbackSemanticAcceptance": "UNVERIFIED",
        "runtimeChanged": False, "manifestChanged": False, "runtimeAccepted": False, "runtimePublished": False,
        "reviewClosed": [], "published": [], "dedicatedWorktreesClean": True, "parentLockTouched": False,
        "optionalHistoricalHelpersAccessed": False, "actualNewPermissionDenials": [],
        "publishedAdditions": 131, "remainingAdditions": 1097, "lastPublishedCommit": before["lastPublishedCommit"],
        "physicalPhoneAcceptance": "outstanding", "generalReleaseAcceptance": "outstanding",
        "wholeProjectComplete": False, "nextBatchStarted": False,
        "finalRunnerPreflight": load(L / "preflight-813-before-issue.json"),
        "nextAction": next_action, "blocker": None,
        "historicalRootKeysCompared": len(before), "allOriginalHistoricalValuesPreserved": True,
    }
    after = copy.deepcopy(current)
    assert "execution813CoordinatorCheckpoint" not in after
    after["execution813CoordinatorCheckpoint"] = checkpoint
    after["execution813StartingState"]["status"] = "signed-local-native-checkpoint-complete"
    changed = {"checkpoint", "status", "stage", "nextAction", "blocker"}
    for key in changed:
        after[key] = checkpoint[key]
    for key, value in before.items():
        if key not in changed:
            assert after[key] == value, key
    assert after["remainingAdditions"] == 1097 and after["lastPublishedCommit"] == before["lastPublishedCommit"]
    save(L / "checkpoint-813-summary.json", checkpoint)
    temp = C / "progress.json.813-final.tmp"
    save(temp, after)
    assert load(C / "progress.json") == current
    os.replace(temp, C / "progress.json")
    assert load(C / "progress.json") == after
    save(L / "checkpoint-813-final-verification.json",
         {"checkpoint": 813, "savedCommit": head, "signature": "G",
          "allOriginalHistoricalValuesPreserved": True, "originalRootKeysCompared": len(before),
          "dedicatedWorktreesClean": True, "runtimeHashesVerified": 8469,
          "ownerIssueAuthorAndExactBodyVerified": True, "parentLockTouched": False})
    print(json.dumps({"checkpoint": 813, "status": "continue", "savedCommit": head,
                      "historicalKeysPreserved": len(before), "issueUpdate": posted["url"]}, ensure_ascii=True))


if __name__ == "__main__":
    {"prepare": prepare, "finish": finish}[sys.argv[1]]()
