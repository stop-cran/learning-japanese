$ErrorActionPreference = 'Stop'
$control = $PSScriptRoot
$log = "$control\logs\0d2bbc25-ee1d-4c63-9201-dfcc128991a9"
$content = "$control\..\learning-japanese"
$bodyPath = "$control\batch-105-acceptance-817-issue-body.txt"
if ((Test-Path "$log\issue-817-posted.json") -or (Test-Path $bodyPath)) { throw 'Do not duplicate issue update' }
$head = git -C $content rev-parse HEAD
if ($LASTEXITCODE -ne 0) { throw 'HEAD lookup failed' }
& "$control\preflight-817.ps1" -ReceiptName 'preflight-817-before-issue.json' -ExpectedContentHead $head
if ((git -C $content rev-parse 'HEAD^') -ne 'f6de9f217044536460172e68cb07c5b3f8b42f4c') {
    throw 'Wrong acceptance ancestry'
}
$e = [IO.File]::ReadAllText("$content\docs\n1-sources\execution-817.json") | ConvertFrom-Json
if ($e.runtimeChanged -or $e.runtimePublished -or $e.fullBatchAcceptanceComplete -or
    -not $e.runtimeAccepted -or -not $e.localBatchAcceptanceComplete -or
    $e.runtime.runtimeHashesVerified -ne 8469) {
    throw 'Acceptance evidence mismatch'
}
$template = [IO.File]::ReadAllText("$control\batch-105-acceptance-817-issue-template.txt")
[IO.File]::WriteAllText($bodyPath, $template.Replace('{HEAD}', $head), [Text.UTF8Encoding]::new($false))
$priorToken = $env:GH_TOKEN
try {
    $env:GH_TOKEN = (gh auth token --user stop-cran)
    if ($LASTEXITCODE -ne 0 -or -not $env:GH_TOKEN) { throw 'Owner credential unavailable' }
    $login = gh api user --jq .login
    if ($LASTEXITCODE -ne 0 -or $login -cne 'stop-cran') { throw 'Wrong command-scoped identity' }
    $url = gh issue comment 60 --repo stop-cran/learning-japanese --body-file $bodyPath
    if ($LASTEXITCODE -ne 0) { throw 'Issue update failed' }
    $url = $url.Trim()
    @{ url=$url; author=$login; bodySha256=(Get-FileHash $bodyPath).Hash.ToLowerInvariant() } |
        ConvertTo-Json | Set-Content "$log\issue-817-posted.json" -Encoding utf8NoBOM
    if ($url -notmatch '#issuecomment-(\d+)$') { throw 'Unexpected comment URL; preserve receipt' }
    $raw = gh api "repos/stop-cran/learning-japanese/issues/comments/$($Matches[1])"
    if ($LASTEXITCODE -ne 0) { throw 'Comment reread failed' }
    $raw | Set-Content "$log\issue-817-reread.json" -Encoding utf8NoBOM
    $comment = $raw | ConvertFrom-Json
    if ($comment.user.login -cne 'stop-cran' -or
        $comment.body -cne [IO.File]::ReadAllText($bodyPath) -or $comment.html_url -cne $url) {
        throw 'Exact owner/body verification failed'
    }
    Write-Output "Verified owner update: $url"
} finally {
    $env:GH_TOKEN = $priorToken
}
