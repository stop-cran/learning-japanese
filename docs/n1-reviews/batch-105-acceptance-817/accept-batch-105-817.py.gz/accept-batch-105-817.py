"""Persist bounded local batch 105 acceptance without claiming publication."""
import copy
from datetime import datetime, timezone
import gzip
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET

C = Path(__file__).resolve().parent
R, A = C.parent / "learning-japanese", C.parent / "kanji-cards-android"
L = C / "logs" / "0d2bbc25-ee1d-4c63-9201-dfcc128991a9"
S, V = R / "docs" / "n1-sources", R / "docs" / "n1-reviews"
D = V / "batch-105-acceptance-817"
HEAD = "f6de9f217044536460172e68cb07c5b3f8b42f4c"
MAIN = "047c2cef6b6a48b1738f2c5957de01be481c63e1"
TEACHING = "27e252daa091e21c907ff6799818f6b2da74c7aa"
APP = "bf30cdead8515739bc0e671d57a54b9a3109dd46"
MEMBER = "\u52c1"
WORD = "\u96c4\u52c1"
NEXT = (
    "SAME105 signed local acceptance only; normal owner fast-forward publication remains. "
    "Fresh fetch/exact signed heads/wholly clean dedicated worktrees/live parent ancestry/"
    "decoded launcher/current session required. If main advanced, nonrewriting merge, "
    "regenerate/revalidate actual combined tree and independently confirm changed substantive "
    "teaching. Then command-scoped stop-cran normal push, exact remote SHA, terminal green "
    "relevant CI, EVERY immutable GitHub ZIP runtime manifest entry/hash and unchanged "
    "18000-entry/42MiB compressed/80MiB inflated/56MiB retained plus per-file/media/path guards. "
    "Persist signed publication ledgers and terminal evidence, verify owner issue receipt, "
    "update full-history checkpoint and delivery counts only after all publication gates; "
    "yield before106. Inherit unchanged810/811/813/814/815/816 evidence without new blind "
    "initials/native/image loops absent consequential change. Preserve both original reports, "
    "all source/read-depth/range/compaction/rendition/finite-pool/hypothesis/process/permission/"
    "OOM/ANR/routing/phone limits. Compatible Android125/132 required; old clients ignore "
    "curation/guards. QualifiedAPP is approved backport, not latestmain. Parent13320 owns "
    "runner.lock: no child acquire/delete/unlock/readprobe. Approved control/committed sources/"
    "frozen inputs only, not optional historical-session recipes. Preserve/report/yield actual "
    "new denial, signing hang or uncertain ownership; no signing retry/bypass, guard increase, "
    "unreviewed push, concurrent heavy work, author agents,106 or second runner. Published131/"
    "1228,remaining1097,lastpublished047c2cef unchanged until verified publication. "
    "Support words are not N1 vocabulary delivery; physical-phone/general-release/whole-set "
    "acceptance outstanding; project incomplete."
)
sys.path.insert(0, str(R / "tools"))
sys.stdout.reconfigure(encoding="utf-8")


def load(path):
    return json.loads(path.read_bytes())


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def now():
    return datetime.now(timezone.utc).isoformat()


def save(path, value):
    path.write_bytes((json.dumps(value, ensure_ascii=True, indent=2) + "\n").encode())
    assert load(path) == value


def git(*args, repo=R):
    return subprocess.check_output(
        ["git", "--no-pager", "-C", str(repo), *args], encoding="utf-8").strip()


def progress_replace(current, updated, label):
    assert load(C / "progress.json") == current
    temp = C / f"progress.json.817-{label}.tmp"
    assert not temp.exists()
    save(temp, updated)
    os.replace(temp, C / "progress.json")
    assert load(C / "progress.json") == updated


def runtime():
    spec = importlib.util.spec_from_file_location("reconciliation816", C / "reconcile-batch-105-816.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.runtime()


def start():
    assert git("rev-parse", "HEAD") == HEAD and git("rev-parse", "origin/main") == MAIN
    assert git("merge-base", MAIN, HEAD) == MAIN
    for repo in [R, A]:
        assert not git("status", "--porcelain", "--untracked-files=all", repo=repo)
        assert git("log", "-1", "--format=%G?", repo=repo) == "G"
    assert git("rev-parse", "HEAD", repo=A) == APP
    current = load(C / "progress.json")
    assert (current["checkpoint"], current["batch"], current["status"]) == (816, "105", "continue")
    assert current["execution816CoordinatorCheckpoint"]["savedCommit"] == HEAD
    raw = (L / "request.txt").read_bytes()
    text = raw.decode("utf-8-sig")
    embedded = json.loads(text.split(
        "Current execution checkpoint (complete historical state remains at checkpointHistory paths):", 1)[1])
    assert embedded["checkpoint"] == 816
    assert embedded["execution816CoordinatorCheckpoint"]["savedCommit"] == HEAD
    assert not (L / "progress-before-817.json").exists()
    save(L / "progress-before-817.json", current)
    state = {
        "execution": 817, "batch": "105", "startedAt": now(), "startingHead": HEAD,
        "androidHead": APP, "freshOriginMain": MAIN,
        "scope": "SAME105 signed LOCAL acceptance/source-row/inventory/pending-publication ledgers only. No runtime edits, reviewers, HOST/native reruns, publication,106 or second runner.",
        "request": {
            "sha256": sha(raw), "bytes": len(raw), "lines": len(text.splitlines()),
            "completeFileLoadedAndCheckpointParsed": True,
            "limits": "Entire request loaded/decoded/parsed; operative contract, complete approved issue and final816 inspected directly. Historical middle parsed, not freshly semantically re-reviewed. Initial console encoding failure did not alter evidence."
        },
        "runnerPreflight": load(L / "preflight-817.json"),
        "artifactPathPreflight": "Approved committed source packets and control helpers/frozen inputs only; no optional historical-session helper access.",
        "parentLockTouched": False, "actualNewPermissionDenials": [],
        "status": "local-acceptance-in-progress"
    }
    save(L / "starting-state-817.json", state)
    updated = copy.deepcopy(current)
    assert "execution817StartingState" not in updated
    updated["execution817StartingState"] = state
    updated["stage"] = "batch-105-local-signed-acceptance-in-progress"
    updated["nextAction"] = state["scope"]
    allowed = {"stage", "nextAction"}
    assert all(updated[k] == v for k, v in current.items() if k not in allowed)
    progress_replace(current, updated, "start")
    print("SAME105 starting scope persisted; complete historical state preserved.")


def canonical(element):
    return (element.tag, tuple(sorted(element.attrib.items())), (element.text or "").strip(),
            tuple(canonical(child) for child in element))


def audit():
    from audit_n1_batch import runtime_delta
    from audit_n1_pilot import metadata
    from extract_n1_jmdict import extract
    from generate_strokes import convert

    assert git("rev-parse", "HEAD") == HEAD and git("rev-parse", "origin/main") == MAIN
    assert git("merge-base", MAIN, HEAD) == MAIN
    assert not git("status", "--porcelain", "--untracked-files=all")
    current_runtime = runtime()
    previous = load(S / "execution-816.json")
    assert previous["independentRenderedReviewClosed"] and previous["nativeRouteExecutionAccepted"]
    assert previous["runtimeHashesVerified"] == current_runtime["runtimeHashesVerified"] == 8469
    assert previous["manifestSha256"] == current_runtime["manifestSha256"]
    assert previous["pythonTestsPassed"] == 377 and previous["validatorErrors"] == 0
    for row in previous["checks"]:
        packed = (V / "batch-105-reconciliation-816" / row["archive"]).read_bytes()
        assert sha(packed) == row["archiveSha256"]
        assert sha(gzip.decompress(packed)) == row["rawSha256"]
        assert row["exitCode"] == (1 if row["name"] == "batch-audit" else 0)
    for directory in ["batch-105-reconciliation-816", "batch-105-rendered-815"]:
        for row in load(V / directory / "artifact-index.json"):
            raw = (V / directory / row["file"]).read_bytes()
            assert sha(raw) == row["sha256"]
    decision = load(V / "batch-105-reconciliation-816" / "disposition.json")
    assert not decision["acceptanceDecision"]["consequentialUnresolvedTeachingDefects"]
    assert decision["acceptanceDecision"]["independentRenderedReviewClosed"]
    initial = load(V / "batch-105-reconciliation.json")
    assert initial["snapshot"] == TEACHING
    assert not initial["establishedActionableFindings"] and not initial["consequentialUnresolvedTextualClaims"]
    assert not initial["teachingChangesAfterReview"]
    executions = load(V / initial["executionAndReadEvidence"])["initialExecutions"]
    for who, model in [("claude", "claude-opus-5.5"), ("gpt", "gpt-6.1-sol")]:
        row = executions[who]
        assert row["exitCode"] == 0 and row["snapshot"] == TEACHING
        assert row["actualModels"] == [model] and row["serialInternalToolCalls"]
        assert row["fullPacketReturnedExactly"]
        assert sha((V / row["report"]).read_bytes()) == row["reportSha256"]
        packed = (V / row["rawArchive"]).read_bytes()
        assert sha(packed) == row["archiveSha256"]
        assert sha(gzip.decompress(packed)) == row["rawExecutionSha256"]
    assert datetime.fromisoformat(executions["claude"]["completedAt"]) < datetime.fromisoformat(
        executions["gpt"]["startedAt"])
    snapshot = load(R / "docs" / "n1-source-snapshot.json")
    inputs = {}
    for name, row in snapshot["inputs"].items():
        raw = (C / "inputs" / name).read_bytes()
        assert len(raw) == row["bytes"] and sha(raw) == row["sha256"]
        inputs[name] = raw
    families = []
    for selection, packet in [("batch-105-lexical-selection.json", "batch-105-jmdict.xml"),
                              ("batch-105-comparison-selection.json", "batch-105-comparisons.xml")]:
        ids = load(S / selection)["entryIds"]
        raw = extract(inputs["n1-implementation-JMdict_e.gz"],
                      snapshot["inputs"]["n1-implementation-JMdict_e.gz"]["sha256"], ids)
        assert raw == (S / packet).read_bytes()
        families.append({"file": packet, "completeFamilies": len(ids), "sha256": sha(raw)})
    assert [row["completeFamilies"] for row in families] == [9, 28]
    xml = gzip.decompress(inputs["n1-planning-kanjidic2.xml.gz"])
    assert sha(xml) == snapshot["kanjidic2"]["xmlSha256"]
    records = {}
    for name in ["batch-105-kanjidic2.xml", "batch-105-support-characters.xml"]:
        for entry in ET.parse(S / name).getroot().findall("character"):
            char = entry.findtext("literal")
            assert char not in records
            records[char] = canonical(entry)
    actual = {}
    for _, entry in ET.iterparse(io.BytesIO(xml), events=["end"]):
        if entry.tag == "character":
            char = entry.findtext("literal")
            if char in records:
                actual[char] = canonical(entry)
            entry.clear()
    assert records == actual and len(records) == 9
    counts = dict(kanji=0, words=0, strokes=0)
    for name, row in load(S / "baseline-inventory.json")["files"].items():
        kind = name.split("/")[0]
        if kind in {"kanji", "words"}:
            current = metadata(R, name)
            for key, value in row["metadata"].items():
                if key == "quiz_exclusions":
                    assert set(value) <= set(current.get(key, [])), name
                elif name == "kanji/\u5c71.md" and key == "distractors":
                    assert current[key] == list("\u5ddd\u51fa\u6728")
                else:
                    assert current[key] == value, (name, key)
            counts[kind] += 1
        elif kind == "strokes":
            assert sha((R / Path(*name.split("/"))).read_bytes()) == row["sha256"]
            counts[kind] += 1
    assert counts == dict(kanji=985, words=4942, strokes=985)
    before = json.loads(git("show", MAIN + ":manifest.json"))
    manifest = load(R / "manifest.json")
    additions = [f"kanji/{MEMBER}.md", f"strokes/{MEMBER}.json", f"words/{WORD}.md"]
    runtime_delta(before, manifest, additions, [])
    for section, entries in before.items():
        if isinstance(entries, dict):
            assert all(manifest[section][name] == digest for name, digest in entries.items())
    plan = load(S / "batch-105-source-completion-plan.json")
    k = metadata(R, f"kanji/{MEMBER}.md")
    w = metadata(R, f"words/{WORD}.md")
    assert k["onyomi"] == ["\u30b1\u30a4"] and k["kunyomi"] == ["\u3064\u3088.\u3044"]
    assert k["quizOnyomi"] == ["\u30b1\u30a4"] and k["quizKunyomi"] == []
    assert k["quiz_exclusions"] == plan["kanjiTeachingPlan"]["quizExclusions"]
    assert w["quiz_exclusions"] == plan["supportTeachingPlan"]["quizExclusions"]
    assert w["reading"] == "\u3086\u3046\u3051\u3044" and "jlpt" not in w
    mapped = [f"words/{p.name}" for p in (R / "words").glob("*.md")
              if MEMBER in metadata(R, f"words/{p.name}")["kanji"]]
    assert mapped == [f"words/{WORD}.md"]
    assert plan["navigationAndBaselinePlan"]["proposedAllMappedPairs"] == [[MEMBER, mapped[0]]]
    assert not plan["navigationAndBaselinePlan"]["activatedBaselinePairs"]
    assert f"(../words/{WORD}.md)" in (R / "kanji" / f"{MEMBER}.md").read_text(encoding="utf-8")
    assert f"(../kanji/{MEMBER}.md)" in (R / "words" / f"{WORD}.md").read_text(encoding="utf-8")
    strokes = load(R / "strokes" / f"{MEMBER}.json")
    assert strokes == convert(MEMBER, (S / "batch-105-kanjivg.svg").read_text(encoding="utf-8"))
    assert strokes["strokeCount"] == len(strokes["strokes"]) == 9
    named = load(C / "inputs" / "n1-kanji-source-20261102.json")
    assert named == load(S / "community-list-20261102.json") and named[115] == MEMBER
    assert metadata(R, "kanji/\u5996.md")["jlpt"] == 1
    assert all(metadata(R, f"kanji/{c}.md")["jlpt"] == 2 for c in "\u4fdd\u6848\u6d3e\u7b2c\u7b56\u7d50")
    chars = {p.stem for p in (R / "kanji").glob("*.md")}
    current_counts = {
        "kanji": len(chars), "words": len(list((R / "words").glob("*.md"))),
        "n1Labels": sum(metadata(R, f"kanji/{c}.md")["jlpt"] == 1 for c in chars),
        "namedSourceMembersPresent": len(chars & set(named)),
    }
    assert current_counts == dict(kanji=1128, words=5079, n1Labels=137, namedSourceMembersPresent=142)
    for name in ["source-index.json", "baseline-inventory.json"]:
        assert (S / name).read_bytes().replace(b"\r\n", b"\n") == subprocess.check_output(
            ["git", "-C", str(R), "show", MAIN + ":docs/n1-sources/" + name])
    result = {
        "schemaVersion": 1, "execution": 817, "batch": "105", "recordedAt": now(),
        "testedSnapshot": HEAD, "latestMainIntegrated": MAIN, "mainAlreadyAncestor": True,
        "mergeRequired": False, "runtime": current_runtime,
        "frozenInputHashesVerified": len(inputs), "dictionaryPacketsReextractedExactly": families,
        "completeRawCharacterRecordsVerified": len(records),
        "originalBaselineMetadataAndStrokesPreserved": counts,
        "preexistingBaselineExceptions": [
            "Previously reviewed 山 distractors [川,出,木] retained, matching existing806 baseline audit; not changed817. Original quiz exclusions remain subsets, never removed."
        ],
        "baselineRuntimeHashesPreserved": 8466, "exactRuntimeAdditions": additions,
        "sourceRow": 116, "membership": [MEMBER], "fullReadingDispositions": 2,
        "curatedOfferedKeys": ["\u3051\u3044"], "sourceOnlyOfferedKeys": [],
        "allMappedReciprocalPairs": 1, "mappedDirectedLinks": 2, "activatedBaselinePairs": 0,
        "changedReusedArticles": 0, "directKanjiGuardPairs": 4, "directWordGuardPairs": 6,
        "pinnedGeometryReconvertedExactly": True, "currentCounts": current_counts,
        "immutableSourceIndexAndBaselineInventoryPreserved": True,
        "originalInitialExecutionAndReportBytesVerified": True,
        "reconciliation816AndRendered815ArtifactIndexesVerified": True,
        "pythonTestsInherited": 377, "validatorErrorsInherited": 0,
        "nativeHostEvidenceInherited": [811, 813], "newReviewerNativeHostRuns": 0,
        "genericAuditFailurePreserved": previous["genericAuditFailure"],
        "limits": "Fresh mechanical source/baseline/inventory/byte audit; not fresh linguistic, native, reviewer, image or Python-suite execution. Unchanged runtime/tools preserve exact816 test applicability; all original reports and limitations remain unchanged."
    }
    assert not (L / "source-audit-817.json").exists()
    save(L / "source-audit-817.json", result)
    print(json.dumps({"runtimeHashes": 8469, "frozenInputs": len(inputs),
                      "baselinePreserved": counts, "currentCounts": current_counts}, indent=2))


def checks():
    assert git("rev-parse", "HEAD") == HEAD and not git("status", "--porcelain", "--untracked-files=all")
    receipts = []
    for name, args in [
        ("validate", [sys.executable, "-X", "utf8", "-B", "tools\\validate.py"]),
        ("manifest", [sys.executable, "-X", "utf8", "-B", "tools\\build_manifest.py"]),
        ("manifest-diff", ["git", "--no-pager", "diff", "--exit-code", "--", "manifest.json"]),
        ("vocabulary", [sys.executable, "-X", "utf8", "-B", "tools\\grammar_vocabulary.py", "check"]),
        ("budget", [sys.executable, "-X", "utf8", "-B", "tools\\check_content_budget.py"]),
    ]:
        path = L / f"817-{name}.txt"
        started = now()
        with path.open("xb") as stream:
            result = subprocess.run(args, cwd=R, stdout=stream, stderr=subprocess.STDOUT)
        row = dict(name=name, command=args, startedAt=started, completedAt=now(),
                   exitCode=result.returncode, output=str(path), rawSha256=sha(path.read_bytes()))
        receipts.append(row)
        save(L / "checks-817.json", receipts)
        assert result.returncode == 0, name
        print(name + " passed", flush=True)
    assert (L / "817-validate.txt").read_text(encoding="utf-8-sig").rstrip().endswith("0 error(s)")
    assert not git("status", "--porcelain", "--untracked-files=all")
    assert runtime() == load(L / "source-audit-817.json")["runtime"]


def seal():
    assert git("rev-parse", "HEAD") == HEAD and git("rev-parse", "origin/main") == MAIN
    assert git("merge-base", MAIN, HEAD) == MAIN
    assert not git("status", "--porcelain", "--untracked-files=all")
    source_audit = load(L / "source-audit-817.json")
    assert source_audit["runtime"] == runtime()
    previous = load(S / "execution-816.json")
    disposition = load(V / "batch-105-reconciliation-816" / "disposition.json")
    decision = disposition["acceptanceDecision"]
    assert not decision["consequentialUnresolvedTeachingDefects"]
    assert decision["nativeRouteExecutionAccepted"] and decision["independentRenderedReviewClosed"]
    assert not D.exists()
    D.mkdir()
    receipts = []
    for row in load(L / "checks-817.json"):
        assert row["exitCode"] == 0
        raw = Path(row["output"]).read_bytes()
        assert sha(raw) == row["rawSha256"]
        packed = gzip.compress(raw, mtime=0)
        path = D / (row["name"] + ".txt.gz")
        path.write_bytes(packed)
        receipts.append({**row, "archive": str(path.relative_to(R)),
                         "archiveSha256": sha(packed)})
    inherited = {
        "unchangedTeachingSnapshot": TEACHING,
        "textualReview": "docs/n1-reviews/batch-105-reconciliation.json",
        "renderedAndNativeReconciliation": "docs/n1-reviews/batch-105-reconciliation-816/disposition.json",
        "models": ["claude-opus-5.5", "gpt-6.1-sol"],
        "originalSessions": ["6f978e1c-a137-4b6c-879f-c7874d512549",
                             "113f3d1f-f44b-4233-91f2-f7bf720262b2"],
        "pythonTestsPassed": 377, "pythonTestsExecution": 816,
        "hostTests": 5, "hostFailuresErrorsSkips": [0, 0, 0], "hostExecution": 811,
        "nativeExecution": 813, "nativeTerminalCase0Results": 2,
        "productionContentSyncCalls": 1, "supplementalSourceExecution": 814,
        "renderedOriginalFamilyConfirmationExecution": 815,
        "finiteSampleSemanticAcceptance": decision["finiteSampleSemanticAcceptance"],
        "finiteOptionSets": 192, "finiteScope": "Target-relative exact supplied sets and live default only; not all future pools or wrong-choice pair relations.",
        "renderedScope": decision["independentRenderedReviewClosedScope"],
        "drawingScope": "Nine ungraded reference-point touches and intentional recall reveal grade1 on Next; no model/recognition/mastery claim.",
        "readingScope": "Full on[ケイ]/kun[つよ.い],selected[ケイ]/[],soleけい displayedケイ,good done1of1; legacyつよい remains reference display.",
        "sourceOnlyDisposition": "勁い search-only spelling; recognition only, ordinary強い guidance is not an allocation example.",
        "lowConfidenceHypotheses": "Claude 活気/もりもり future-pool notes partially resolved/nondefects; GPT no actionable hypothesis. Original810 withdrawn history and original reports unchanged; no forced agreement or new exclusions.",
        "newReviewerNativeHostRuns": 0, "newImageInspection": False,
        "legacyAuditFailure": previous["genericAuditFailure"],
        "limits": disposition["limits"]
    }
    remaining = [
        "Fresh main check before publication; nonrewriting merge/regenerated manifest/revalidation and changed-teaching confirmation only if actual combined tree changes.",
        "Normal signed owner-scoped fast-forward; exact remote SHA and terminal green relevant CI.",
        "Every exact immutable GitHub ZIP runtime manifest entry/hash, manifest equality,18000entries/42MiBcompressed/80MiBinflated/56MiBretained and per-file/media/path guards.",
        "Signed publication ledger/terminal evidence, verified stop-cran issue receipt and full-history checkpoint before106; delivery counts change only after these gates."
    ]
    record = {
        "schemaVersion": 1, "execution": 817, "batch": "105", "membership": [MEMBER],
        "status": "review-closed-combined-main-accepted-publication-pending", "recordedAt": now(),
        "baseCommit": MAIN, "authoredSnapshot": TEACHING, "reviewedSnapshot": TEACHING,
        "combinedTestedSnapshot": HEAD, "latestMainIntegrated": MAIN,
        "mainAlreadyAncestor": True, "mergeRequired": False,
        "preexistingBaselineExceptions": [
            "Previously reviewed 山 distractors [川,出,木] retained, matching existing806 audit; not changed817. Original exclusions preserved as subsets."
        ],
        "qualifiedAndroidHead": APP, "sourceAudit": source_audit,
        "sourceRowDisposition": {
            "sourceRow": 116, "kanji": MEMBER,
            "status": "review-closed-runtime-accepted-publication-pending",
            "article": f"kanji/{MEMBER}.md", "strokeFile": f"strokes/{MEMBER}.json",
            "supportArticle": f"words/{WORD}.md", "supportReading": "\u3086\u3046\u3051\u3044",
            "frozenIndexUnchanged": True, "published": False
        },
        "checks": receipts, "inheritedAcceptance": inherited, "runtime": runtime(),
        "pythonTestsPassed": 377, "pythonTestsInheritedFrom": 816, "validatorErrors": 0,
        "manifestRegenerated": True, "manifestChanged": False,
        "runtimeChangedThisExecution": False, "runtimeAccepted": True,
        "runtimeAcceptanceScope": "Bounded compatible-client owner testing: both new articles/192 exact target-relative option sets/live default/inherited native routes/delivered900x2000 rendering. Not unrestricted quiz safety or original-pixel/equal-comprehension/retention/fallback-face certification.",
        "localBatchAcceptanceComplete": True, "fullBatchAcceptanceComplete": False,
        "fullBatchAcceptanceDefinition": "Local content/runtime gates closed; full batch delivery additionally requires remaining publication gates.",
        "reviewClosed": [MEMBER], "published": [], "runtimePublished": False,
        "publishedAdditions": 131, "remainingAdditions": 1097, "lastPublishedCommit": MAIN,
        "physicalPhoneAcceptance": "outstanding", "generalReleaseAcceptance": "outstanding",
        "wholeSetAcceptance": "outstanding", "wholeProjectComplete": False, "nextBatchStarted": False,
        "historicalLimitations": "Original pending flags remain historical;817 local gate discharge does not rewrite previous receipts. Frozen source index/baseline inventory preserved; actual row disposition is this acceptance plus batch-progress.",
        "remainingPublicationGates": remaining,
        "parentLockTouched": False, "optionalHistoricalHelpersAccessed": False,
        "actualNewPermissionDenials": [], "nextAction": NEXT
    }
    acceptance = S / "batch-105-acceptance-817.json"
    assert not acceptance.exists()
    save(acceptance, record)
    ledger_path = S / "batch-105-progress.json"
    ledger = load(ledger_path)
    assert ledger["reviewClosed"] == ledger["published"] == []
    assert ledger["independentRenderedReviewClosed"] and not ledger["runtimeAccepted"]
    ledger["preAcceptance817State"] = copy.deepcopy(ledger)
    ledger.update(
        status=record["status"], reviewClosed=[MEMBER], runtimeAccepted=True,
        localBatchAcceptanceComplete=True, fullBatchAcceptanceComplete=False,
        fullBatchAcceptanceDefinition=record["fullBatchAcceptanceDefinition"],
        acceptanceRecord=acceptance.name, pendingGates=remaining, nextAction=NEXT,
        sourceRowDisposition=record["sourceRowDisposition"],
        limits=ledger["limits"] + [
            "Bounded817 local content/runtime acceptance closes reviewClosed for row116; publication/full delivery pending. Original816 pending flags preserved in preAcceptance817State.",
            "377Python cases inherited from unchanged816 tree/tools; fresh817 source/baseline/runtime audit, validator, manifest/vocabulary/budget. No new native/reviewer/image run or new phone claim."
        ])
    save(ledger_path, ledger)
    publication = S / "batch-105-publication.json"
    assert not publication.exists()
    save(publication, {
        "schemaVersion": 1, "execution": 817, "batch": "105", "membership": [MEMBER],
        "status": "review-closed-runtime-accepted-publication-pending", "recordedAt": now(),
        "baseCommit": MAIN, "authoredSnapshot": TEACHING, "reviewedSnapshot": TEACHING,
        "combinedTestedSnapshot": HEAD, "latestMainIntegrated": MAIN,
        "acceptanceRecord": acceptance.name, "acceptedCommit": None, "publishedCommit": None,
        "remoteVerified": False, "ci": None, "archive": None,
        "runtime": runtime(), "runtimeAccepted": True, "runtimePublished": False,
        "reviewClosed": [MEMBER], "published": [], "counts": source_audit["currentCounts"],
        "projectPublishedAdditions": 131, "remainingAdditions": 1097,
        "supportScope": "One necessary雄勁 article, not delivered N1 vocabulary.",
        "remainingPublicationGates": remaining, "physicalPhoneAcceptance": "outstanding",
        "generalReleaseAcceptance": "outstanding", "wholeSetAcceptance": "outstanding",
        "wholeProjectComplete": False, "nextBatchStarted": False,
        "limits": "Pending ledger only. No SHA, CI, ZIP or delivery receipt invented. Existing complete source/review/native/acceptance limits retained by reference.",
        "nextAction": NEXT
    })
    save(S / "execution-817.json", {
        "schemaVersion": 1, "execution": 817, "batch": "105", "recordedAt": now(),
        "startingState": load(L / "starting-state-817.json"), "acceptanceRecord": acceptance.name,
        "pendingPublicationRecord": publication.name, "status": record["status"],
        "sourceAudit": source_audit, "checks": receipts, "inheritedAcceptance": inherited,
        "runtime": runtime(), "runtimeAccepted": True, "runtimeChanged": False,
        "manifestChanged": False, "runtimePublished": False,
        "localBatchAcceptanceComplete": True, "fullBatchAcceptanceComplete": False,
        "reviewClosed": [MEMBER], "published": [], "newReviewerNativeHostRuns": 0,
        "newImageInspection": False, "publishedAdditions": 131, "remainingAdditions": 1097,
        "lastPublishedCommit": MAIN, "physicalPhoneAcceptance": "outstanding",
        "generalReleaseAcceptance": "outstanding", "wholeSetAcceptance": "outstanding",
        "wholeProjectComplete": False, "nextBatchStarted": False,
        "parentLockTouched": False, "optionalHistoricalHelpersAccessed": False,
        "actualNewPermissionDenials": [], "limits": disposition["limits"], "nextAction": NEXT
    })
    for path in [Path(__file__), C / "preflight-817.ps1", C / "post-acceptance-817.ps1",
                 C / "batch-105-acceptance-817-issue-template.txt",
                 L / "starting-state-817.json", L / "source-audit-817.json", L / "preflight-817.json"]:
        (D / (path.name + ".gz")).write_bytes(gzip.compress(path.read_bytes(), mtime=0))
    save(D / "artifact-index.json", [
        {"file": p.name, "bytes": p.stat().st_size, "sha256": sha(p.read_bytes())}
        for p in sorted(D.iterdir()) if p.is_file()
    ])
    assert runtime() == source_audit["runtime"]
    print("Local acceptance/source-row/inventory/pending-publication ledgers sealed; no publication or delivery credit.")


def finish():
    before = load(L / "progress-before-817.json")
    current = load(C / "progress.json")
    allowed = {"checkpoint", "status", "stage", "nextAction", "blocker"}
    assert all(current[k] == value for k, value in before.items() if k not in allowed)
    assert (current["checkpoint"], current["status"], current["batch"]) == (816, "continue", "105")
    head = git("rev-parse", "HEAD")
    assert git("rev-parse", "HEAD^") == HEAD and git("log", "-1", "--format=%G?") == "G"
    assert git("rev-parse", "origin/main") == MAIN and git("merge-base", MAIN, head) == MAIN
    for repo in [R, A]:
        assert not git("status", "--porcelain", "--untracked-files=all", repo=repo)
    assert git("rev-parse", "HEAD", repo=A) == APP and git("log", "-1", "--format=%G?", repo=A) == "G"
    paths = git("diff", "--name-only", HEAD, head).splitlines()
    permitted = {
        "docs/n1-sources/batch-105-progress.json",
        "docs/n1-sources/batch-105-acceptance-817.json",
        "docs/n1-sources/batch-105-publication.json",
        "docs/n1-sources/execution-817.json"
    }
    assert paths and all(p in permitted or p.startswith("docs/n1-reviews/batch-105-acceptance-817/")
                         for p in paths)
    for row in load(D / "artifact-index.json"):
        path = str((D / row["file"]).relative_to(R)).replace("\\", "/")
        raw = subprocess.check_output(["git", "-C", str(R), "show", head + ":" + path])
        assert sha(raw) == row["sha256"]
    posted, reread = load(L / "issue-817-posted.json"), load(L / "issue-817-reread.json")
    body = (C / "batch-105-acceptance-817-issue-body.txt").read_bytes()
    assert posted["author"] == reread["user"]["login"] == "stop-cran"
    assert sha(body) == posted["bodySha256"] and body.decode() == reread["body"]
    assert posted["url"] == reread["html_url"]
    role = load(L / "preflight-817-before-issue.json")
    assert role["contentHead"] == head and not role["lockTouched"]
    accepted = load(S / "batch-105-acceptance-817.json")
    assert accepted["runtimeAccepted"] and accepted["reviewClosed"] == [MEMBER]
    assert not accepted["runtimePublished"] and not accepted["fullBatchAcceptanceComplete"]
    verified_runtime = runtime()
    checkpoint = {
        "schemaVersion": 1, "execution": 817, "checkpoint": 817, "batch": "105",
        "status": "continue", "stage": "batch-105-signed-local-acceptance-awaiting-publication",
        "savedCommit": head, "signedAcceptanceCommit": head, "signature": "G",
        "qualifiedAndroidHead": APP, "recordedAt": now(),
        "evidence": "docs/n1-sources/execution-817.json",
        "acceptanceRecord": "docs/n1-sources/batch-105-acceptance-817.json",
        "pendingPublicationRecord": "docs/n1-sources/batch-105-publication.json",
        "issueUpdate": posted["url"], "ownerIssueAuthorAndExactBodyVerified": True,
        "localBatchAcceptanceComplete": True, "fullBatchAcceptanceComplete": False,
        "runtimeAccepted": True, "runtimePublished": False, "runtimeChanged": False,
        "reviewClosed": [MEMBER], "published": [], "manifestChanged": False,
        "newReviewerNativeHostRuns": 0, "newImageInspection": False,
        "pythonTestsInherited": 377, "validatorErrors": 0,
        "sourceAudit": "docs/n1-reviews/batch-105-acceptance-817/source-audit-817.json.gz",
        "genericLegacyAuditFailurePreserved": True,
        "dedicatedWorktreesClean": True, "parentLockTouched": False,
        "optionalHistoricalHelpersAccessed": False, "actualNewPermissionDenials": [],
        "publishedAdditions": 131, "remainingAdditions": 1097, "lastPublishedCommit": MAIN,
        "physicalPhoneAcceptance": "outstanding", "generalReleaseAcceptance": "outstanding",
        "wholeSetAcceptance": "outstanding", "wholeProjectComplete": False, "nextBatchStarted": False,
        "finalRunnerPreflight": role, "nextAction": f"SAME105 checkpoint817 signed LOCAL acceptance HEAD{head}, qualifiedAndroid{APP}. "
            "Read docs/n1-sources/execution-817.json and batch-105-acceptance-817.json; pending publication ledger has intentionally null accepted/published SHA until derived from this signed checkpoint. "
            + NEXT,
        "blocker": None, "historicalRootKeysCompared": len(before),
        "allOriginalHistoricalValuesPreserved": True, "runtime": verified_runtime
    }
    updated = copy.deepcopy(current)
    updated["execution817StartingState"]["status"] = "signed-local-bounded-acceptance-checkpoint-complete"
    updated["historicalExecution816Before817Acceptance"] = {
        key: copy.deepcopy(before[key]) for key in allowed}
    updated["execution817CoordinatorCheckpoint"] = checkpoint
    for key in allowed:
        updated[key] = checkpoint[key]
    assert all(updated[k] == value for k, value in before.items() if k not in allowed)
    progress_replace(current, updated, "finish")
    save(L / "checkpoint-817-verification.json", checkpoint)
    print(json.dumps({key: checkpoint[key] for key in [
        "checkpoint", "status", "savedCommit", "issueUpdate",
        "historicalRootKeysCompared", "allOriginalHistoricalValuesPreserved"]}, indent=2))


if __name__ == "__main__":
    {"start": start, "audit": audit, "checks": checks, "seal": seal, "finish": finish}[sys.argv[1]]()
