package io.github.stopcran.kanji.ui

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.os.Build
import androidx.activity.ComponentActivity
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.junit4.createEmptyComposeRule
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.res.ResourcesCompat
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.room.withTransaction
import androidx.test.core.app.ActivityScenario
import androidx.test.platform.app.InstrumentationRegistry
import io.github.stopcran.kanji.KanjiApp
import io.github.stopcran.kanji.MainActivity
import io.github.stopcran.kanji.R
import io.github.stopcran.kanji.core.content.ContentParser
import io.github.stopcran.kanji.core.content.RepoSource
import io.github.stopcran.kanji.core.quiz.QuizBuilder
import io.github.stopcran.kanji.core.reading.ReadingKind
import io.github.stopcran.kanji.core.srs.KanjiFont
import io.github.stopcran.kanji.core.srs.StudyMode
import io.github.stopcran.kanji.core.words.WordDirection
import io.github.stopcran.kanji.core.words.WordQuizBuilder
import io.github.stopcran.kanji.data.*
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.File
import java.security.MessageDigest
import java.util.UUID


private fun disposable101() {
    assertEquals("true", InstrumentationRegistry.getArguments().getString("n1Disposable"))
    assertTrue(Build.HARDWARE in setOf("ranchu", "goldfish"))
}

class N1Batch101Glyph767Test {
    @get:Rule val rule = createAndroidComposeRule<ComponentActivity>()

    @Test fun meritLookalikesAndAllNineteenHanAcrossFourProductionFamilies() {
        disposable101()
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val fonts = listOf(KanjiFont.Gothic, KanjiFont.Mincho, KanjiFont.Textbook, KanjiFont.Brush)
        val pages = listOf("働 凱 刀 力 功 加 効 勝 工 幼", "徳 成 技 敬 果 栄 業 績 達", "功 工 力 加 幼 刀 功績 成功 功徳")
        val page = mutableStateOf(0)
        rule.setContent {
            MaterialTheme {
                Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Batch 101: merit / look-alikes / all scoped Han")
                    Text("Panel ${page.value + 1} / ${pages.size}")
                    fonts.forEach { font ->
                        Text(font.name)
                        Text(pages[page.value], fontFamily = font.family(), fontSize = 18.sp, lineHeight = 26.sp)
                    }
                    Text("Inspect all 19 scoped Han; focus 功/加/幼 and 力/刀, 功績/成功. Cmap presence is not readability.", fontSize = 16.sp)
                }
            }
        }
        val typefaces = listOf(Typeface.DEFAULT,
            requireNotNull(ResourcesCompat.getFont(context, R.font.kanji_mincho)),
            requireNotNull(ResourcesCompat.getFont(context, R.font.kanji_textbook)),
            requireNotNull(ResourcesCompat.getFont(context, R.font.kanji_brush)))
        val rows = JSONArray()
        for ((index, typeface) in typefaces.withIndex()) {
            val hashes = mutableSetOf<String>()
            for (char in listOf("働", "凱", "刀", "力", "功", "加", "効", "勝", "工", "幼", "徳", "成", "技", "敬", "果", "栄", "業", "績", "達")) {
                val paint = Paint(Paint.ANTI_ALIAS_FLAG).also {
                    it.typeface = typeface
                    it.textSize = 96f
                    it.textLocale = java.util.Locale.JAPAN
                }
                assertTrue("$char ${fonts[index]}", paint.hasGlyph(char))
                val image = Bitmap.createBitmap(if (char.length > 1) 256 else 128, 128, Bitmap.Config.ARGB_8888)
                Canvas(image).drawText(char, 8f, 104f, paint)
                val pixels = IntArray(image.width * image.height)
                image.getPixels(pixels, 0, image.width, 0, 0, image.width, image.height)
                assertTrue(pixels.any { it != 0 })
                val bytes = java.nio.ByteBuffer.allocate(pixels.size * 4)
                    .also { it.asIntBuffer().put(pixels) }.array()
                val hash = MessageDigest.getInstance("SHA-256").digest(bytes)
                    .joinToString("") { "%02x".format(it) }
                assertTrue("Indistinguishable raster ${fonts[index]}", hashes.add(hash))
                rows.put(JSONObject().put("character", char).put("font", fonts[index].name)
                    .put("hasGlyph", true).put("nativePaintRasterSha256", hash))
                image.recycle()
            }
            for (word in listOf("功績", "成功")) {
                val paint = Paint(Paint.ANTI_ALIAS_FLAG).also {
                    it.typeface = typeface
                    it.textSize = 96f
                    it.textLocale = java.util.Locale.JAPAN
                }
                // hasGlyph tests multi-character ligatures, not ordinary word coverage.
                val image = Bitmap.createBitmap(kotlin.math.ceil(paint.measureText(word)).toInt() + 16, 128, Bitmap.Config.ARGB_8888)
                Canvas(image).drawText(word, 8f, 104f, paint)
                val pixels = IntArray(image.width * image.height)
                image.getPixels(pixels, 0, image.width, 0, 0, image.width, image.height)
                for (position in word.indices) {
                    val left = (8f + paint.measureText(word, 0, position)).toInt()
                    val right = kotlin.math.ceil(8f + paint.measureText(word, 0, position + 1)).toInt()
                    assertTrue("Word raster bounds $word ${fonts[index]}", left >= 0 && right <= image.width && left < right)
                    assertTrue("Blank word character ${word[position]} ${fonts[index]}",
                        (0 until image.height).any { y -> (left until right).any { x -> pixels[y * image.width + x] != 0 } })
                }
                val bytes = java.nio.ByteBuffer.allocate(pixels.size * 4)
                    .also { it.asIntBuffer().put(pixels) }.array()
                val hash = MessageDigest.getInstance("SHA-256").digest(bytes)
                    .joinToString("") { "%02x".format(it) }
                rows.put(JSONObject().put("word", word).put("font", fonts[index].name)
                    .put("renderedCharactersNonblank", word.length).put("nativePaintRasterSha256", hash))
                image.recycle()
            }
        }
        assertEquals(84, rows.length())
        for (index in pages.indices) {
            rule.runOnIdle { page.value = index }
            rule.waitForIdle()
            rule.onAllNodesWithText(pages[index]).assertCountEquals(4)
            for (fontIndex in fonts.indices) rule.onAllNodesWithText(pages[index])[fontIndex].assertIsDisplayed()
            File(context.getExternalFilesDir(null), "n1-101-font-panel-${index + 1}.png").outputStream().use {
                assertTrue(rule.onRoot().captureToImage().asAndroidBitmap().compress(Bitmap.CompressFormat.PNG, 100, it))
            }
        }
        File(context.getExternalFilesDir(null), "n1-101-font-raster.json").writeText(JSONObject()
            .put("fingerprint", Build.FINGERPRINT).put("sdk", Build.VERSION.SDK_INT)
            .put("fontScale", context.resources.configuration.fontScale).put("rows", rows)
            .put("individualGlyphProbes", 76).put("wholeWordRasterProbes", 8).put("panels", 3)
            .put("limits", "19 actual scoped Han across four production families, three bounded Compose panels and eight whole-word rasters. All are present in bundled cmaps; that is not rendering acceptance. Hashes are not readability or fallback-face evidence. Actual PNG inspection required; emulator not phone.")
            .toString(2))
    }
}


class N1Batch101Article767Test {
    @get:Rule val rule = createEmptyComposeRule()
    private lateinit var app: KanjiApp
    private lateinit var scenario: ActivityScenario<MainActivity>

    @Test fun fullSingleImportMeritDirectGuardsOneCuratedKeyFourPairsFiveStrokesOfflineAndBack() {
        disposable101()
        val instrumentation = InstrumentationRegistry.getInstrumentation()
        app = instrumentation.targetContext.applicationContext as KanjiApp
        val source = RepoSource("acceptance-fixture", "n1-101-${UUID.randomUUID()}", "main")
        val head = "93540981895e8586c9227098214d04aa56a767c3"
        assertTrue(app.settings.setSource("https://github.com/${source.id}", source.branch))
        var archiveRequests = 0
        val http = ContentHttp { url, _, _, _ ->
            val input = when (url) {
                "https://api.github.com/repos/${source.id}/commits/main" -> ByteArrayInputStream(head.toByteArray())
                source.commitZipUrl(head) -> {
                    archiveRequests++
                    instrumentation.context.assets.open("n1-batch-101-93540981-envelope.zip")
                }
                else -> error("Unexpected fixture request: $url")
            }
            object : ContentResponse {
                override val code = 200
                override val body = input
                override fun header(name: String): String? = null
                override fun close() = input.close()
            }
        }
        val result = runBlocking { ContentSync(app.db, app.settings.sync, http).sync(source, force = true) }
        assertTrue(result.toString(), result is SyncResult.Updated)
        val updated = result as SyncResult.Updated
        assertEquals(1, archiveRequests)
        assertEquals(1124, updated.kanji)
        assertEquals(5073, updated.words)
        assertTrue(updated.problems.toString(), updated.problems.isEmpty())
        val meta = requireNotNull(runBlocking { app.db.content().meta(source.id) })
        assertEquals("6e9b74967e21fc3c", meta.contentVersion)
        assertEquals(0, meta.problems)
        assertNull(meta.grammarProblem)
        assertNull(meta.listeningProblem)
        assertNull(meta.grammarCurriculumProblem)
        assertEquals(1, ContentParser.KANJI_READING_PARSER_EPOCH)
        assertEquals(ContentParser.KANJI_READING_PARSER_EPOCH, meta.kanjiReadingParserEpoch)
        assertEquals(1, ContentParser.KANJI_MEANING_PARSER_EPOCH)
        assertEquals(ContentParser.KANJI_MEANING_PARSER_EPOCH, meta.kanjiMeaningParserEpoch)
        val all = runBlocking { app.db.content().kanjiLite(source.id) }
        val n1 = all.filter { it.jlpt == 1 }
        assertEquals(133, n1.size)
        assertEquals(n1.map { it.kanji }.toSet(),
            all.filter { "jlpt-n1" in it.tags.splitSep() }.map { it.kanji }.toSet())
        val target = n1.single { it.kanji == "功" }
        val guards = listOf("績", "効", "果", "成", "達", "勝", "凱", "栄", "敬", "働", "業", "技", "工")
        assertEquals(guards, target.quizExclusions.splitSep())
        val observed = runBlocking { app.db.content().observeKanjiLite(source.id).first() }.single { it.kanji == "功" }
        assertEquals(guards, observed.toQuizCard().quizExclusions)
        val full = requireNotNull(runBlocking { app.db.content().kanjiCard(source.id, "功") })
        assertEquals(guards, full.quizExclusions.splitSep())
        assertEquals(guards, full.toQuizCard().quizExclusions)
        assertEquals(guards, runBlocking { app.db.content().kanji(source.id) }
            .single { it.kanji == "功" }.toQuizCard().quizExclusions)
        assertEquals(listOf("加", "幼", "刀"), target.distractors.splitSep())
        assertEquals(listOf("コウ", "ク"), target.onyomi.splitSep())
        assertEquals(listOf("いさお"), target.kunyomi.splitSep())
        assertEquals(listOf("コウ"), target.quizOnyomi?.splitSep())
        assertEquals(emptyList<String>(), target.quizKunyomi?.splitSep())
        assertEquals(listOf("こう"), target.toReadingCard().quizKeys(ReadingKind.On))
        assertEquals(emptyList<String>(), target.toReadingCard().quizKeys(ReadingKind.Kun))
        val expectedMeanings = mapOf("功" to "merit; achievement", "加" to "add",
            "幼" to "early childhood; immature", "刀" to "sword; blade")
        val curatedIds = listOf("加", "幼", "刀")
        assertEquals(mapOf("加" to 3, "幼" to 2, "刀" to 1),
            all.filter { it.kanji in curatedIds }.associate { it.kanji to it.jlpt })
        assertEquals(setOf("刀"), n1.filter { it.kanji in curatedIds }.map { it.kanji }.toSet())
        val custom = all.filter { it.kanji in expectedMeanings }
        val randomSubset = listOf(target) +
            n1.filter { it.kanji != "功" }.shuffled(kotlin.random.Random(767)).take(15)
        val choices = JSONArray()
        for ((poolName, pool) in listOf("N1" to n1, "All" to all,
            "boundedCustom" to custom, "randomN1Subset" to randomSubset)) {
            val cards = pool.map { it.toQuizCard() }
            val quizTarget = cards.single { it.kanji == "功" }
            val available = curatedIds.filter { id -> cards.any { it.kanji == id } }
            repeat(16) { seed ->
                val options = QuizBuilder.options(quizTarget, cards, kotlin.random.Random(seed))
                assertEquals(4, options.size)
                assertEquals(4, options.map { it.title }.toSet().size)
                assertEquals(1, options.count { it.kanji == "功" })
                assertTrue(options.none { it.kanji in guards })
                assertTrue(available.all { id -> options.any { it.kanji == id } })
                assertTrue(options.all { o -> pool.any { it.kanji == o.kanji && it.title == o.title } })
                if (available.size == 3) assertEquals(expectedMeanings, options.associate { it.kanji to it.title })
                choices.put(JSONObject().put("pool", poolName).put("seed", seed)
                    .put("poolMembershipInOrder", JSONArray(pool.map { it.kanji }))
                    .put("options", JSONArray().also { rows ->
                        options.forEach { rows.put(JSONObject().put("kanji", it.kanji).put("title", it.title)) }
                    }))
            }
        }
        assertEquals(64, choices.length())
        val allCards = all.map { it.toQuizCard() }
        val guardChecks = JSONArray()
        for (excludedId in guards) {
            val pair = allCards.filter { it.kanji in setOf("功", excludedId) }
            assertEquals(2, pair.size)
            for (quizTarget in pair) {
                val excluded = pair.single { it.kanji != quizTarget.kanji }
                repeat(16) { seed ->
                    val sampled = pair + allCards.filter { it.kanji !in setOf("功", excludedId) }
                        .shuffled(kotlin.random.Random(767 + seed)).take(seed)
                    for ((poolName, pool) in listOf(
                        "N1" to n1.map { it.toQuizCard() }, "All" to allCards,
                        "boundedCustom" to (pair + allCards.filter { it.kanji in curatedIds }),
                        "randomN1Subset767" to (pair + randomSubset.map { it.toQuizCard() }
                            .filter { it.kanji !in setOf("功", excludedId) }),
                        "sampledFiltered" to sampled, "pairOnly" to pair,
                        "targetOutsidePool" to sampled.filter { it.kanji != quizTarget.kanji },
                    )) {
                        val options = QuizBuilder.options(quizTarget, pool, kotlin.random.Random(seed))
                        assertEquals(1, options.count { it.kanji == quizTarget.kanji })
                        assertFalse("Direct guard leaked $excludedId $poolName", options.any { it.kanji == excluded.kanji })
                        assertTrue(options.size in 1..4)
                        assertEquals(options.size, options.map { it.title }.toSet().size)
                        assertTrue(options.all { it.kanji == quizTarget.kanji || pool.any { p -> p.kanji == it.kanji } })
                        if (poolName == "pairOnly") assertEquals(1, options.size)
                        guardChecks.put(JSONObject().put("target", quizTarget.kanji).put("excluded", excluded.kanji)
                            .put("pool", poolName).put("seed", seed)
                            .put("poolMembershipInOrder", JSONArray(pool.map { it.kanji }))
                            .put("options", JSONArray(options.map { it.kanji })))
                    }
                }
            }
        }
        assertEquals(2912, guardChecks.length())
        val nontransitiveChecks = JSONArray()
        for (left in guards) for (right in guards.filter { it != left }) repeat(16) { seed ->
            val pair = allCards.filter { it.kanji in setOf(left, right) }
            val leftCard = pair.single { it.kanji == left }
            val rightCard = pair.single { it.kanji == right }
            assertFalse(right in leftCard.quizExclusions || left in rightCard.quizExclusions)
            val options = QuizBuilder.options(leftCard, pair, kotlin.random.Random(seed))
            assertEquals(setOf(left, right), options.map { it.kanji }.toSet())
            nontransitiveChecks.put(JSONObject().put("target", left).put("neighbor", right).put("seed", seed)
                .put("options", JSONArray(options.map { it.kanji })))
        }
        assertEquals(2496, nontransitiveChecks.length())
        val words = runBlocking { app.db.content().wordsLite(source.id) }.map { it.toCard() }
        val preserved = mapOf(
            "功績" to listOf("成功", "貢献", "成績", "結果", "活躍", "寄付", "働き"),
            "成功" to emptyList())
        assertEquals("こうせき", words.single { it.word == "功績" }.reading)
        assertEquals(2, words.single { it.word == "功績" }.jlpt)
        assertEquals("せいこう", words.single { it.word == "成功" }.reading)
        assertEquals(3, words.single { it.word == "成功" }.jlpt)
        val wordChecks = JSONArray()
        for ((id, excludedIds) in preserved) {
            val left = words.single { it.word == id }
            assertEquals(excludedIds, left.quizExclusions)
            for (excludedId in excludedIds) {
                val right = words.single { it.word == excludedId }
                for ((wordTarget, excluded) in listOf(left to right, right to left)) {
                    val pool = listOf(wordTarget, excluded) + words.filter {
                        it.word !in setOf(wordTarget.word, excluded.word) && it.title !in setOf(wordTarget.title, excluded.title) &&
                            it.word !in wordTarget.quizExclusions && wordTarget.word !in it.quizExclusions
                    }.take(12)
                    for ((poolName, selected) in listOf("All" to words, "boundedCustom" to pool))
                        for (direction in listOf(WordDirection.JpToEn, WordDirection.EnToJp)) repeat(16) { seed ->
                            val options = WordQuizBuilder.options(wordTarget, selected, direction, kotlin.random.Random(seed))
                            assertEquals(4, options.size)
                            assertEquals(1, options.count { it.word == wordTarget.word })
                            assertFalse(options.any { it.word == excluded.word })
                            wordChecks.put(JSONObject().put("target", wordTarget.word).put("excluded", excluded.word)
                                .put("pool", poolName).put("direction", direction.name).put("seed", seed)
                                .put("options", JSONArray().also { rows ->
                                    options.forEach { rows.put(JSONObject().put("word", it.word).put("label", it.label)) }
                                }))
                        }
                }
            }
        }
        assertEquals(896, wordChecks.length())
        val now = System.currentTimeMillis()
        app.settings.sync.lastCheckMs = now
        app.settings.setStartingGuideVisible(false)
        app.settings.setDailyNewCards(50)
        app.settings.setWeekPlan("FFFFFFF")
        app.settings.setTraceNew(true)
        app.settings.setVaryFonts(true)
        app.settings.setStack("jlpt-n5")
        runBlocking {
            app.db.withTransaction {
                n1.forEach { card ->
                    app.db.reviews().putState(ReviewStateEntity(
                        source.id, "jlpt-n1", card.kanji, StudyMode.Quiz.name, "Review", 30.0, 5.0,
                        if (card.kanji == "功") now - 60_000 else now + 30L * 86_400_000,
                        now - 2L * 86_400_000, 3, 0,
                    ))
                    for (kind in ReadingKind.entries) for (key in card.toReadingCard().quizKeys(kind))
                        app.db.reviews().putState(ReviewStateEntity(
                            source.id, "jlpt-n1", card.kanji, kind.mode.name, "Review", 30.0, 5.0,
                            if (card.kanji == "功") now - 60_000 else now + 30L * 86_400_000,
                            now - 2L * 86_400_000, 3, 0, reading = key,
                        ))
                }
                for (days in 1..2) app.db.reviews().putLog(ReviewLogEntity(
                    0, source.id, "jlpt-n1", "功", StudyMode.Quiz.name, 3, now - days * 86_400_000L,
                ))
            }
        }
        val connectivity = app.getSystemService(ConnectivityManager::class.java)
        assertNull("Disable owned emulator Wi-Fi/data before offline acceptance", connectivity.activeNetwork)
        val evidence = JSONObject().put("contentSnapshot", head).put("contentVersion", meta.contentVersion)
            .put("archiveRequests", archiveRequests).put("importedKanji", updated.kanji).put("importedWords", updated.words)
            .put("problems", updated.problems.size).put("n1Cards", n1.size)
            .put("acceptedReadingParserEpoch", meta.kanjiReadingParserEpoch)
            .put("acceptedMeaningParserEpoch", meta.kanjiMeaningParserEpoch)
            .put("productionBuilderN1AndAllExactChoices", choices).put("kanjiDirectGuardChecks", guardChecks)
            .put("nontransitiveNeighborChecks", nontransitiveChecks).put("preservedWordGuardChecks", wordChecks)
            .put("fullOnyomi", JSONArray(target.onyomi.splitSep())).put("fullKunyomi", JSONArray(target.kunyomi.splitSep()))
            .put("quizOnKeys", JSONArray(target.toReadingCard().quizKeys(ReadingKind.On)))
            .put("quizKunKeys", JSONArray(target.toReadingCard().quizKeys(ReadingKind.Kun)))
            .put("kanjiQuizExclusions", JSONArray(guards))
            .put("fingerprint", Build.FINGERPRINT).put("sdk", Build.VERSION.SDK_INT)
            .put("transport", "Exact full git archive through production ContentSync ONCE; synthetic source/HEAD")
            .put("fixture", "Other N1 meanings/readings postponed; only功 meaning andこう due. Two historical good meaning logs unlock drawing. No drawing state seeded. Disposable source, not owner progress.")
            .put("limits", "Sampled pools, not exhaustive future semantics. Direct conservative guards are not unrestricted synonyms. Unchanged legacy word-guard exact-label audit remains UNVERIFIED. Raster hashes are not readability. Emulator, not phone.")
            .put("phoneEvidence", false).put("passed", false)
        scenario = ActivityScenario.launch(MainActivity::class.java)
        try {
            click("Kanji")
            click("N1")
            rule.waitUntil(30_000) { app.settings.stack.value == "jlpt-n1" }
            await("N1 · 133 cards").performScrollTo().assertIsDisplayed()
            capture("selection")
            click("Browse all kanji")
            rule.onNode(hasSetTextAction()).performTextReplacement("功")
            click("merit; achievement")
            await("功 — merit; achievement")
            show(articleBullet("Strokes: 5 · Key (radical): 力 (no. 19), on the right · JLPT: N1 (community list)"), "article-01")
            section("Meaning and origin")
            show(articleBullet("功 concerns merit or achievement: something successfully accomplished or a valued contribution. 功績 こうせき highlights a meritorious achievement; 成功 せいこう means success in achieving a result."), "article-03")
            show(articleBullet("功 can also refer to the effect produced by accumulated work or practice. It does not mean every effort or every neutral result."), "article-04")
            show(articleBullet("Modern-shape mnemonic, not etymology: Picture 工-shaped work beside 力-shaped strength producing an accomplishment. This is a memory aid for the modern shape, not a historical or phonetic explanation."), "article-05")
            section("Readings")
            show(readingExample("コウ"), "article-07")
            show(readingExample("功績 こうせき — achievement; meritorious contribution; 成功 せいこう — success; achievement"), "article-08")
            show(readingExample("ク"), "article-09")
            show(readingExample("功徳 (くどく) — religious merit; blessing, especially in Buddhist contexts. Recognition only."), "article-10")
            show(readingExample("いさお"), "article-11")
            show(readingExample("功 (いさお) — achievement; meritorious deed. Dated noun; recognition only."), "article-12")
            show(articleBullet("Reading questions select only コウ. ク is a valid reading in religious compounds, not another reading of 功績 or 成功. The native reading いさお is a documented dated noun, not merely a personal-name reading; it is retained for lookup rather than reading questions."), "article-13")
            section("Common words")
            show(articleBullet("功績 こうせき — achievement; meritorious contribution"), "article-15")
            show(articleBullet("成功 せいこう — success; achievement"), "article-16")
            section("Notes")
            show(articleBullet("功績 foregrounds a valued achievement or contribution; 成功 foregrounds success. Their meanings overlap, but a successful task need not be described as a distinguished contribution."), "article-18")
            show(articleBullet("績, \"achievements; results,\" shares the achievement meaning. This is a useful comparison, not a reliably wrong meaning choice."), "article-19")
            show(articleBullet("Compare 加, \"add,\" and 幼, \"early childhood; immature.\" Like 功, both have five strokes and contain 力, but the other components and meanings differ."), "article-20")
            show(articleBullet("Distinguish the right-hand 力 in 功 from 刀, \"sword; blade\": in 力 the slanting stroke crosses the upper stroke; in 刀 it starts inside the hooked outline."), "article-21")
            show(articleBullet("Metadata: KANJIDIC2, 2026-11-02 snapshot. Word families and register: JMdict, entries 1275070, 1375690, 1275080, 2411570 and 2411590. Character senses and reading allocation: Digital Daijisen, Seisenban Nihon Kokugo Daijiten and Jitsu, 功."), "article-22")
            section("Common words")
            val meritWord = "功績 こうせき — achievement; meritorious contribution"
            val meritParts = "功 contributes merit or successful accomplishment, and 績 contributes achievements or results. The related meanings reinforce a meritorious accomplishment. The on readings are コウ + セキ."
            inline(await(articleBullet(meritWord)), "功績", 0)
            await("功績 (こうせき) - achievement; meritorious contribution")
            section("How the kanji combine")
            show(articleBullet(meritParts), "koseki-components")
            inline(await(articleBullet(meritParts)), "功", 0)
            await("功 — merit; achievement")
            back()
            await(articleBullet(meritParts)).assertIsDisplayed()
            inline(await(articleBullet(meritParts)), "績", meritParts.indexOf("績"))
            await("績 — achievements; results")
            section("Common words")
            val recordWord = "功績 こうせき - achievement; meritorious service"
            show(articleBullet(recordWord), "seki-counterpart-reciprocal")
            inline(await(articleBullet(recordWord)), "功績", 0)
            await("功績 (こうせき) - achievement; meritorious contribution")
            back()
            await(articleBullet(recordWord)).assertIsDisplayed()
            back()
            await(articleBullet(meritParts)).assertIsDisplayed()
            back()
            await(articleBullet(meritWord)).assertIsDisplayed()
            val successWord = "成功 せいこう — success; achievement"
            val successParts = "成 contributes accomplishing or becoming, and 功 contributes achievement or merit. Together they convey accomplishment. The on readings are セイ + コウ."
            inline(await(articleBullet(successWord)), "成功", 0)
            await("成功 (せいこう) - success; achievement")
            section("How the kanji combine")
            show(articleBullet(successParts), "seiko-components")
            inline(await(articleBullet(successParts)), "功", successParts.indexOf("功"))
            await("功 — merit; achievement")
            back()
            await(articleBullet(successParts)).assertIsDisplayed()
            inline(await(articleBullet(successParts)), "成", 0)
            await("成 — become")
            section("Common words")
            show(articleBullet(successWord), "sei-new-reciprocal")
            inline(await(articleBullet(successWord)), "成功", 0)
            await("成功 (せいこう) - success; achievement")
            back()
            await(articleBullet(successWord)).assertIsDisplayed()
            back()
            await(articleBullet(successParts)).assertIsDisplayed()
            back()
            await(articleBullet(successWord)).assertIsDisplayed()
            back()
            await("Search kanji, meaning or reading")
            back()
            await("Meaning quiz")
            evidence.put("mappedReciprocalPairs", 4).put("directedLinkTransitions", 8)
                .put("activatedBaselinePairs", 2).put("changedReusedArticles", 3).put("reciprocalLinkAndSystemBack", true)
            click(rule.onNode(hasText("Start") and hasAnyAncestor(hasText("Meaning quiz"))))
            rule.waitUntil(30_000) { (model("quiz:") as? QuizViewModel)?.ui is QuizUi.Question }
            val quiz = model("quiz:") as QuizViewModel
            val meaning = quiz.ui as QuizUi.Question
            assertEquals("功", meaning.card.kanji)
            val n1Curated = curatedIds.filter { id -> n1.any { it.kanji == id } }
            assertEquals(setOf("刀"), n1Curated.toSet())
            assertEquals(4, meaning.options.size)
            assertEquals(4, meaning.options.map { it.title }.toSet().size)
            assertEquals(1, meaning.options.count { it.kanji == "功" })
            assertTrue(n1Curated.all { id -> meaning.options.any { it.kanji == id && it.title == expectedMeanings[id] } })
            assertTrue(meaning.options.all { option -> n1.any { it.kanji == option.kanji && it.title == option.title } })
            assertFalse(meaning.options.any { it.kanji in setOf("加", "幼") })
            val fallback = meaning.options.filter { it.kanji != "功" && it.kanji !in curatedIds }
            assertEquals(2, fallback.size)
            assertEquals(guards, meaning.card.toQuizCard().quizExclusions)
            assertTrue(meaning.options.none { it.kanji in guards })
            val actualCards = meaning.options.map { option -> n1.single { it.kanji == option.kanji }.toQuizCard() }
            for (left in actualCards) for (right in actualCards.filter { it.kanji != left.kanji })
                assertFalse(right.kanji in left.quizExclusions || left.kanji in right.quizExclusions)
            for (option in meaning.options) await(option.title).assertIsDisplayed()
            evidence.put("exactDefaultMeaningOptions", JSONArray().also { rows ->
                meaning.options.forEach { rows.put(JSONObject().put("kanji", it.kanji).put("title", it.title)) }
            }).put("actualN1CuratedAvailable", 1).put("actualN1FallbackOptions", 2)
                .put("curatedDistractorLevels", JSONObject().put("加", 3).put("幼", 2).put("刀", 1))
                .put("meaningFallbackNeedsSemanticReview", true)
            capture("meaning-question")
            click("merit; achievement")
            await("Correct!")
            capture("meaning-feedback")
            back()
            await("Meaning quiz")
            click(rule.onNode(hasText("Start") and hasAnyAncestor(hasText("Readings (on'yomi and kun'yomi)"))))
            rule.waitUntil(30_000) { (model("kreading:") as? KanjiReadingViewModel)?.ui is ReadingUi.Question }
            val reading = model("kreading:") as KanjiReadingViewModel
            val question = reading.ui as ReadingUi.Question
            assertEquals("功", question.card.kanji)
            assertEquals("こう", question.question.correctKey)
            assertEquals(ReadingKind.On, question.question.kind)
            assertEquals(1, question.question.options.count { it.key == "こう" })
            capture("curated-on-question")
            click(question.question.options.single { it.key == "こう" }.label)
            await("Correct! — on'yomi")
            assertTrue((reading.ui as ReadingUi.Answer).correct)
            capture("curated-on-feedback")
            click("Next")
            rule.waitUntil(30_000) { (model("kreading:") as? KanjiReadingViewModel)?.ui is ReadingUi.Done }
            val done = (model("kreading:") as KanjiReadingViewModel).ui as ReadingUi.Done
            assertEquals(1, done.answered)
            assertEquals(1, done.correct)
            rule.waitUntil(30_000) { runBlocking {
                app.db.reviews().allLog().any { log -> log.sourceId == source.id && log.kanji == "功" &&
                    log.mode == ReadingKind.On.mode.name && log.reading == "こう" && log.grade == 3 }
            } }
            val logs = runBlocking { app.db.reviews().allLog().filter {
                it.sourceId == source.id && it.kanji == "功" &&
                    it.mode in setOf(ReadingKind.On.mode.name, ReadingKind.Kun.mode.name)
            } }
            assertEquals(1, logs.size)
            assertEquals("こう", logs.single().reading)
            assertEquals(ReadingKind.On.mode.name, logs.single().mode)
            assertEquals(3, logs.single().grade)
            capture("curated-one-key-done")
            back()
            await("Meaning quiz")
            click(rule.onNode(hasText("Start") and hasAnyAncestor(hasText("Drawing"))))
            await("Trace the kanji for")
            await("merit; achievement").assertIsDisplayed()
            val card = requireNotNull(runBlocking { app.db.content().kanjiCard(source.id, "功") })
            assertEquals(listOf("コウ", "ク"), card.onyomi.splitSep())
            assertEquals(listOf("いさお"), card.kunyomi.splitSep())
            assertEquals(listOf("コウ"), card.quizOnyomi?.splitSep())
            assertEquals(emptyList<String>(), card.quizKunyomi?.splitSep())
            assertEquals(guards, card.quizExclusions.splitSep())
            evidence.put("fullProjectionOnyomi", JSONArray(card.onyomi.splitSep()))
                .put("fullProjectionKunyomi", JSONArray(card.kunyomi.splitSep()))
                .put("fullProjectionQuizOnyomi", JSONArray(requireNotNull(card.quizOnyomi).splitSep()))
                .put("fullProjectionQuizKunyomi", JSONArray(requireNotNull(card.quizKunyomi).splitSep()))
            val strokes = JSONObject(requireNotNull(card.strokesJson)).getJSONArray("strokes")
            assertEquals(5, strokes.length())
            capture("drawing-trace")
            val pad = rule.onNode(hasContentDescription("Drawing area for the kanji", substring = true))
            pad.performScrollTo()
            for (index in 0 until strokes.length()) {
                val points = strokes.getJSONObject(index).getJSONArray("points")
                pad.performTouchInput {
                    fun point(i: Int): Offset {
                        val pair = points.getJSONArray(i)
                        return Offset(pair.getDouble(0).toFloat() * width / 109f,
                            pair.getDouble(1).toFloat() * height / 109f)
                    }
                    down(point(0))
                    for (i in 1 until points.length()) moveTo(point(i), delayMillis = 16)
                    up()
                }
            }
            rule.onNode(hasContentDescription("5 strokes drawn", substring = true)).assertExists()
            click("Check")
            await("Practice only: this attempt is not graded.")
            assertFalse(runBlocking { app.db.reviews().allLog().any {
                it.sourceId == source.id && it.kanji == "功" && it.mode == StudyMode.Draw.name
            } })
            await("Correct strokes").performScrollTo().assertIsDisplayed()
            capture("drawing-feedback")
            click("Next")
            await("Draw the kanji for")
            click("I don't remember")
            await("Here is the kanji")
            capture("drawing-recall-feedback")
            click("Next")
            rule.waitUntil(30_000) { runBlocking { app.db.reviews().allLog().any {
                it.sourceId == source.id && it.kanji == "功" && it.mode == StudyMode.Draw.name && it.grade == 1
            } } }
            back()
            await("Meaning quiz")
            assertEquals("jlpt-n1", app.settings.stack.value)
            assertNull(connectivity.activeNetwork)
            assertEquals(1, archiveRequests)
            evidence.put("meaningQuestionAndFeedback", true).put("oneCuratedKeyPersistedGoodAndDone", true)
                .put("touchInjectedReferenceStrokes", strokes.length()).put("drawingTraceThenRecall", true)
                .put("drawingGradeRecordedOnNext", true).put("offline", true).put("passed", true)
        } finally {
            File(app.getExternalFilesDir(null), "n1-101-article-route.json").writeText(evidence.toString(2))
            File(app.getExternalFilesDir(null), "n1-101-article-tree.txt").writeText(rule.onRoot().printToString())
            scenario.close()
        }
    }

    private fun model(prefix: String): ViewModel? {
        var result: ViewModel? = null
        scenario.onActivity { activity ->
            result = activity.viewModelStore.keys().lastOrNull { it.startsWith(prefix) }?.let { activity.viewModelStore[it] }
        }
        return result
    }

    private fun await(text: String, substring: Boolean = false): SemanticsNodeInteraction {
        return await(hasText(text, substring = substring))
    }

    private fun await(matcher: SemanticsMatcher): SemanticsNodeInteraction {
        rule.waitUntil(30_000) { rule.onAllNodes(matcher).fetchSemanticsNodes().isNotEmpty() }
        rule.onAllNodes(matcher).assertCountEquals(1)
        return rule.onNode(matcher)
    }

    private fun readingExample(text: String): SemanticsMatcher {
        return hasText(text) and hasAnyAncestor(hasTestTag("article-body")) and
            hasAnyAncestor(SemanticsMatcher.keyIsDefined(SemanticsProperties.HorizontalScrollAxisRange))
    }

    private fun articleBullet(text: String): SemanticsMatcher {
        return hasText(text) and hasAnyAncestor(hasTestTag("article-body")) and
            !hasAnyAncestor(SemanticsMatcher.keyIsDefined(SemanticsProperties.HorizontalScrollAxisRange))
    }

    private fun click(text: String) = click(await(text))

    private fun click(node: SemanticsNodeInteraction) {
        rule.waitUntil(30_000) { !node.fetchSemanticsNode().config.contains(SemanticsProperties.Disabled) }
        if (node.onAncestors().filter(hasScrollAction()).fetchSemanticsNodes().isNotEmpty()) node.performScrollTo()
        node.assertIsDisplayed().assertIsEnabled().performClick()
    }

    private fun section(title: String) {
        rule.onNodeWithTag("article-body").performScrollToIndex(0)
        click("Article contents")
        rule.onNode(hasText(title, substring = true) and hasClickAction()).performScrollTo().performClick()
        rule.waitForIdle()
    }

    private fun show(selector: String, step: String) {
        show(hasText(selector, substring = true), step)
    }

    private fun show(matcher: SemanticsMatcher, step: String, occurrence: Int = 0, expectedCount: Int = 1) {
        val body = rule.onNodeWithTag("article-body")
        body.performScrollToNode(matcher)
        rule.onAllNodes(matcher).assertCountEquals(expectedCount)
        val target = rule.onAllNodes(matcher)[occurrence]
        target.performScrollTo()
        val viewport = body.fetchSemanticsNode()
        val cell = target.fetchSemanticsNode()
        val top = viewport.positionInRoot.y
        val bottom = top + viewport.size.height
        if (cell.positionInRoot.y < top || cell.positionInRoot.y + cell.size.height > bottom) {
            body.performSemanticsAction(SemanticsActions.ScrollBy) {
                it(0f, cell.positionInRoot.y - top - 16f)
            }
            rule.waitForIdle()
        }
        target.assertIsDisplayed()
        capture(step)
    }

    private fun inline(node: SemanticsNodeInteraction, label: String, offset: Int) {
        node.performScrollTo().assertIsDisplayed()
        val text = node.fetchSemanticsNode().config[SemanticsProperties.Text].joinToString("") { it.text }
        val layouts = mutableListOf<TextLayoutResult>()
        node.performSemanticsAction(SemanticsActions.GetTextLayoutResult) { it(layouts) }
        assertTrue("Wrong linked offset $offset for $label in $text", offset >= 0 && text.substring(offset).startsWith(label))
        node.performTouchInput { click(layouts.single().getBoundingBox(offset).center) }
    }

    private fun back() {
        InstrumentationRegistry.getInstrumentation().uiAutomation.performGlobalAction(
            android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
        rule.waitForIdle()
    }

    private fun capture(step: String) {
        rule.waitForIdle()
        val automation = InstrumentationRegistry.getInstrumentation().uiAutomation
        automation.waitForIdle(500, 5_000)
        android.os.SystemClock.sleep(1_000)
        rule.waitForIdle()
        val bitmap = requireNotNull(automation.takeScreenshot())
        File(app.getExternalFilesDir(null), "n1-101-$step.png").outputStream().use {
            assertTrue(bitmap.compress(Bitmap.CompressFormat.PNG, 100, it))
        }
        bitmap.recycle()
    }
}
