$ErrorActionPreference = 'Stop'
$control = $PSScriptRoot
$log = "$control\logs\b190c29d-6bc1-4bfd-9074-9fc78b4d935c"
$content = "$control\..\learning-japanese"
$bodyPath = "$control\batch-106-native-sources-826-issue-body.txt"
if ((Test-Path "$log\issue-826-posted.json") -or (Test-Path $bodyPath)) {
    throw 'Do not duplicate owner issue update'
}
$head = git -C $content rev-parse HEAD
if ($LASTEXITCODE -ne 0) { throw 'HEAD lookup failed' }
& "$control\preflight-826.ps1" -ReceiptName 'preflight-826-before-issue.json' -ExpectedContentHead $head
if (-not $?) { throw 'Final preflight failed' }
if ((git -C $content rev-parse 'HEAD^') -ne 'bf5fe7cb3bdaebd5c59867b13d4fb8c7f0a73140' -or
    $LASTEXITCODE -ne 0) { throw 'Wrong evidence ancestry' }
$e = [IO.File]::ReadAllText("$content\docs\n1-sources\execution-826.json") | ConvertFrom-Json
if ($e.completeCharacterRecords -ne 5 -or $e.completeDictionaryFamilies -ne 21 -or
    $e.completeCurrentKanjiBodies -ne 5 -or $e.completeCurrentWordBodies -ne 10 -or
    $e.runtime.runtimeHashesVerified -ne 8472 -or $e.runtimeChanged -or
    $e.runtimeAccepted -or $e.runtimePublished -or $e.independentRenderedReviewClosed) {
    throw 'Source supplement evidence mismatch'
}
$body = @"
Checkpoint 826, SAME batch 106: the five additional actual native quiz labels now have a bounded, inspected source supplement at signed LOCAL evidence commit $head. See docs/n1-sources/execution-826.json and docs/n1-reviews/batch-106-native-sources-826/.

Preserved FIVE complete raw KANJIDIC2 records/all English meanings,21 complete JMdict families/all spellings/readings/restrictions/senses, and FIFTEEN complete actual comparison bodies (5kanji+10word articles), pinned to unchanged contentbf5fe7cb3bdaebd5c59867b13d4fb8c7f0a73140. Both compressed and decompressed approved frozen dictionary hashes verified. Labels: remainder/surplus amount; handle/deal with; beast/animal; spear/polearm; tuber/yam. Exact characters and displayed labels, all applicable cited full families, actual body hashes and coordinator sense-by-sense target-relative disposition are in the packet. No new upstream retrieval or independent-review credit is claimed.

Coordinator inspection found no consequential ambiguity between these five exact additional displayed answers and the target imperial order, including ordinary secondary senses, archaic handling senses, search-only remainder forms, restricted subculture usage, broader arms/bow-grip/festival-float uses and derogatory tuber senses. Contextual relationships do not prove synonymy; different labels/POS alone do not prove safety. No speculative guard, title distortion or runtime change. This is finite target-relative inspection, not a new whole-article review or universal current/future-pool or wrong-pair certification.

The original weak instruction/precept comparison hypothesis remains explicitly UNRESOLVED NONBLOCKING, not withdrawn, not an established defect and not a reason to manufacture a guard. BOTH ORIGINAL model-family rendered confirmations remain required on one frozen snapshot with original reports, complete relevant families, inherited HOST options, this supplement, exact native labels/pools/order/seeds, actual PNG scope and limitations. Serial reviewer processes and serial per-tool reads remain mandatory. New native fallback semantic acceptance remains UNVERIFIED pending those confirmations; no reviewer launched in826. Existing822textual/823HOST/825native evidence is inherited, not rerun or expanded.

All8472runtime hashes/contentVersion89809c00e1676979 unchanged; validator zero errors and regenerated manifest unchanged. Dedicated worktrees clean after normal signed LOCAL evidence commit. No content push, runtime acceptance, delivery credit, next batch, Android/native rerun or phone claim. Full historical progress is preserved, including the verified792correction; initial checkpoint comparison caught only two equivalent timestamp-offset renderings, verified as the same instants without altering live history. Parent runner lock untouched; approved workspace inputs only, no optional historical-session recipes or actual new permission denial.

Published132/1228; remaining1096; last published0c582f18b31f65a5e1a908d92e37dde3d34f81ee. Combined-current-main integration, changed-teaching review, all required Python/vocabulary/baseline-membership-links/manifest/per-file-media-safe-path checks, normal signed owner fast-forward publication, terminal green CI and EVERY immutable-ZIP runtime hash/budget check remain mandatory. Unchanged18000entries/42MiBcompressed/80MiBinflated/56MiBretained guards. Compatible Android reading-curation/kanji-exclusion client required; old clients ignore those fields. Unaccepted one-kanji/one-necessary-support batch is not N1 vocabulary delivery. Physical-phone/general-release/whole-set acceptance remains outstanding; project incomplete.
"@
[IO.File]::WriteAllText($bodyPath, ($body -replace "`r`n", "`n") + "`n", [Text.UTF8Encoding]::new($false))
$priorToken = $env:GH_TOKEN
try {
    $env:GH_TOKEN = (gh auth token --user stop-cran)
    if ($LASTEXITCODE -ne 0 -or -not $env:GH_TOKEN) { throw 'Owner credential unavailable' }
    $login = gh api user --jq .login
    if ($LASTEXITCODE -ne 0 -or $login -cne 'stop-cran') { throw 'Wrong command-scoped identity' }
    $url = gh issue comment 60 --repo stop-cran/learning-japanese --body-file $bodyPath
    if ($LASTEXITCODE -ne 0) { throw 'Issue update failed' }
    $url = $url.Trim()
    @{url=$url; author=$login; bodySha256=(Get-FileHash $bodyPath).Hash.ToLowerInvariant()} |
        ConvertTo-Json | Set-Content "$log\issue-826-posted.json" -Encoding utf8NoBOM
    if ($url -notmatch '#issuecomment-(\d+)$') { throw 'Unexpected URL; preserve receipt' }
    $raw = gh api "repos/stop-cran/learning-japanese/issues/comments/$($Matches[1])"
    if ($LASTEXITCODE -ne 0) { throw 'Comment reread failed' }
    $raw | Set-Content "$log\issue-826-reread.json" -Encoding utf8NoBOM
    $comment = $raw | ConvertFrom-Json
    if ($comment.user.login -cne 'stop-cran' -or $comment.body -cne [IO.File]::ReadAllText($bodyPath) -or
        $comment.html_url -cne $url) { throw 'Exact owner/body verification failed' }
    Write-Output "Verified owner update: $url"
} finally {
    $env:GH_TOKEN = $priorToken
}
