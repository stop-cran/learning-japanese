"""Correct authoring-artifact hashes to the exact Git LF bytes before checkpointing."""
import gzip
import hashlib
import json
from pathlib import Path
import subprocess

C = Path(__file__).resolve().parent
R = C.parent / "learning-japanese"
L = C / "logs" / "b190c29d-6bc1-4bfd-9074-9fc78b4d935c"
D = R / "docs" / "n1-reviews" / "batch-106-native-sources-826"
E = R / "docs" / "n1-sources" / "execution-826.json"
FIRST = "850bc16331421049fe4aff74c1a6307ce4a64ed5"
assert subprocess.check_output(["git", "-C", str(R), "rev-parse", "HEAD"], text=True).strip() == FIRST
assert not subprocess.check_output(["git", "-C", str(R), "status", "--porcelain"], text=True).strip()
p = json.loads((C / "progress.json").read_bytes())
assert (p["checkpoint"], p["batch"], p["status"]) == (825, "106", "continue")
assert p["execution826StartingState"]["startingHead"] == "bf5fe7cb3bdaebd5c59867b13d4fb8c7f0a73140"
original_index = (D / "artifact-index.json").read_bytes()
record = {"firstSignedEvidenceCommit": FIRST,
          "originalOwnerReport": "https://github.com/stop-cran/learning-japanese/issues/60#issuecomment-6721498068",
          "cause": "Windows Path.write_text used default CRLF; Git normalized text/JSON to LF. Final checkpoint verification caught four artifact hash mismatches before any checkpoint save. The first signed commit and owner report remain unchanged; this narrow correction uses exact Git LF bytes without changing source fields or runtime.",
          "changedArtifacts": [], "runtimeChanged": False, "parentLockTouched": False}
for row in json.loads(original_index):
    path = D / row["file"]
    raw = path.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == row["sha256"]
    committed = subprocess.check_output(["git", "-C", str(R), "show",
                                        FIRST + ":" + path.relative_to(R).as_posix()])
    if hashlib.sha256(committed).hexdigest() != row["sha256"]:
        assert raw.replace(b"\r\n", b"\n") == committed
        record["changedArtifacts"].append({"file": row["file"], "originalWorkingSha256": row["sha256"],
                                          "gitLfSha256": hashlib.sha256(committed).hexdigest()})
        path.write_bytes(committed)
assert len(record["changedArtifacts"]) == 4
assert not (D / "normalization-correction.json").exists()
(D / "original-working-artifact-index.json.gz").write_bytes(gzip.compress(original_index, mtime=0))
for name in ("prepare-native-sources-826.py", "checkpoint-native-sources-826.py", "normalize-native-sources-826.py",
             "post-native-sources-826-normalization.ps1"):
    (D / (name + ".gz")).write_bytes(gzip.compress((C / name).read_bytes(), mtime=0))
(D / "normalization-correction.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8", newline="\n")
index = [{"file": x.name, "sha256": hashlib.sha256(x.read_bytes()).hexdigest(), "bytes": x.stat().st_size}
         for x in sorted(D.iterdir()) if x.is_file() and x.name != "artifact-index.json"]
index_bytes = (json.dumps(index, indent=2) + "\n").encode("utf-8")
(D / "artifact-index.json").write_bytes(index_bytes)
e = json.loads(E.read_bytes())
e["artifactIndexSha256"] = hashlib.sha256(index_bytes).hexdigest()
e["normalizationCorrection"] = record
E.write_text(json.dumps(e, ensure_ascii=True, indent=2) + "\n", encoding="utf-8", newline="\n")
for row in index:
    raw = (D / row["file"]).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == row["sha256"]
    if (D / row["file"]).suffix in {".json", ".txt", ".xml"}:
        assert b"\r\n" not in raw
(L / "normalization-826-diagnostic.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8", newline="\n")
print("Exact Git LF artifact hashes corrected; original signed evidence/index preserved; no runtime change.")
