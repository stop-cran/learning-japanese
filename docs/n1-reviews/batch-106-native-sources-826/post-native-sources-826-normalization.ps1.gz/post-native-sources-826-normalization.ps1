$ErrorActionPreference = 'Stop'
$control = $PSScriptRoot
$log = "$control\logs\b190c29d-6bc1-4bfd-9074-9fc78b4d935c"
$content = "$control\..\learning-japanese"
if (Test-Path "$log\normalization-826-reread.json") { throw 'Do not duplicate correction report' }
$head = git -C $content rev-parse HEAD
if ($LASTEXITCODE -ne 0) { throw 'HEAD lookup failed' }
& "$control\preflight-826.ps1" -ReceiptName 'preflight-826-normalization-before-issue.json' -ExpectedContentHead $head
if (-not $?) { throw 'Correction preflight failed' }
if ((git -C $content rev-parse 'HEAD^') -ne '850bc16331421049fe4aff74c1a6307ce4a64ed5') {
    throw 'Wrong correction ancestry'
}
$body = @"
Checkpoint826 artifact-hash correction: final checkpoint verification caught four authoring text/JSON artifact index hashes that described Windows CRLF working bytes rather than the LF bytes committed by Git. The original signed evidence850bc16331421049fe4aff74c1a6307ce4a64ed5 and earlier issue report remain unchanged. Narrow normally signed correction $head makes the index match exact committed LF bytes, preserves the original working index and precise diagnostic, and fixes the durable generators to write LF explicitly. Source records, article content, dictionaries, runtime/manifest/version, counters and acceptance are unchanged. No runtime was pushed. Both original-family rendered confirmations, publication gates and all previous limits remain outstanding;132published/1096remaining and project incomplete. No signing bypass/retry, parent-lock change, historical helper access or new permission denial.
"@
[IO.File]::WriteAllText("$log\normalization-826-body.txt", ($body -replace "`r`n", "`n") + "`n", [Text.UTF8Encoding]::new($false))
$prior = $env:GH_TOKEN
try {
    $env:GH_TOKEN = gh auth token --user stop-cran
    if ($LASTEXITCODE -ne 0 -or -not $env:GH_TOKEN) { throw 'Owner credential unavailable' }
    if ((gh api user --jq .login) -cne 'stop-cran' -or $LASTEXITCODE -ne 0) { throw 'Wrong owner' }
    $url = gh issue comment 60 --repo stop-cran/learning-japanese --body-file "$log\normalization-826-body.txt"
    if ($LASTEXITCODE -ne 0) { throw 'Correction post failed or uncertain' }
    [IO.File]::WriteAllText("$log\normalization-826-url.txt", $url)
    if ($url -notmatch '#issuecomment-(\d+)$') { throw 'Uncertain correction URL' }
    $raw = gh api "repos/stop-cran/learning-japanese/issues/comments/$($Matches[1])"
    if ($LASTEXITCODE -ne 0) { throw 'Correction reread failed' }
    $raw | Set-Content "$log\normalization-826-reread.json" -Encoding utf8NoBOM
    $comment = $raw | ConvertFrom-Json
    if ($comment.user.login -cne 'stop-cran' -or $comment.body -cne [IO.File]::ReadAllText("$log\normalization-826-body.txt") -or
        $comment.html_url -cne $url.Trim()) { throw 'Correction verification failed' }
    Write-Output "Verified owner correction: $url"
} finally {
    $env:GH_TOKEN = $prior
}
