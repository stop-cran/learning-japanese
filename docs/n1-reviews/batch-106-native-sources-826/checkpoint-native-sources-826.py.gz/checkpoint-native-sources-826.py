"""Verify, archive and checkpoint the bounded native-label source supplement."""
import copy
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

C = Path(__file__).resolve().parent
R, A = C.parent / "learning-japanese", C.parent / "kanji-cards-android"
L = C / "logs" / "b190c29d-6bc1-4bfd-9074-9fc78b4d935c"
D = R / "docs" / "n1-reviews" / "batch-106-native-sources-826"
E = R / "docs" / "n1-sources" / "execution-826.json"
BASE = "bf5fe7cb3bdaebd5c59867b13d4fb8c7f0a73140"
APP = "bf30cdead8515739bc0e671d57a54b9a3109dd46"


def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, data):
    assert not path.exists(), path
    path.write_text(json.dumps(data, ensure_ascii=True, indent=2) + "\n", encoding="utf-8", newline="\n")


def git(*args, root=R):
    return subprocess.check_output(["git", "--no-pager", "-c", "core.quotepath=false",
                                   "-C", str(root), *args], encoding="utf-8").strip()


def verify(clean):
    p = load(C / "progress.json")
    assert (p["checkpoint"], p["status"], p["batch"]) == (825, "continue", "106")
    runner = load(C / "runner.json")
    assert (runner["status"], runner["pid"], runner["sessionId"]) == ("running", 13320, L.name)
    assert git("rev-parse", "HEAD", root=A) == APP
    assert git("log", "-1", "--format=%G?", root=A) == "G"
    assert not git("status", "--porcelain", "--untracked-files=all", root=A)
    assert git("log", "-1", "--format=%G?") == "G"
    if clean:
        assert not git("status", "--porcelain", "--untracked-files=all")
    return p


def runtime():
    manifest = load(R / "manifest.json")
    assert manifest == json.loads(git("show", BASE + ":manifest.json"))
    count = 0
    for section, entries in manifest.items():
        if not isinstance(entries, dict):
            continue
        for path, digest in entries.items():
            raw = (R / path).read_bytes()
            if section not in {"images", "audio", "listeningTaskAudio", "listeningTaskImages"}:
                raw = raw.replace(b"\r\n", b"\n")
            assert hashlib.sha256(raw).hexdigest() == digest, path
            count += 1
    assert count == 8472 and manifest["contentVersion"] == "89809c00e1676979"
    return {"runtimeHashesVerified": count, "contentVersion": manifest["contentVersion"],
            "manifestSha256": sha(R / "manifest.json"), "manifestUnchanged": True}


def archive():
    p = verify(False)
    assert git("rev-parse", "HEAD") == BASE
    assert not git("diff", "--name-only", BASE)
    paths = git("ls-files", "--others", "--exclude-standard").splitlines()
    assert paths and all(x.startswith("docs/n1-reviews/batch-106-native-sources-826/") for x in paths)
    selection = load(D / "source-selection.json")
    inspection = load(D / "semantic-inspection.json")
    assert selection["completeCharacterRecords"] == 5 and selection["completeDictionaryFamilies"] == 21
    assert len(selection["completeCurrentArticles"]) == 15
    assert len((D / "complete-current-articles.txt").read_text(encoding="utf-8").splitlines()) <= 730
    assert inspection["inspected"]["completeJMdictFamilies"] == 21
    assert len(inspection["labels"]) == 5 and not inspection["runtimeChanged"]
    assert not inspection["nextGate"]["independentRenderedReviewClosed"]
    for name in ("validate-826.txt", "manifest-826.txt", "manifest-diff-826.txt"):
        assert (L / name).exists()
    diff_log = (L / "manifest-diff-826.txt").read_text(encoding="utf-8-sig").strip()
    expected_warning = "warning: in the working copy of 'manifest.json', LF will be replaced by CRLF the next time Git touches it"
    assert diff_log in ("", expected_warning)
    diff = subprocess.run(["git", "-C", str(R), "diff", "--exit-code", "--", "manifest.json"],
                          capture_output=True, encoding="utf-8", check=True)
    assert not diff.stdout
    assert diff.stderr.strip() in ("", expected_warning)
    for name in ("preflight-826.ps1", "prepare-native-sources-826.py",
                 "checkpoint-native-sources-826.py", "post-native-sources-826.ps1"):
        source = C / name
        (D / (name + ".gz")).write_bytes(gzip.compress(source.read_bytes(), mtime=0))
    for name in ("preflight-826.json", "starting-state-826.json", "validate-826.txt",
                 "manifest-826.txt", "manifest-diff-826.txt"):
        source = L / name
        (D / (name + ".gz")).write_bytes(gzip.compress(source.read_bytes(), mtime=0))
    index = [{"file": x.name, "sha256": sha(x), "bytes": x.stat().st_size}
             for x in sorted(D.iterdir()) if x.is_file()]
    save(D / "artifact-index.json", index)
    save(E, {
        "schemaVersion": 1, "execution": 826, "batch": "106",
        "recordedAt": datetime.now(timezone.utc).isoformat(),
        "stage": "five-native-only-label-sources-inspected-awaiting-original-family-rendered-confirmations",
        "startingState": p["execution826StartingState"], "sourceSnapshot": BASE,
        "qualifiedAndroidHead": APP, "supplement": D.relative_to(R).as_posix(),
        "completeCharacterRecords": 5, "completeDictionaryFamilies": 21,
        "completeCurrentKanjiBodies": 5, "completeCurrentWordBodies": 10,
        "sourceSelection": selection, "coordinatorSemanticInspection": inspection,
        "artifactIndex": (D / "artifact-index.json").relative_to(R).as_posix(),
        "artifactIndexSha256": sha(D / "artifact-index.json"), "runtime": runtime(),
        "checks": {"validatorErrors": 0, "manifestRegenerated": True, "manifestUnchanged": True,
                   "diagnostic": "First archive assertion rejected the normal LF-to-CRLF Git warning despite successful diff exit0. Original log retained. Exact warning inspected; independent captured diff verifies exit0 and empty stdout; no content difference or Git configuration change.",
                   "limits": "Source/evidence-only checkpoint. No fresh full Python suite, HOST/native rerun, independent review or publication. Existing mandatory acceptance gates remain."},
        "independentReviewersLaunched": 0, "independentRenderedReviewClosed": False,
        "newNativeOrdinarySenseFallbackSemanticAcceptance": "UNVERIFIED pending both original-family rendered confirmations",
        "runtimeChanged": False, "runtimeAccepted": False, "runtimePublished": False,
        "parentLockTouched": False, "optionalHistoricalHelpersAccessed": False,
        "actualNewPermissionDenials": [], "publishedAdditions": 132, "remainingAdditions": 1096,
        "lastPublishedCommit": p["lastPublishedCommit"],
        "physicalPhoneAcceptance": "outstanding", "generalReleaseAcceptance": "outstanding",
        "wholeProjectComplete": False, "nextBatchStarted": False,
    })
    print("Source packet, helper provenance and all8472 unchanged runtime hashes verified.")


def format_packet():
    verify(False)
    assert git("rev-parse", "HEAD") == BASE
    packet = D / "complete-current-articles.txt"
    original = packet.read_text(encoding="utf-8")
    formatted = re.sub(r"^(\d+:) $", r"\1", original, flags=re.M)
    assert formatted != original
    packet.write_text(formatted, encoding="utf-8", newline="\n")
    for name in ("prepare-native-sources-826.py", "checkpoint-native-sources-826.py"):
        (D / (name + ".gz")).write_bytes(gzip.compress((C / name).read_bytes(), mtime=0))
    index = [{"file": x.name, "sha256": sha(x), "bytes": x.stat().st_size}
             for x in sorted(D.iterdir()) if x.is_file() and x.name != "artifact-index.json"]
    (D / "artifact-index.json").write_text(json.dumps(index, ensure_ascii=True, indent=2) + "\n", encoding="utf-8", newline="\n")
    e = load(E)
    e["artifactIndexSha256"] = sha(D / "artifact-index.json")
    e["checks"]["packetFormattingDiagnostic"] = (
        "Staged whitespace check stopped before any signing attempt: numbered empty article lines had a trailing prefix space. "
        "Removed only that generated prefix space, leaving source article bytes and source hashes unchanged; corrected the durable generator "
        "and refreshed helper/artifact hashes before the first normal signed commit. No signing hang or signing retry.")
    E.write_text(json.dumps(e, ensure_ascii=True, indent=2) + "\n", encoding="utf-8", newline="\n")
    assert runtime() == e["runtime"]
    print("Generated empty-line prefixes formatted; source bodies and runtime unchanged.")


def finish():
    current = verify(True)
    before = load(L / "progress-before-826.json")
    head = git("rev-parse", "HEAD")
    first_head = "850bc16331421049fe4aff74c1a6307ce4a64ed5"
    assert git("rev-parse", "HEAD^") == first_head
    assert git("rev-parse", first_head + "^") == BASE
    assert git("log", "-1", "--format=%G?", first_head) == "G"
    allowed = ("docs/n1-reviews/batch-106-native-sources-826/", "docs/n1-sources/execution-826.json")
    changed = git("diff", "--name-only", BASE, head).splitlines()
    assert changed and all(x.startswith(allowed) for x in changed)
    assert not git("diff", "--name-only", BASE, head, "--", "manifest.json", "kanji", "words", "articles", "strokes")
    e = load(E)
    assert e["runtime"] == runtime()
    for row in load(D / "artifact-index.json"):
        path = (D / row["file"]).relative_to(R).as_posix()
        assert sha(D / row["file"]) == row["sha256"]
        assert hashlib.sha256(subprocess.check_output(
            ["git", "-C", str(R), "show", head + ":" + path])).hexdigest() == row["sha256"]
    assert sha(D / "artifact-index.json") == e["artifactIndexSha256"]
    posted, reread = load(L / "issue-826-posted.json"), load(L / "issue-826-reread.json")
    body = C / "batch-106-native-sources-826-issue-body.txt"
    assert posted["author"] == reread["user"]["login"] == "stop-cran"
    assert posted["bodySha256"] == sha(body) and reread["body"] == body.read_text(encoding="utf-8")
    assert reread["html_url"] == posted["url"]
    correction = load(L / "normalization-826-reread.json")
    assert correction["user"]["login"] == "stop-cran"
    assert correction["body"] == (L / "normalization-826-body.txt").read_text(encoding="utf-8")
    assert head in correction["body"] and first_head in correction["body"]
    next_action = (
        f"SAME106 checkpoint826 signed LOCAL five-native-label source supplement HEAD{head}, qualifiedAndroid{APP}. "
        "Read docs/n1-sources/execution-826.json and docs/n1-reviews/batch-106-native-sources-826/: "
        "FIVE complete raw character records/allEnglishmeanings,21completeJMdictfamilies/allspellings/readings/"
        "restrictions/senses,5completekanji+10completewordbodies at unchangedbf5fe7cb. Exact additional native labels "
        "剰remainder-surplusamount/扱handle-dealwith/獣beast-animal/矛spear-polearm/芋tuber-yam inspected. "
        "Coordinator found no consequentialtarget-relativeambiguity; no speculativeguard/title/metadata change. "
        "Both compressed/decompressed frozen source hashes verified. Entire15articlepacket and21families read, "
        "not independentupstream/native/fulllegacyarticle certification. NEXT SAME106 bounded ORIGINAL-family "
        "rendered confirmation preparation and/or execution: use original sessions/reports/actualmodels from "
        "batch-106-initial-executions-822.json and batch-106-reconciliation.json, notnewblindinitials. "
        "Give BOTH identical frozen teaching/currentdiff, originalfindings, complete inherited822/823sources and "
        "finiteactualoptions, this five-labelsupplement, exact825native labels/pools/order/seeds/route/actualPNGscope. "
        "Keep original822勅訓weak hypothesis UNRESOLVED NONBLOCKING; include complete1956150/1236890families/"
        "actualinstruction-kunreadingversusimperialorderlabels/32unguardedsamples. Do notforcewithdrawal/"
        "inventguard/claimuniversalsafety. Newnativeordinarysecondarysensefallbacksemanticacceptance remainsUNVERIFIED "
        "until BOTH SERIAL ORIGINAL-family rendered confirmations; onlyONEreviewerprocessatonce, actualexitbeforethenext, "
        "per-toolserialization/readlimits/actualmodels recorded, noeditfrozensnapshot. No reviewer launched826. "
        "Any consequentialdefect:exactsource/minimalcorrection/audits/manifest/normalsignednewfreeze/BOTHoriginalfamilies. "
        "All8472runtimehashes/version89809c00e1676979/manifestunchanged;validator0errors/regeneratedmanifestunchanged. "
        "No freshHOST/native/phoneclaim; original822textual823HOST825native mechanics/PNGlimits remain inherited. "
        "Complete previous825nextAction retained verbatim in historicalExecution825Before826Sources.nextAction; "
        "ALL original acceptance/publication/source/reviewer/process/denial/OOM/history limits remain mandatory. "
        "Combinedcurrentmain/nonrewritingmerge/changedteachingreview/fullrequiredPython/vocabulary/baseline-membership-links/"
        "manifestbudget/normalsigning/ownerfastforward/terminalgreenCI/EVERYimmutableGitHubZIPmanifesthash/"
        "unchanged18000entries42MiBcompressed80MiBinflated56MiBretained/perfilepathmedia/verifiedownerissue. "
        "No107/unreviewedpush/authoragents/concurrentheavywork/secondrunner/signingretry/guardincrease. "
        "Freshsignedheads/checkpoint/whollyclean/freshmain/liveparentancestry/decodedlauncher/exactsession required. "
        "Parent13320ownsrunner.lock:nochildacquire/delete/unlock/readprobe; approvedcontrol/committedsource/frozeninputs only. "
        "Preserve/report/yield actualnewdenial/signinghang/uncertainownership. "
        "Published132/1228/remainder1096unchanged;lastpublished0c582f18b31f65a5e1a908d92e37dde3d34f81ee; "
        "unaccepted勅/necessarysupport勅令notdeliveredN1vocabulary. CompatibleAndroid125+132 required;oldclientsignore. "
        "Physicalphone/generalrelease/whole-setoutstanding;projectincomplete."
    )
    checkpoint = {
        "schemaVersion": 1, "execution": 826, "checkpoint": 826, "batch": "106",
        "status": "continue", "stage": "batch-106-native-label-sources-inspected-awaiting-original-family-rendered-confirmations",
        "recordedAt": datetime.now(timezone.utc).isoformat(), "savedCommit": head, "signature": "G",
        "qualifiedAndroidHead": APP, "sourceSnapshot": BASE,
        "evidence": E.relative_to(R).as_posix(), "issueUpdate": posted["url"],
        "ownerIssueAuthorAndExactBodyVerified": True,
        "normalizationCorrectionOwnerReport": correction["html_url"],
        "originalEvidenceCommit": first_head,
        "completeCharacterRecords": 5, "completeDictionaryFamilies": 21,
        "completeCurrentKanjiBodies": 5, "completeCurrentWordBodies": 10,
        "independentReviewersLaunched": 0, "independentRenderedReviewClosed": False,
        "newNativeOrdinarySenseFallbackSemanticAcceptance": e["newNativeOrdinarySenseFallbackSemanticAcceptance"],
        **runtime(), "runtimeChanged": False, "runtimeAccepted": False, "runtimePublished": False,
        "reviewClosed": [], "published": [], "dedicatedWorktreesClean": True,
        "parentLockTouched": False, "optionalHistoricalHelpersAccessed": False, "actualNewPermissionDenials": [],
        "publishedAdditions": 132, "remainingAdditions": 1096, "lastPublishedCommit": before["lastPublishedCommit"],
        "physicalPhoneAcceptance": "outstanding", "generalReleaseAcceptance": "outstanding",
        "wholeProjectComplete": False, "nextBatchStarted": False,
        "finalRunnerPreflight": load(L / "preflight-826-before-issue.json"),
        "originalHistoricalRootKeysCompared": len(before), "allOriginalHistoricalValuesPreserved": True,
        "nextAction": next_action, "blocker": None,
    }
    after = copy.deepcopy(current)
    assert "execution826CoordinatorCheckpoint" not in after
    after["historicalExecution825Before826Sources"] = {
        k: before[k] for k in ("checkpoint", "status", "stage", "nextAction", "blocker")}
    after["execution826CoordinatorCheckpoint"] = checkpoint
    after["execution826StartingState"]["status"] = "signed-local-native-label-source-checkpoint-complete"
    for key in ("checkpoint", "status", "stage", "nextAction", "blocker"):
        after[key] = checkpoint[key]
    allowed_root_changes = {"checkpoint", "status", "stage", "nextAction", "blocker"}
    for key, value in before.items():
        if key not in allowed_root_changes:
            assert after[key] == value, key
    assert after["remainingAdditions"] == 1096 and after["lastPublishedCommit"] == before["lastPublishedCommit"]
    save(L / "checkpoint-826-summary.json", checkpoint)
    temp = C / "progress.json.826-final.tmp"
    save(temp, after)
    assert load(C / "progress.json") == current
    os.replace(temp, C / "progress.json")
    assert load(C / "progress.json") == after
    save(L / "checkpoint-826-final-verification.json",
         {"checkpoint": 826, "signedHead": head, "allOriginalHistoricalValuesPreserved": True,
          "comparedRootKeys": len(before), "runtimeHashesVerified": 8472,
          "dedicatedWorktreesClean": True, "ownerIssueAuthorAndBodyVerified": True,
          "parentLockTouched": False, "projectComplete": False})
    print("Checkpoint826 saved CONTINUE; history preserved, worktrees clean, no runtime acceptance/publication credit.")


if __name__ == "__main__":
    {"archive": archive, "format-packet": format_packet, "finish": finish}[sys.argv[1]]()
