"""Freeze the five native-only labels from the approved dictionary inputs."""
import copy
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import xml.etree.ElementTree as ET

C = Path(__file__).resolve().parent
R = C.parent / "learning-japanese"
L = C / "logs" / "b190c29d-6bc1-4bfd-9074-9fc78b4d935c"
D = R / "docs" / "n1-reviews" / "batch-106-native-sources-826"
BASE = "bf5fe7cb3bdaebd5c59867b13d4fb8c7f0a73140"


def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, data):
    assert not path.exists(), path
    path.write_text(json.dumps(data, ensure_ascii=True, indent=2) + "\n", encoding="utf-8", newline="\n")


def git(*args):
    return subprocess.check_output(["git", "--no-pager", "-C", str(R), *args], encoding="utf-8").strip()


def start():
    original = (C / "progress.json").read_bytes()
    before = json.loads(original)
    assert (before["checkpoint"], before["status"], before["batch"]) == (825, "continue", "106")
    request = (L / "request.txt").read_bytes()
    text = request.decode("utf-8-sig")
    embedded = json.loads(text.split(
        "Current execution checkpoint (complete historical state remains at checkpointHistory paths):", 1)[1])
    snapshot_checkpoint = copy.deepcopy(embedded["execution825CoordinatorCheckpoint"])
    live_checkpoint = before["execution825CoordinatorCheckpoint"]
    for snapshot_record, live_record, key in [
        (snapshot_checkpoint, live_checkpoint, "recordedAt"),
        (snapshot_checkpoint["finalRunnerPreflight"], live_checkpoint["finalRunnerPreflight"], "verifiedAt"),
    ]:
        assert datetime.fromisoformat(snapshot_record[key]) == datetime.fromisoformat(live_record[key])
        snapshot_record[key] = live_record[key]
    assert snapshot_checkpoint == live_checkpoint
    assert git("rev-parse", "HEAD") == BASE
    assert not git("status", "--porcelain", "--untracked-files=all")
    preflight = load(L / "preflight-826.json")
    assert preflight["contentHead"] == BASE and preflight["initiallyWhollyClean"]
    assert not preflight["lockTouched"]
    assert before["execution792HistoryCorrection"]["ownerReportCorrection"].endswith("6721328619")
    assert not (L / "progress-before-826.json").exists()
    (L / "progress-before-826.json").write_bytes(original)
    after = copy.deepcopy(before)
    state = {
        "execution": 826, "batch": "106", "startedAt": datetime.now(timezone.utc).isoformat(),
        "startingHead": BASE, "androidHead": preflight["androidHead"],
        "freshOriginMain": preflight["freshOriginMain"], "runnerPreflight": preflight,
        "scope": "SAME106 five native-only label complete frozen sources and comparison-body inspection; signed LOCAL evidence checkpoint only. No reviewer, Android/native rerun, publication or107.",
        "request": {"sha256": hashlib.sha256(request).hexdigest(), "bytes": len(request),
                    "lines": len(text.splitlines()), "completeFileLoadedAndCheckpointParsed": True,
                    "limits": "Entire request loaded/decoded and final JSON parsed; operative contract, entire approved issue and current825 checkpoint inspected directly. Historical middle parsed, not freshly semantically re-reviewed. Initial state print hit console encoding error; bounded UTF-8 output recovered current state."},
        "artifactPathPreflight": "Committed source packets and approved frozen workspace inputs only; reusable helpers in control; optional historical session recipes not accessed.",
        "parentLockTouched": False, "actualNewPermissionDenials": [],
        "status": "native-label-source-preparation-in-progress",
        "snapshotDiagnostic": "Initial strict checkpoint comparison stopped before any write: request serialization converted recordedAt and finalRunnerPreflight.verifiedAt to +01:00 while live JSON retains +00:00. Both exact instants verified equal; all other checkpoint825 fields match exactly. Live historical values are preserved unchanged.",
    }
    assert "execution826StartingState" not in after
    after["execution826StartingState"] = state
    assert all(after[k] == v for k, v in before.items())
    temp = C / "progress.json.826-start.tmp"
    save(temp, after)
    assert (C / "progress.json").read_bytes() == original
    os.replace(temp, C / "progress.json")
    assert load(C / "progress.json") == after
    save(L / "starting-state-826.json", state)
    print("Starting scope saved; complete live history preserved.")


def prepare():
    assert git("rev-parse", "HEAD") == BASE
    assert not git("status", "--porcelain", "--untracked-files=all")
    p = load(C / "progress.json")
    assert (p["checkpoint"], p["status"], p["batch"]) == (825, "continue", "106")
    assert "execution826StartingState" in p
    assert not D.exists()
    delta_path = R / "docs" / "n1-reviews" / "batch-106-native-825" / "sampled-labels-and-host-delta.json"
    delta = load(delta_path)
    labels = delta["newVersusHost823"]
    assert [x[0] for x in labels] == ["剰", "扱", "獣", "矛", "芋"]
    ids_by_character = {
        "剰": ["1196170", "1355690", "1544260", "1580500", "1584930", "1543910"],
        "扱": ["1153430", "1153440", "2029490", "1153460"],
        "獣": ["1335590", "1335610", "1534040", "1636790"],
        "矛": ["1603450", "1531090"],
        "芋": ["1167960", "1772660", "1005930", "1550780", "1299220"],
    }
    ids = {seq for group in ids_by_character.values() for seq in group}
    snapshot = load(R / "docs" / "n1-source-snapshot.json")
    frozen = {}
    for name, section in [("n1-planning-kanjidic2.xml.gz", "kanjidic2"),
                          ("n1-implementation-JMdict_e.gz", "jmdict")]:
        path = C / "inputs" / name
        assert sha(path) == snapshot["inputs"][name]["sha256"]
        raw = gzip.decompress(path.read_bytes())
        assert hashlib.sha256(raw).hexdigest() == snapshot[section]["xmlSha256"]
        frozen[section] = raw
    characters = {x[0] for x in labels}
    kd = ET.Element("kanjidic2")
    for entry in ET.fromstring(frozen["kanjidic2"]).findall("character"):
        if entry.findtext("literal") in characters:
            kd.append(entry)
    assert {x.findtext("literal") for x in kd} == characters
    jm = ET.Element("JMdict")
    for entry in ET.fromstring(frozen["jmdict"]).findall("entry"):
        if entry.findtext("ent_seq") in ids:
            jm.append(entry)
    assert {x.findtext("ent_seq") for x in jm} == ids
    spellings = {x.text for entry in jm for x in entry.findall("k_ele/keb") + entry.findall("r_ele/reb")}
    word_paths = sorted(R / "words" / (term + ".md") for term in spellings
                        if (R / "words" / (term + ".md")).exists())
    body_paths = [R / "kanji" / (char + ".md") for char, _ in labels] + word_paths
    D.mkdir()
    for name, tree in [("native-only-kanjidic2.xml", kd), ("native-only-jmdict.xml", jm)]:
        ET.indent(tree, space="  ")
        (D / name).write_bytes(ET.tostring(tree, encoding="utf-8", xml_declaration=True) + b"\n")
    articles = []
    bodies = []
    for path in body_paths:
        raw = subprocess.check_output(["git", "-C", str(R), "show", BASE + ":" + path.relative_to(R).as_posix()])
        text = path.read_text(encoding="utf-8")
        assert raw.replace(b"\r\n", b"\n") == text.encode("utf-8")
        title = re.search(r"^title: (.+)$", text, re.M).group(1)
        if path.parent.name == "kanji":
            assert [path.stem, title] in labels
        articles.append({"path": path.relative_to(R).as_posix(), "title": title,
                         "gitBlobSha256": hashlib.sha256(raw).hexdigest(),
                         "normalizedSha256": hashlib.sha256(text.encode("utf-8")).hexdigest(),
                         "lines": len(text.splitlines())})
        bodies.append("FILE " + path.relative_to(R).as_posix() + "\n" +
                      "\n".join(f"{n}:" + (f" {line}" if line else "")
                                for n, line in enumerate(text.splitlines(), 1)))
    (D / "complete-current-articles.txt").write_text("\n\n".join(bodies) + "\n", encoding="utf-8", newline="\n")
    packet = []
    for entry in kd:
        packet.append(json.dumps({"kanji": entry.findtext("literal"),
            "allEnglishMeanings": [m.text for m in entry.findall("reading_meaning/rmgroup/meaning")
                                   if not m.attrib]}, ensure_ascii=False))
    for entry in jm:
        packet.append(json.dumps({"entry": entry.findtext("ent_seq"),
            "spellings": [[(x.tag, x.text, x.attrib) for x in ke] for ke in entry.findall("k_ele")],
            "readings": [[(x.tag, x.text, x.attrib) for x in re] for re in entry.findall("r_ele")],
            "senses": [[(x.tag, x.text, x.attrib) for x in se] for se in entry.findall("sense")]}, ensure_ascii=False))
    (D / "complete-source-reading.txt").write_text("\n".join(packet) + "\n", encoding="utf-8", newline="\n")
    save(D / "source-selection.json", {
        "snapshot": BASE, "nativeDelta": delta_path.relative_to(R).as_posix(),
        "nativeDeltaSha256": sha(delta_path), "labels": labels,
        "completeCharacterRecords": len(kd), "completeDictionaryFamilies": len(jm),
        "idsByCharacter": ids_by_character, "completeCurrentArticles": articles,
        "frozenInputs": {name: snapshot["inputs"][name] for name in [
            "n1-planning-kanjidic2.xml.gz", "n1-implementation-JMdict_e.gz"]},
        "decompressedHashes": {section: snapshot[section]["xmlSha256"] for section in frozen},
        "allCharacterFieldsEnglishMeaningsFamiliesSensesRestrictionsPreserved": True,
        "selectionBasis": "Exact five native labels absent823; complete families explicitly cited by their actual committed cards. All existing word articles matching any spelling/reading in those complete families included, not merely selected easy senses.",
        "attribution": snapshot["dictionaryAttribution"],
        "limits": "Coordinator-provided frozen sources and full comparison bodies; no independent upstream retrieval, fresh review, new teaching, universal pool safety or native/phone certification.",
    })
    print(f"Prepared {len(kd)} full character records, {len(jm)} complete families, {len(body_paths)} complete current articles.")


if __name__ == "__main__":
    {"start": start, "prepare": prepare}[sys.argv[1]]()
