import copy
import datetime
import hashlib
import json
import os
from pathlib import Path

CONTROL = Path(r"C:\Users\stop-\n1-kanji-workspace\control")
SESSION = "d4043c76-1b27-483b-a35c-59b66b41e3e7"
LOG = CONTROL / "logs" / SESSION
path = CONTROL / "progress.json"
original = json.loads(path.read_text(encoding="utf-8-sig"))
assert original["checkpoint"] == 790 and original["batch"] == "103"
assert original["status"] == "continue"
backup = LOG / "progress-before-791.json"
assert not backup.exists()
backup.write_bytes(path.read_bytes())
request = (LOG / "request.txt").read_bytes()
state = {
    "execution": 791,
    "batch": "103",
    "startedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "startingHead": "93dac09f2a1e3a1918e18662049dff70e26a0025",
    "androidHead": "bf30cdead8515739bc0e671d57a54b9a3109dd46",
    "freshOriginMain": "a38f4cf554300ce34ee65aada79e87b7c9d0319e",
    "scope": "SAME103 exact compiled790 APK native execution and bounded coordinator PNG inspection only; no reviewer/publication/104.",
    "request": {
        "sha256": hashlib.sha256(request).hexdigest(),
        "bytes": len(request),
        "completeFileLoadedAndCheckpointParsed": True,
        "limits": "Entire request loaded and checkpoint decoded; operative contract, entire approved issue and final790 inspected directly. Historical middle parsed, not freshly semantically re-reviewed.",
    },
    "runnerPreflight": json.loads((LOG / "preflight-791.json").read_text(encoding="utf-8-sig")),
    "artifactPathPreflight": "Approved committed packets/frozen workspace inputs/control helpers only; optional historical-session recipes not accessed.",
    "status": "native-in-progress",
}
assert "execution791StartingState" not in original
updated = copy.deepcopy(original)
updated["execution791StartingState"] = state
temporary = CONTROL / "progress.json.791-start.tmp"
assert not temporary.exists()
temporary.write_text(json.dumps(updated, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
os.replace(temporary, path)
reread = json.loads(path.read_text(encoding="utf-8-sig"))
assert all(reread[key] == value for key, value in original.items())
(LOG / "starting-state-791.json").write_text(json.dumps(state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print("Starting scope persisted; all original historical values unchanged.")
