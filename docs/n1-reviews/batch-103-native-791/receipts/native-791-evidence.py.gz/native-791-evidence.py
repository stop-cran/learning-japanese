import datetime
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import shutil
import subprocess
import zipfile

C = Path(__file__).resolve().parent
R = C.parent / "learning-japanese"
A = C.parent / "kanji-cards-android"
SESSION = "d4043c76-1b27-483b-a35c-59b66b41e3e7"
L = C / "logs" / SESSION
RAW = C / "artifacts" / "batch-103-native-791"
D = R / "docs" / "n1-reviews" / "batch-103-native-791"
BASE = "93dac09f2a1e3a1918e18662049dff70e26a0025"
APP = "bf30cdead8515739bc0e671d57a54b9a3109dd46"


def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    assert not path.exists(), path
    path.write_text(json.dumps(value, ensure_ascii=True, indent=2) + "\n", encoding="utf-8")
    assert load(path) == value


def git(*args, root=R):
    return subprocess.check_output(["git", "--no-pager", "-C", str(root), *args], encoding="utf-8").strip()


def runtime():
    spec = importlib.util.spec_from_file_location("preparation790", C / "prepare-batch-103-native-790.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    result = module.runtime()
    packet = load(R / "docs" / "n1-reviews" / "batch-103-native-790" / "compiled-packet.json")
    prep, compiled = packet["preparation"], packet["compilation"]
    for path, digest in [
        (prep["archive"], prep["archiveSha256"]), (prep["fixture"], prep["fixtureSha256"]),
        (compiled["appApk"], compiled["appApkSha256"]), (compiled["testApk"], compiled["testApkSha256"]),
    ]:
        assert sha(Path(path)) == digest, path
    manifest_bytes = (R / "manifest.json").read_bytes()
    manifest = json.loads(manifest_bytes)
    assert result["manifestSha256"] == prep["manifestSha256"]
    assert subprocess.check_output(["git", "-C", str(R), "show", prep["contentSnapshot"] + ":manifest.json"]) == manifest_bytes
    with zipfile.ZipFile(prep["archive"]) as archive:
        names = archive.namelist()
        prefix = names[0].split("/")[0] + "/"
        assert len(names) == len(set(names)) == 8485 <= 18000
        assert all(n.startswith(prefix) and "\\" not in n and ".." not in n.split("/")
                   and not n.startswith("/") and not re.search(r"(^|/)[^/]*:", n) for n in names)
        assert not any("/docs/" in n or "/tools/" in n for n in names)
        assert archive.read(prefix + "manifest.json") == manifest_bytes
        retained, count, media = len(manifest_bytes), 0, 0
        for section_name, section in manifest.items():
            if not isinstance(section, dict):
                continue
            for name, digest in section.items():
                assert len(name.split("/")) == 2 and ".." not in name.split("/")
                data = archive.read(prefix + name)
                local = (R / name).read_bytes()
                binary = section_name in {"images", "audio", "listeningTaskAudio", "listeningTaskImages"}
                limit = 150 * 1024 if section_name in {"images", "listeningTaskImages"} else (
                    512 * 1024 if section_name in {"audio", "listeningTaskAudio"} else 2 * 1024 * 1024)
                assert len(data) <= limit, name
                normalized = data if binary else data.replace(b"\r\n", b"\n")
                assert hashlib.sha256(normalized).hexdigest() == digest, name
                assert normalized == (local if binary else local.replace(b"\r\n", b"\n")), name
                retained += len(data)
                count += 1
                if section_name in {"listeningTaskAudio", "listeningTaskImages"}:
                    media += len(data)
        inflated = sum(info.file_size for info in archive.infolist())
        compressed = Path(prep["archive"]).stat().st_size
        assert count == 8463 and retained == 44405793 <= 56 * 1024 * 1024
        assert inflated == 44674131 <= 80 * 1024 * 1024
        assert compressed == 30490568 <= 42 * 1024 * 1024
        assert media == 5893602 <= 20 * 1024 * 1024
    result.update({
        "manifestEqualsCompiledArchive": True, "archiveContentSnapshot": prep["contentSnapshot"],
        "archiveSha256": prep["archiveSha256"], "zipEntries": len(names), "compressedBytes": compressed,
        "inflatedBytes": inflated, "retainedBytes": retained, "listeningTaskMediaBytes": media,
        "allOriginalBudgetsAndPerFilePathMediaGuardsPassed": True,
    })
    return result


def results():
    attempt = load(RAW / "execution.json")
    assert attempt["passed"] and attempt["nativeExecuted"] and attempt["failure"] is None
    assert attempt["terminalSuccessCases"] == 2 and attempt["adbExitCode"] == 0
    assert attempt["ownedHelperStopped"] and attempt["ownedQemuStopped"]
    assert attempt["coordinatorHead"] == BASE and attempt["androidSnapshot"] == APP
    assert attempt["prelaunch"]["connections"] == []
    assert attempt["heapGrowth"] == "192m" and attempt["heapSize"] == "576m"
    assert attempt["network"] == "Active default network: none"
    assert not any(attempt[k] for k in ("parentLockTouched", "guestOrAppHeapChanged", "guardsChanged"))
    raw = (RAW / "instrumentation.txt").read_text(encoding="utf-8-sig")
    assert len(re.findall(r"(?m)^INSTRUMENTATION_STATUS_CODE: 0\s*$", raw)) == 2
    assert "OK (2 tests)" in raw
    assert not re.search(r"INSTRUMENTATION_STATUS_CODE: -[234]|FAILURES|INSTRUMENTATION_FAILED|ignored|assumptionFailure", raw)
    route = load(RAW / "n1-103-article-route.json")
    assert route["passed"] and route["archiveRequests"] == 1
    assert (route["importedKanji"], route["importedWords"], route["n1Cards"], route["problems"],
            route["acceptedReadingParserEpoch"], route["acceptedMeaningParserEpoch"]) == (1126, 5077, 135, 0, 1, 1)
    assert (route["mappedReciprocalPairs"], route["directedLinkTransitions"],
            route["activatedBaselinePairs"], route["changedReusedArticles"],
            route["changedReusedNavigationTransitions"]) == (3, 6, 0, 3, 3)
    assert all(route[k] for k in (
        "reciprocalLinkAndSystemBack", "meaningQuestionAndFeedback", "twoCuratedKeysPersistedGoodAndDone",
        "drawingTraceThenRecall", "drawingGradeRecordedOnNext", "offline"))
    assert route["touchInjectedReferenceStrokes"] == 7
    assert route["fullOnyomi"] == route["fullProjectionOnyomi"] == route["fullProjectionQuizOnyomi"] == ["レイ"]
    assert route["fullKunyomi"] == route["fullProjectionKunyomi"] == route["fullProjectionQuizKunyomi"] == ["はげ.む", "はげ.ます"]
    assert route["quizOnKeys"] == ["れい"] and route["quizKunKeys"] == ["はげむ"]
    assert (route["actualN1CuratedAvailable"], route["actualN1FallbackOptions"]) == (1, 2)
    assert route["curatedDistractorLevels"] == {"劣": 1, "万": 5, "厚": 2}
    for key, count in {
        "productionBuilderN1AndAllExactChoices": 64, "kanjiDirectGuardChecks": 896,
        "nontransitiveNeighborChecks": 192, "preservedWordGuardChecks": 1728,
        "wordNontransitiveChecks": 128,
    }.items():
        assert len(route[key]) == count, key
    for row in route["kanjiDirectGuardChecks"]:
        assert row["target"] in row["options"] and row["excluded"] not in row["options"]
        assert len(row["options"]) == len(set(row["options"]))
    assert all(set(r["options"]) == {r["target"], r["neighbor"]} for r in route["nontransitiveNeighborChecks"])
    raster = load(RAW / "n1-103-font-raster.json")
    assert (raster["individualGlyphProbes"], raster["wholeWordRasterProbes"], raster["panels"],
            len(raster["rows"]), raster["sdk"], raster["fontScale"]) == (188, 12, 6, 200, 35, 1)
    assert len([r for r in raster["rows"] if r.get("character") == "厂" and r["hasGlyph"]]) == 4
    return attempt, route, raster


def archive():
    progress = load(C / "progress.json")
    assert (progress["checkpoint"], progress["status"], progress["batch"]) == (790, "continue", "103")
    for root, head in [(R, BASE), (A, APP)]:
        assert git("rev-parse", "HEAD", root=root) == head
        assert git("log", "-1", "--format=%G?", root=root) == "G"
        assert not git("status", "--porcelain", "--untracked-files=all", root=root)
    verified_runtime = runtime()
    attempt, route, raster = results()
    inspection = load(L / "coordinator-inspection-791.json")
    assert not inspection["independentRenderedReviewClosed"]
    pngs = sorted(p.name for p in RAW.glob("*.png"))
    assert inspection["totalOriginalPngs"] == len(pngs)
    assert all(name in pngs for name in inspection["viewedOriginalPngs"])
    assert inspection["viewedCount"] == len(inspection["viewedOriginalPngs"])
    D.mkdir(exist_ok=False)
    artifacts = []

    def preserve(source, destination):
        destination.parent.mkdir(exist_ok=True, parents=True)
        assert not destination.exists()
        if destination.suffix == ".gz":
            destination.write_bytes(gzip.compress(source.read_bytes(), mtime=0))
            assert gzip.decompress(destination.read_bytes()) == source.read_bytes()
        else:
            shutil.copyfile(source, destination)
        artifacts.append({
            "file": str(destination.relative_to(D)).replace("\\", "/"),
            "sourceBytes": source.stat().st_size, "sourceSha256": sha(source),
            "storedSha256": sha(destination),
        })

    for source in sorted(RAW.iterdir()):
        assert source.is_file()
        preserve(source, D / "native" / (source.name if source.suffix == ".png" else source.name + ".gz"))
    for name in ("preflight-791.ps1", "start-checkpoint-791.py", "run-791-native.ps1", "native-791-evidence.py"):
        preserve(C / name, D / "receipts" / (name + ".gz"))
    for name in ("preflight-791.json", "preflight-791-native.json", "starting-state-791.json"):
        preserve(L / name, D / "receipts" / (name + ".gz"))
    preserve(R / "docs" / "n1-reviews" / "batch-103-native-790" / "compiled-packet.json",
             D / "receipts" / "790-compiled-packet.json.gz")
    save(D / "artifact-index.json", artifacts)
    save(D / "coordinator-inspection.json", inspection)
    labels = {(o["kanji"], o["title"]) for row in route["productionBuilderN1AndAllExactChoices"] for o in row["options"]}
    labels.update((o["kanji"], o["title"]) for o in route["exactDefaultMeaningOptions"])
    host = {(r["kanji"], r["title"]) for r in load(
        R / "docs" / "n1-reviews" / "batch-103-host-789" / "sampled-labels.json")}
    comparison = {
        "nativeUniqueLabelCount": len(labels), "nativeLabels": [list(x) for x in sorted(labels)],
        "newVersusHost789": [list(x) for x in sorted(labels - host)],
        "absentVersusHost789": [list(x) for x in sorted(host - labels)],
        "exactLiveDefault": route["exactDefaultMeaningOptions"],
        "limits": "Actual production-builder64 sampled choices and actual live N1 default labels; ordinary-secondary-sense semantic acceptance UNVERIFIED pending complete applicable frozen dictionary evidence and both original-family rendered confirmations.",
    }
    save(D / "sampled-labels-and-host-delta.json", comparison)
    evidence = {
        "schemaVersion": 1, "execution": 791, "batch": "103",
        "stage": "native-two-terminal-cases-passed-awaiting-original-family-rendered-confirmations",
        "recordedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "startingState": progress["execution791StartingState"], "testedContentHead": BASE,
        "archiveContentSnapshot": route["contentSnapshot"], "qualifiedAndroidHead": APP,
        "runtime": verified_runtime, "nativeAttempt": attempt,
        "nativeResults": {
            "terminalSuccessCases": 2, "terminalFailureCases": 0, "skipped": 0,
            "productionContentSyncCalls": 1, "preparseCalls": 0,
            "importedCounts": {"kanji": 1126, "words": 5077, "n1": 135, "problems": 0},
            "acceptedReadingParserEpoch": 1, "acceptedMeaningParserEpoch": 1,
            "directSymmetricGuardChecks": 896, "nontransitiveNeighborChecks": 192,
            "preservedWordGuardChecks": 1728, "selectedWordNontransitiveChecks": 128,
            "productionBuilderChoices": 64, "individualGlyphProbes": 188,
            "wholeWordRasterProbes": 12, "fontPanels": 6, "scopedHan": 47,
            "explicitFallbackCodepoint": "厂 U+5382, absent from all three bundled cmaps",
            "nativePngs": len(pngs), "twoCuratedKeysPersistedGoodAndDone": True,
            "selectedSourceEntries": 3, "actualKeys": route["quizOnKeys"] + route["quizKunKeys"],
            "nonOfferedHagemasuProtected": True, "drawingStrokes": 7,
            "mappedReciprocalPairs": 3, "directedLinkTransitions": 6,
            "activatedBaselinePairs": 0, "changedReusedArticles": 3,
            "offline": True, "systemBack": True,
        },
        "sampledLabels": comparison, "coordinatorInspection": inspection,
        "nativeExecutionComplete": True, "independentReviewersLaunched": 0,
        "independentRenderedReviewClosed": False,
        "ordinarySenseFallbackSemanticAcceptance": "UNVERIFIED",
        "runtimeChanged": False, "manifestChanged": False, "runtimeAccepted": False, "runtimePublished": False,
        "reviewClosed": [], "published": [], "nextBatchStarted": False,
        "publishedAdditions": 129, "remainingAdditions": 1099,
        "lastPublishedCommit": progress["lastPublishedCommit"],
        "physicalPhoneAcceptance": "outstanding", "generalReleaseAcceptance": "outstanding",
        "wholeProjectComplete": False, "actualNewPermissionDenials": [],
        "limits": [
            "Exact790 compiled APKs executed without rebuilding archive or app; debug APKs, not an owner-signed release.",
            "Other N1 meanings/readings postponed, two historical meaning logs seeded; disposable fixture, no owner progress. No drawing state seeded.",
            "Reference-stroke touch injection and deliberate recall failure are not human handwriting recognition, learning mastery or measured effectiveness.",
            "Full route assertions do not establish equal fresh visual reading of every PNG or native-speaker certification.",
            "Sampled fallback ordinary-secondary-sense semantic acceptance remains UNVERIFIED pending source-backed rendered confirmations.",
            "788 textual and789 HOST evidence inherited, not repeated; all original reports/process/read/source limitations preserved.",
            "Prior780 noncompliant Claude report remains unaccepted;781 dependent supplement is not retroacceptance;782 rescaled images are not original pixels.",
            "No publication, physical-phone, general-release or whole-set acceptance; all original gates remain mandatory.",
        ],
    }
    save(R / "docs" / "n1-sources" / "execution-791.json", evidence)
    save(L / "native-evidence-791-summary.json", {
        "nativeResults": evidence["nativeResults"], "runtime": verified_runtime,
        "sampledLabels": comparison, "nativePngs": len(pngs),
    })
    print(json.dumps({"archived": str(D), "nativePngs": len(pngs), "newLabels": comparison["newVersusHost789"]}, ensure_ascii=True))


if __name__ == "__main__":
    archive()
