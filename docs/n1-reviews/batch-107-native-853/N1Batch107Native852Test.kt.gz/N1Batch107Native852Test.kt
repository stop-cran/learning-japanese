package io.github.stopcran.kanji.ui

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.os.Build
import androidx.activity.ComponentActivity
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.junit4.createEmptyComposeRule
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.res.ResourcesCompat
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.room.withTransaction
import androidx.test.core.app.ActivityScenario
import androidx.test.platform.app.InstrumentationRegistry
import io.github.stopcran.kanji.KanjiApp
import io.github.stopcran.kanji.MainActivity
import io.github.stopcran.kanji.R
import io.github.stopcran.kanji.core.content.ContentParser
import io.github.stopcran.kanji.core.content.RepoSource
import io.github.stopcran.kanji.core.quiz.QuizBuilder
import io.github.stopcran.kanji.core.reading.ReadingKind
import io.github.stopcran.kanji.core.srs.KanjiFont
import io.github.stopcran.kanji.core.srs.StudyMode
import io.github.stopcran.kanji.core.words.WordDirection
import io.github.stopcran.kanji.core.words.WordQuizBuilder
import io.github.stopcran.kanji.data.*
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.File
import java.security.MessageDigest
import java.util.UUID


private fun disposable107() {
    assertEquals("true", InstrumentationRegistry.getArguments().getString("n1Disposable"))
    assertTrue(Build.HARDWARE in setOf("ranchu", "goldfish"))
}

class N1Batch107Glyph852Test {
    @get:Rule val rule = createAndroidComposeRule<ComponentActivity>()

    @Test fun intuitionScopedHanFallbackAndLookalikesAcrossFourFamilies() {
        disposable107()
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val fonts = listOf(KanjiFont.Gothic, KanjiFont.Mincho, KanjiFont.Textbook, KanjiFont.Brush)
        val pages = listOf("与 且 久 予 人 代 会 入 分 判", "力 助 勘 勤 口 外 失 宀 定 室", "察 当 思 想 感 払 支 敗 数 料", "断 日 明 月 期 査 比 甚 知 私", "答 算 給 考 胸 色 規 覚 解 計", "誤 識 議 走 足 辵 辶 連 週 違", "遠 選 金 鈍 鋭 間 韋 願", "勘 勤 助 期 甚 且 力 月 宀 辵 辶 韋 勘定 勘違い")
        val page = mutableStateOf(0)
        rule.setContent {
            MaterialTheme {
                Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Batch 107: intuition / radicals / look-alikes / fallback")
                    Text("Panel ${page.value + 1} / ${pages.size}")
                    fonts.forEach { font ->
                        Text(font.name)
                        Text(pages[page.value], fontFamily = font.family(), fontSize = 18.sp, lineHeight = 26.sp)
                    }
                    Text("Inspect all 68 scoped and comparison Han in all four families/default, including 宀 辵 辶 韋. Cmap presence and hashes are not readability.", fontSize = 16.sp)
                }
            }
        }
        val typefaces = listOf(Typeface.DEFAULT,
            requireNotNull(ResourcesCompat.getFont(context, R.font.kanji_mincho)),
            requireNotNull(ResourcesCompat.getFont(context, R.font.kanji_textbook)),
            requireNotNull(ResourcesCompat.getFont(context, R.font.kanji_brush)))
        val rows = JSONArray()
        for ((index, typeface) in typefaces.withIndex()) {
            val hashes = mutableSetOf<String>()
            for (char in listOf("与", "且", "久", "予", "人", "代", "会", "入", "分", "判", "力", "助", "勘", "勤", "口", "外", "失", "宀", "定", "室", "察", "当", "思", "想", "感", "払", "支", "敗", "数", "料", "断", "日", "明", "月", "期", "査", "比", "甚", "知", "私", "答", "算", "給", "考", "胸", "色", "規", "覚", "解", "計", "誤", "識", "議", "走", "足", "辵", "辶", "連", "週", "違", "遠", "選", "金", "鈍", "鋭", "間", "韋", "願")) {
                val paint = Paint(Paint.ANTI_ALIAS_FLAG).also {
                    it.typeface = typeface
                    it.textSize = 96f
                    it.textLocale = java.util.Locale.JAPAN
                }
                assertTrue("$char ${fonts[index]}", paint.hasGlyph(char))
                val image = Bitmap.createBitmap(if (char.length > 1) 256 else 128, 128, Bitmap.Config.ARGB_8888)
                Canvas(image).drawText(char, 8f, 104f, paint)
                val pixels = IntArray(image.width * image.height)
                image.getPixels(pixels, 0, image.width, 0, 0, image.width, image.height)
                assertTrue(pixels.any { it != 0 })
                val bytes = java.nio.ByteBuffer.allocate(pixels.size * 4)
                    .also { it.asIntBuffer().put(pixels) }.array()
                val hash = MessageDigest.getInstance("SHA-256").digest(bytes)
                    .joinToString("") { "%02x".format(it) }
                hashes.add(hash)
                rows.put(JSONObject().put("character", char).put("font", fonts[index].name)
                    .put("hasGlyph", true).put("nativePaintRasterSha256", hash))
                image.recycle()
            }
            for (word in listOf("勘", "勘定", "勘違い")) {
                val paint = Paint(Paint.ANTI_ALIAS_FLAG).also {
                    it.typeface = typeface
                    it.textSize = 96f
                    it.textLocale = java.util.Locale.JAPAN
                }
                // hasGlyph tests multi-character ligatures, not ordinary word coverage.
                val image = Bitmap.createBitmap(kotlin.math.ceil(paint.measureText(word)).toInt() + 16, 128, Bitmap.Config.ARGB_8888)
                Canvas(image).drawText(word, 8f, 104f, paint)
                val pixels = IntArray(image.width * image.height)
                image.getPixels(pixels, 0, image.width, 0, 0, image.width, image.height)
                for (position in word.indices) {
                    val left = (8f + paint.measureText(word, 0, position)).toInt()
                    val right = kotlin.math.ceil(8f + paint.measureText(word, 0, position + 1)).toInt()
                    assertTrue("Word raster bounds $word ${fonts[index]}", left >= 0 && right <= image.width && left < right)
                    assertTrue("Blank word character ${word[position]} ${fonts[index]}",
                        (0 until image.height).any { y -> (left until right).any { x -> pixels[y * image.width + x] != 0 } })
                }
                val bytes = java.nio.ByteBuffer.allocate(pixels.size * 4)
                    .also { it.asIntBuffer().put(pixels) }.array()
                val hash = MessageDigest.getInstance("SHA-256").digest(bytes)
                    .joinToString("") { "%02x".format(it) }
                rows.put(JSONObject().put("word", word).put("font", fonts[index].name)
                    .put("renderedCharactersNonblank", word.length).put("nativePaintRasterSha256", hash))
                image.recycle()
            }
        }
        assertEquals(284, rows.length())
        for (index in pages.indices) {
            rule.runOnIdle { page.value = index }
            rule.waitForIdle()
            rule.onAllNodesWithText(pages[index]).assertCountEquals(4)
            for (fontIndex in fonts.indices) rule.onAllNodesWithText(pages[index])[fontIndex].assertIsDisplayed()
            File(context.getExternalFilesDir(null), "n1-107-font-panel-${index + 1}.png").outputStream().use {
                assertTrue(rule.onRoot().captureToImage().asAndroidBitmap().compress(Bitmap.CompressFormat.PNG, 100, it))
            }
        }
        File(context.getExternalFilesDir(null), "n1-107-font-raster.json").writeText(JSONObject()
            .put("fingerprint", Build.FINGERPRINT).put("sdk", Build.VERSION.SDK_INT)
            .put("fontScale", context.resources.configuration.fontScale).put("rows", rows)
            .put("individualGlyphProbes", 272).put("wholeWordRasterProbes", 12).put("panels", 8)
            .put("limits", "65 Han from six actual articles plus 3 earlier comparison Han across four production families/default and 8 Compose panels. Inspect 宀, 辵, 辶 and 韋 fallback and 勘/勤/助/期 look-alikes on the actual screenshots. Hashes are not readability or fallback-face evidence. Actual PNG inspection required; emulator not phone.")
            .toString(2))
    }
}


class N1Batch107Article852Test {
    @get:Rule val rule = createEmptyComposeRule()
    private lateinit var app: KanjiApp
    private lateinit var scenario: ActivityScenario<MainActivity>

    @Test fun fullSingleImportIntuitionGuardsReadingsThreeWordsElevenStrokesOfflineAndBack() {
        disposable107()
        val instrumentation = InstrumentationRegistry.getInstrumentation()
        app = instrumentation.targetContext.applicationContext as KanjiApp
        val source = RepoSource("acceptance-fixture", "n1-107-${UUID.randomUUID()}", "main")
        val head = "996898d775c61af7188c6da5b4644b838f999236"
        assertTrue(app.settings.setSource("https://github.com/${source.id}", source.branch))
        var archiveRequests = 0
        val http = ContentHttp { url, _, _, _ ->
            val input = when (url) {
                "https://api.github.com/repos/${source.id}/commits/main" -> ByteArrayInputStream(head.toByteArray())
                source.commitZipUrl(head) -> {
                    archiveRequests++
                    instrumentation.context.assets.open("n1-batch-107-996898d7-lf-envelope.zip")
                }
                else -> error("Unexpected fixture request: $url")
            }
            object : ContentResponse {
                override val code = 200
                override val body = input
                override fun header(name: String): String? = null
                override fun close() = input.close()
            }
        }
        val result = runBlocking { ContentSync(app.db, app.settings.sync, http).sync(source, force = true) }
        assertTrue(result.toString(), result is SyncResult.Updated)
        val updated = result as SyncResult.Updated
        assertEquals(1, archiveRequests)
        assertEquals(1130, updated.kanji)
        assertEquals(5080, updated.words)
        assertTrue(updated.problems.toString(), updated.problems.isEmpty())
        val meta = requireNotNull(runBlocking { app.db.content().meta(source.id) })
        assertEquals("d19ddd349a584532", meta.contentVersion)
        assertEquals(0, meta.problems)
        assertNull(meta.grammarProblem)
        assertNull(meta.listeningProblem)
        assertNull(meta.grammarCurriculumProblem)
        assertEquals(1, ContentParser.KANJI_READING_PARSER_EPOCH)
        assertEquals(ContentParser.KANJI_READING_PARSER_EPOCH, meta.kanjiReadingParserEpoch)
        assertEquals(1, ContentParser.KANJI_MEANING_PARSER_EPOCH)
        assertEquals(ContentParser.KANJI_MEANING_PARSER_EPOCH, meta.kanjiMeaningParserEpoch)
        val all = runBlocking { app.db.content().kanjiLite(source.id) }
        val n1 = all.filter { it.jlpt == 1 }
        assertEquals(139, n1.size)
        assertEquals(n1.map { it.kanji }.toSet(),
            all.filter { "jlpt-n1" in it.tags.splitSep() }.map { it.kanji }.toSet())
        val target = n1.single { it.kanji == "勘" }
        val guards = listOf("感", "思", "考", "判", "査", "比", "算", "察")
        assertEquals(guards, target.quizExclusions.splitSep())
        val observed = runBlocking { app.db.content().observeKanjiLite(source.id).first() }.single { it.kanji == "勘" }
        assertEquals(guards, observed.toQuizCard().quizExclusions)
        val full = requireNotNull(runBlocking { app.db.content().kanjiCard(source.id, "勘") })
        assertEquals(guards, full.quizExclusions.splitSep())
        assertEquals(guards, full.toQuizCard().quizExclusions)
        assertEquals(guards, runBlocking { app.db.content().kanji(source.id) }
            .single { it.kanji == "勘" }.toQuizCard().quizExclusions)
        assertEquals(listOf("勤", "助", "期"), target.distractors.splitSep())
        assertEquals(listOf("カン"), target.onyomi.splitSep())
        assertEquals(emptyList<String>(), target.kunyomi.splitSep())
        assertEquals(listOf("カン"), target.quizOnyomi?.splitSep())
        assertEquals(emptyList<String>(), target.quizKunyomi?.splitSep())
        assertEquals(listOf("かん"), target.toReadingCard().quizKeys(ReadingKind.On))
        assertEquals(emptyList<String>(), target.toReadingCard().quizKeys(ReadingKind.Kun))
        assertNull(io.github.stopcran.kanji.core.reading.KanjiReadingQuiz.question(
            target.toReadingCard(), ReadingKind.Kun, all.map { it.toReadingCard() }, kotlin.random.Random(852)))
        assertEquals(emptyList<String>(), full.kunyomi.splitSep())
        assertEquals(emptyList<String>(), full.quizKunyomi?.splitSep())
        assertEquals(listOf("カン"), full.onyomi.splitSep())
        assertEquals(listOf("カン"), full.quizOnyomi?.splitSep())
        val expectedMeanings = mapOf("勘" to "intuition; hunch", "勤" to "employment; diligence", "助" to "help; rescue", "期" to "period; term")
        val curatedIds = listOf("勤", "助", "期")
        assertEquals(mapOf("勤" to 3, "助" to 3, "期" to 3),
            all.filter { it.kanji in curatedIds }.associate { it.kanji to it.jlpt })
        assertEquals(emptySet<String>(), n1.filter { it.kanji in curatedIds }.map { it.kanji }.toSet())
        val custom = all.filter { it.kanji in expectedMeanings }
        val randomSubset = listOf(target) +
            n1.filter { it.kanji != "勘" }.shuffled(kotlin.random.Random(852)).take(15)
        val choices = JSONArray()
        for ((poolName, pool) in listOf("N1" to n1, "All" to all,
            "boundedCustom" to custom, "randomN1Subset" to randomSubset)) {
            val cards = pool.map { it.toQuizCard() }
            val quizTarget = cards.single { it.kanji == "勘" }
            val available = curatedIds.filter { id -> cards.any { it.kanji == id } }
            repeat(16) { seed ->
                val options = QuizBuilder.options(quizTarget, cards, kotlin.random.Random(seed))
                assertEquals(4, options.size)
                assertEquals(4, options.map { it.title }.toSet().size)
                assertEquals(1, options.count { it.kanji == "勘" })
                val offeredCards = options.map { option -> cards.single { it.kanji == option.kanji } }
                for (left in offeredCards) for (right in offeredCards.filter { it.kanji != left.kanji })
                    assertFalse(right.kanji in left.quizExclusions || left.kanji in right.quizExclusions)
                assertTrue(options.none { it.kanji in guards })
                assertTrue(available.all { id -> options.any { it.kanji == id } })
                assertTrue(options.all { o -> pool.any { it.kanji == o.kanji && it.title == o.title } })
                if (available.size == 3) assertEquals(expectedMeanings, options.associate { it.kanji to it.title })
                choices.put(JSONObject().put("pool", poolName).put("seed", seed)
                    .put("poolMembershipInOrder", JSONArray(pool.map { it.kanji }))
                    .put("options", JSONArray().also { rows ->
                        options.forEach { rows.put(JSONObject().put("kanji", it.kanji).put("title", it.title)) }
                    }))
            }
        }
        assertEquals(64, choices.length())
        val allCards = all.map { it.toQuizCard() }
        val guardChecks = JSONArray()
        for (excludedId in guards) {
            val pair = allCards.filter { it.kanji in setOf("勘", excludedId) }
            assertEquals(2, pair.size)
            for (quizTarget in pair) {
                val excluded = pair.single { it.kanji != quizTarget.kanji }
                repeat(16) { seed ->
                    val sampled = pair + allCards.filter { it.kanji !in setOf("勘", excludedId) }
                        .shuffled(kotlin.random.Random(852 + seed)).take(seed)
                    for ((poolName, pool) in listOf(
                        "N1" to n1.map { it.toQuizCard() }, "All" to allCards,
                        "boundedCustom" to (pair + allCards.filter { it.kanji in curatedIds }),
                        "randomN1Subset852" to (pair + randomSubset.map { it.toQuizCard() }
                            .filter { it.kanji !in setOf("勘", excludedId) }),
                        "sampledFiltered" to sampled, "pairOnly" to pair,
                        "targetOutsidePool" to sampled.filter { it.kanji != quizTarget.kanji },
                    )) {
                        val options = QuizBuilder.options(quizTarget, pool, kotlin.random.Random(seed))
                        assertEquals(1, options.count { it.kanji == quizTarget.kanji })
                        assertFalse("Direct guard leaked $excludedId $poolName", options.any { it.kanji == excluded.kanji })
                        assertTrue(options.size in 1..4)
                        val offeredCards = options.map { option -> allCards.single { it.kanji == option.kanji } }
                        for (left in offeredCards) for (right in offeredCards.filter { it.kanji != left.kanji })
                            assertFalse(right.kanji in left.quizExclusions || left.kanji in right.quizExclusions)
                        assertEquals(options.size, options.map { it.title }.toSet().size)
                        assertTrue(options.all { it.kanji == quizTarget.kanji || pool.any { p -> p.kanji == it.kanji } })
                        if (poolName == "pairOnly") assertEquals(1, options.size)
                        guardChecks.put(JSONObject().put("target", quizTarget.kanji).put("excluded", excluded.kanji)
                            .put("pool", poolName).put("seed", seed)
                            .put("poolMembershipInOrder", JSONArray(pool.map { it.kanji }))
                            .put("options", JSONArray(options.map { it.kanji })))
                    }
                }
            }
        }
        assertEquals(1792, guardChecks.length())
        val nontransitiveChecks = JSONArray()
        for (left in guards) for (right in guards.filter { it != left }) {
            val pair = allCards.filter { it.kanji in setOf(left, right) }
            val leftCard = pair.single { it.kanji == left }
            val rightCard = pair.single { it.kanji == right }
            if (right in leftCard.quizExclusions || left in rightCard.quizExclusions) continue
            repeat(16) { seed ->
                val options = QuizBuilder.options(leftCard, pair, kotlin.random.Random(seed))
                assertEquals(setOf(left, right), options.map { it.kanji }.toSet())
                nontransitiveChecks.put(JSONObject().put("target", left).put("neighbor", right).put("seed", seed)
                    .put("options", JSONArray(options.map { it.kanji })))
            }
        }
        assertTrue(nontransitiveChecks.length() > 0)
        val hypothesisChecks = JSONArray()
        val hypothesisPair = allCards.filter { it.kanji in setOf("勘", "識") }
        assertEquals(2, hypothesisPair.size)
        for (hypothesisTarget in hypothesisPair) repeat(16) { seed ->
            val options = QuizBuilder.options(hypothesisTarget, hypothesisPair, kotlin.random.Random(seed))
            assertEquals(setOf("勘", "識"), options.map { it.kanji }.toSet())
            hypothesisChecks.put(JSONObject().put("target", hypothesisTarget.kanji).put("seed", seed)
                .put("options", JSONArray().also { rows ->
                    options.forEach { rows.put(JSONObject().put("kanji", it.kanji).put("title", it.title)) }
                }))
        }
        assertEquals(32, hypothesisChecks.length())
        val words = runBlocking { app.db.content().wordsLite(source.id) }.map { it.toCard() }
        val preserved = mapOf("勘" to listOf("感覚"), "勘定" to listOf("計算", "支払う", "給与", "払う", "代金", "料金"), "勘違い" to listOf("誤解", "間違い", "誤り", "ミス", "失敗"), "会計" to listOf("勘定"))
        val wordChecks = JSONArray()
        for ((id, excludedIds) in preserved) {
            val left = words.single { it.word == id }
            assertEquals(excludedIds, left.quizExclusions)
            assertEquals(mapOf("勘" to 3, "勘定" to 3, "勘違い" to 2, "会計" to 3)[id], left.jlpt)
            for (excludedId in excludedIds) {
                val right = words.single { it.word == excludedId }
                val pair = listOf(left, right)
                for (wordTarget in pair)
                    for (direction in listOf(WordDirection.JpToEn, WordDirection.EnToJp)) repeat(16) { seed ->
                        val options = WordQuizBuilder.options(wordTarget, pair, direction, kotlin.random.Random(seed))
                        assertEquals(listOf(wordTarget.word), options.map { it.word })
                        wordChecks.put(JSONObject().put("declaredOn", id).put("excluded", excludedId)
                            .put("target", wordTarget.word).put("pool", "pairOnly")
                            .put("direction", direction.name).put("seed", seed)
                            .put("label", options.single().label))
                    }
            }
        }
        assertEquals(832, wordChecks.length())
        val now = System.currentTimeMillis()
        app.settings.sync.lastCheckMs = now
        app.settings.setStartingGuideVisible(false)
        app.settings.setDailyNewCards(50)
        app.settings.setWeekPlan("FFFFFFF")
        app.settings.setTraceNew(true)
        app.settings.setVaryFonts(true)
        app.settings.setStack("jlpt-n5")
        runBlocking {
            app.db.withTransaction {
                for ((stack, cards) in listOf("jlpt-n1" to n1, "all" to all)) {
                    cards.forEach { card ->
                    app.db.reviews().putState(ReviewStateEntity(
                        source.id, stack, card.kanji, StudyMode.Quiz.name, "Review", 30.0, 5.0,
                        if (card.kanji == "勘") now - 60_000 else now + 30L * 86_400_000,
                        now - 2L * 86_400_000, 3, 0,
                    ))
                    for (kind in ReadingKind.entries) for (key in card.toReadingCard().quizKeys(kind))
                        app.db.reviews().putState(ReviewStateEntity(
                            source.id, stack, card.kanji, kind.mode.name, "Review", 30.0, 5.0,
                            if (card.kanji == "勘") now - 60_000 else now + 30L * 86_400_000,
                            now - 2L * 86_400_000, 3, 0, reading = key,
                        ))
                    }
                }
                for (days in 1..2) app.db.reviews().putLog(ReviewLogEntity(
                    0, source.id, "jlpt-n1", "勘", StudyMode.Quiz.name, 3, now - days * 86_400_000L,
                ))
            }
        }
        val connectivity = app.getSystemService(ConnectivityManager::class.java)
        assertNull("Disable owned emulator Wi-Fi/data before offline acceptance", connectivity.activeNetwork)
        val evidence = JSONObject().put("contentSnapshot", head).put("contentVersion", meta.contentVersion)
            .put("archiveRequests", archiveRequests).put("importedKanji", updated.kanji).put("importedWords", updated.words)
            .put("problems", updated.problems.size).put("n1Cards", n1.size)
            .put("acceptedReadingParserEpoch", meta.kanjiReadingParserEpoch)
            .put("acceptedMeaningParserEpoch", meta.kanjiMeaningParserEpoch)
            .put("productionBuilderN1AndAllExactChoices", choices).put("kanjiDirectGuardChecks", guardChecks)
            .put("nontransitiveNeighborChecks", nontransitiveChecks).put("preservedWordGuardChecks", wordChecks).put("unresolvedNonblockingKunHypothesisPairs", hypothesisChecks)
            .put("fullOnyomi", JSONArray(target.onyomi.splitSep())).put("fullKunyomi", JSONArray(target.kunyomi.splitSep()))
            .put("quizOnKeys", JSONArray(target.toReadingCard().quizKeys(ReadingKind.On)))
            .put("quizKunKeys", JSONArray(target.toReadingCard().quizKeys(ReadingKind.Kun)))
            .put("kanjiQuizExclusions", JSONArray(guards))
            .put("fingerprint", Build.FINGERPRINT).put("sdk", Build.VERSION.SDK_INT)
            .put("transport", "Exact full git archive through production ContentSync ONCE; synthetic source/HEAD")
            .put("fixture", "Other N1 meanings/readings postponed; only勘 meaning and soleかん on-reading due; no full or curated kun reading is offered. Two historical good meaning logs unlock drawing. No drawing state seeded. Disposable source, not owner progress.")
            .put("limits", "Sampled pools, not exhaustive future semantics. Direct conservative guards are not unrestricted synonyms. Sampled fallback ordinary-sense semantic acceptance remains UNVERIFIED until source-backed rendered review. Raster hashes are not readability. Emulator, not phone.")
            .put("phoneEvidence", false).put("passed", false)
        scenario = ActivityScenario.launch(MainActivity::class.java)
        try {
            click("Kanji")
            click("All")
            rule.waitUntil(30_000) { app.settings.stack.value == "all" }
            await("All · 1130 cards").performScrollTo().assertIsDisplayed()
            capture("all-selection")
            click(rule.onNode(hasText("Start") and hasAnyAncestor(hasText("Meaning quiz"))))
            rule.waitUntil(30_000) { (model("quiz:") as? QuizViewModel)?.ui is QuizUi.Question }
            val allMeaning = (model("quiz:") as QuizViewModel).ui as QuizUi.Question
            assertEquals("勘", allMeaning.card.kanji)
            assertEquals(4, allMeaning.options.map { it.title }.toSet().size)
            assertTrue(allMeaning.options.all { option -> all.any { it.kanji == option.kanji && it.title == option.title } })
            assertTrue(allMeaning.options.none { it.kanji in guards })
            evidence.put("exactAllMeaningOptions", JSONArray().also { rows ->
                allMeaning.options.forEach { rows.put(JSONObject().put("kanji", it.kanji).put("title", it.title)) }
            })
            capture("all-meaning-question")
            click("intuition; hunch")
            await("Correct!")
            capture("all-meaning-feedback")
            back()
            await("Meaning quiz")
            click(rule.onNode(hasText("Start") and hasAnyAncestor(hasText("Readings (on'yomi and kun'yomi)"))))
            rule.waitUntil(30_000) { (model("kreading:") as? KanjiReadingViewModel)?.ui is ReadingUi.Question }
            val allReading = (model("kreading:") as KanjiReadingViewModel).ui as ReadingUi.Question
            assertEquals("勘", allReading.card.kanji)
            assertEquals(ReadingKind.On, allReading.question.kind)
            assertEquals("かん", allReading.question.correctKey)
            evidence.put("exactAllReadingOptions", JSONArray().also { rows ->
                allReading.question.options.forEach { rows.put(JSONObject().put("key", it.key).put("label", it.label)) }
            })
            capture("all-reading-question")
            click("カン")
            await("Correct! — on'yomi")
            capture("all-reading-feedback")
            click("Next")
            rule.waitUntil(30_000) { (model("kreading:") as? KanjiReadingViewModel)?.ui is ReadingUi.Done }
            back()
            await("Meaning quiz")
            evidence.put("allMeaningAndReadingQuestionAndFeedback", true)
            click("N1")
            rule.waitUntil(30_000) { app.settings.stack.value == "jlpt-n1" }
            await("N1 · 139 cards").performScrollTo().assertIsDisplayed()
            capture("selection")
            click("Browse all kanji")
            rule.onNode(hasSetTextAction()).performTextReplacement("勘")
            click("intuition; hunch")
            await("勘 — intuition; hunch")
            show(articleBullet("Strokes: 11 · Key (radical): 力 (no. 19, at the right) · JLPT: N1 (community list)"), "article-00")
            section("Meaning and origin")
            show(articleBullet("As the noun 勘 (かん), this character means intuition or a hunch: sensing something or judging it without explicitly working through every step. That intuitive feel can develop through experience, but a hunch can also be wrong."), "article-02")
            show(articleBullet("In compounds, 勘 also contributes examining or reckoning. 勘定 (かんじょう), \"reckoning; bill,\" is not a \"settled hunch\"; learn the whole word rather than translating every 勘 as intuition."), "article-03")
            show(articleBullet("Modern-shape mnemonic: notice the stacked 甚-shaped section at the left and 力 at the right. Imagine effort spent noticing clues. This uses the present-day outline only, not a verified account of the character's historical formation."), "article-04")
            section("Readings")
            show(readingExample("カン"), "article-06")
            show(readingExample("勘 (かん) — intuition; 勘定 (かんじょう) — reckoning; bill; 勘違い (かんちがい) — mistaken assumption"), "article-07")
            show(articleBullet("In 勘定, the readings are カン + ジョウ. 勘違い combines カン with native 違い (ちがい); it is not two on readings."), "article-08")
            section("Common words")
            show(articleBullet("勘 (かん) — intuition; hunch"), "article-10")
            show(articleBullet("勘定 (かんじょう) — reckoning; bill"), "article-11")
            show(articleBullet("勘違い (かんちがい) — mistaken assumption; misunderstanding"), "article-12")
            section("Notes")
            show(articleBullet("Compare 勤, \"employment; diligence\": both have 力 at the right, but their dense left sides differ. 助, \"help; rescue,\" has a simpler 且-shaped left side. 期, \"period; term,\" has 月 at the right instead of 力."), "article-14")
            show(articleBullet("勘が当たる (かんがあたる) means \"one's hunch proves right\"; 勘が外れる (かんがはずれる) means \"one's hunch proves wrong.\" Intuition does not guarantee correctness or imply supernatural powers."), "article-15")
            show(articleBullet("Supplementary spelling recognition: Digital Daijisen also lists the native reading かんがえる. JMdict records 勘える as a rare spelling of the usual 考える (かんがえる), \"think about; consider.\" The spelling 勘える is rare, not the pronunciation かんがえる. This is recognition information, not an additional reading question on this card."), "article-16")
            show(articleBullet("Sources: KANJIDIC2; JMdict, complete entries 1210590, 1210750, 1210620 and 1281020; Digital Daijisen, 勘."), "article-17")
            section("Common words")
            inline(await(articleBullet("勘 (かん) — intuition; hunch")), "勘", 0)
            await("勘 (かん) - intuition; hunch")
            section("Meaning")
            show(articleBullet("勘 is a noun for intuition, a hunch, or an intuitive feel for something. It can concern a quick guess or an ability developed through experience. Use 勘で for doing something by intuition rather than through an explicit calculation."), "word-0-01")
            show(articleBullet("答えが分からなかったので、勘で選びました。 (こたえがわからなかったので、かんでえらびました。) - I did not know the answer, so I chose by intuition."), "word-0-02")
            show(articleBullet("私の勘が当たりました。 (わたしのかんがあたりました。) - My hunch was right."), "word-0-03")
            show(articleBullet("勘が当たる (かんがあたる) says the hunch proves right; 勘が外れる (かんがはずれる) says it proves wrong."), "word-0-04")
            section("How the kanji combine")
            show(articleBullet("勘 is a single kanji used as the whole noun, with the on reading カン. There is no multi-kanji compound to break down."), "word-0-06")
            section("Synonyms and antonyms")
            show(articleBullet("予想 (よそう) is an expectation or prediction and need not come from intuition. 判断 (はんだん) names a judgment; 勘 can be one basis for making it. Neither word is an exact opposite."), "word-0-08")
            section("Distinctive meaning")
            show(articleBullet("勘がいい, \"have good intuition,\" and 勘が鋭い (かんがするどい), \"have sharp intuition,\" describe sensitivity to clues. They do not assert supernatural powers or guarantee correctness. 久しぶりで勘が鈍った (ひさしぶりでかんがにぶった) means one's feel for an activity has become rusty after a long break."), "word-0-10")
            show(articleBullet("Dictionary: JMdict, entry 1210590, sense 1."), "word-0-11")
            section("How the kanji combine")
            show(articleBullet("勘 is a single kanji used as the whole noun, with the on reading カン. There is no multi-kanji compound to break down."), "pair-0-components")
            inline(await(articleBullet("勘 is a single kanji used as the whole noun, with the on reading カン. There is no multi-kanji compound to break down.")), "勘", 0)
            await("勘 — intuition; hunch")
            back()
            await(articleBullet("勘 is a single kanji used as the whole noun, with the on reading カン. There is no multi-kanji compound to break down.")).assertIsDisplayed()
            back()
            await(articleBullet("勘 (かん) — intuition; hunch")).assertIsDisplayed()
            section("Common words")
            inline(await(articleBullet("勘定 (かんじょう) — reckoning; bill")), "勘定", 0)
            await("勘定 (かんじょう) - reckoning; bill")
            section("Meaning")
            show(articleBullet("勘定 is counting or reckoning, and 勘定する means to count or calculate something. It also names a bill or the settlement of a bill, especially in expressions with お."), "word-1-01")
            show(articleBullet("人数を勘定しました。 (にんずうをかんじょうしました。) - I counted the people."), "word-1-02")
            show(articleBullet("お勘定をお願いします。 (おかんじょうをおねがいします。) - The bill, please."), "word-1-03")
            show(articleBullet("In the first example, を marks what is counted. In the second, the speaker is asking to settle the bill, not requesting an abstract mathematics calculation."), "word-1-04")
            section("How the kanji combine")
            show(articleBullet("勘 contributes examining or reckoning, and 定 contributes settling or determining. Together they suggest determining an amount or account. The on readings are カン + ジョウ."), "word-1-06")
            section("Synonyms and antonyms")
            show(articleBullet("計算 (けいさん) covers calculation more broadly. 会計 (かいけい) overlaps in payment and accounting contexts. 支払う (しはらう) directly means \"pay,\" whereas 勘定 can name the amount or the counting process."), "word-1-08")
            section("Distinctive meaning")
            show(articleBullet("勘定に入れる (かんじょうにいれる) means \"take into account\"; 勘定に入れない means \"leave out of the reckoning.\" This is the consideration sense, not a general replacement for every use of \"think.\" Context distinguishes counting participants, paying a restaurant bill, and allowing for a factor in a decision."), "word-1-10")
            show(articleBullet("Dictionary: JMdict, entry 1210750, senses 1-3."), "word-1-11")
            section("How the kanji combine")
            show(articleBullet("勘 contributes examining or reckoning, and 定 contributes settling or determining. Together they suggest determining an amount or account. The on readings are カン + ジョウ."), "pair-1-components")
            inline(await(articleBullet("勘 contributes examining or reckoning, and 定 contributes settling or determining. Together they suggest determining an amount or account. The on readings are カン + ジョウ.")), "勘", 0)
            await("勘 — intuition; hunch")
            back()
            await(articleBullet("勘 contributes examining or reckoning, and 定 contributes settling or determining. Together they suggest determining an amount or account. The on readings are カン + ジョウ.")).assertIsDisplayed()
            inline(await(articleBullet("勘 contributes examining or reckoning, and 定 contributes settling or determining. Together they suggest determining an amount or account. The on readings are カン + ジョウ.")), "定", 42)
            await("定 — determine; settle")
            section("Common words")
            show(articleBullet("勘定 (かんじょう) — reckoning; bill; 定 has the on reading ジョウ here"), "reused-定-new-line")
            inline(await(articleBullet("勘定 (かんじょう) — reckoning; bill; 定 has the on reading ジョウ here")), "勘定", 0)
            await("勘定 (かんじょう) - reckoning; bill")
            back()
            await(articleBullet("勘定 (かんじょう) — reckoning; bill; 定 has the on reading ジョウ here")).assertIsDisplayed()
            back()
            await(articleBullet("勘 contributes examining or reckoning, and 定 contributes settling or determining. Together they suggest determining an amount or account. The on readings are カン + ジョウ.")).assertIsDisplayed()
            back()
            await(articleBullet("勘定 (かんじょう) — reckoning; bill")).assertIsDisplayed()
            section("Common words")
            inline(await(articleBullet("勘違い (かんちがい) — mistaken assumption; misunderstanding")), "勘違い", 0)
            await("勘違い (かんちがい) - mistaken assumption; misunderstanding")
            section("Meaning")
            show(articleBullet("勘違い is a mistaken understanding, assumption, or guess. 勘違いする means to get the wrong idea. Use clause + と勘違いする to state what someone mistakenly believed."), "word-2-01")
            show(articleBullet("会議は明日だと勘違いしていました。 (かいぎはあしただとかんちがいしていました。) - I had mistakenly thought the meeting was tomorrow."), "word-2-02")
            show(articleBullet("私の勘違いでした。 (わたしのかんちがいでした。) - I had the wrong idea."), "word-2-03")
            show(articleBullet("In the first example, と follows the full mistaken claim, 明日だ. XをYと勘違いする means mistaking X for Y."), "word-2-04")
            section("How the kanji combine")
            show(articleBullet("勘 contributes judgment or intuition, and 違 contributes being different or mistaken. The word combines カン with native 違い (ちがい), related to 違う. This is a mixed on-first compound, not two on readings."), "word-2-06")
            section("Synonyms and antonyms")
            show(articleBullet("誤解 (ごかい) overlaps in a misunderstanding or wrong interpretation. 間違い (まちがい) is broader: a copying error need not involve a mistaken belief about the situation. These distinctions do not make every use mutually exclusive."), "word-2-08")
            section("Distinctive meaning")
            show(articleBullet("勘違い does not necessarily imply deliberate deception. The speaker may genuinely have assumed the wrong date, person, or meaning. Do not infer that 勘違い is always harmless or only concerns another person's words; context determines the consequences and what was mistaken."), "word-2-10")
            show(articleBullet("Dictionary: JMdict, entry 1210620, sense 1."), "word-2-11")
            section("How the kanji combine")
            show(articleBullet("勘 contributes judgment or intuition, and 違 contributes being different or mistaken. The word combines カン with native 違い (ちがい), related to 違う. This is a mixed on-first compound, not two on readings."), "pair-2-components")
            inline(await(articleBullet("勘 contributes judgment or intuition, and 違 contributes being different or mistaken. The word combines カン with native 違い (ちがい), related to 違う. This is a mixed on-first compound, not two on readings.")), "勘", 0)
            await("勘 — intuition; hunch")
            back()
            await(articleBullet("勘 contributes judgment or intuition, and 違 contributes being different or mistaken. The word combines カン with native 違い (ちがい), related to 違う. This is a mixed on-first compound, not two on readings.")).assertIsDisplayed()
            inline(await(articleBullet("勘 contributes judgment or intuition, and 違 contributes being different or mistaken. The word combines カン with native 違い (ちがい), related to 違う. This is a mixed on-first compound, not two on readings.")), "違", 41)
            await("違 — differ")
            section("Common words")
            show(articleBullet("勘違い かんちがい — mistaken assumption; 勘 has on カン and 違い is native ちがい here"), "reused-違-new-line")
            inline(await(articleBullet("勘違い かんちがい — mistaken assumption; 勘 has on カン and 違い is native ちがい here")), "勘違い", 0)
            await("勘違い (かんちがい) - mistaken assumption; misunderstanding")
            back()
            await(articleBullet("勘違い かんちがい — mistaken assumption; 勘 has on カン and 違い is native ちがい here")).assertIsDisplayed()
            back()
            await(articleBullet("勘 contributes judgment or intuition, and 違 contributes being different or mistaken. The word combines カン with native 違い (ちがい), related to 違う. This is a mixed on-first compound, not two on readings.")).assertIsDisplayed()
            back()
            await(articleBullet("勘違い (かんちがい) — mistaken assumption; misunderstanding")).assertIsDisplayed()
            back()
            await("Search kanji, meaning or reading")
            back()
            await("Meaning quiz")
            evidence.put("mappedReciprocalPairs", 5).put("directedLinkTransitions", 10)
                .put("activatedBaselinePairs", 3).put("changedReusedArticles", 2)
                .put("changedReusedNavigationTransitions", 4).put("reciprocalLinkAndSystemBack", true)
            click(rule.onNode(hasText("Start") and hasAnyAncestor(hasText("Meaning quiz"))))
            rule.waitUntil(30_000) { (model("quiz:") as? QuizViewModel)?.ui is QuizUi.Question }
            val quiz = model("quiz:") as QuizViewModel
            val meaning = quiz.ui as QuizUi.Question
            assertEquals("勘", meaning.card.kanji)
            val n1Curated = curatedIds.filter { id -> n1.any { it.kanji == id } }
            assertEquals(emptySet<String>(), n1Curated.toSet())
            assertEquals(4, meaning.options.size)
            assertEquals(4, meaning.options.map { it.title }.toSet().size)
            assertEquals(1, meaning.options.count { it.kanji == "勘" })
            assertTrue(n1Curated.all { id -> meaning.options.any { it.kanji == id && it.title == expectedMeanings[id] } })
            assertTrue(meaning.options.all { option -> n1.any { it.kanji == option.kanji && it.title == option.title } })
            assertFalse(meaning.options.any { it.kanji in curatedIds })
            val fallback = meaning.options.filter { it.kanji != "勘" && it.kanji !in curatedIds }
            assertEquals(3, fallback.size)
            assertEquals(guards, meaning.card.toQuizCard().quizExclusions)
            assertTrue(meaning.options.none { it.kanji in guards })
            val actualCards = meaning.options.map { option -> n1.single { it.kanji == option.kanji }.toQuizCard() }
            for (left in actualCards) for (right in actualCards.filter { it.kanji != left.kanji })
                assertFalse(right.kanji in left.quizExclusions || left.kanji in right.quizExclusions)
            for (option in meaning.options) await(option.title).assertIsDisplayed()
            evidence.put("exactDefaultMeaningOptions", JSONArray().also { rows ->
                meaning.options.forEach { rows.put(JSONObject().put("kanji", it.kanji).put("title", it.title)) }
            }).put("actualN1CuratedAvailable", 0).put("actualN1FallbackOptions", 3)
                .put("curatedDistractorLevels", JSONObject().put("勤", 3).put("助", 3).put("期", 3))
                .put("meaningFallbackNeedsSemanticReview", true)
            capture("meaning-question")
            click("intuition; hunch")
            await("Correct!")
            capture("meaning-feedback")
            back()
            await("Meaning quiz")
            click(rule.onNode(hasText("Start") and hasAnyAncestor(hasText("Readings (on'yomi and kun'yomi)"))))
            val answeredKeys = mutableSetOf<String>()
            rule.waitUntil(30_000) { (model("kreading:") as? KanjiReadingViewModel)?.ui is ReadingUi.Question }
            val reading = model("kreading:") as KanjiReadingViewModel
            val question = reading.ui as ReadingUi.Question
            assertEquals("勘", question.card.kanji)
            assertEquals(ReadingKind.On, question.question.kind)
            assertEquals("かん", question.question.correctKey)
            assertEquals(emptyList<String>(), question.card.kunyomi.splitSep())
            assertEquals(emptyList<String>(), question.card.quizKunyomi?.splitSep())
            assertTrue(answeredKeys.add("かん"))
            assertEquals(1, question.question.options.count { it.key == "かん" })
            assertEquals("カン", question.question.options.single { it.key == "かん" }.label)
            evidence.put("exactOnReadingOptions", JSONArray().also { rows ->
                question.question.options.forEach { rows.put(JSONObject().put("key", it.key).put("label", it.label)) }
            })
            capture("curated-on-question")
            click("カン")
            await("Correct! — on'yomi")
            assertTrue((reading.ui as ReadingUi.Answer).correct)
            capture("curated-on-feedback")
            click("Next")
            assertEquals(setOf("かん"), answeredKeys)
            rule.waitUntil(30_000) { (model("kreading:") as? KanjiReadingViewModel)?.ui is ReadingUi.Done }
            val done = (model("kreading:") as KanjiReadingViewModel).ui as ReadingUi.Done
            assertEquals(1, done.answered)
            assertEquals(1, done.correct)
            rule.waitUntil(30_000) { runBlocking {
                app.db.reviews().allLog().count { log -> log.sourceId == source.id && log.stack == "jlpt-n1" && log.kanji == "勘" &&
                    log.mode in setOf(ReadingKind.On.mode.name, ReadingKind.Kun.mode.name) && log.grade == 3 } == 1
            } }
            val logs = runBlocking { app.db.reviews().allLog().filter {
                it.sourceId == source.id && it.stack == "jlpt-n1" && it.kanji == "勘" &&
                    it.mode in setOf(ReadingKind.On.mode.name, ReadingKind.Kun.mode.name)
            } }
            assertEquals(1, logs.size)
            assertEquals(setOf("かん"), logs.map { it.reading }.toSet())
            assertTrue(logs.all { it.grade == 3 && it.mode == ReadingKind.On.mode.name })
            capture("curated-sole-on-done")
            back()
            await("Meaning quiz")
            click(rule.onNode(hasText("Start") and hasAnyAncestor(hasText("Drawing"))))
            await("Trace the kanji for")
            await("intuition; hunch").assertIsDisplayed()
            val card = requireNotNull(runBlocking { app.db.content().kanjiCard(source.id, "勘") })
            assertEquals(listOf("カン"), card.onyomi.splitSep())
            assertEquals(emptyList<String>(), card.kunyomi.splitSep())
            assertEquals(listOf("カン"), card.quizOnyomi?.splitSep())
            assertEquals(emptyList<String>(), card.quizKunyomi?.splitSep())
            assertEquals(guards, card.quizExclusions.splitSep())
            evidence.put("fullProjectionOnyomi", JSONArray(card.onyomi.splitSep()))
                .put("fullProjectionKunyomi", JSONArray(card.kunyomi.splitSep()))
                .put("fullProjectionQuizOnyomi", JSONArray(requireNotNull(card.quizOnyomi).splitSep()))
                .put("fullProjectionQuizKunyomi", JSONArray(requireNotNull(card.quizKunyomi).splitSep()))
            val strokes = JSONObject(requireNotNull(card.strokesJson)).getJSONArray("strokes")
            assertEquals(11, strokes.length())
            capture("drawing-trace")
            val pad = rule.onNode(hasContentDescription("Drawing area for the kanji", substring = true))
            pad.performScrollTo()
            for (index in 0 until strokes.length()) {
                val points = strokes.getJSONObject(index).getJSONArray("points")
                pad.performTouchInput {
                    fun point(i: Int): Offset {
                        val pair = points.getJSONArray(i)
                        return Offset(pair.getDouble(0).toFloat() * width / 109f,
                            pair.getDouble(1).toFloat() * height / 109f)
                    }
                    down(point(0))
                    for (i in 1 until points.length()) moveTo(point(i), delayMillis = 16)
                    up()
                }
            }
            rule.onNode(hasContentDescription("11 strokes drawn", substring = true)).assertExists()
            click("Check")
            await("Practice only: this attempt is not graded.")
            assertFalse(runBlocking { app.db.reviews().allLog().any {
                it.sourceId == source.id && it.stack == "jlpt-n1" && it.kanji == "勘" && it.mode == StudyMode.Draw.name
            } })
            await("Correct strokes").performScrollTo().assertIsDisplayed()
            capture("drawing-feedback")
            click("Next")
            await("Draw the kanji for")
            click("I don't remember")
            await("Here is the kanji")
            capture("drawing-recall-feedback")
            click("Next")
            rule.waitUntil(30_000) { runBlocking { app.db.reviews().allLog().any {
                it.sourceId == source.id && it.stack == "jlpt-n1" && it.kanji == "勘" && it.mode == StudyMode.Draw.name && it.grade == 1
            } } }
            back()
            await("Meaning quiz")
            assertEquals("jlpt-n1", app.settings.stack.value)
            assertNull(connectivity.activeNetwork)
            assertEquals(1, archiveRequests)
            evidence.put("meaningQuestionAndFeedback", true).put("soleCuratedOnPersistedGoodAndDone", true)
                .put("touchInjectedReferenceStrokes", strokes.length()).put("drawingTraceThenRecall", true)
                .put("drawingGradeRecordedOnNext", true).put("offline", true).put("passed", true)
        } finally {
            File(app.getExternalFilesDir(null), "n1-107-article-route.json").writeText(evidence.toString(2))
            File(app.getExternalFilesDir(null), "n1-107-article-tree.txt").writeText(rule.onRoot().printToString())
            scenario.close()
        }
    }

    private fun model(prefix: String): ViewModel? {
        var result: ViewModel? = null
        scenario.onActivity { activity ->
            result = activity.viewModelStore.keys().lastOrNull { it.startsWith(prefix) }?.let { activity.viewModelStore[it] }
        }
        return result
    }

    private fun await(text: String, substring: Boolean = false): SemanticsNodeInteraction {
        return await(hasText(text, substring = substring))
    }

    private fun await(matcher: SemanticsMatcher): SemanticsNodeInteraction {
        rule.waitUntil(30_000) { rule.onAllNodes(matcher).fetchSemanticsNodes().isNotEmpty() }
        rule.onAllNodes(matcher).assertCountEquals(1)
        return rule.onNode(matcher)
    }

    private fun readingExample(text: String): SemanticsMatcher {
        return hasText(text) and hasAnyAncestor(hasTestTag("article-body")) and
            hasAnyAncestor(SemanticsMatcher.keyIsDefined(SemanticsProperties.HorizontalScrollAxisRange))
    }

    private fun articleBullet(text: String): SemanticsMatcher {
        return hasText(text) and hasAnyAncestor(hasTestTag("article-body")) and
            !hasAnyAncestor(SemanticsMatcher.keyIsDefined(SemanticsProperties.HorizontalScrollAxisRange))
    }

    private fun click(text: String) = click(await(text))

    private fun click(node: SemanticsNodeInteraction) {
        rule.waitUntil(30_000) { !node.fetchSemanticsNode().config.contains(SemanticsProperties.Disabled) }
        if (node.onAncestors().filter(hasScrollAction()).fetchSemanticsNodes().isNotEmpty()) node.performScrollTo()
        node.assertIsDisplayed().assertIsEnabled().performClick()
    }

    private fun section(title: String) {
        rule.onNodeWithTag("article-body").performScrollToIndex(0)
        click("Article contents")
        rule.onNode(hasText(title, substring = true) and hasClickAction()).performScrollTo().performClick()
        rule.waitForIdle()
    }

    private fun show(selector: String, step: String) {
        show(hasText(selector, substring = true), step)
    }

    private fun show(matcher: SemanticsMatcher, step: String, occurrence: Int = 0, expectedCount: Int = 1) {
        val body = rule.onNodeWithTag("article-body")
        body.performScrollToNode(matcher)
        rule.onAllNodes(matcher).assertCountEquals(expectedCount)
        val target = rule.onAllNodes(matcher)[occurrence]
        target.performScrollTo()
        val viewport = body.fetchSemanticsNode()
        val cell = target.fetchSemanticsNode()
        val top = viewport.positionInRoot.y
        val bottom = top + viewport.size.height
        if (cell.positionInRoot.y < top || cell.positionInRoot.y + cell.size.height > bottom) {
            body.performSemanticsAction(SemanticsActions.ScrollBy) {
                it(0f, cell.positionInRoot.y - top - 16f)
            }
            rule.waitForIdle()
        }
        target.assertIsDisplayed()
        capture(step)
    }

    private fun inline(node: SemanticsNodeInteraction, label: String, offset: Int) {
        node.performScrollTo().assertIsDisplayed()
        val text = node.fetchSemanticsNode().config[SemanticsProperties.Text].joinToString("") { it.text }
        val layouts = mutableListOf<TextLayoutResult>()
        node.performSemanticsAction(SemanticsActions.GetTextLayoutResult) { it(layouts) }
        assertTrue("Wrong linked offset $offset for $label in $text", offset >= 0 && text.substring(offset).startsWith(label))
        node.performTouchInput { click(layouts.single().getBoundingBox(offset).center) }
    }

    private fun back() {
        InstrumentationRegistry.getInstrumentation().uiAutomation.performGlobalAction(
            android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
        rule.waitForIdle()
    }

    private fun capture(step: String) {
        rule.waitForIdle()
        val automation = InstrumentationRegistry.getInstrumentation().uiAutomation
        automation.waitForIdle(500, 5_000)
        android.os.SystemClock.sleep(1_000)
        rule.waitForIdle()
        val bitmap = requireNotNull(automation.takeScreenshot())
        File(app.getExternalFilesDir(null), "n1-107-$step.png").outputStream().use {
            assertTrue(bitmap.compress(Bitmap.CompressFormat.PNG, 100, it))
        }
        bitmap.recycle()
    }
}
