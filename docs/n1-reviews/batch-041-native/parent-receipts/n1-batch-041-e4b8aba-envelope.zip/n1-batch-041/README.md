# Learning Japanese

English-language notes on Japanese grammar, vocabulary, and usage.

This repository starts as a collection of standalone articles prompted by specific questions. It is not yet a course or a systematic reference: topics can be connected and organized more formally as the collection grows.

## Articles

| Area | Article | Main question |
| --- | --- | --- |
| Grammar | [Japanese verb foundations](articles/japanese-verb-foundations.md) | How do plain/polite, nonpast/past, negative and て forms work, including important exceptions? |
| Grammar | [Japanese adjective foundations](articles/japanese-adjective-foundations.md) | How do い／な adjectives and noun predicates change with time, negation and politeness? |
| Grammar | [Japanese actions, states and time](articles/japanese-actions-states-and-time.md) | When does ている describe an action, a result or a routine, and how do basic temporal patterns differ? |
| Grammar | [Japanese requests, permission and rules](articles/japanese-requests-permission-and-rules.md) | How do requests, permission, prohibition and obligation differ, including common contractions? |
| Grammar | [Pointing and asking questions](articles/pointing-and-asking-questions.md) | How do things, noun modifiers, places, questions and unspecified or negative references differ? |
| Grammar | [Describing nouns and talking about activities](articles/noun-descriptions-and-activities.md) | How do noun descriptions, understood items and nominalized activities differ, and when can subject が become の? |
| Grammar | [Wants, plans, invitations and offers](articles/wants-plans-and-invitations.md) | How do a wish, an intention, a joint proposal, an offer, a choice and a motion purpose differ? |
| Grammar | [Reasons, contrasts and conversational prefaces](articles/reasons-and-contrasts.md) | How do reason and contrast connectors attach, and when does が mark a subject or introduce a question? |
| Grammar | [Comparisons, changes and degree](articles/comparisons-change-and-degree.md) | What does a pair or set comparison establish, and how do a change, a high degree and excess differ? |
| Grammar | [Giving, receiving and viewpoint](articles/giving-receiving-and-viewpoint.md) | Who gives to whom, and how do あげる, くれる and もらう frame the same event? |
| Grammar | [Explanations, quotations and sentence endings](articles/explanations-quotations-and-endings.md) | How do explanatory context, reported words, listener alignment and conjecture differ without relying on imagined intonation? |
| Grammar | [Wanting to act, wanting a thing and wanting an outcome](articles/desire-actions-and-outcomes.md) | Whose wish is expressed, who would act, and how do たい, がほしい and てほしい differ? |
| Grammar | [Ability, availability and perception](articles/ability-and-perception.md) | How do potential forms, available actions, visibility, audibility and sensory がする differ? |
| Grammar | [Actions, events and resulting states](articles/actions-events-and-results.md) | Who acts on what, what changes, and how do ている, てある and ておく frame states and preparation? |
| Grammar | [Trying, preparing and getting things done](articles/trying-preparing-and-finishing.md) | What do てみる, ておく and てしまう contribute, and how do their conversational contractions work? |
| Grammar | [Doing things for others and asking favors](articles/benefactive-actions.md) | Who acts and benefits, and how do benefactive frames, thanks, apologies and negative favor questions differ? |
| Grammar | [Passive voice and affected participants](articles/passive-and-affected-participants.md) | Who acts and who is affected, why can を remain, and how does passive られる differ from potential? |
| Grammar | [Making, letting and being made to act](articles/making-letting-and-being-made-to-act.md) | Who causes an action and who performs it, and how do causative, causative-passive and common shortened forms differ? |
| Grammar | [Looks, likeness and informed impressions](articles/appearance-resemblance-and-impressions.md) | How do appearance, resemblance, inferred information, typicality and outward feelings differ without a fixed certainty ladder? |
| Grammar | [Thinking, possibility and expectation](articles/thinking-possibility-and-expectation.md) | How do thoughts, possibilities and reason-based expectations attach, and how do event time, thinking time and negative scope differ? |
| Grammar | [Embedded questions, reports and noticing](articles/embedded-questions-and-reports.md) | What is the inner question or content, what does the outer message do, and who issues or receives a reported instruction? |
| Grammar | [Volition, plans and goals](articles/volition-plans-and-goals.md) | How do intended actions, planned activities, desired outcomes, observed changes and maintained effort differ? |
| Grammar | [Necessity, advice and instructions](articles/necessity-advice-and-instructions.md) | How do optionality, prohibition, necessity, commands, requests, suggestions, regrets and relief differ? |
| Grammar | [Koto, wake, and Japanese noun-based grammar](articles/koto-wake-and-formal-nouns.md) | How do こと and わけ differ, which common formal nouns and noun-based expressions are useful to know, and where do の/ん and ほど fit? |
| Grammar | [Japanese verb extensions: direction and aspect](articles/verb-extensions-direction-and-aspect.md) | How do direction, temporal viewpoint, beginning, continuation, redoing and recent completion differ? Includes focused N4 practice and links to the existing action-stage exercises. |
| Grammar | [Japanese conditionals: たら, ば, なら, と, and 場合](articles/japanese-conditionals.md) | How do conditions, premises, event order, discoveries, and procedural cases differ, and when can several patterns fit? |
| Grammar | [のに: unexpected outcomes, comparisons, and the other のに](articles/noni-and-concessive-contrasts.md) | How do concessive のに, わりに and くせに overlap, and how is nominalizing の plus に different? |
| Grammar | [Japanese listing and examples: と, や, とか, など, たり, and し](articles/japanese-listing-and-examples.md) | How do named lists, representative examples, added reasons, and alternatives differ, and when is one stated item enough? |
| Grammar | [Japanese nouns and basic particles: building a sentence](articles/japanese-nouns-and-basic-particles.md) | How do particles mark whole noun phrases, how does the predicate determine their roles, and how do に/で, に/へ, と/で, and まで/までに differ? |
| Grammar | [は, が, and も: topic, contrast, and inclusion](articles/wa-ga-mo-topic-and-inclusion.md) | How do topic and grammatical role differ, what does も add, and when are several framings or an omitted participant natural? |
| Grammar | [Only, even, and unexpected inclusion](articles/only-and-unexpected-inclusion.md) | How do だけ and しか differ under negation, what makes an included example unexpected, and when do さえ, でも, まで, or も overlap? |
| Grammar | [About, towards, and from someone's perspective](articles/about-targets-and-perspectives.md) | How do について, に対して, にとって, and に関して differ, and how do they connect to こと, ため, 場合, and nominalized clauses? |
| Vocabulary | [Strange, suspicious, and rare: ayashii and related words](articles/ayashii-and-related-words.md) | How do 怪しい, 妖しい, 疑わしい, いかがわしい, 変な, and 珍しい differ? |
| Vocabulary | [Kaeru: change, replace, exchange, and return](articles/kaeru-change-replace-and-return.md) | How do 変える, 替える, 換える, 代える, 帰る, 返る, 還る, and 孵る differ, and why is 交える not read かえる? |
| Vocabulary | [Japanese occupation and role endings](articles/occupation-and-role-endings.md) | What do 者, 家, 師, 士, 手, 員, and 屋 contribute, and how do they relate to prestige and new word formation? |
| Vocabulary | [Japanese onomatopoeia: 201 words](articles/japanese-onomatopoeia.md) | How do sound words and mimetic words describe everyday scenes, and which constructions go with them? |
| Vocabulary | [Onomatopoeia sound patterns](articles/onomatopoeia-sound-patterns.md) | What can repetition, endings, and voiced consonants suggest without becoming rigid meaning rules? |
| Vocabulary | [Warmth and texture](articles/onomatopoeia-texture-and-warmth.md) | How do ぽかぽか, ほかほか, ふわふわ, ふかふか, ぺたぺた, and べたべた differ? |
| Vocabulary | [Rain, rolling, walking, and similar forms](articles/onomatopoeia-sound-and-movement.md) | How do vivid scene descriptions differ, and why are similar-looking words not necessarily synonyms? |
| Vocabulary | [Eating and drinking](articles/onomatopoeia-eating-and-drinking.md) | How do gulps, chewing, appetite, texture, and flavor differ? |
| Vocabulary | [Body sensations and feelings](articles/onomatopoeia-body-and-feelings.md) | How do mimetics describe pain, excitement, disappointment, and attention without identifying their causes? |
| Vocabulary | [Motion, voices, and everyday sounds](articles/onomatopoeia-motion-and-sound.md) | Which descriptions concern movement, sound, result, or manner, and where do they overlap? |

## N5 grammar series

The [N5 expansion series](https://github.com/stop-cran/learning-japanese/issues/16) begins with these four
focused guides and supplements the existing noun/particle and listing material. Its
[coverage and source ledger](docs/grammar-n5-foundations-sources.json) distinguishes new exercises,
reused practice and explanation-only boundaries; it does not claim a complete official N5 syllabus.
The [pointing/questions installment](articles/pointing-and-asking-questions.md) adds 54 exercises;
its [ledger](docs/grammar-n5-pointing-sources.json) accounts for the 19 assigned primary anchors and secondary-supported どうやって.
The [noun-description installment](articles/noun-descriptions-and-activities.md) adds 32 exercises and reuses six
existing attachment drills without copying them; its [ledger](docs/grammar-n5-descriptions-sources.json) accounts
for 13 primary anchors, including bounded が／の recognition and activity-versus-item scope.
The [wants/plans installment](articles/wants-plans-and-invitations.md) adds 38 exercises and a local group for six
existing intention drills; its [ledger](docs/grammar-n5-wants-sources.json) records seven primary anchors,
secondary-supported item requests, fair shared invitation answers and an optional N4 desire bridge.
The [reasons/contrasts installment](articles/reasons-and-contrasts.md) adds 34 exercises;
its [ledger](docs/grammar-n5-reasons-sources.json) accounts for five primary anchors, whole-predicate attachment,
bounded が-role recognition and preface interpretation. Sentence-level linkers remain supporting reading.
The [comparisons/change installment](articles/comparisons-change-and-degree.md) adds 42 exercises and groups five
existing N5 quantity/limit drills; its [ledger](docs/grammar-n5-comparisons-sources.json) distinguishes assessed
comparison, change and excess patterns from shared degree wording and support-only quantity vocabulary.
The [giving/receiving installment](articles/giving-receiving-and-viewpoint.md) adds 36 exercises;
its [ledger](docs/grammar-n5-giving-sources.json) maps basic transfers, participant markers, past forms and viewpoint
without treating family membership as a fixed partition.
The [explanations/endings installment](articles/explanations-quotations-and-endings.md) adds 52 exercises;
its [ledger](docs/grammar-n5-endings-sources.json) separates requested formation and bounded interpretation
from recognition-only notes and optional advanced reading.
The [desire follow-up](articles/desire-actions-and-outcomes.md) adds 34 exercises;
its [ledger](docs/grammar-desire-sources.json) separates 30 N4 tasks from four N5-only role interpretations,
with sourced observation/benefactive bridges kept optional.

## N4 grammar series

The [N4 series index](https://github.com/stop-cran/learning-japanese/issues/17) separates new grammar families
from consolidation of existing practice. The [consolidation ledger](docs/grammar-n4-consolidation-sources.json)
records 13 small introduction groups for 73 existing exercises and vocabulary support for 88 existing prompts.
All 240 N4 exercises present at consolidation gained complete grouping and lexical coverage; their questions, answers, levels,
identities and progress keys are unchanged. This improves entry points and reading support, not the number of
independent scenarios or the completeness of an official syllabus.

The [ability/perception installment](articles/ability-and-perception.md) adds 34 N4 exercises in five groups:
potential formation and polarity, skill/circumstance interpretation, perception versus access, and sensory frames.
Its [ledger](docs/grammar-ability-perception-sources.json) records exact reuse of existing ability/change/goal tasks.
The [actions/events/results installment](articles/actions-events-and-results.md) adds 28 N4 exercises in
four groups, connecting supplied transitivity pairs, quality changes, purposeful results and preparation.
Its [ledger](docs/grammar-transitivity-results-sources.json) preserves the older state/change owners and
records fitting alternative てある frames rather than making が versus を a universal answer key.
The [trying/preparing/finishing installment](articles/trying-preparing-and-finishing.md) adds 24 N4 tasks:
six formation, ten contextual interpretations and eight contraction expansions in four focused groups.
Its [ledger](docs/grammar-try-prepare-complete-sources.json) keeps existing state/result and maintained-practice owners.
The [benefactive/request installment](articles/benefactive-actions.md) adds 36 N4 tasks in four groups:
roles/viewpoint, auxiliary polarity, thanks/apologies and casual/indirect requests.
Its [ledger](docs/grammar-benefactive-requests-sources.json) preserves older giving, desire and request owners,
with the genuine てやる curriculum disagreement recorded as optional recognition rather than a scored N4 claim.
The [direction/development installment](articles/verb-extensions-direction-and-aspect.md) adds 34 N4 tasks:
12 formation and 22 interpretation items in four groups, covering stem compounds, quoted-observer motion,
reference-time development and recency. Its [ledger](docs/grammar-motion-stages-sources.json) preserves the
nine existing action-stage tasks and keeps harder concentration/unchanged-state comparisons separate.
The [passive installment](articles/passive-and-affected-participants.md) adds 30 N4 tasks in four groups:
formation/polarity, actor/target roles, direct and affected-person frames, and passive/potential interpretation.
Its [ledger](docs/grammar-passive-participants-sources.json) keeps retained を and intransitive affected uses
explicit without teaching universal negativity or duplicating the existing potential-formation owners.
The [causative installment](articles/making-letting-and-being-made-to-act.md) adds 40 N4 tasks in six groups,
staging causative forms/roles and make/let interpretation before causative-passive forms, roles and shortening.
Its [ledger](docs/grammar-causative-perspective-sources.json) preserves the existing desire and passive owners
and separates particle tendencies from universal permission/coercion rules.
The [appearance/impressions installment](articles/appearance-resemblance-and-impressions.md) adds 38 N4 tasks
in five groups covering そう, みたい, contextual よう, the two らしい uses and selected がる／たがる forms.
Its [ledger](docs/grammar-appearance-impressions-sources.json) preserves existing よう/desire owners and
keeps hearsay-そう an explicitly unscored N3 follow-up.
The [judgment/expectation installment](articles/thinking-possibility-and-expectation.md) adds 36 N4 tasks
in four groups for thought, possibility, expectation attachment and negative scope.
Its [ledger](docs/grammar-judgment-expectation-sources.json) preserves the twelve existing expectation
time/polarity tasks and the mixed-routine group; no fixed confidence ladder or new hard prerequisite is introduced.
The [reports/questions installment](articles/embedded-questions-and-reports.md) adds 40 N4 tasks in five groups:
embedded information questions, whether-or-not, reports, nominalized content/noticing and reported instructions.
Its [ledger](docs/grammar-reports-questions-sources.json) records exact reused owners and preserves fitting
bare-か／かどうか and の／こと alternatives in both answer modes, without making reported information proof.

The [volition/plans installment](articles/volition-plans-and-goals.md) adds 25 N4 tasks in three groups:
plain volitional formation, volitional thought and planned activities with 予定.
Its [ledger](docs/grammar-plans-goals-sources.json) records exact reuse of intentions, invitations,
goals, changes, maintained practice and desire; wish/advice and manner/purpose-plus-desire remain recognition bridges.

The [necessity/instructions installment](articles/necessity-advice-and-instructions.md) adds 41 N4 tasks and three N5 controls
in ten small groups, separating formation from interpretation and suggestions from retrospective evaluations.
Its [ledger](docs/grammar-necessity-instructions-sources.json) records exact reuse of requests/rules,
advice and favors, while preserving the harder mixed no-need contrasts at their existing levels.

The [time/linking supplement](articles/japanese-actions-states-and-time.md#とき-and-relative-event-order) adds 38 N4 tasks
in eleven groups for relative event viewpoints, simultaneous activity, negative links, causal/means/parallel connections,
deadline transfer and selective concession. It extends the existing time and
[reasons articles](articles/reasons-and-contrasts.md#て-links-for-reasons-means-and-parallel-facts), rather than creating another overview.
Its [ledger](docs/grammar-time-linking-sources.json) records exact reuse of temporal, foundation, conditional and のに owners.

The [respectful/humble introduction](articles/honorifics-humble-and-polite-language.md) adds 37 N4 tasks
in eight groups, distinguishing actor respect, a humble action's respected party and listener-directed formality.
It covers productive and common special forms, formal existence/copula, courteous requests and scoped service scenes.
Its [ledger](docs/grammar-honorific-humble-sources.json) records exact reuse of ordinary politeness, requests and benefactive viewpoints.

The [ease/methods/descriptions installment](articles/ease-methods-and-descriptive-forms.md) adds 30 N4 tasks
in six groups: ease/difficulty and proneness, method nouns with argument changes, adjective action modifiers,
and degree/quality nouns. Its [ledger](docs/grammar-productive-descriptions-sources.json) preserves existing
predicate, excess, change and demonstrative owners; kinds, materials and descriptive compounds remain short recognition bridges.

The [quantity/range/frequency installment](articles/quantity-ranges-and-frequency.md) adds 26 N4 tasks
and two N5 ordinary-action controls in five groups. It covers inclusive versus strict bounds, quantity framing,
frequency, negative scope and time/price frames. Its [ledger](docs/grammar-quantity-scope-sources.json)
records unchanged restriction, listing, comparison and estimate/limit owners and the bounded recognition bridges.

The [conversation-endings supplement](articles/explanations-quotations-and-endings.md#n4-conversation-endings-and-prefaces)
and [whole-message links](articles/reasons-and-contrasts.md#n4-links-between-whole-messages) add 24 N4 tasks and four N5 controls
in five groups: wondering, confirmation/familiar questions, explanatory prefaces, discourse connections and
register/quoted voice. Its [ledger](docs/grammar-conversation-connectors-sources.json) preserves the existing
N5 owners and distinguishes named formation from contextual interpretation, not gender or hierarchy tests.

## Confusable vocabulary

The [candidate inventory](docs/confusable-words.md) collects overlapping meanings, misleading English glosses,
similar forms, false friends, and other easy-to-conflate cases for future comparison articles. It is a working list with
provisional notation and links to existing material, not yet a complete usage reference or new app metadata.

## Kanji cards and words

Kanji cards, word articles and stroke data feed the [Ensō Nihongo Android app](https://github.com/stop-cran/kanji-cards-android). The
format is described in [docs/content-format.md](docs/content-format.md); data sources are in [NOTICE.md](NOTICE.md).

### App archive packaging

GitHub source ZIPs omit `.github/`, `docs/` and `tools/` using `.gitattributes` `export-ignore`.
These contributor instructions, source ledgers, review evidence and tools remain available in Git,
the web interface and clones; no runtime content or manifest entry is excluded.
Use a clone rather than a source ZIP when contributing or inspecting the complete audit trail.

`python tools/check_content_budget.py` checks exportable working-tree files, including untracked
runtime additions and any non-runtime files that still ship, and rejects exclusions of the manifest
or any manifested runtime file. The publishing entry guard is **18,000**, below the updated
Android **20,000-entry** hard limit. Both count directories and skipped files, not just cards.
The compressed, inflated, retained and per-file byte guards are unchanged.

The N2 baseline (`7535831`) has 7,964 public ZIP entries. The current
[N1 kanji-only expansion](docs/n1-authoring-notes.md) uses
[kanjiapi.dev's 1,232-kanji community set](https://kanjiapi.dev/v1/kanji/jlpt-1):
1,228 additions to the 985-card implementation baseline. Its twelve-card pilot needs
nine new support word articles and reuses eight; these are not an N1 vocabulary-list expansion.
The [accepted-pilot recalibration](docs/n1-sources/pilot-accepted-recalibration.json)
measures **8,101 entries / 43,393,072 retained bytes** before publication documentation.
At the pilot's mean card/stroke/manifest sizes, full kanji coverage with 9, 921 or 1,228
total new support articles would use approximately **10,533 / 11,445 / 11,752 entries**
and **47.100 / 48.755 / 49.312 MiB retained**. These are capacity sensitivities,
not support-count forecasts, targets, upper bounds or permission to spend media budgets.
The deliberately risk-heavy pilot does not establish future compressed/inflated sizes or effort.
At most 15 kanji per later batch means a floor of **83 batches / 166 initial review assignments**;
the pilot's separate curation pair already adds two assignments beyond that floor.
The later owner-main scene retirement (`7f40d40`) leaves **8,100 entries /
43,365,235 retained bytes** in the integrated tree without changing N1 teaching.
The [publication ledger](docs/n1-sources/pilot-publication.json) distinguishes
that integration from the original pilot/native measurement basis above.

The earlier **13,847-entry / approximately 52.4-MiB** projection combined kanji with
[3,427 N1 vocabulary rows](https://github.com/stephenmk/yomitan-jlpt-vocab/blob/b062d4e38c4bdd0950ae1d4ec55f04b176182e03/original_data/n1.csv).
That vocabulary project and other N1 sections remain deferred. Check actual combined output
incrementally against the unchanged 18,000-entry / 42-MiB compressed / 80-MiB inflated /
56-MiB retained publishing guards.

Deliver an upgraded Android APK before publishing an archive above older clients' **8,000-entry**
limit. Source publication alone does not upgrade installed apps; failed sync keeps their last accepted
offline collection. The pilot also requires curated-reading-compatible Android **`f9b59a2` or later**:
older APKs ignore its approved quiz subsets. The normally owner-signed prerequisite APK is
available to the owner; phone transfer/installation and physical-phone/general-release acceptance
remain explicitly outstanding. [Native acceptance](docs/n1-reviews/pilot-native-single-import-acceptance.md)
is bounded API35 emulator evidence for owner testing, not phone certification.
Before publication, check the exact GitHub ZIP and every manifested file/hash as well as local budgets.

### Content inventory

- `kanji/` – one card per kanji (997): meaning, radical, readings, common words, and origin notes or explicitly labelled modern-shape mnemonics.
  The deck covers all 79 N5, 166 N4, 367 N3 and 367 N2 kanji in the selected [kanjiapi.dev](https://kanjiapi.dev) community sets.
  It also includes 分 as a documented N5 exception, five N1 article-subject additions and the twelve-card N1 pilot:
  80 N5, 166 N4, 367 N3, 367 N2 and 17 N1. The [N2 expansion](docs/n2-review.md) added 365 cards
  to the two existing N2 cards in twenty-four 15-card batches and a final five-card batch.
  All 25 batches have independent GPT/Claude review and reconciled reports, including changed-passage confirmations.
  These community level sets are not official JLPT kanji lists.
  The `starter` tag identifies the original 118-card cohort, not the later expansions.
- `words/` – one article per written word form (4,951): native words, Sino-Japanese compounds and loanwords, including kana-only spellings.
  Articles explain meaning, spelling or formation, synonyms, antonyms and usage distinctions.
  The selected community vocabulary list's 684 N5 and 640 additional N4 rows are covered by 1,308 articles:
  924 new articles and 384 reused ones. Multiple source readings can share an article.
  Its 1,730 additional N3 rows are covered by 1,698 articles: 1,490 new and 208 reused from the preceding collection.
  The level indexes overlap where an existing article teaches an additional reading or meaning.
  The [N2 vocabulary expansion](docs/n2-vocabulary-review.md) covers all 1,812 further
  source rows with 1,793 articles: 1,669 new and 124 reused. All 91 batches have sequential
  independent GPT/Claude reviews, reconciled findings and post-review confirmations.
  Word and applicable existing N2 kanji cards link reciprocally; the
  [completion audit](docs/n2-vocabulary-completion-audit.json) records the exact coverage and limits.
  Nine additional articles support the N1 kanji pilot; their vocabulary levels are not inferred from kanji membership.
- `strokes/` – generated stroke data. Validate with `python tools/validate.py`.
- `grammar/` – versioned, contrast-focused exercises for the app's Grammar section: the original 8-exercise pilot, an
  18-exercise foundations batch on nominalization and negative meanings, 12 exercises on ability, occurrence, decisions and
  outcomes, 9 on intended meaning, inference and normative judgment, 9 on ところ action stages, 6 on まま state contrasts,
  6 on before/after event order, 27 on time windows, periods and occasions, 24 on purposes, causes and alternatives,
  12 on evidence, cases and conditions, 12 on models, governing conditions and linked steps,
  12 on comparison, addition and advice, 15 on expectations and eventual outcomes,
  12 on characteristic patterns, recollections and reasons, 15 on particle neighbors,
  12 on degree, comparison and desired extent, 12 on plans and believed completion,
  12 on よう comparisons, examples and desired outcomes,
  12 on きり limits, estimates, last events and recurring follow-ups,
  12 on よう changes in ability or habit and positive/negative practices,
  12 on つもり self-assessment versus intended changes,
  12 on negative plans and present/past intention denial,
  12 on retained versus changed noun/adjective states,
  12 on ほか exclusions and no other option versus no need,
  12 on past はず expectations, event time and actual outcomes,
  12 on possible versus desired extent with かぎり／だけ,
  12 on くらい degree/minimum versus のに counterexpectations,
  12 mixed-context questions on changed routines, maintained practices and current inferences,
  12 on recent completion, retained states and inferences about past actions,
  12 on current intentions, no need and no available alternative,
  12 on earlier intentions, completion beliefs and current inferences,
  12 on norms, predictions and goal-relative practical necessity,
  60 on たら／ば／なら／と／場合 conditionals in two batches, 26 on のに and related contrasts,
  36 on listing, examples and addition, 36 on は／が／も topic, contrast and inclusion,
  64 on basic nouns and particles, 50 on restriction and unexpected inclusion,
  48 on compound relations and formal-noun contrasts, 125 introductory N5 foundations exercises,
  54 on pointing and asking questions, 32 on noun descriptions and activities,
  38 on wants, plans, invitations and offers, 34 on reasons, contrasts and prefaces,
  42 on comparisons, changes and degree, 36 on giving, receiving and viewpoint,
  52 on explanations, quotations and endings, 34 on desire, actors and outcomes,
  34 on ability and perception, 28 on actions/events/results, 24 on trying/preparing/completing,
  36 on benefactives/requests, 34 on direction/development/stages, 30 on passive participants,
  40 on causative perspective, 38 on appearance/impressions, 36 on judgment/expectation,
  40 on embedded questions/reports, 25 on volition/plans, 44 on necessity/instructions, 38 on time/linking,
  37 on respectful/humble language, 30 on ease, methods and descriptions, 28 on quantity/scope,
  and 28 on conversation/discourse (1738 in total).
  All 1738 exercises have grammar-only study labels: **596 N5, 801 N4, 235 N3, 102 N2 and four N1**.
  These are editorial estimates using Bunpro as the primary reference, with documented JLPT Sensei comparisons,
  not an official syllabus. Vocabulary and kanji difficulty do not determine them; natural examples remain unchanged.
  See the [policy and per-article distribution](docs/jlpt-levels.md#grammar-baseline) and
  [original classification record](docs/grammar-jlpt-sources.json) and
  [N5 foundations ledger](docs/grammar-n5-foundations-sources.json). Mixed-level articles are browsed through matching exercises.
  Time practice includes うち, あいだ, とき, ころ, たび and shared とき／おり／さい occasion answers;
  shared alternatives are not independently contrasted targets.
  Purpose/cause practice adds ため, おかげ, せい, かわり and ついで, including compensating trade-offs.
  Condition practice covers かぎり evidence limits and positive/negative conditions, plus ばあい procedural cases.
  Relational practice covers とおり／どおり, もと, and additive versus preliminary-step うえ.
  Comparison/advice practice adds ほう and additive ほか, including recommendations to do or not do something.
  Expectation/outcome practice adds わり and くせに, plus six shared すえ／あげく answers contrasted with additive うえ.
  The shared outcome items show three model options per noun, not independent discrimination between the two nouns.
  The もの batch practices general patterns and past recollections, plus casual もの／もん reasons versus わけだ conclusions.
  Particle practice groups six shared approximate quantities with ほど／くらい／ぐらい／ばかり, adds three constrained だけ
  limits, and contrasts three activity-concentration with three recent-completion ばかり items.
  The six shared quantity items are not independently discriminated particle targets.
  Degree/extent practice adds three each for a stated ほど degree, a below-standard comparison, correlated change with
  VばVるほど, and a desired amount with Vたいだけ. It uses controlled adjective forms and explicitly named whole patterns.
  Plan practice adds three each for affirmative and negative つもり intentions, past intentions and past beliefs in
  completed actions. It preserves the difference between 送るつもりでした and 送ったつもりでした, including a fulfilled
  plan and a confirmed belief; not every past plan failed or every completion belief was mistaken.
  よう practice contrasts three adverbial comparisons with three direct noun modifiers, then three enabled-ability
  goals with three prevented-ability goals. Noun modifiers include two category examples and one figurative resemblance;
  they are not three independently tested examples of each meaning.
  Change/effort practice adds three newly possible actions and three new habits before supplied ようになりました,
  then three positive and three negative maintained practices before supplied ようにしています.
  These verb-form tasks do not independently test selecting なる versus する in unrestricted contexts.
  Self-assessment practice adds six matched つもり pairs, using two nouns, two な-adjectives and two い-adjectives.
  It distinguishes a current self-view from an intention to become something or change a quality, with つもりです supplied.
  Intention-denial practice groups three shared negative plans/denials against three affirmative future intentions,
  then contrasts three denied past intentions with three affirmed ones. It includes accidental actions, blocked intentions
  and a fulfilled plan; an outcome does not by itself establish whether it was intended.
  Noun/adjective state practice adds six matched まま／なる pairs, using two nouns and two adjectives of each class.
  It distinguishes persistence from a transition across the stated interval, including desirable retained states, deliberate
  changes and a past clean state that no longer holds; it does not claim that every detail stays unchanged.
  Exclusion practice contrasts three outside-group ほか answers with three shared within-group なか／うち answers,
  then three shared no-alternative ほか／しか answers with three no-need ことはない answers.
  It preserves the relevant group or goal, accepts fitting particle variants and distinguishes no need from prohibition.
  Past-expectation practice separates earlier forward expectations from current inferences about completed events,
  then affirmative from negative recalled expectations. It includes fulfilled and contradicted outcomes, preserving the
  explicit recollection contexts that avoid treating every はずだった as an automatically failed forecast.
  Possible-extent practice adds six shared potential＋かぎり／だけ answers against six たいだけ desired amounts.
  It separates the available and desired bounds using access, space, transport, supplies, service quotas and speaking time;
  three かぎり and three だけ model labels are not independently discriminated targets.
  The latest particle batch adds three shared くらい／ぐらい／ほど degree illustrations and three くらい／ぐらい basic
  minimums, each with three reciprocal のに counterexpectations. It includes noun-predicate な attachment, optional は
  for the selected minimums, speaker-relative ease and tone, and a favorable outcome despite an obstacle.
  The first mixed set blanks the whole ending and uses one common five-pattern pool throughout: ようになる／ようにする／
  ことにする／はずだ／ようだ. Four questions per function now include contextual なる-versus-する selection, with shared
  ことにしている and habitual ようにする practice alternatives, plus ようだ inferences. The English meaning remains visible, but no item-specific
  form instruction selects the function or conjugation for the learner.
  The next mixed set contrasts shared たところ／たばかり completion, retained たまま results and current はずだ／ようだ
  judgments about past actions. Matching few-second window contexts prevent elapsed time alone from selecting the account;
  deliberate states, lights remaining off and a coat drying in an unchanged position preserve the underlying distinctions.
  Mixed intention/necessity practice adds voluntary unnecessary plans, shared ことはない／必要 no-need answers and all
  fitting basic ほか／しか no-alternative endings. Requirements do not determine intentions, and alternatives are evaluated
  relative to the stated goal rather than every imaginable action.
  Mixed past-stance practice blanks the whole predicate and separates earlier intentions, earlier completion beliefs
  and current はずだ／ようだ inferences about past actions. Fulfilled/unfulfilled plans and supported/contradicted beliefs
  prevent outcome-based guessing; first-person inferences prevent pronouns from supplying the answer.
  Basic だった／であった and だ／である alternatives remain within one shared visible task.
  The final mixed set distinguishes normative べき／もの, predictive はず／よう and goal-relative ほか／しか.
  The same return/wait/contact/redo verbs recur across the three accounts, with complete predicate blanks that retain
  both 連絡するべき and 連絡すべき. Norms can be followed or violated, a prediction can align with a rule,
  and an optional goal can still have a necessary means. Shared equivalents remain one answer class per exercise.
  The first conditionals set adds four introduction groups: 10 named-form tasks, six prospective/completed なら premises,
  six positive/negative state conditions, and eight discoveries, counterfactuals and procedural cases.
  It accepts fitting alternatives within the visible task, rather than claiming unique five-way conditional selection.
  The second set adds five six-exercise groups: further verb/negative-predicate forms; preparation, event triggers and
  ongoing actions; mechanisms, past habits and state-based requests; planned/completed procedural cases; and imagined
  present identities. The original 30 remain unchanged. Across the 60 exercises, たら is accepted in 33, ば in 27,
  なら in 24, と in 14 and 場合 in 20; these overlapping counts measure supported forms, not independent discrimination.
  Nonhypothetical 私の場合, dedicated nominal なのなら practice and explicit necessary-versus-sufficient reasoning
  remain gaps in this dedicated comparison set. Conditional set expressions remain outside its basic scope.
  The のに follow-up adds eight relationship/attachment tasks, six explicit meaning-label questions, six overlapping
  のに／わりに／くせに contrasts and six はず／つもり compositions, in four introduction groups.
  It distinguishes concession from required time and tool use without judging by the spelling or tense alone.
  The six overlap tasks accept fitting alternatives together; they are not independent discrimination of every connector.
  The listing set has six groups of six: noun lists and single examples; たり formation; し/て attachment;
  examples versus variation and denial; inclusion, alternatives and suggestions; and added facts/reasons versus のに.
  It contains 24 completion tasks and 12 explicitly defined meaning-label tasks. Eight questions accept substantive
  alternatives together, with optional choose-any buttons; named-form drills state their restrictions before answering.
  The topic set has six groups of six: topic/が architecture; conversational interpretation; stated comparisons;
  positive/negative inclusion; case-particle combinations; and shared framings/context-supported omission.
  Its 21 completion and 15 meaning-label tasks keep formation restrictions visible and avoid pretending that every
  isolated sentence has one uniquely natural particle. Three questions accept both は and が with optional choose-any buttons.
  The basic-particle set has 11 groups covering noun endings, sentence roles and whole phrases, existence/activity/event
  locations, tools/transport/languages, destinations and other に patterns, companions/lists, の modification, ranges/deadlines,
  clock times/durations, a は/も bridge and special particle pronunciations. Formation restrictions and interpretation labels
  are visible before answering. Two broad destination questions accept に／へ／まで with their different nuances and optional
  choose-any buttons. A third question accepts both 日本語で話します and 日本語を話します, explaining medium versus
  language-as-object framing without transferring を into a letter-writing sentence that already contains 手紙を.
  These shared-answer tasks do not claim to distinguish their accepted realizations independently.
  The restriction/inclusion set has eight groups: restriction formation and meaning; negative scope and not only;
  retained case roles; さえ/でも and shared inclusion; negative addition and minimum counts; emphatic versus endpoint まで;
  ordinary/scalar も and でも suggestions; and focus scope with a conditional-さえ recognition boundary.
  Its 16 formation, 30 interpretation and four contextual questions make their answer units explicit.
  Two bounded transfer questions apply restriction to refrigerator contents and cash in a wallet.
  The conditional questions distinguish a sufficient condition from an unestablished exclusive-route claim.
  The two shared questions accept fitting inclusion alternatives, with eight substantive extra buttons in total;
  this is not independent discrimination of every accepted framing.
  The compound-relation set has eight groups covering subject matter, directed targets, evaluative standpoints,
  noun modifiers, shared topic frames, intended benefit, noun-based attachment and nominalized/comparative layers.
  Its 22 formation, 22 interpretation and four bounded contextual questions distinguish the requested answer units.
  Six drills assemble a supplied noun with its relation; two convert a polite verb to a plain form plus こと.
  Interpretation-label ordering is independent of the answer, and repeated scenarios share context keys.
  Two talking contexts accept について／に関して／のことを together, without pretending their structures or styles
  are identical. The Nのこと／Nであること contrast tests explicit nominalization, not disjoint possible conversation topics.
  All 60 conditional, 26 のに, 36 listing, 36 topic, 64 basic-particle, 50 restriction/inclusion and 48 compound-relation
  prompts have reviewed vocabulary coverage; pure grammar prompts deliberately have no lexical hints.
  Author-reviewed coverage was **771/1168** after the 125 N5 foundations, 54 pointing/questions,
  32 noun-description, 38 wants/plans, 34 reasons/contrasts, 42 comparisons/change,
  36 giving/receiving, 52 explanations/endings and 34 desire-comparison prompts,
  with the original 397 then pending. The N4 series above records subsequent additions and backlog completion.
  The のに source record keeps author and independent review snapshots separate;
  the unsettled causal-past expectation card was retired in favor of a current timetable-based preparation example.
  The topic article and exercise set have independent `gpt-6-astra` and `claude-opus-5.5` reviews, followed by
  original-reviewer reconciliation; historical verdicts and corrected snapshots are recorded separately.
  The unchanged basic-particle article has a fresh independent review, CLEAN in correctness, scoped coverage and
  comprehensibility. Its exercises have a full initial independent review followed by informed fresh-reviewer
  reconciliation, now CLEAN in all three facets within that scope. Initial findings and corrected verdicts remain
  separate; see the snapshots, findings and coverage matrix in the
  [basic-particle source record](docs/grammar-basic-particles-sources.json).
  The restriction/inclusion article and initial 48 exercises have a full independent review.
  Informed fresh-reviewer reconciliation resolved one minor feedback defect and the adopted optional refinements;
  all three facets are CLEAN, combining review of the 18 changed and two new objects with unchanged prior coverage.
  Initial findings, reviewer-continuity limits, source evidence, coverage and exact snapshots are in the
  [restriction/inclusion record](docs/grammar-restriction-sources.json).
  The compound-relation article and all 48 exercises have an initial independent review. Informed fresh-reviewer
  reconciliation resolved an interpretation-answer ordering cue and the adopted metadata/formation refinements.
  All three facets are CLEAN within the composite scope: 34 complete objects were freshly assessed and 14 unchanged
  objects carry forward their initial review. Sources, original reports, corrected snapshots and recognition-only
  boundaries are recorded in the [compound-relation source record](docs/grammar-compound-relations-sources.json).
  See the [content format](docs/content-format.md#grammar-exercises), [foundations sources](docs/grammar-foundations-sources.json),
  [actions sources](docs/grammar-actions-sources.json), [intent sources](docs/grammar-intent-sources.json),
  [action-stage sources](docs/grammar-stages-sources.json), [state sources](docs/grammar-states-sources.json),
  [before/after sources](docs/grammar-before-after-sources.json),
  [time-expression sources](docs/grammar-time-sources.json), [cause/alternative sources](docs/grammar-causes-sources.json),
  [condition sources](docs/grammar-conditions-sources.json), [relation sources](docs/grammar-relations-sources.json),
  [comparison/advice sources](docs/grammar-comparisons-sources.json),
  [expectation/outcome sources](docs/grammar-expectations-sources.json),
  [pattern/recollection/reason sources](docs/grammar-mono-sources.json),
  [particle-neighbor sources](docs/grammar-particles-sources.json),
  [degree/extent sources](docs/grammar-degree-extent-sources.json),
  [plan/belief sources](docs/grammar-plans-sources.json),
  [よう sources](docs/grammar-you-sources.json),
  [change/effort sources](docs/grammar-you-change-effort-sources.json),
  [self-assessment sources](docs/grammar-self-assessment-sources.json),
  [intention-denial sources](docs/grammar-intention-denial-sources.json),
  [noun/adjective state sources](docs/grammar-state-change-sources.json),
  [exclusion/no-alternative sources](docs/grammar-hoka-exclusion-sources.json),
  [past-expectation sources](docs/grammar-past-expectation-sources.json),
  [possible-extent sources](docs/grammar-possible-extent-sources.json),
  [くらい degree/minimum sources](docs/grammar-kurai-degree-minimum-sources.json),
  [mixed-routine sources](docs/grammar-mixed-routines-sources.json),
  [mixed completion/state sources](docs/grammar-mixed-completion-state-sources.json),
  [mixed intention/necessity sources](docs/grammar-mixed-intention-necessity-sources.json),
  [mixed past-stance sources](docs/grammar-mixed-past-stance-sources.json) and
  [mixed norms/expectations sources](docs/grammar-mixed-norms-expectations-sources.json),
  plus the [initial conditionals sources and review](docs/grammar-conditionals-sources.json) and
  [second conditionals batch and combined coverage](docs/grammar-conditionals-contexts-sources.json), plus the
  [のに source and coverage record](docs/grammar-noni-sources.json),
  [listing source and coverage record](docs/grammar-listing-sources.json) and
  [topic-particle source and coverage record](docs/grammar-topic-sources.json).
  Every named formal-noun/particle family in the formal-nouns article now appears in practice, but this is not complete construction
  coverage. The five mixed sets complete the bounded formal-noun expansion planned in
  [Android #46](https://github.com/stop-cran/kanji-cards-android/issues/46); the app's remaining engineering, documentation
  and local-evidence acceptance is separate. Stated pools do not claim every construction or register, or unrestricted cloze.

The revised JLPT does not publish exhaustive kanji or vocabulary syllabi. Level coverage here means the exact named community set,
not a guarantee about every examination question or a complete beginner curriculum.
See the [level-source policy](docs/jlpt-levels.md) and the [N4](docs/n4-source-snapshot.json) and
[N3](docs/n3-source-snapshot.json) kanji source snapshots. The
[N5/N4 vocabulary snapshot](docs/n5-n4-vocabulary-snapshot.json) and
[source-row index](docs/n5-n4-vocabulary-sources.tsv) preserve the pinned list, spelling normalizations, corrected dictionary identities
and sense qualifications.
The separate [N3 vocabulary snapshot](docs/n3-vocabulary-snapshot.json) and
[source-row index](docs/n3-vocabulary-sources.tsv) extend that same pinned list and dictionary snapshot.
The [N2 vocabulary snapshot](docs/n2-vocabulary-snapshot.json) and
[source-row index](docs/n2-vocabulary-sources.tsv) cover its N2 rows using the later 2026-10-21 dictionary snapshot.
The [article-subject snapshot](docs/article-subjects-source-snapshot.json) records the six additional kanji,
17 new word cards, and reuse of 訳 for わけ, including dictionary-reading caveats and the 妖 level exception.
作家 is shared with the N3 vocabulary expansion, so merging these additions adds 16 distinct word cards to that collection.

Source-covered word articles carry their own `jlpt` metadata: 672 N5, 636 N4, 1,625 N3, 1,739 N2 and two N1 articles, independently of the kanji they contain.
This article-level label does not assign every subsidiary sense or reading to that level. The remaining 277 articles have no
sourced word-level label. In particular, the pinned list's N1 labels for くらい and だけ are not recommendations to postpone these basic particles.
Vocabulary-aware app versions use explicit levels first and retain kanji-based inference only when the
field is absent; older versions ignore word-level metadata. N4 study includes N5; N3 study includes both.
Known ambiguous word pairs are marked with [`quiz_exclusions`](docs/content-format.md#word-article);
these require an exclusion-aware app version and do not imply that every possible ambiguity has been identified.

## N5 listening

`listening/` contains 36 original passages (26 dialogues and ten monologues), with 108 questions and about 20m35s of audio.
The original twelve are preserved; the [24-passage expansion and coverage ledger](docs/listening-n5-expansion/coverage.json)
broaden home, classroom, belongings, appointment, errand and recreation contexts. Each passage has three English questions,
explanations, transcript, translation and vocabulary tips. These are N5-oriented learning materials, not official JLPT exam items
or a guarantee of readiness. Two optional contextual illustrations provide unselected classroom/reception settings without supplying scored facts.
The recordings use Microsoft Azure Speech's stock Nanami, Keita, Aoi and Daichi Japanese voices at mildly slower -10% or -5% rates.
They are synthetic speech, not recordings of human actors. Each exact final recording has been listened to and approved
against its questions. See the [authoring and approval contract](docs/listening-n5.md).
Approved mono Ogg Opus recordings are in `audio/`; PCM caches and Azure configuration do not belong in this repository.
The [audio](docs/listening-n5-expansion/audio-generation.json) and [image provenance](docs/listening-n5-expansion/images.json)
record the expansion's exact outputs, owner approval and remaining device-integration limits.

## Onomatopoeia collection

The [201-word index](articles/japanese-onomatopoeia.md) preserves the first 100 and adds a
[second 100](articles/japanese-onomatopoeia.md#second-100-word-cards), grouped by everyday situation.
The second batch adds 97 cards and enriches three existing ones, plus three comparison guides.
Later additions are listed separately, beginning with [ぶかぶか / ブカブカ](words/ぶかぶか.md), for oversized clothing or shoes.
Cards carry the `onomatopoeia` tag, a broad category such as
`giongo`, `giseigo`, or `gitaigo`, and a form tag where applicable. Categories can overlap by sense;
these tags are not new word types or JLPT levels. Existing word IDs and sourced level labels are retained.

The app has an Onomatopoeia stack with the normal word quizzes. Eligible named scenes (`scenes/` and `images/`)
support both picture-to-word and word-to-picture quizzes; article-only scenes remain visible in the article.
The Onomatopoeia stack includes
tagged words independently of JLPT level; unlevelled words also remain in All rather than a numbered JLPT stack.
All 201 tagged words have scene catalogs, with 397 illustrations in total. The ぷにぷに scenes pair
a duck-shaped squishy toy with a cat's soft paw pad, showing the texture in inanimate material and living tissue.
See the [collection and source notes](docs/onomatopoeia.md).

### Generated images

The word-scene pictures in `images/` are AI-generated with Azure OpenAI from original scenes in
`tools/image_prompts.json` and `tools/onomatopoeia_scene_plan.json`, then compressed to 512 px WebP. Each illustrates one selected use, not
every sense or a guarantee of unique quiz choices. The original 20-image pilot has owner approval.
The new 100 received an assistant visual review and were **accepted by the owner for learning use
on 2026-10-19**; feedback from actual study remains to come.
The [named-scene provenance and per-picture observations](docs/onomatopoeia-scene-images.json) record
the actual model, output hashes, corrections and limitations. The images are text-free by design,
but generated art may still contain small inaccuracies. Earlier batch acceptance does not imply owner
approval of later additions. The original implementation is tracked in
[app issue #45](https://github.com/stop-cran/kanji-cards-android/issues/45).

## Approach

- Keep each article independently readable, with a short explanation of the central distinction.
- Write explanations in English; retain Japanese spellings and examples, with English translations.
- Distinguish useful learning shortcuts from strict grammatical or semantic rules.
- Note differences in register, context, and classification where they matter.
- Link to references for further study. Some source material is in Japanese even though the articles are in English.

The notes focus on practical understanding rather than exhaustive coverage. Examples illustrate particular uses; their translations are not intended as universal replacements for the Japanese expressions.

For contributors and reviewers, see the [writing and review guidance](.github/copilot-instructions.md) and [REVIEW.md](REVIEW.md).
