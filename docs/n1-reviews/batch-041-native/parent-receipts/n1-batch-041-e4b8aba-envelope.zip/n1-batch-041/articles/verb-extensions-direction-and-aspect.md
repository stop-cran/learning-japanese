# Japanese verb extensions: direction and aspect

**Japanese often uses another verb to describe where an action goes, how it unfolds, or what result is left. But 読んでおく and 読み続ける use different attachment patterns: て-form + verb versus verb stem + verb.** Recognizing the pattern is the first step; interpreting the whole construction is the second.

Compare **読んでおく**, "read beforehand," with **読み続ける**, "keep reading." Neither expression describes a new kind of reading. Instead, it places the activity in relation to preparation or continuation.

This article covers direction, temporal viewpoint, beginning, continuation, completion, and related preparation/result meanings. **Aspect** concerns how an event unfolds or is presented, rather than simply when it happens. Keigo, or honorific language, is a separate topic: not every subsidiary verb expresses direction or aspect.

## 1. Two ways to extend a verb

### The useful terms

| Term | What it describes here | Examples |
| --- | --- | --- |
| **補助動詞（ほじょどうし）**, subsidiary or auxiliary verb | A verb whose independent meaning is weakened in a grammatical use | ～ていく, ～てくる, ～ておく, ～てしまう |
| **複合動詞（ふくごうどうし）**, compound verb | A combination formed from a verb's continuative form plus another verb | 読み始める, 読み続ける, 読み込む |

These are not completely disjoint categories. Some descriptions also call certain compound second members subsidiary verbs. Conversely, merely following て does not make a verb a grammatical auxiliary: it may still describe an ordinary action.

NINJAL distinguishes **syntactic compounds**, such as productive patterns with ～始める, from **lexical compounds**, whose combinations and meanings are more word-specific. Both can use the stem + verb pattern. For learning, the important question is how freely a pattern combines and how predictable its meaning is.

**形式動詞（けいしきどうし）**, "formal verb," exists as a framework-specific term, but is not a useful umbrella here. One historical dictionary definition refers specifically to す／する. Nor is **補助動詞** identical to **助動詞（じょどうし）**, the traditional category containing endings such as た and たい.

This resembles the classification caution in [the article on noun-based grammar](koto-wake-and-formal-nouns.md): a useful family resemblance does not guarantee one universal grammatical category.

### How the parts attach

The **ます-stem** is what remains when you remove ます from the polite form: 読みます gives 読み. It is a learner-friendly way to identify the relevant **連用形（れんようけい）**, or continuative form.

| Dictionary form | ます-stem | て/で-form |
| --- | --- | --- |
| 読む - read | 読み | 読んで |
| 書く - write | 書き | 書いて |
| 食べる - eat | 食べ | 食べて |
| する - do | し | して |
| 来る（くる） - come | 来（き） | 来て（きて） |

Thus:

- **読んで + おく → 読んでおく**: read beforehand.
- **読み + 続ける → 読み続ける**: keep reading.

Do not remove the final kana of every dictionary form: 読む becomes 読み, not 読. Nor does the continuative form automatically turn the verb into a noun.

To build that stem from a dictionary form, change a godan verb's final u-row sound to its i-row counterpart
(書く → 書き, 読む → 読み); remove る from an ichidan verb (食べる → 食べ).
The irregular stems are し from する and き from 来る. Use the
[verb foundations](japanese-verb-foundations.md) to identify the class first: not every verb ending in る is ichidan.

Conjugate the final verb according to its class. **読んでおく → 読んでおいた／読んでおかない**, "I read it beforehand / I won't read it beforehand"; **読み続ける → 読み続けた／読み続けない**, "I kept reading / I won't keep reading." Polite forms likewise appear at the end: **読んでおきます**, **読み続けます**.

| Final member | Plain past | Plain negative |
| --- | --- | --- |
| 始める／続ける | 始めた／続けた | 始めない／続けない |
| 出す／直す | 出した／直した | 出さない／直さない |
| 終わる | 終わった | 終わらない |

Read **直す（なおす）**, "redo/correct" in the compound use below. Named attachment drills sometimes keep the
added member in kana so attention stays on stem formation and final inflection. That is a visible practice
convention, not a claim that ordinary kanji spellings are ungrammatical.

## 2. Coming and going: movement becomes viewpoint

### Physical direction

Imagine standing by a lake and watching a bird:

| Sentence | Interpretation from your position |
| --- | --- |
| 鳥が飛んできた。 | A bird flew toward me. |
| 鳥が飛んでいった。 | A bird flew away from me. |

**[～てくる](../words/来る.md)** presents movement toward a viewpoint; **[～ていく](../words/行く.md)** presents movement away from it. The viewpoint is often the speaker's location, but context can establish another center. These are relative directions, not compass directions.

The final verbs are still conjugated: くる becomes **きた**, and いく becomes **いった**.

### Development through time

The same viewpoint contrast helps with activities extending through time:

> これまで毎日、日本語を勉強してきた。  
> I have studied Japanese every day up to now.

> これからも毎日、日本語を勉強していく。  
> I will continue studying Japanese every day from now on.

In the first, you look back over an activity leading **up to your reference point**. In the second, you view it as extending **onward from that point**.

```text
earlier activity ----> reference point ----> onward development
     ～てきた                                ～ていく
```

This is a picture of those examples, **not a tense rule**. ～てくる does not mean "past," and ～ていく does not mean "future":

> その後、町は少しずつ変わっていった。  
> After that, the town gradually changed.

Here, change unfolds forward from a point in a past narrative.

> これから、もっと寒くなってくるだろう。  
> It will probably get colder from now on.

Here, a future change is presented as coming into the speaker's experience. The choice concerns viewpoint as well as time.

Also, looking back with ～てきた does not imply that the activity has now stopped. Someone can say 勉強してきた and intend to continue.

### A change comes into experience

> 説明を聞いて、だんだん分かってきた。  
> Listening to the explanation, I have gradually begun to understand.

Nothing literally travels toward the speaker. **～てくる** presents understanding as emerging into their experience. Similar uses involve something becoming audible, visible, or noticeable.

Do not force every ～てくる into that explanation. Spoken before stepping out, **パンを買ってくる**, "I'll go buy some bread and come back," concerns an errand and return. The meaning comes from the verb and situation, not just the final くる.

## 3. How an action unfolds: start, continue, finish

### Beginning: ～始める and ～出す

Both take the **ます-stem**. **[～始める](../words/始める.md)（はじめる）** is a relatively neutral way to mark a beginning; onset **[～出す](../words/出す.md)（だす）** brings the beginning into focus, often as something abrupt or noticeable.

| Example | Natural interpretation |
| --- | --- |
| 雨が降り始めた。 | It began to rain. |
| 雨が降り出した。 | It started raining, with the onset more prominent. |

Here, 降る（ふる） means "rain" or "snow." Both sentences can describe the same event; the distinction is in how the beginning is presented.

Do not memorize "始める = slow and intentional; 出す = always involuntary." Rain is not intentional with either form, and a person can deliberately set off running: **走り出す**. However, the patterns are not freely interchangeable in instructions: **読み始めてください**, "Please start reading," is the straightforward choice for asking someone to begin.

Nor does every compound ending in 出す mean "start." We will return to its outward and lexical meanings below.

### Continuation: ～続ける

**[～続ける](../words/続ける.md)（つづける）** makes continuation or persistence explicit:

> 疲れたが、本を読み続けた。  
> I was tired, but I kept reading the book.

Continuation may also span repeated occasions: **毎日日記を書き続ける** means "keep writing a diary every day," not writing continuously without sleeping.

For the limited comparison needed here, **読んでいる** can describe someone reading, while **読み続けている** explicitly presents them as continuing to read. ～ている has a broader aspectual system; it is not simply another way to say "keep doing."

The spelling is **つづく／つづける**, not つずく／つずける. **続く（つづく）** is the intransitive verb "continue," and occurs in established compounds such as **降り続く（ふりつづく）**, "continue raining or snowing." But the broadly useful pattern here is **V-stem + 続ける**: do not replace it freely with 続く.

### Doing it again: ～直す

Attach **直す（なおす）** to the same stem, not to the て-form:

> 名前を間違えたので、手紙を書き直した。  
> なまえをまちがえたので、てがみをかきなおした。  
> I got the name wrong, so I rewrote the letter.
>
> 結末を確かめたくて、小説を読み直した。  
> けつまつをたしかめたくて、しょうせつをよみなおした。  
> I reread the novel because I wanted to check the ending.

**書き続けた** continues writing; **書き直した** returns to the writing and does it over.
Rereading does not repair the printed book, and rewriting does not guarantee that every error is now fixed.
The second member often contributes correction or reconsideration, but the whole compound and context matter:
do not attach 直す to arbitrary verbs just because English permits "again."

### Ending and completion: ～終わる, ～切る, ～てしまう

These can all occur around the end of an activity, but they do not express the same thing:

| Form | Attachment | What it highlights in these uses |
| --- | --- | --- |
| **[～終わる](../words/終わる.md)（おわる）** | ます-stem | Finishing an activity |
| **[～切る](../words/切る.md)（きる）** | ます-stem | Doing something all the way through or completely |
| **～てしまう** | て/で-form | Getting something done; in other contexts, ending up doing something, often with an emotional reaction |

Compare:

> この本を読み終わった。  
> I finished reading this book.

> 長い本だったが、最後まで読み切った。  
> It was a long book, but I read it all the way through.

Both can describe a completed reading. **読み終わる** identifies the endpoint; **読み切る** emphasizes reaching it fully. The second example suggests achievement because of its context, but ～切る does not always imply difficulty.

**～てしまう is not invariably regretful:**

> 今日中に、この本を読んでしまおう。  
> I'll get this book read by the end of today.

This presents finishing as something to get done. Compare an unwanted development:

> 本を読んでいたが、途中で寝てしまった。  
> I was reading the book, but ended up falling asleep partway through.

The last sentence does not mean "I finished sleeping." It illustrates why "finish" alone is not an adequate definition of ～てしまう.

In casual speech, **～てしまう → ～ちゃう** and **～でしまう → ～じゃう**: **食べちゃった**, "ate it up / ended up eating it"; **読んじゃった**, "finished reading it / ended up reading it." Context still determines the nuance.

Likewise, not every ～切る compound describes completing a task: **疲れ切る（つかれきる）** means "be completely exhausted." Learn the applicable sense, not a universal instruction to attach 切る to anything.

## 4. Doing it beforehand and leaving it that way

### Preparation with ～ておく

**[～ておく](../words/置く.md)** often presents an action as preparation for later:

> 明日の授業の前に、この文章を読んでおく。  
> I'll read this passage beforehand, before tomorrow's class.

The reading is useful for what follows. Unlike a plain 読む, the expression explicitly frames it as an advance arrangement.

In its completion use, **読んでしまう** emphasizes getting the reading done; **読んでおく** frames it as preparation. In a suitable situation, both could describe the same planned reading, but with different emphasis.

### Leaving a state in place

Another important use is keeping or leaving something in a state:

> 部屋が暑いので、窓を開けておく。  
> The room is hot, so I'll leave the window open.

Depending on the situation, this may include opening it or keeping it open. It does not merely mean putting a completed opening action on a timeline.

One compact comparison is enough:

| Sentence | Focus |
| --- | --- |
| 窓を開けておく。 | I will open/leave the window open as an arrangement. |
| 窓が開けてある。 | The window has been opened and left that way intentionally. |
| 窓が開いている。 | The window is open. |

**開ける（あける）** is transitive, "open something"; **開く（あく）** is intransitive, "open/become open." The last sentence describes the state without itself specifying an intentional arrangement. These are supporting contrasts, not a full lesson on ～てある or ～ている.

The focused [actions, events and results](actions-events-and-results.md) lesson develops these roles,
both が and を frames for てある, and contextual result/preparation choices. Preparation and an already
prepared result can have compatible descriptions; the particle alone is not a universal answer key.

**そのままにしておく**, "leave it as it is," connects this construction to [まま and unchanged states](koto-wake-and-formal-nouns.md#まま-a-state-remains-unchanged).

For recognition in casual conversation, **～ておく → ～とく** and **～でおく → ～どく**: **見ておく → 見とく**, "look beforehand"; **読んでおく → 読んどく**, "read beforehand."

The focused [trying/preparing/finishing companion](trying-preparing-and-finishing.md) adds てみる,
basic auxiliary formation and contextual use, plus とく／どく and ちゃう／じゃう recognition.
It separates completion from regret without replacing the direction/compound discussion here.

## 5. Inside, outside, and deeper: learn the whole compound

### ～込む: inward movement and more

**[～込む](../words/込む.md)（こむ）** takes the **ます-stem**, but does not have one freely applicable translation:

| Compound | Meaning in the selected use |
| --- | --- |
| 部屋に飛び込む | Rush/leap into a room |
| 問題について考え込む | Become absorbed in thinking about a problem |
| 資料を読み込む | Read/study the materials closely |

The image of going "in" can help you remember some connections, but it is not a grammatical rule licensing arbitrary new compounds.

Even one compound can have different interpretations. NINJAL contrasts two uses of **走り込む**: running **into a police box**, and doing **intensive running practice before a match**. The first involves a physical destination; the second concerns intensive training.

Likewise, **読み込む** also means "read/load" in computing. Understanding the components helps, but the whole word and context select the sense.

### ～つく: reaching a target or an idea

**追いつく** and **思いつく** are established **ます-stem + verb** compounds, not て-form auxiliaries:

| First verb | Formation | Compound and selected meaning |
| --- | --- | --- |
| 追う（おう） - pursue | 追い + つく | 追いつく（おいつく） - catch up |
| 思う（おもう） - think | 思い + つく | 思いつく（おもいつく） - think of, hit upon |

For these uses, **reaching something** is a useful connection: a target in pursuit, or an idea in thought. This is a learning aid, not a universal definition of ～つく.

> 彼を追いかけたが、追いつけなかった。  
> I chased after him, but couldn't catch up.

**追いかける（おいかける）** describes pursuit; **追いつく** describes reaching the other person's position or level. Pursuit need not succeed, and catching up does not necessarily mean touching or capturing someone. Here, **追いつけなかった** is the past negative potential form: "couldn't catch up."

> しばらく考えて、いい方法を思いついた。  
> After thinking for a while, I came up with a good way to do it.

In this use, **思いつく** focuses on an idea coming to mind, not simply continuing or beginning to think. It can follow deliberate thought, as here; inspiration need not come out of nowhere. The word also has "remember/recall" uses, so a wholly new idea is not required.

Dictionary spellings include **追い付く／追い着く** and **思い付く**; the kana spellings above are also valid. Learn the spelling with the word rather than forcing every つく into one kanji-based explanation.

Like ～込む, this belongs among patterns whose **whole compounds must be learned**. Do not attach つく freely to mean "successfully finish doing something."

### ～出す: outward movement is not always onset

> かばんから本を取り出した。  
> I took a book out of my bag.

Here, **取り出す（とりだす）** concerns taking something out, not "starting to take." Contrast **雨が降り出した**, where 出す marks onset.

Some compounds are more lexicalized still: **思い出す（おもいだす）** ordinarily means "remember/recall," not "start thinking." A spelling shared with a productive pattern does not guarantee the same interpretation.

### A few neighboring patterns

These also use stem-based constructions, but deserve separate treatment rather than one universal "direction" rule:

| Form | Useful starting point | Example |
| --- | --- | --- |
| ～かける | An action on the verge of happening or begun but incomplete, depending on the verb and context | 読みかけの本 - a partly read book; 読みかけ is the noun form here |
| ～直す（なおす） | Do again, often to correct or improve | 書き直す - rewrite |
| ～抜く（ぬく） | Carry something through to the end | やり抜く - carry through |
| ～上げる／～下ろす | Direction in selected compounds | 見上げる／見下ろす - look up at / look down at or over |
| ～戻す（もどす） | Return or recovery in selected compounds | 取り戻す - get back, recover |

The upward/downward readings are **みあげる／みおろす**. These meanings belong to the illustrated compounds; they do not exhaust what 上げる, 下ろす, or 戻す can contribute elsewhere.

## 6. Putting the pieces together

The two attachment patterns can combine:

> これからも日本語の本を読み続けていきたい。  
> I want to keep reading Japanese books from now on.

The construction builds in stages:

```text
読む                    read
読み + 続ける           keep reading
読み続けて + いく       continue that activity onward
読み続けていき + たい   want to continue it onward
```

**続ける** makes continuation explicit; **いく** adds the forward-looking perspective in this context. The sentence expresses sustained reading over time, not necessarily uninterrupted reading of one book.

### Quick reference

| Intended contribution | Pattern to consider | Example |
| --- | --- | --- |
| Movement/development toward a viewpoint | て-form + くる | 分かってきた - have begun to understand |
| Movement/development onward from a viewpoint | て-form + いく | 変わっていく - go on changing |
| Begin | Stem + 始める | 読み始める - start reading |
| Bring an onset into focus | Stem + 出す | 降り出す - start raining |
| Keep doing | Stem + 続ける | 読み続ける - keep reading |
| Finish an activity | Stem + 終わる | 読み終わる - finish reading |
| Do completely/all the way through | Stem + 切る | 読み切る - read all the way through |
| Get done / end up doing | て-form + しまう | 読んでしまう - get it read / end up reading it |
| Prepare or leave a state in place | て-form + おく | 読んでおく - read beforehand |
| Inward movement or deeper involvement | Stem + 込む, where the compound is established | 考え込む - become absorbed in thought |
| Reaching a target or an idea in selected compounds | ます-stem + つく, where the compound is established | 追いつく - catch up; 思いつく - hit upon an idea |

Here, "て-form" includes the appropriate **で-form**, as in 読んで. This is a navigation aid, not a promise that every verb accepts every pattern.

### Check the distinction

1. You will discuss a passage tomorrow and want to read it in preparation. Which directly expresses that purpose: **読んでおく** or **読み始める**?
2. Does **町が変わっていった** contradict the idea of ～ていく because it is past?
3. Does **本を取り出す** mean "start taking a book"?
4. Does **彼を追いかけた**, "I chased after him," guarantee that you **追いついた**, "caught up"?

**Answers:** 1. 読んでおく; 読み始める merely marks beginning the reading. 2. No: change can unfold forward from a reference point in the past. 3. No: it means taking a book out. 4. No: pursuing someone does not guarantee reaching them.

## 7. An action's stage is not a stopwatch

Compare the [three basic ところ stages](koto-wake-and-formal-nouns.md#ところ-locating-an-actions-stage):

| Form | Example | What it presents |
| --- | --- | --- |
| Dictionary form + ところです | 手紙を書くところです。 | I am just about to write a letter. |
| ている + ところです | 手紙を書いているところです。 | I am in the middle of writing a letter. |
| た-form + ところです | 手紙を書いたところです。 | I have just written a letter. |
| た-form + ばかりです | 手紙を書いたばかりです。 | I have only recently written a letter. |

The nine existing stage exercises remain in that earlier lesson. The additional practice here introduces
**たばかり**, rather than replacing those exercises or their progress.

**ばかり** presents the event as still recent from the speaker's perspective, not as necessarily occurring
within a fixed number of minutes:

> この小説は先週読んだばかりです。内容をよく覚えています。  
> このしょうせつはせんしゅうよんだばかりです。ないようをよくおぼえています。  
> I only read this novel last week. I remember its contents well.
>
> 大学を先月卒業したばかりです。仕事にはまだ慣れていません。  
> だいがくをせんげつそつぎょうしたばかりです。しごとにはまだなれていません。  
> I only graduated from university last month. I am not used to working yet.

What counts as recent depends on the event and the conversation. This does not make any elapsed interval
equally natural in any situation. Nor does ばかり itself guarantee good memory, inexperience or an unchanged result;
those details come from these particular examples.

An immediately completed letter can be described with **書いたところです** or **書いたばかりです**.
The first locates the action at its just-completed stage; the second presents its recency.
Do not invent a seconds-versus-minutes cutoff or assume one must always be wrong.
In **読んだばかりの本**, "a book I only recently read," use **の** before the following noun.
Conversational **ばっか／ばっかり** and written **許り** also occur; the regular kana spelling is our model.

The new practice separates stem formation, interpretation of a supplied compound, physical direction,
temporal viewpoint and recent completion. Its ところ interpretation controls do not retest every existing stage.
Broader **てばかり** concentration, **まま** unchanged states and **～切る** are optional onward comparisons,
not required choices in this N4 set. A vocabulary or kanji level does not determine these grammar tasks' levels.

## References

- [Kotobank: 補助動詞](https://kotobank.jp/word/補助動詞-630074) and [形式動詞](https://kotobank.jp/word/形式動詞-2033591) - dictionary definitions and the limits of the terminology.
- [NINJAL Compound Verb Lexicon: scope and analysis](https://www2.ninjal.ac.jp/vvlexicon/about.html) - attachment patterns, lexical/syntactic compounds, subsidiary functions, and the contrasting uses of 込む. Its detailed word-structure analysis is presented as an analytical proposal, not a universal classification.
- [Japan Foundation: Vてきた・Vていく (PDF)](https://www.jpf.go.jp/j/project/japanese/teach/tsushin/bn/dw_pdfs/tushin46_p22-23.pdf) - physical movement, temporal development, and aspect.
- [Tofugu: ～ていく and ～てくる](https://www.tofugu.com/japanese-grammar/teiku-tekuru/) - viewpoint explanations, including future ～てくる and past ～ていった.
- [IMABI: Start to I - ～始める and ～出す](https://imabi.org/start-to-%EF%BD%9E%E5%A7%8B%E3%82%81%E3%82%8B-%EF%BD%9E%E5%87%BA%E3%81%99-%EF%BD%9E%E3%81%8B%E3%81%91%E3%82%8B/) - onset, lexical senses, and restrictions on interchangeability.
- Jisho's JMdict entries for [終わる](https://jisho.org/word/終わる), [切る](https://jisho.org/word/切る), and [しまう](https://jisho.org/word/仕舞う) - completion and related suffix/auxiliary senses.
- Jisho's JMdict entries for [降り続く](https://jisho.org/word/降り続く), [読み込む](https://jisho.org/word/読み込む), and [読みかけ](https://jisho.org/word/読みかけ) - specific compounds and senses illustrated here.
- Jisho's JMdict entries for [追いつく](https://jisho.org/word/追いつく) and [思い付く](https://jisho.org/word/思い付く) - catch-up, idea, and recall senses, with recorded spellings.
- [Japan Foundation: ～てある, ～ている, and ～ておく (PDF)](https://www.jpf.go.jp/j/project/japanese/teach/tsushin/grammar/pdf/NK51_16-17.pdf) - preparation and state comparisons.
- [Tofugu: ～ておく](https://www.tofugu.com/japanese-grammar/teoku/) - preparation, leaving a state, and casual contractions.
- [Bunpro: ～始める](https://bunpro.jp/grammar_points/はじめる), [～出す](https://bunpro.jp/grammar_points/だす),
  [～続ける](https://bunpro.jp/grammar_points/つづける), [～終わる](https://bunpro.jp/grammar_points/おわる) and
  [～直す](https://bunpro.jp/grammar_points/なおす) - basic stem connections and final-member inflection.
  The examples do not support an absolute intention/involuntariness split between 始める and 出す.
- [Bunpro: たばかり](https://bunpro.jp/grammar_points/たばかり),
  [Maggie Sensei: ばかり](https://maggiesensei.com/2013/07/02/%E3%81%B0%E3%81%8B%E3%82%8A-bakari/) and
  [Tae Kim: time-specific actions](https://guidetojapanese.org/learn/grammar/timeactions) - recent completion,
  attachment, noun modification and conversational forms. Other same-spelled constructions need their own lessons.

[Article index on GitHub](https://github.com/stop-cran/learning-japanese#articles)
