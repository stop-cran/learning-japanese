package io.github.stopcran.kanji.ui

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.os.Build
import androidx.activity.ComponentActivity
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.junit4.createEmptyComposeRule
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.res.ResourcesCompat
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.room.withTransaction
import androidx.test.core.app.ActivityScenario
import androidx.test.platform.app.InstrumentationRegistry
import io.github.stopcran.kanji.KanjiApp
import io.github.stopcran.kanji.MainActivity
import io.github.stopcran.kanji.R
import io.github.stopcran.kanji.core.content.ContentParser
import io.github.stopcran.kanji.core.content.RepoSource
import io.github.stopcran.kanji.core.quiz.QuizBuilder
import io.github.stopcran.kanji.core.reading.ReadingKind
import io.github.stopcran.kanji.core.srs.KanjiFont
import io.github.stopcran.kanji.core.srs.StudyMode
import io.github.stopcran.kanji.core.words.WordDirection
import io.github.stopcran.kanji.core.words.WordQuizBuilder
import io.github.stopcran.kanji.data.*
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.File
import java.security.MessageDigest
import java.util.UUID


private fun disposable103() {
    assertEquals("true", InstrumentationRegistry.getArguments().getString("n1Disposable"))
    assertTrue(Build.HARDWARE in setOf("ranchu", "goldfish"))
}

class N1Batch103Glyph790Test {
    @get:Rule val rule = createAndroidComposeRule<ComponentActivity>()

    @Test fun encouragementAllFortySevenHanAndExplicitCliffFallbackAcrossFourFamilies() {
        disposable103()
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val fonts = listOf(KanjiFont.Gothic, KanjiFont.Mincho, KanjiFont.Textbook, KanjiFont.Brush)
        val pages = listOf("一 万 中 人 先 凝 分 切 力 劣", "努 励 勉 勤 勧 厂 厚 友 命 問", "団 夢 学 少 張 強 心 応 慰 懸", "手 援 支 日 毎 注 激 熱 生 研", "究 自 苦 葉 言 達 選", "励 劣 万 厚 厂 力 努 勉 勤 支 激励 励む 励ます")
        val page = mutableStateOf(0)
        rule.setContent {
            MaterialTheme {
                Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Batch 103: encouragement / look-alikes / explicit 厂 fallback")
                    Text("Panel ${page.value + 1} / ${pages.size}")
                    fonts.forEach { font ->
                        Text(font.name)
                        Text(pages[page.value], fontFamily = font.family(), fontSize = 18.sp, lineHeight = 26.sp)
                    }
                    Text("Inspect all 47 scoped Han. 厂 is absent from all three bundled cmaps: inspect real fallback in every family. Raster hashes are not readability.", fontSize = 16.sp)
                }
            }
        }
        val typefaces = listOf(Typeface.DEFAULT,
            requireNotNull(ResourcesCompat.getFont(context, R.font.kanji_mincho)),
            requireNotNull(ResourcesCompat.getFont(context, R.font.kanji_textbook)),
            requireNotNull(ResourcesCompat.getFont(context, R.font.kanji_brush)))
        val rows = JSONArray()
        for ((index, typeface) in typefaces.withIndex()) {
            val hashes = mutableSetOf<String>()
            for (char in listOf("一", "万", "中", "人", "先", "凝", "分", "切", "力", "劣", "努", "励", "勉", "勤", "勧", "厂", "厚", "友", "命", "問", "団", "夢", "学", "少", "張", "強", "心", "応", "慰", "懸", "手", "援", "支", "日", "毎", "注", "激", "熱", "生", "研", "究", "自", "苦", "葉", "言", "達", "選")) {
                val paint = Paint(Paint.ANTI_ALIAS_FLAG).also {
                    it.typeface = typeface
                    it.textSize = 96f
                    it.textLocale = java.util.Locale.JAPAN
                }
                assertTrue("$char ${fonts[index]}", paint.hasGlyph(char))
                val image = Bitmap.createBitmap(if (char.length > 1) 256 else 128, 128, Bitmap.Config.ARGB_8888)
                Canvas(image).drawText(char, 8f, 104f, paint)
                val pixels = IntArray(image.width * image.height)
                image.getPixels(pixels, 0, image.width, 0, 0, image.width, image.height)
                assertTrue(pixels.any { it != 0 })
                val bytes = java.nio.ByteBuffer.allocate(pixels.size * 4)
                    .also { it.asIntBuffer().put(pixels) }.array()
                val hash = MessageDigest.getInstance("SHA-256").digest(bytes)
                    .joinToString("") { "%02x".format(it) }
                assertTrue("Indistinguishable raster ${fonts[index]}", hashes.add(hash))
                rows.put(JSONObject().put("character", char).put("font", fonts[index].name)
                    .put("hasGlyph", true).put("nativePaintRasterSha256", hash))
                image.recycle()
            }
            for (word in listOf("激励", "励む", "励ます")) {
                val paint = Paint(Paint.ANTI_ALIAS_FLAG).also {
                    it.typeface = typeface
                    it.textSize = 96f
                    it.textLocale = java.util.Locale.JAPAN
                }
                // hasGlyph tests multi-character ligatures, not ordinary word coverage.
                val image = Bitmap.createBitmap(kotlin.math.ceil(paint.measureText(word)).toInt() + 16, 128, Bitmap.Config.ARGB_8888)
                Canvas(image).drawText(word, 8f, 104f, paint)
                val pixels = IntArray(image.width * image.height)
                image.getPixels(pixels, 0, image.width, 0, 0, image.width, image.height)
                for (position in word.indices) {
                    val left = (8f + paint.measureText(word, 0, position)).toInt()
                    val right = kotlin.math.ceil(8f + paint.measureText(word, 0, position + 1)).toInt()
                    assertTrue("Word raster bounds $word ${fonts[index]}", left >= 0 && right <= image.width && left < right)
                    assertTrue("Blank word character ${word[position]} ${fonts[index]}",
                        (0 until image.height).any { y -> (left until right).any { x -> pixels[y * image.width + x] != 0 } })
                }
                val bytes = java.nio.ByteBuffer.allocate(pixels.size * 4)
                    .also { it.asIntBuffer().put(pixels) }.array()
                val hash = MessageDigest.getInstance("SHA-256").digest(bytes)
                    .joinToString("") { "%02x".format(it) }
                rows.put(JSONObject().put("word", word).put("font", fonts[index].name)
                    .put("renderedCharactersNonblank", word.length).put("nativePaintRasterSha256", hash))
                image.recycle()
            }
        }
        assertEquals(200, rows.length())
        for (index in pages.indices) {
            rule.runOnIdle { page.value = index }
            rule.waitForIdle()
            rule.onAllNodesWithText(pages[index]).assertCountEquals(4)
            for (fontIndex in fonts.indices) rule.onAllNodesWithText(pages[index])[fontIndex].assertIsDisplayed()
            File(context.getExternalFilesDir(null), "n1-103-font-panel-${index + 1}.png").outputStream().use {
                assertTrue(rule.onRoot().captureToImage().asAndroidBitmap().compress(Bitmap.CompressFormat.PNG, 100, it))
            }
        }
        File(context.getExternalFilesDir(null), "n1-103-font-raster.json").writeText(JSONObject()
            .put("fingerprint", Build.FINGERPRINT).put("sdk", Build.VERSION.SDK_INT)
            .put("fontScale", context.resources.configuration.fontScale).put("rows", rows)
            .put("individualGlyphProbes", 188).put("wholeWordRasterProbes", 12).put("panels", 6)
            .put("limits", "47 actual scoped Han across four production families/default, six bounded Compose panels and twelve whole-word rasters. 厂 U+5382 is absent from all three bundled cmaps; this explicitly exercises actual native fallback, not acceptance by cmap. Hashes are not readability or fallback-face evidence. Actual PNG inspection required; emulator not phone.")
            .toString(2))
    }
}


class N1Batch103Article790Test {
    @get:Rule val rule = createEmptyComposeRule()
    private lateinit var app: KanjiApp
    private lateinit var scenario: ActivityScenario<MainActivity>

    @Test fun fullSingleImportEncouragementDirectGuardsSharedStemThreePairsSevenStrokesOfflineAndBack() {
        disposable103()
        val instrumentation = InstrumentationRegistry.getInstrumentation()
        app = instrumentation.targetContext.applicationContext as KanjiApp
        val source = RepoSource("acceptance-fixture", "n1-103-${UUID.randomUUID()}", "main")
        val head = "fed59b164f3a68264bfc040cc9d413986728e40c"
        assertTrue(app.settings.setSource("https://github.com/${source.id}", source.branch))
        var archiveRequests = 0
        val http = ContentHttp { url, _, _, _ ->
            val input = when (url) {
                "https://api.github.com/repos/${source.id}/commits/main" -> ByteArrayInputStream(head.toByteArray())
                source.commitZipUrl(head) -> {
                    archiveRequests++
                    instrumentation.context.assets.open("n1-batch-103-fed59b16-envelope.zip")
                }
                else -> error("Unexpected fixture request: $url")
            }
            object : ContentResponse {
                override val code = 200
                override val body = input
                override fun header(name: String): String? = null
                override fun close() = input.close()
            }
        }
        val result = runBlocking { ContentSync(app.db, app.settings.sync, http).sync(source, force = true) }
        assertTrue(result.toString(), result is SyncResult.Updated)
        val updated = result as SyncResult.Updated
        assertEquals(1, archiveRequests)
        assertEquals(1126, updated.kanji)
        assertEquals(5077, updated.words)
        assertTrue(updated.problems.toString(), updated.problems.isEmpty())
        val meta = requireNotNull(runBlocking { app.db.content().meta(source.id) })
        assertEquals("38c32a8df5fd6063", meta.contentVersion)
        assertEquals(0, meta.problems)
        assertNull(meta.grammarProblem)
        assertNull(meta.listeningProblem)
        assertNull(meta.grammarCurriculumProblem)
        assertEquals(1, ContentParser.KANJI_READING_PARSER_EPOCH)
        assertEquals(ContentParser.KANJI_READING_PARSER_EPOCH, meta.kanjiReadingParserEpoch)
        assertEquals(1, ContentParser.KANJI_MEANING_PARSER_EPOCH)
        assertEquals(ContentParser.KANJI_MEANING_PARSER_EPOCH, meta.kanjiMeaningParserEpoch)
        val all = runBlocking { app.db.content().kanjiLite(source.id) }
        val n1 = all.filter { it.jlpt == 1 }
        assertEquals(135, n1.size)
        assertEquals(n1.map { it.kanji }.toSet(),
            all.filter { "jlpt-n1" in it.tags.splitSep() }.map { it.kanji }.toSet())
        val target = n1.single { it.kanji == "励" }
        val guards = listOf("努", "勉", "勤", "支")
        assertEquals(guards, target.quizExclusions.splitSep())
        val observed = runBlocking { app.db.content().observeKanjiLite(source.id).first() }.single { it.kanji == "励" }
        assertEquals(guards, observed.toQuizCard().quizExclusions)
        val full = requireNotNull(runBlocking { app.db.content().kanjiCard(source.id, "励") })
        assertEquals(guards, full.quizExclusions.splitSep())
        assertEquals(guards, full.toQuizCard().quizExclusions)
        assertEquals(guards, runBlocking { app.db.content().kanji(source.id) }
            .single { it.kanji == "励" }.toQuizCard().quizExclusions)
        assertEquals(listOf("劣", "万", "厚"), target.distractors.splitSep())
        assertEquals(listOf("レイ"), target.onyomi.splitSep())
        assertEquals(listOf("はげ.む", "はげ.ます"), target.kunyomi.splitSep())
        assertEquals(listOf("レイ"), target.quizOnyomi?.splitSep())
        assertEquals(listOf("はげ.む", "はげ.ます"), target.quizKunyomi?.splitSep())
        assertEquals(listOf("れい"), target.toReadingCard().quizKeys(ReadingKind.On))
        assertEquals(listOf("はげむ"), target.toReadingCard().quizKeys(ReadingKind.Kun))
        val expectedMeanings = mapOf("励" to "encourage; be diligent", "劣" to "inferior; worse",
            "万" to "ten thousand", "厚" to "thick; cordial")
        val curatedIds = listOf("劣", "万", "厚")
        assertEquals(mapOf("劣" to 1, "万" to 5, "厚" to 2),
            all.filter { it.kanji in curatedIds }.associate { it.kanji to it.jlpt })
        assertEquals(setOf("劣"), n1.filter { it.kanji in curatedIds }.map { it.kanji }.toSet())
        val custom = all.filter { it.kanji in expectedMeanings }
        val randomSubset = listOf(target) +
            n1.filter { it.kanji != "励" }.shuffled(kotlin.random.Random(790)).take(15)
        val choices = JSONArray()
        for ((poolName, pool) in listOf("N1" to n1, "All" to all,
            "boundedCustom" to custom, "randomN1Subset" to randomSubset)) {
            val cards = pool.map { it.toQuizCard() }
            val quizTarget = cards.single { it.kanji == "励" }
            val available = curatedIds.filter { id -> cards.any { it.kanji == id } }
            repeat(16) { seed ->
                val options = QuizBuilder.options(quizTarget, cards, kotlin.random.Random(seed))
                assertEquals(4, options.size)
                assertEquals(4, options.map { it.title }.toSet().size)
                assertEquals(1, options.count { it.kanji == "励" })
                val offeredCards = options.map { option -> cards.single { it.kanji == option.kanji } }
                for (left in offeredCards) for (right in offeredCards.filter { it.kanji != left.kanji })
                    assertFalse(right.kanji in left.quizExclusions || left.kanji in right.quizExclusions)
                assertTrue(options.none { it.kanji in guards })
                assertTrue(available.all { id -> options.any { it.kanji == id } })
                assertTrue(options.all { o -> pool.any { it.kanji == o.kanji && it.title == o.title } })
                if (available.size == 3) assertEquals(expectedMeanings, options.associate { it.kanji to it.title })
                choices.put(JSONObject().put("pool", poolName).put("seed", seed)
                    .put("poolMembershipInOrder", JSONArray(pool.map { it.kanji }))
                    .put("options", JSONArray().also { rows ->
                        options.forEach { rows.put(JSONObject().put("kanji", it.kanji).put("title", it.title)) }
                    }))
            }
        }
        assertEquals(64, choices.length())
        val allCards = all.map { it.toQuizCard() }
        val guardChecks = JSONArray()
        for (excludedId in guards) {
            val pair = allCards.filter { it.kanji in setOf("励", excludedId) }
            assertEquals(2, pair.size)
            for (quizTarget in pair) {
                val excluded = pair.single { it.kanji != quizTarget.kanji }
                repeat(16) { seed ->
                    val sampled = pair + allCards.filter { it.kanji !in setOf("励", excludedId) }
                        .shuffled(kotlin.random.Random(790 + seed)).take(seed)
                    for ((poolName, pool) in listOf(
                        "N1" to n1.map { it.toQuizCard() }, "All" to allCards,
                        "boundedCustom" to (pair + allCards.filter { it.kanji in curatedIds }),
                        "randomN1Subset790" to (pair + randomSubset.map { it.toQuizCard() }
                            .filter { it.kanji !in setOf("励", excludedId) }),
                        "sampledFiltered" to sampled, "pairOnly" to pair,
                        "targetOutsidePool" to sampled.filter { it.kanji != quizTarget.kanji },
                    )) {
                        val options = QuizBuilder.options(quizTarget, pool, kotlin.random.Random(seed))
                        assertEquals(1, options.count { it.kanji == quizTarget.kanji })
                        assertFalse("Direct guard leaked $excludedId $poolName", options.any { it.kanji == excluded.kanji })
                        assertTrue(options.size in 1..4)
                        val offeredCards = options.map { option -> allCards.single { it.kanji == option.kanji } }
                        for (left in offeredCards) for (right in offeredCards.filter { it.kanji != left.kanji })
                            assertFalse(right.kanji in left.quizExclusions || left.kanji in right.quizExclusions)
                        assertEquals(options.size, options.map { it.title }.toSet().size)
                        assertTrue(options.all { it.kanji == quizTarget.kanji || pool.any { p -> p.kanji == it.kanji } })
                        if (poolName == "pairOnly") assertEquals(1, options.size)
                        guardChecks.put(JSONObject().put("target", quizTarget.kanji).put("excluded", excluded.kanji)
                            .put("pool", poolName).put("seed", seed)
                            .put("poolMembershipInOrder", JSONArray(pool.map { it.kanji }))
                            .put("options", JSONArray(options.map { it.kanji })))
                    }
                }
            }
        }
        assertEquals(896, guardChecks.length())
        val nontransitiveChecks = JSONArray()
        for (left in guards) for (right in guards.filter { it != left }) repeat(16) { seed ->
            val pair = allCards.filter { it.kanji in setOf(left, right) }
            val leftCard = pair.single { it.kanji == left }
            val rightCard = pair.single { it.kanji == right }
            assertFalse(right in leftCard.quizExclusions || left in rightCard.quizExclusions)
            val options = QuizBuilder.options(leftCard, pair, kotlin.random.Random(seed))
            assertEquals(setOf(left, right), options.map { it.kanji }.toSet())
            nontransitiveChecks.put(JSONObject().put("target", left).put("neighbor", right).put("seed", seed)
                .put("options", JSONArray(options.map { it.kanji })))
        }
        assertEquals(192, nontransitiveChecks.length())
        val words = runBlocking { app.db.content().wordsLite(source.id) }.map { it.toCard() }
        val preserved = mapOf(            "激励" to listOf("励ます", "応援", "勧める", "慰める", "支える", "力強い"),
            "励む" to listOf("努める", "努力", "一生懸命", "苦心", "せっせと", "凝らす", "注ぐ", "ねっしん", "くるくる", "ばりばり", "もりもり", "勉強", "凝る", "夢中", "熱中", "張り切る"),
            "励ます" to listOf("応援", "勧める", "慰める", "支える", "力強い"))
        val wordChecks = JSONArray()
        for ((id, excludedIds) in preserved) {
            val left = words.single { it.word == id }
            assertEquals(excludedIds, left.quizExclusions)
            assertNull(left.jlpt)
            for (excludedId in excludedIds) {
                val right = words.single { it.word == excludedId }
                val pair = listOf(left, right)
                for (wordTarget in pair)
                    for (direction in listOf(WordDirection.JpToEn, WordDirection.EnToJp)) repeat(16) { seed ->
                        val options = WordQuizBuilder.options(wordTarget, pair, direction, kotlin.random.Random(seed))
                        assertEquals(listOf(wordTarget.word), options.map { it.word })
                        wordChecks.put(JSONObject().put("declaredOn", id).put("excluded", excludedId)
                            .put("target", wordTarget.word).put("pool", "pairOnly")
                            .put("direction", direction.name).put("seed", seed)
                            .put("label", options.single().label))
                    }
            }
        }
        assertEquals(1728, wordChecks.length())
        val wordNontransitive = JSONArray()
        for (id in listOf("激励", "励ます")) {
            val pair = words.filter { it.word in setOf(id, "励む") }
            assertEquals(2, pair.size)
            for (wordTarget in pair)
                for (direction in listOf(WordDirection.JpToEn, WordDirection.EnToJp)) repeat(16) { seed ->
                    val options = WordQuizBuilder.options(wordTarget, pair, direction, kotlin.random.Random(seed))
                    assertEquals(pair.map { it.word }.toSet(), options.map { it.word }.toSet())
                    wordNontransitive.put(JSONObject().put("pair", JSONArray(pair.map { it.word }))
                        .put("target", wordTarget.word).put("direction", direction.name).put("seed", seed))
                }
        }
        assertEquals(128, wordNontransitive.length())
        val now = System.currentTimeMillis()
        app.settings.sync.lastCheckMs = now
        app.settings.setStartingGuideVisible(false)
        app.settings.setDailyNewCards(50)
        app.settings.setWeekPlan("FFFFFFF")
        app.settings.setTraceNew(true)
        app.settings.setVaryFonts(true)
        app.settings.setStack("jlpt-n5")
        runBlocking {
            app.db.withTransaction {
                n1.forEach { card ->
                    app.db.reviews().putState(ReviewStateEntity(
                        source.id, "jlpt-n1", card.kanji, StudyMode.Quiz.name, "Review", 30.0, 5.0,
                        if (card.kanji == "励") now - 60_000 else now + 30L * 86_400_000,
                        now - 2L * 86_400_000, 3, 0,
                    ))
                    for (kind in ReadingKind.entries) for (key in card.toReadingCard().quizKeys(kind))
                        app.db.reviews().putState(ReviewStateEntity(
                            source.id, "jlpt-n1", card.kanji, kind.mode.name, "Review", 30.0, 5.0,
                            if (card.kanji == "励") now - 60_000 else now + 30L * 86_400_000,
                            now - 2L * 86_400_000, 3, 0, reading = key,
                        ))
                }
                for (days in 1..2) app.db.reviews().putLog(ReviewLogEntity(
                    0, source.id, "jlpt-n1", "励", StudyMode.Quiz.name, 3, now - days * 86_400_000L,
                ))
            }
        }
        val connectivity = app.getSystemService(ConnectivityManager::class.java)
        assertNull("Disable owned emulator Wi-Fi/data before offline acceptance", connectivity.activeNetwork)
        val evidence = JSONObject().put("contentSnapshot", head).put("contentVersion", meta.contentVersion)
            .put("archiveRequests", archiveRequests).put("importedKanji", updated.kanji).put("importedWords", updated.words)
            .put("problems", updated.problems.size).put("n1Cards", n1.size)
            .put("acceptedReadingParserEpoch", meta.kanjiReadingParserEpoch)
            .put("acceptedMeaningParserEpoch", meta.kanjiMeaningParserEpoch)
            .put("productionBuilderN1AndAllExactChoices", choices).put("kanjiDirectGuardChecks", guardChecks)
            .put("nontransitiveNeighborChecks", nontransitiveChecks).put("preservedWordGuardChecks", wordChecks)
            .put("wordNontransitiveChecks", wordNontransitive)
            .put("fullOnyomi", JSONArray(target.onyomi.splitSep())).put("fullKunyomi", JSONArray(target.kunyomi.splitSep()))
            .put("quizOnKeys", JSONArray(target.toReadingCard().quizKeys(ReadingKind.On)))
            .put("quizKunKeys", JSONArray(target.toReadingCard().quizKeys(ReadingKind.Kun)))
            .put("kanjiQuizExclusions", JSONArray(guards))
            .put("fingerprint", Build.FINGERPRINT).put("sdk", Build.VERSION.SDK_INT)
            .put("transport", "Exact full git archive through production ContentSync ONCE; synthetic source/HEAD")
            .put("fixture", "Other N1 meanings/readings postponed; only励 meaning andれい/はげむ due; three selected source entries yield two keys. Two historical good meaning logs unlock drawing. No drawing state seeded. Disposable source, not owner progress.")
            .put("limits", "Sampled pools, not exhaustive future semantics. Direct conservative guards are not unrestricted synonyms. Sampled fallback ordinary-sense semantic acceptance remains UNVERIFIED until source-backed rendered review. Raster hashes are not readability. Emulator, not phone.")
            .put("phoneEvidence", false).put("passed", false)
        scenario = ActivityScenario.launch(MainActivity::class.java)
        try {
            click("Kanji")
            click("N1")
            rule.waitUntil(30_000) { app.settings.stack.value == "jlpt-n1" }
            await("N1 · 135 cards").performScrollTo().assertIsDisplayed()
            capture("selection")
            click("Browse all kanji")
            rule.onNode(hasSetTextAction()).performTextReplacement("励")
            click("encourage; be diligent")
            await("励 — encourage; be diligent")
            show(articleBullet("Strokes: 7 · Key (radical): 力 (no. 19), at the right · JLPT: N1 (community list)"), "article-00")
            section("Meaning and origin")
            show(articleBullet("励 covers both encouraging someone and diligently applying oneself. 励む はげむ means \"work hard; strive,\" while 励ます はげます means \"encourage; cheer someone on.\" 激励 げきれい is encouragement that spurs someone on."), "article-02")
            show(articleBullet("Modern-shape mnemonic, not etymology: Notice a 厂-like cover over 万-shaped strokes, beside 力, \"strength.\" Imagine putting strength into effort or encouragement. This is a visual memory aid, not a historical derivation; the 万-like shape does not contribute \"ten thousand\" to this meaning."), "article-03")
            section("Readings")
            show(readingExample("レイ"), "article-05")
            show(readingExample("激励 げきれい — encouragement; spurring on"), "article-06")
            show(readingExample("はげ.む"), "article-07")
            show(readingExample("励む はげむ — work hard; strive"), "article-08")
            show(readingExample("はげ.ます"), "article-09")
            show(readingExample("励ます はげます — encourage; cheer someone on"), "article-10")
            show(articleBullet("All three sourced readings are retained in the practice selections. The app groups kun-readings with the same stem before the dot, so はげ.む supplies the はげむ question; はげ.ます remains in the reading table but does not create a separate question. The on-reading question is れい. In 激励, 激 supplies ゲキ and 励 supplies レイ."), "article-11")
            show(articleBullet("励ます is a plain dictionary form, despite ending in ます. Its polite form is 励まします (はげまします). The polite form of the separate verb 励む is 励みます (はげみます)."), "article-12")
            section("Common words")
            show(articleBullet("激励 げきれい — encouragement; spurring on"), "article-14")
            show(articleBullet("励む はげむ — work hard; strive"), "article-15")
            show(articleBullet("励ます はげます — encourage; cheer someone on"), "article-16")
            section("Notes")
            show(articleBullet("劣, \"inferior; worse,\" has 力 below 少 rather than at the right. Making an effort does not itself mean being inferior."), "article-18")
            show(articleBullet("万, \"ten thousand,\" resembles part of the left side, but lacks the cover and right-hand 力 of 励."), "article-19")
            show(articleBullet("厚, \"thick; cordial,\" also has a 厂 overhang, but a different interior and no right-hand 力."), "article-20")
            show(articleBullet("努, 勉 and 勤 share effort or diligence meanings. They are useful comparisons, not clearly wrong alternatives to that side of 励's meaning."), "article-21")
            show(articleBullet("Distinguish the roles: 勉強に励む (べんきょうにはげむ), \"work hard at one's studies,\" versus 友達を励ます (ともだちをはげます), \"encourage a friend.\" Neither effort nor encouragement guarantees success."), "article-22")
            show(articleBullet("Metadata: KANJIDIC2, 2026-11-02 snapshot. Word identities: JMdict, entries 1253760, 1557390, 1557350 and 1907660. Character senses and reading allocation: Digital Daijisen, 励."), "article-23")
            section("Common words")
            inline(await(articleBullet("激励 げきれい — encouragement; spurring on")), "激励", 0)
            await("激励 (げきれい) — encouragement; spurring on")
            section("Meaning")
            show(articleBullet("激励 is encouragement that spurs someone on. It is a noun, and 激励する means \"encourage\" or \"give a pep talk.\" The person or group encouraged can take を."), "word-0-01")
            show(articleBullet("選手団を激励する。 (せんしゅだんをげきれいする。) — They encourage the team."), "word-0-02")
            show(articleBullet("先生は学生たちを激励しました。 (せんせいはがくせいたちをげきれいしました。) — The teacher encouraged the students."), "word-0-03")
            section("How the kanji combine")
            show(articleBullet("激 contributes intensity or stirring up, and 励 contributes encouraging. This is an intensifying combination, not a literal instruction to become violent. The readings are ゲキ + レイ."), "word-0-05")
            section("Synonyms and antonyms")
            show(articleBullet("励ます (はげます) is the native verb for encouraging or cheering someone on. 応援 (おうえん) covers support and cheering, including practical backup as well as encouragement. The overlap is real: it is not a strict division between words and actions."), "word-0-07")
            section("Distinctive meaning")
            show(articleBullet("Learn both the noun 激励 and the verb 激励する. Encouraging someone to keep going is not the same as every kind of assistance, and the word does not guarantee success or an immediate improvement in the recipient's mood. Nor does every use require shouting or harsh treatment."), "word-0-09")
            show(articleBullet("Dictionary: JMdict, entry 1253760; comparisons 1557350 and 1179840. Usage and the team example: Digital Daijisen, 激励."), "word-0-10")
            section("How the kanji combine")
            show(articleBullet("激 contributes intensity or stirring up, and 励 contributes encouraging. This is an intensifying combination, not a literal instruction to become violent. The readings are ゲキ + レイ."), "pair-0-components")
            inline(await(articleBullet("激 contributes intensity or stirring up, and 励 contributes encouraging. This is an intensifying combination, not a literal instruction to become violent. The readings are ゲキ + レイ.")), "励", 44)
            await("励 — encourage; be diligent")
            back()
            await(articleBullet("激 contributes intensity or stirring up, and 励 contributes encouraging. This is an intensifying combination, not a literal instruction to become violent. The readings are ゲキ + レイ.")).assertIsDisplayed()
            back()
            await(articleBullet("激励 げきれい — encouragement; spurring on")).assertIsDisplayed()
            section("Common words")
            inline(await(articleBullet("励む はげむ — work hard; strive")), "励む", 0)
            await("励む (はげむ) — work hard; strive")
            section("Meaning")
            show(articleBullet("励む means working hard or applying oneself to an activity. In this useful modern pattern, mark the activity with に: 勉強に励む (べんきょうにはげむ), \"work hard at one's studies.\""), "word-1-01")
            show(articleBullet("毎日、勉強に励んでいます。 (まいにち、べんきょうにはげんでいます。) — I work hard at my studies every day."), "word-1-02")
            show(articleBullet("研究に励みました。 (けんきゅうにはげみました。) — I applied myself to research."), "word-1-03")
            section("How the kanji combine")
            show(articleBullet("励 writes はげ, and む is the written ending. This is one native verb, not a compound of separate on-reading words."), "word-1-05")
            show(articleBullet("It is a godan verb ending in む. Useful forms are 励みます (はげみます), 励んで (はげんで), 励んだ (はげんだ) and 励まない (はげまない)."), "word-1-06")
            section("Synonyms and antonyms")
            show(articleBullet("努める (つとめる), \"strive; make an effort,\" and 努力 (どりょく), \"effort,\" overlap with 励む."), "word-1-08")
            show(articleBullet("Contrast 励ます (はげます), \"encourage; cheer someone on\":"), "word-1-09")
            show(articleBullet("自分が勉強に励む。 (じぶんがべんきょうにはげむ。) — I myself work hard at my studies."), "word-1-10")
            show(articleBullet("友達を励ます。 (ともだちをはげます。) — I encourage a friend."), "word-1-11")
            show(articleBullet("These are different roles: applying oneself to an activity versus encouraging someone."), "word-1-12")
            section("Distinctive meaning")
            show(articleBullet("励む describes effort, not guaranteed success. The activity + に pattern above is the modern teaching model here; it is not a claim that historical dictionaries contain no other constructions."), "word-1-14")
            show(articleBullet("Do not mistake 励ます for a polite form of 励む. 励む becomes 励みます; 励ます is a separate verb whose polite form is 励まします (はげまします)."), "word-1-15")
            show(articleBullet("Dictionary: JMdict, entries 1557390 and 1907660; comparisons 1240820, 1445130 and 1557350. Activity + に examples: Digital Daijisen, 励む."), "word-1-16")
            section("How the kanji combine")
            show(articleBullet("励 writes はげ, and む is the written ending. This is one native verb, not a compound of separate on-reading words."), "pair-1-components")
            inline(await(articleBullet("励 writes はげ, and む is the written ending. This is one native verb, not a compound of separate on-reading words.")), "励", 0)
            await("励 — encourage; be diligent")
            back()
            await(articleBullet("励 writes はげ, and む is the written ending. This is one native verb, not a compound of separate on-reading words.")).assertIsDisplayed()
            back()
            await(articleBullet("励む はげむ — work hard; strive")).assertIsDisplayed()
            section("Common words")
            inline(await(articleBullet("励ます はげます — encourage; cheer someone on")), "励ます", 0)
            await("励ます (はげます) — encourage; cheer someone on")
            section("Meaning")
            show(articleBullet("励ます means encouraging or cheering someone on or up. In the ordinary person-encouragement use, the person takes を."), "word-2-01")
            show(articleBullet("友達を励ましました。 (ともだちをはげましました。) — I encouraged my friend."), "word-2-02")
            show(articleBullet("友人の言葉に励まされました。 (ゆうじんのことばにはげまされました。) — I was encouraged by my friend's words."), "word-2-03")
            show(articleBullet("The second sentence is passive: 励まされる (はげまされる) means \"be encouraged.\" The speaker receives encouragement rather than encouraging someone else."), "word-2-04")
            section("How the kanji combine")
            show(articleBullet("励 writes はげ, with ます in kana. Here ます is part of the dictionary-form spelling, not a polite ending. This is one native godan verb ending in す, not a compound of on readings."), "word-2-06")
            show(articleBullet("Useful forms are 励まします (はげまします), 励まして (はげまして), 励ました (はげました) and 励まさない (はげまさない). Compare the separate verb 励む (はげむ), \"work hard,\" whose polite form is 励みます (はげみます)."), "word-2-07")
            section("Synonyms and antonyms")
            show(articleBullet("激励 (げきれい) is a noun for encouragement; 激励する is a related する verb. 応援 (おうえん) includes support and cheering, but can also mean practical backup."), "word-2-09")
            show(articleBullet("慰める (なぐさめる), \"comfort; console,\" emphasizes easing distress. 励ます can urge someone onward. Encouragement and consolation may occur together; this is a difference of emphasis, not mutually exclusive compartments."), "word-2-10")
            section("Distinctive meaning")
            show(articleBullet("Encouragement does not guarantee success or that the recipient immediately feels better. The verb is not restricted to encouraging other people: one can encourage oneself too. This article focuses on encouragement, not the separate voice-raising sense recorded in dictionaries."), "word-2-12")
            show(articleBullet("Dictionary: JMdict, entry 1557350, sense 1; comparisons 1253760, 1179840, 1156890 and 1557390. Usage: Digital Daijisen, 励ます."), "word-2-13")
            section("How the kanji combine")
            show(articleBullet("励 writes はげ, with ます in kana. Here ます is part of the dictionary-form spelling, not a polite ending. This is one native godan verb ending in す, not a compound of on readings."), "pair-2-components")
            inline(await(articleBullet("励 writes はげ, with ます in kana. Here ます is part of the dictionary-form spelling, not a polite ending. This is one native godan verb ending in す, not a compound of on readings.")), "励", 0)
            await("励 — encourage; be diligent")
            back()
            await(articleBullet("励 writes はげ, with ます in kana. Here ます is part of the dictionary-form spelling, not a polite ending. This is one native godan verb ending in す, not a compound of on readings.")).assertIsDisplayed()
            back()
            await(articleBullet("励ます はげます — encourage; cheer someone on")).assertIsDisplayed()
            back()
            await("Search kanji, meaning or reading")
            back()
            await("Meaning quiz")
            back()
            click("Words")
            click("Browse all words")
            rule.onNode(hasSetTextAction()).performTextReplacement("応援")
            click("support; cheering")
            await("応援 (おうえん) - support; cheering")
            section("Synonyms and antonyms")
            show(articleBullet("援助 (えんじょ) concerns aid or assistance. 手伝う (てつだう) is helping with a task, and 助ける (たすける) is helping or saving someone. 励ます (はげます) is encouraging or cheering someone on. These meanings overlap without making every kind of help a sports cheer."), "reused-0")
            inline(await(articleBullet("援助 (えんじょ) concerns aid or assistance. 手伝う (てつだう) is helping with a task, and 助ける (たすける) is helping or saving someone. 励ます (はげます) is encouraging or cheering someone on. These meanings overlap without making every kind of help a sports cheer.")), "励ます", 118)
            await("励ます (はげます) — encourage; cheer someone on")
            back()
            await(articleBullet("援助 (えんじょ) concerns aid or assistance. 手伝う (てつだう) is helping with a task, and 助ける (たすける) is helping or saving someone. 励ます (はげます) is encouraging or cheering someone on. These meanings overlap without making every kind of help a sports cheer.")).assertIsDisplayed()
            back()
            rule.onNode(hasSetTextAction()).performTextReplacement("慰める")
            click("comfort; console")
            await("慰める (なぐさめる) - comfort; console")
            section("Synonyms and antonyms")
            show(articleBullet("助ける (たすける) is broader help or rescue. 励ます (はげます), \"encourage,\" can urge someone onward; 慰める emphasizes easing their distress. Both actions can occur together, but encouragement and consolation are not interchangeable in every situation."), "reused-1")
            inline(await(articleBullet("助ける (たすける) is broader help or rescue. 励ます (はげます), \"encourage,\" can urge someone onward; 慰める emphasizes easing their distress. Both actions can occur together, but encouragement and consolation are not interchangeable in every situation.")), "励ます", 38)
            await("励ます (はげます) — encourage; cheer someone on")
            back()
            await(articleBullet("助ける (たすける) is broader help or rescue. 励ます (はげます), \"encourage,\" can urge someone onward; 慰める emphasizes easing their distress. Both actions can occur together, but encouragement and consolation are not interchangeable in every situation.")).assertIsDisplayed()
            back()
            rule.onNode(hasSetTextAction()).performTextReplacement("学問")
            click("scholarship; academic learning")
            await("学問 (がくもん) - scholarship; academic learning")
            section("Meaning")
            show(articleBullet("学問に励む means to apply oneself to study; 学問をする means to pursue learning. 学問の自由 (がくもんのじゆう) is \"academic freedom.\""), "reused-2")
            inline(await(articleBullet("学問に励む means to apply oneself to study; 学問をする means to pursue learning. 学問の自由 (がくもんのじゆう) is \"academic freedom.\"")), "励む", 3)
            await("励む (はげむ) — work hard; strive")
            back()
            await(articleBullet("学問に励む means to apply oneself to study; 学問をする means to pursue learning. 学問の自由 (がくもんのじゆう) is \"academic freedom.\"")).assertIsDisplayed()
            back()
            back()
            back()
            click("Kanji")
            await("Meaning quiz")
            evidence.put("mappedReciprocalPairs", 3).put("directedLinkTransitions", 6)
                .put("activatedBaselinePairs", 0).put("changedReusedArticles", 3)
                .put("changedReusedNavigationTransitions", 3).put("reciprocalLinkAndSystemBack", true)
            click(rule.onNode(hasText("Start") and hasAnyAncestor(hasText("Meaning quiz"))))
            rule.waitUntil(30_000) { (model("quiz:") as? QuizViewModel)?.ui is QuizUi.Question }
            val quiz = model("quiz:") as QuizViewModel
            val meaning = quiz.ui as QuizUi.Question
            assertEquals("励", meaning.card.kanji)
            val n1Curated = curatedIds.filter { id -> n1.any { it.kanji == id } }
            assertEquals(setOf("劣"), n1Curated.toSet())
            assertEquals(4, meaning.options.size)
            assertEquals(4, meaning.options.map { it.title }.toSet().size)
            assertEquals(1, meaning.options.count { it.kanji == "励" })
            assertTrue(n1Curated.all { id -> meaning.options.any { it.kanji == id && it.title == expectedMeanings[id] } })
            assertTrue(meaning.options.all { option -> n1.any { it.kanji == option.kanji && it.title == option.title } })
            assertFalse(meaning.options.any { it.kanji in setOf("万", "厚") })
            val fallback = meaning.options.filter { it.kanji != "励" && it.kanji !in curatedIds }
            assertEquals(2, fallback.size)
            assertEquals(guards, meaning.card.toQuizCard().quizExclusions)
            assertTrue(meaning.options.none { it.kanji in guards })
            val actualCards = meaning.options.map { option -> n1.single { it.kanji == option.kanji }.toQuizCard() }
            for (left in actualCards) for (right in actualCards.filter { it.kanji != left.kanji })
                assertFalse(right.kanji in left.quizExclusions || left.kanji in right.quizExclusions)
            for (option in meaning.options) await(option.title).assertIsDisplayed()
            evidence.put("exactDefaultMeaningOptions", JSONArray().also { rows ->
                meaning.options.forEach { rows.put(JSONObject().put("kanji", it.kanji).put("title", it.title)) }
            }).put("actualN1CuratedAvailable", 1).put("actualN1FallbackOptions", 2)
                .put("curatedDistractorLevels", JSONObject().put("劣", 1).put("万", 5).put("厚", 2))
                .put("meaningFallbackNeedsSemanticReview", true)
            capture("meaning-question")
            click("encourage; be diligent")
            await("Correct!")
            capture("meaning-feedback")
            back()
            await("Meaning quiz")
            click(rule.onNode(hasText("Start") and hasAnyAncestor(hasText("Readings (on'yomi and kun'yomi)"))))
            val answeredKeys = mutableSetOf<String>()
            repeat(2) {
                rule.waitUntil(30_000) { (model("kreading:") as? KanjiReadingViewModel)?.ui is ReadingUi.Question }
                val reading = model("kreading:") as KanjiReadingViewModel
                val question = reading.ui as ReadingUi.Question
                assertEquals("励", question.card.kanji)
                val expectedKey = when (question.question.kind) {
                    ReadingKind.On -> "れい"
                    ReadingKind.Kun -> "はげむ"
                }
                assertEquals(expectedKey, question.question.correctKey)
                assertFalse(question.question.options.any { it.key == "はげます" })
                assertEquals(listOf("はげ.む", "はげ.ます"), question.card.kunyomi.splitSep())
                assertEquals(listOf("はげ.む", "はげ.ます"), question.card.quizKunyomi?.splitSep())
                assertTrue(answeredKeys.add(expectedKey))
                assertEquals(1, question.question.options.count { it.key == expectedKey })
                val kind = if (question.question.kind == ReadingKind.On) "on" else "kun"
                capture("curated-$kind-question")
                click(question.question.options.single { it.key == expectedKey }.label)
                await(if (question.question.kind == ReadingKind.On) "Correct! — on'yomi" else "Correct! — kun'yomi")
                assertTrue((reading.ui as ReadingUi.Answer).correct)
                capture("curated-$kind-feedback")
                click("Next")
            }
            assertEquals(setOf("れい", "はげむ"), answeredKeys)
            rule.waitUntil(30_000) { (model("kreading:") as? KanjiReadingViewModel)?.ui is ReadingUi.Done }
            val done = (model("kreading:") as KanjiReadingViewModel).ui as ReadingUi.Done
            assertEquals(2, done.answered)
            assertEquals(2, done.correct)
            rule.waitUntil(30_000) { runBlocking {
                app.db.reviews().allLog().count { log -> log.sourceId == source.id && log.kanji == "励" &&
                    log.mode in setOf(ReadingKind.On.mode.name, ReadingKind.Kun.mode.name) && log.grade == 3 } == 2
            } }
            val logs = runBlocking { app.db.reviews().allLog().filter {
                it.sourceId == source.id && it.kanji == "励" &&
                    it.mode in setOf(ReadingKind.On.mode.name, ReadingKind.Kun.mode.name)
            } }
            assertEquals(2, logs.size)
            assertEquals(setOf("れい", "はげむ"), logs.map { it.reading }.toSet())
            assertTrue(logs.all { it.grade == 3 })
            assertEquals(ReadingKind.On.mode.name, logs.single { it.reading == "れい" }.mode)
            assertEquals(ReadingKind.Kun.mode.name, logs.single { it.reading == "はげむ" }.mode)
            capture("curated-two-keys-done")
            back()
            await("Meaning quiz")
            click(rule.onNode(hasText("Start") and hasAnyAncestor(hasText("Drawing"))))
            await("Trace the kanji for")
            await("encourage; be diligent").assertIsDisplayed()
            val card = requireNotNull(runBlocking { app.db.content().kanjiCard(source.id, "励") })
            assertEquals(listOf("レイ"), card.onyomi.splitSep())
            assertEquals(listOf("はげ.む", "はげ.ます"), card.kunyomi.splitSep())
            assertEquals(listOf("レイ"), card.quizOnyomi?.splitSep())
            assertEquals(listOf("はげ.む", "はげ.ます"), card.quizKunyomi?.splitSep())
            assertEquals(guards, card.quizExclusions.splitSep())
            evidence.put("fullProjectionOnyomi", JSONArray(card.onyomi.splitSep()))
                .put("fullProjectionKunyomi", JSONArray(card.kunyomi.splitSep()))
                .put("fullProjectionQuizOnyomi", JSONArray(requireNotNull(card.quizOnyomi).splitSep()))
                .put("fullProjectionQuizKunyomi", JSONArray(requireNotNull(card.quizKunyomi).splitSep()))
            val strokes = JSONObject(requireNotNull(card.strokesJson)).getJSONArray("strokes")
            assertEquals(7, strokes.length())
            capture("drawing-trace")
            val pad = rule.onNode(hasContentDescription("Drawing area for the kanji", substring = true))
            pad.performScrollTo()
            for (index in 0 until strokes.length()) {
                val points = strokes.getJSONObject(index).getJSONArray("points")
                pad.performTouchInput {
                    fun point(i: Int): Offset {
                        val pair = points.getJSONArray(i)
                        return Offset(pair.getDouble(0).toFloat() * width / 109f,
                            pair.getDouble(1).toFloat() * height / 109f)
                    }
                    down(point(0))
                    for (i in 1 until points.length()) moveTo(point(i), delayMillis = 16)
                    up()
                }
            }
            rule.onNode(hasContentDescription("7 strokes drawn", substring = true)).assertExists()
            click("Check")
            await("Practice only: this attempt is not graded.")
            assertFalse(runBlocking { app.db.reviews().allLog().any {
                it.sourceId == source.id && it.kanji == "励" && it.mode == StudyMode.Draw.name
            } })
            await("Correct strokes").performScrollTo().assertIsDisplayed()
            capture("drawing-feedback")
            click("Next")
            await("Draw the kanji for")
            click("I don't remember")
            await("Here is the kanji")
            capture("drawing-recall-feedback")
            click("Next")
            rule.waitUntil(30_000) { runBlocking { app.db.reviews().allLog().any {
                it.sourceId == source.id && it.kanji == "励" && it.mode == StudyMode.Draw.name && it.grade == 1
            } } }
            back()
            await("Meaning quiz")
            assertEquals("jlpt-n1", app.settings.stack.value)
            assertNull(connectivity.activeNetwork)
            assertEquals(1, archiveRequests)
            evidence.put("meaningQuestionAndFeedback", true).put("twoCuratedKeysPersistedGoodAndDone", true)
                .put("touchInjectedReferenceStrokes", strokes.length()).put("drawingTraceThenRecall", true)
                .put("drawingGradeRecordedOnNext", true).put("offline", true).put("passed", true)
        } finally {
            File(app.getExternalFilesDir(null), "n1-103-article-route.json").writeText(evidence.toString(2))
            File(app.getExternalFilesDir(null), "n1-103-article-tree.txt").writeText(rule.onRoot().printToString())
            scenario.close()
        }
    }

    private fun model(prefix: String): ViewModel? {
        var result: ViewModel? = null
        scenario.onActivity { activity ->
            result = activity.viewModelStore.keys().lastOrNull { it.startsWith(prefix) }?.let { activity.viewModelStore[it] }
        }
        return result
    }

    private fun await(text: String, substring: Boolean = false): SemanticsNodeInteraction {
        return await(hasText(text, substring = substring))
    }

    private fun await(matcher: SemanticsMatcher): SemanticsNodeInteraction {
        rule.waitUntil(30_000) { rule.onAllNodes(matcher).fetchSemanticsNodes().isNotEmpty() }
        rule.onAllNodes(matcher).assertCountEquals(1)
        return rule.onNode(matcher)
    }

    private fun readingExample(text: String): SemanticsMatcher {
        return hasText(text) and hasAnyAncestor(hasTestTag("article-body")) and
            hasAnyAncestor(SemanticsMatcher.keyIsDefined(SemanticsProperties.HorizontalScrollAxisRange))
    }

    private fun articleBullet(text: String): SemanticsMatcher {
        return hasText(text) and hasAnyAncestor(hasTestTag("article-body")) and
            !hasAnyAncestor(SemanticsMatcher.keyIsDefined(SemanticsProperties.HorizontalScrollAxisRange))
    }

    private fun click(text: String) = click(await(text))

    private fun click(node: SemanticsNodeInteraction) {
        rule.waitUntil(30_000) { !node.fetchSemanticsNode().config.contains(SemanticsProperties.Disabled) }
        if (node.onAncestors().filter(hasScrollAction()).fetchSemanticsNodes().isNotEmpty()) node.performScrollTo()
        node.assertIsDisplayed().assertIsEnabled().performClick()
    }

    private fun section(title: String) {
        rule.onNodeWithTag("article-body").performScrollToIndex(0)
        click("Article contents")
        rule.onNode(hasText(title, substring = true) and hasClickAction()).performScrollTo().performClick()
        rule.waitForIdle()
    }

    private fun show(selector: String, step: String) {
        show(hasText(selector, substring = true), step)
    }

    private fun show(matcher: SemanticsMatcher, step: String, occurrence: Int = 0, expectedCount: Int = 1) {
        val body = rule.onNodeWithTag("article-body")
        body.performScrollToNode(matcher)
        rule.onAllNodes(matcher).assertCountEquals(expectedCount)
        val target = rule.onAllNodes(matcher)[occurrence]
        target.performScrollTo()
        val viewport = body.fetchSemanticsNode()
        val cell = target.fetchSemanticsNode()
        val top = viewport.positionInRoot.y
        val bottom = top + viewport.size.height
        if (cell.positionInRoot.y < top || cell.positionInRoot.y + cell.size.height > bottom) {
            body.performSemanticsAction(SemanticsActions.ScrollBy) {
                it(0f, cell.positionInRoot.y - top - 16f)
            }
            rule.waitForIdle()
        }
        target.assertIsDisplayed()
        capture(step)
    }

    private fun inline(node: SemanticsNodeInteraction, label: String, offset: Int) {
        node.performScrollTo().assertIsDisplayed()
        val text = node.fetchSemanticsNode().config[SemanticsProperties.Text].joinToString("") { it.text }
        val layouts = mutableListOf<TextLayoutResult>()
        node.performSemanticsAction(SemanticsActions.GetTextLayoutResult) { it(layouts) }
        assertTrue("Wrong linked offset $offset for $label in $text", offset >= 0 && text.substring(offset).startsWith(label))
        node.performTouchInput { click(layouts.single().getBoundingBox(offset).center) }
    }

    private fun back() {
        InstrumentationRegistry.getInstrumentation().uiAutomation.performGlobalAction(
            android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
        rule.waitForIdle()
    }

    private fun capture(step: String) {
        rule.waitForIdle()
        val automation = InstrumentationRegistry.getInstrumentation().uiAutomation
        automation.waitForIdle(500, 5_000)
        android.os.SystemClock.sleep(1_000)
        rule.waitForIdle()
        val bitmap = requireNotNull(automation.takeScreenshot())
        File(app.getExternalFilesDir(null), "n1-103-$step.png").outputStream().use {
            assertTrue(bitmap.compress(Bitmap.CompressFormat.PNG, 100, it))
        }
        bitmap.recycle()
    }
}
