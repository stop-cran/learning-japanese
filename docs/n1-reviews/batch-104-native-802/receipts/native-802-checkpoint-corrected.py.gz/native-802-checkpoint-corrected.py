import copy
from datetime import datetime, timezone
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import zipfile

C = Path(__file__).resolve().parent
R, A = C.parent / "learning-japanese", C.parent / "kanji-cards-android"
SESSION = "b57944dc-3d69-479e-a3bc-baf9fca37c02"
L = C / "logs" / SESSION
FIRST = C / "artifacts" / "batch-104-native-802"
NO_LAUNCH = C / "artifacts" / "batch-104-native-802-retry"
RAW = C / "artifacts" / "batch-104-native-802-retry2"
D = R / "docs" / "n1-reviews" / "batch-104-native-802"
BASE = "e275d7c4245335bed7268afb022568f7daa8ad33"
APP = "bf30cdead8515739bc0e671d57a54b9a3109dd46"


def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    assert not path.exists(), path
    path.write_text(json.dumps(value, ensure_ascii=True, indent=2) + "\n", encoding="utf-8")
    assert load(path) == value


def git(*args, root=R):
    return subprocess.check_output(["git", "--no-pager", "-C", str(root), *args], encoding="utf-8").strip()


def context(head=BASE):
    p = load(C / "progress.json")
    assert (p["checkpoint"], p["status"], p["batch"]) == (801, "continue", "104")
    runner = load(C / "runner.json")
    assert (runner["status"], runner["sessionId"], runner["pid"]) == ("running", SESSION, 13320)
    for root, expected in ((R, head), (A, APP)):
        assert git("rev-parse", "HEAD", root=root) == expected
        assert git("log", "-1", "--format=%G?", root=root) == "G"
        assert not git("status", "--porcelain", "--untracked-files=all", root=root)
    return p


def update(current, after, phase):
    temporary = C / f"progress.json.802-{phase}.tmp"
    save(temporary, after)
    assert load(C / "progress.json") == current
    os.replace(temporary, C / "progress.json")
    assert load(C / "progress.json") == after


def runtime():
    spec = importlib.util.spec_from_file_location("preparation801", C / "prepare-batch-104-native-801.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    result = module.runtime()
    packet = load(R / "docs" / "n1-reviews" / "batch-104-native-801" / "compiled-packet.json")
    prep, compiled = packet["preparation"], packet["compilation"]
    for path, digest in ((prep["archive"], prep["archiveSha256"]),
                         (prep["fixture"], prep["fixtureSha256"]),
                         (compiled["appApk"], compiled["appApkSha256"]),
                         (compiled["testApk"], compiled["testApkSha256"])):
        assert sha(Path(path)) == digest, path
    manifest_bytes = (R / "manifest.json").read_bytes()
    manifest = json.loads(manifest_bytes)
    assert subprocess.check_output(["git", "-C", str(R), "show",
                                    prep["contentSnapshot"] + ":manifest.json"]) == manifest_bytes
    with zipfile.ZipFile(prep["archive"]) as archive:
        names = archive.namelist()
        prefix = names[0].split("/")[0] + "/"
        assert len(names) == len(set(names)) == 8488 <= 18000
        assert all(n.startswith(prefix) and "\\" not in n and ".." not in n.split("/")
                   and not n.startswith("/") and not re.search(r"(^|/)[^/]*:", n) for n in names)
        assert not any("/docs/" in n or "/tools/" in n for n in names)
        assert archive.read(prefix + "manifest.json") == manifest_bytes
        retained, count, media = len(manifest_bytes), 0, 0
        for section_name, section in manifest.items():
            if not isinstance(section, dict):
                continue
            for name, digest in section.items():
                assert len(name.split("/")) == 2 and ".." not in name.split("/")
                data = archive.read(prefix + name)
                local = (R / name).read_bytes()
                binary = section_name in {"images", "audio", "listeningTaskAudio", "listeningTaskImages"}
                limit = 150 * 1024 if section_name in {"images", "listeningTaskImages"} else (
                    512 * 1024 if section_name in {"audio", "listeningTaskAudio"} else 2 * 1024 * 1024)
                assert len(data) <= limit, name
                normalized = data if binary else data.replace(b"\r\n", b"\n")
                assert hashlib.sha256(normalized).hexdigest() == digest, name
                assert normalized == (local if binary else local.replace(b"\r\n", b"\n")), name
                retained += len(data)
                count += 1
                if section_name in {"listeningTaskAudio", "listeningTaskImages"}:
                    media += len(data)
        inflated = sum(info.file_size for info in archive.infolist())
        compressed = Path(prep["archive"]).stat().st_size
        assert count == 8466 and retained == 44413398 <= 56 * 1024 * 1024
        assert inflated == 44681736 <= 80 * 1024 * 1024
        assert compressed == 30494847 <= 42 * 1024 * 1024
        assert media == 5893602 <= 20 * 1024 * 1024
    result.update({
        "manifestEqualsCompiledArchive": True, "archiveContentSnapshot": prep["contentSnapshot"],
        "archiveSha256": prep["archiveSha256"], "zipEntries": len(names), "compressedBytes": compressed,
        "inflatedBytes": inflated, "retainedBytes": retained, "listeningTaskMediaBytes": media,
        "allOriginalBudgetsAndPerFilePathMediaGuardsPassed": True,
    })
    return result


def start():
    p = context()
    assert p == load(L / "checkpoint-full.json")
    text = (L / "request.txt").read_text(encoding="utf-8-sig")
    embedded = json.loads(text.split(
        "Current execution checkpoint (complete historical state remains at checkpointHistory paths):", 1)[1])
    assert embedded["execution801CoordinatorCheckpoint"]["savedCommit"] == BASE
    save(L / "progress-before-802.json", p)
    state = {
        "execution": 802, "batch": "104", "startedAt": datetime.now(timezone.utc).isoformat(),
        "startingHead": BASE, "androidHead": APP, "freshOriginMain": git("rev-parse", "origin/main"),
        "scope": "SAME104 exact compiled801 APKs/full archive native execution and signed LOCAL evidence only; no reviewer/publication/105.",
        "request": {"sha256": sha(L / "request.txt"), "characters": len(text),
                    "lines": len(text.splitlines()), "completeFileLoadedAndCheckpointParsed": True,
                    "limits": "Entire request loaded/decoded and complete checkpoint parsed; operative contract, approved issue and final801 inspected directly. Historical middle parsed, not freshly semantically re-reviewed."},
        "runnerPreflight": load(L / "preflight-802.json"),
        "artifactPathPreflight": "Approved committed packets/frozen workspace inputs/control helpers only; optional historical-session recipes not accessed.",
        "actualNewPermissionDenials": [], **runtime(),
    }
    save(L / "starting-state-802.json", state)
    after = copy.deepcopy(p)
    assert "execution802StartingState" not in after
    after["execution802StartingState"] = state
    after["stage"] = "batch-104-native-execution-in-progress"
    after["nextAction"] = "SAME104 execution802 exact compiled801 APK/native route only; all801 gates preserved; no reviewer/publication/105."
    for key in p:
        if key not in {"stage", "nextAction"}:
            assert after[key] == p[key]
    update(p, after, "start")
    print("Starting scope persisted; all8466 runtime hashes/full archive/APK bindings verified.")


def results():
    first = load(FIRST / "execution.json")
    assert not first["passed"] and first["nativeExecuted"]
    assert first["terminalSuccessCases"] == 1
    assert first["ownedHelperStopped"] and first["ownedQemuStopped"]
    no_launch = load(NO_LAUNCH / "execution.json")
    assert not no_launch["nativeExecuted"] and not no_launch["passed"]
    assert no_launch["failure"] == "5580/5581 occupied; no helper launched."
    attempt = load(RAW / "execution.json")
    assert attempt["passed"] and attempt["nativeExecuted"] and attempt["failure"] is None
    assert attempt["terminalSuccessCases"] == 2 and attempt["adbExitCode"] == 0
    assert attempt["ownedHelperStopped"] and attempt["ownedQemuStopped"]
    assert attempt["coordinatorHead"] == BASE and attempt["androidSnapshot"] == APP
    assert attempt["prelaunch"]["connections"] == []
    assert attempt["heapGrowth"] == "192m" and attempt["heapSize"] == "576m"
    assert attempt["network"] == "Active default network: none"
    assert not any(attempt[k] for k in ("parentLockTouched", "guestOrAppHeapChanged", "guardsChanged"))
    raw = (RAW / "instrumentation.txt").read_text(encoding="utf-8-sig")
    assert len(re.findall(r"(?m)^INSTRUMENTATION_STATUS_CODE: 0\s*$", raw)) == 2
    assert "OK (2 tests)" in raw
    assert not re.search(r"INSTRUMENTATION_STATUS_CODE: -[234]|FAILURES|INSTRUMENTATION_FAILED|ignored|assumptionFailure", raw)
    route = load(RAW / "n1-104-article-route.json")
    assert route["passed"] and route["archiveRequests"] == 1
    assert (route["importedKanji"], route["importedWords"], route["n1Cards"], route["problems"],
            route["acceptedReadingParserEpoch"], route["acceptedMeaningParserEpoch"]) == (1127, 5078, 136, 0, 1, 1)
    assert (route["mappedReciprocalPairs"], route["directedLinkTransitions"],
            route["activatedBaselinePairs"], route["changedReusedArticles"],
            route["changedReusedNavigationTransitions"]) == (1, 2, 0, 0, 0)
    assert all(route[k] for k in (
        "reciprocalLinkAndSystemBack", "meaningQuestionAndFeedback", "soleCuratedOnPersistedGoodAndDone",
        "drawingTraceThenRecall", "drawingGradeRecordedOnNext", "offline"))
    assert route["touchInjectedReferenceStrokes"] == 8
    assert route["fullOnyomi"] == route["fullProjectionOnyomi"] == route["fullProjectionQuizOnyomi"] == ["ガイ"]
    assert route["fullKunyomi"] == route["fullProjectionKunyomi"] == route["fullProjectionQuizKunyomi"] == []
    assert route["quizOnKeys"] == ["がい"] and route["quizKunKeys"] == []
    assert (route["actualN1CuratedAvailable"], route["actualN1FallbackOptions"]) == (0, 3)
    assert route["curatedDistractorLevels"] == {"刻": 3, "効": 2, "努": 3}
    for key, count in {
        "productionBuilderN1AndAllExactChoices": 64, "kanjiDirectGuardChecks": 1120,
        "nontransitiveNeighborChecks": 320, "preservedWordGuardChecks": 448,
    }.items():
        assert len(route[key]) == count, key
    for row in route["kanjiDirectGuardChecks"]:
        assert row["target"] in row["options"] and row["excluded"] not in row["options"]
        assert len(row["options"]) == len(set(row["options"]))
    assert all(set(r["options"]) == {r["target"], r["neighbor"]} for r in route["nontransitiveNeighborChecks"])
    raster = load(RAW / "n1-104-font-raster.json")
    assert (raster["individualGlyphProbes"], raster["wholeWordRasterProbes"], raster["panels"],
            len(raster["rows"]), raster["sdk"], raster["fontScale"]) == (112, 4, 4, 116, 35, 1)
    assert len([r for r in raster["rows"] if r.get("character") == "刂" and r["hasGlyph"]]) == 4
    return attempt, route, raster


def archive():
    resuming = sys.argv[1] == "resume-archive"
    if resuming:
        p = load(C / "progress.json")
        assert (p["checkpoint"], p["status"], p["batch"]) == (801, "continue", "104")
        for root, expected in ((R, BASE), (A, APP)):
            assert git("rev-parse", "HEAD", root=root) == expected
            assert git("log", "-1", "--format=%G?", root=root) == "G"
            changes = git("status", "--porcelain", "--untracked-files=all", root=root).splitlines()
            assert root == R or not changes
            assert all(line.startswith("?? docs/n1-reviews/batch-104-native-802/") for line in changes)
        for entry in load(D / "artifact-index.json"):
            assert sha(D / entry["file"]) == entry["storedSha256"], entry["file"]
    else:
        p = context()
    verified_runtime = runtime()
    attempt, route, raster = results()
    inspection = load(L / "coordinator-inspection-802.json")
    assert not inspection["independentRenderedReviewClosed"]
    pngs = sorted(path.name for path in RAW.glob("*.png"))
    assert inspection["totalOriginalPngs"] == len(pngs)
    assert all(name in pngs for name in inspection["viewedOriginalPngs"])
    assert inspection["viewedCount"] == len(inspection["viewedOriginalPngs"])
    if not resuming:
        D.mkdir(exist_ok=False)
    artifacts = []

    def preserve(source, destination):
        destination.parent.mkdir(exist_ok=True, parents=True)
        assert not destination.exists()
        if destination.suffix == ".gz":
            destination.write_bytes(gzip.compress(source.read_bytes(), mtime=0))
            assert gzip.decompress(destination.read_bytes()) == source.read_bytes()
        else:
            shutil.copyfile(source, destination)
        artifacts.append({"file": str(destination.relative_to(D)).replace("\\", "/"),
                          "sourceBytes": source.stat().st_size, "sourceSha256": sha(source),
                          "storedSha256": sha(destination)})

    if not resuming:
        for folder, target in ((FIRST, "native-first-failed"), (NO_LAUNCH, "native-port-no-launch"), (RAW, "native")):
            for source in sorted(folder.iterdir()):
                assert source.is_file()
                preserve(source, D / target / (source.name if source.suffix == ".png" else source.name + ".gz"))
        for name in ("preflight-802.ps1", "run-802-native.ps1", "run-802-native-retry.ps1",
                     "run-802-native-retry2.ps1", "native-802-checkpoint.py"):
            preserve(C / name, D / "receipts" / (name + ".gz"))
        for name in ("preflight-802.json", "preflight-802-native.json", "preflight-802-native-retry.json",
                     "preflight-802-native-retry2.json", "starting-state-802.json", "first-attempt-diagnostic-802.json"):
            preserve(L / name, D / "receipts" / (name + ".gz"))
        preserve(R / "docs" / "n1-reviews" / "batch-104-native-801" / "compiled-packet.json",
                 D / "receipts" / "801-compiled-packet.json.gz")
        save(D / "artifact-index.json", artifacts)
        save(D / "coordinator-inspection.json", inspection)
    else:
        assert load(D / "coordinator-inspection.json") == inspection
        preserve(C / "native-802-checkpoint.py", D / "receipts" / "native-802-checkpoint-corrected.py.gz")
        save(D / "archive-correction.json", {
            "originalError": "TypeError: string indices must be integers, not 'str' while reading HOST800 sampled-labels.json as list of objects; actual format is object containing kanji list of [character,title] pairs.",
            "disposition": "All original archived bytes/index preserved and verified; complete only missing label-delta/evidence using exact actual schema. No runtime/native/assertion changes.",
            "correctedHelper": artifacts,
        })
    labels = {(o["kanji"], o["title"]) for row in route["productionBuilderN1AndAllExactChoices"] for o in row["options"]}
    labels.update((o["kanji"], o["title"]) for o in route["exactDefaultMeaningOptions"])
    host = {tuple(row) for row in load(
        R / "docs" / "n1-reviews" / "batch-104-host-800" / "sampled-labels.json")["kanji"]}
    comparison = {
        "nativeUniqueLabelCount": len(labels), "nativeLabels": [list(x) for x in sorted(labels)],
        "newVersusHost800": [list(x) for x in sorted(labels - host)],
        "absentVersusHost800": [list(x) for x in sorted(host - labels)],
        "exactLiveDefault": route["exactDefaultMeaningOptions"],
        "limits": "Actual production-builder64 sampled choices and actual live N1 default labels; ordinary-secondary-sense semantic acceptance of new native labels UNVERIFIED pending complete applicable frozen dictionary evidence and both original-family rendered confirmations.",
    }
    save(D / "sampled-labels-and-host-delta.json", comparison)
    evidence = {
        "schemaVersion": 1, "execution": 802, "batch": "104",
        "stage": "native-two-terminal-cases-passed-awaiting-original-family-rendered-confirmations",
        "recordedAt": datetime.now(timezone.utc).isoformat(),
        "startingState": p["execution802StartingState"], "testedContentHead": BASE,
        "archiveContentSnapshot": route["contentSnapshot"], "qualifiedAndroidHead": APP,
        "runtime": verified_runtime, "nativeAttempt": attempt,
        "preservedFirstFailedAttempt": load(FIRST / "execution.json"),
        "preservedPortNoLaunch": load(NO_LAUNCH / "execution.json"),
        "firstAttemptDiagnostic": load(L / "first-attempt-diagnostic-802.json"),
        "nativeResults": {
            "terminalSuccessCases": 2, "terminalFailureCases": 0, "skipped": 0,
            "productionContentSyncCalls": 1, "preparseCalls": 0,
            "importedCounts": {"kanji": 1127, "words": 5078, "n1": 136, "problems": 0},
            "acceptedReadingParserEpoch": 1, "acceptedMeaningParserEpoch": 1,
            "directSymmetricGuardChecks": 1120, "nontransitiveNeighborChecks": 320,
            "preservedWordGuardChecks": 448, "productionBuilderChoices": 64,
            "individualGlyphProbes": 112, "wholeWordRasterProbes": 4, "fontPanels": 4, "scopedHan": 28,
            "explicitFallbackCodepoint": "刂 U+5202, absent from all three bundled cmaps",
            "nativePngs": len(pngs) - 1, "preservedRetryPngs": len(pngs),
            "environmentPreflightPngs": 1, "soleCuratedOnPersistedGoodAndDone": True,
            "selectedSourceEntries": 1, "actualKeys": route["quizOnKeys"],
            "emptyKunQuestionExpectedNull": True, "drawingStrokes": 8,
            "mappedReciprocalPairs": 1, "directedLinkTransitions": 2,
            "activatedBaselinePairs": 0, "changedReusedArticles": 0, "offline": True, "systemBack": True,
        },
        "sampledLabels": comparison, "coordinatorInspection": inspection,
        "nativeExecutionComplete": True, "independentReviewersLaunched": 0,
        "independentRenderedReviewClosed": False,
        "newNativeOrdinarySenseFallbackSemanticAcceptance": "UNVERIFIED",
        "runtimeChanged": False, "manifestChanged": False, "runtimeAccepted": False, "runtimePublished": False,
        "reviewClosed": [], "published": [], "nextBatchStarted": False,
        "publishedAdditions": 130, "remainingAdditions": 1098, "lastPublishedCommit": p["lastPublishedCommit"],
        "physicalPhoneAcceptance": "outstanding", "generalReleaseAcceptance": "outstanding",
        "wholeProjectComplete": False, "actualNewPermissionDenials": [],
        "limits": [
            "First attempt failed Article801 at system Back with unrelated Messages ANR dialog visible over app; Glyph801 passed. All first logs/screenshots preserved, not reclassified as success.",
            "Separate fresh-device retry uses identical801 APKs/fixture/archive. Only unrelated Google Messages force-stopped on the owned disposable emulator; no disabling package, suppressing target errors or production/fixture edits.",
            "Exact801 compiled APKs executed without rebuilding archive or app; debug APKs, not an owner-signed release.",
            "Other N1 meanings/readings postponed, two historical meaning logs seeded; disposable fixture, no owner progress. No drawing state seeded.",
            "Reference-stroke touch injection and deliberate recall failure are not human handwriting recognition, learning mastery or measured effectiveness.",
            "Route assertions and raster hashes do not establish equal fresh visual reading of every PNG or native-speaker certification.",
            "New native sampled fallback semantic acceptance remains UNVERIFIED pending full frozen source evidence and original-family rendered confirmations.",
            "799 textual and800 HOST finite target-relative acceptance inherited, not repeated; all original reports/process/read/source limitations and unresolved low-risk hypotheses preserved.",
            "Original103 visual coverage/rendition/readability limitations remain historical, not improved by this run.",
            "No publication, physical-phone, general-release or whole-set acceptance; all original gates remain mandatory.",
        ],
    }
    save(R / "docs" / "n1-sources" / "execution-802.json", evidence)
    print(json.dumps({"archived": str(D), "nativePngs": len(pngs),
                      "newLabels": comparison["newVersusHost800"]}, ensure_ascii=True))


def finish():
    before = load(L / "progress-before-802.json")
    head = git("rev-parse", "HEAD")
    current = context(head)
    assert git("rev-parse", "HEAD^") == BASE
    assert not git("diff", BASE, head, "--", "manifest.json", "kanji", "words", "strokes")
    verified_runtime = runtime()
    attempt, route, raster = results()
    for entry in load(D / "artifact-index.json"):
        assert sha(D / entry["file"]) == entry["storedSha256"], entry["file"]
    for entry in load(D / "archive-correction.json")["correctedHelper"]:
        assert sha(D / entry["file"]) == entry["storedSha256"], entry["file"]
    posted, reread = load(L / "issue-802-posted.json"), load(L / "issue-802-reread.json")
    body = C / "batch-104-native-802-issue-body.txt"
    assert posted["author"] == reread["user"]["login"] == "stop-cran"
    assert posted["bodySha256"] == sha(body) and body.read_text(encoding="utf-8") == reread["body"]
    assert posted["url"] == reread["html_url"]
    next_action = (
        f"SAME104 checkpoint802 signed LOCAL native-success evidence HEAD{head}, qualifiedAndroid{APP}. "
        "Read docs/n1-sources/execution-802.json and docs/n1-reviews/batch-104-native-802/. "
        "Exact compiled801 APKs/fixture/fullLFarchive executed without rebuild. BOTH named Glyph801/Article801 "
        "terminalcase0/zero failures/skips on separate fresh-device retry; FIRST FAILED Article801/systemBack "
        "with visible unrelated Messages ANR overlay preserved in native-first-failed, Glyph801passed. "
        "Retry only force-stopped unrelatedGoogleMessages on OWNED disposable emulator before instrumentation; "
        "no package disable/production/fixture edits/error suppression. Fresh signedhead/whollyclean/liveparent/session/decodedlauncher/801checkpoint "
        "and localANDremote5584/5585 includingTimeWait preflight passed. Sharedadb remote5581 reconnects caused "
        "preserved intermediateNO-LAUNCH5580attempt; no sharedadb restart/otherdevice changes. Freshunusedhostrouting "
        "5584/5585 retained sameAVD/flags/resources/assertions, not batch040 waiver. Owned readonlyAPI35 emulator5584 "
        f"parent{attempt['parentEmulatorPid']}/QEMU{attempt['qemuPid']} responsive; BOTH stopped. "
        "Guest2g/192mgrowth576mmax/allguards unchanged; sharedadb/parentrunner.lock untouched. "
        "Full productionContentSyncONCE signed2184e58f archive2b6c497c5b582913a2236ee6b888b6f8998dc741cbccbf0b631a392e3bab9492: "
        "1127kanji5078words136N1/0problems/reading+meaningepochs1. "
        "1120directsymmetricguards/320NONTRANSITIVEneighbors/448paironlywordguards/64builderchoices/allofferedsetspairwise. "
        "N1curatedZERO/THREEactualfallbacks; curated刻N3効N2努N3unchanged. "
        "Full/selectedガイ soleactualkeyがい persistedgood/done; kunyomi empty/nonoffered/nullquestion. "
        "ONEactualmappedpair/TWOdirections/zeroactivatedbaselinepairs/zerochangedreused/Back/offline/meaning passed. "
        "Eightreferencepointtouch-injected trace ungraded/noDrawlog; recall deliberatefailure/grade1onNext, NOT mastery. "
        "112individualglyphs/4wordrasters/4panels/28scopedHan; coordinator originalPNG inspection recorded precisely in "
        "coordinator-inspection.json; raster/cmap not readability, no fallbackface certification. "
        "NEXT SAME104 TWO SERIAL ORIGINAL-family rendered confirmations after complete applicable frozen dictionary "
        "evidence for actual native labels (sampled-labels-and-host-delta.json), using original sessions/reports from "
        "docs/n1-reviews/batch-104-reconciliation.json, not new blind initials. Preserve original799 readdepth/process/"
        "source/calibrateddisagreement/fouroptionalpolish; unprovedLOWRISK 劾/偵 and弾劾/叱る hypotheses preserved, "
        "not forced withdrawal or universal pool safety. HOST800 finite41kanjilabels26words target-relative inherited. "
        "New native fallback semantic acceptance UNVERIFIED until exact full frozen sources/labels inspected; "
        "mechanical success is NOT whole-batch acceptance. Any consequential defect requires minimal correction, "
        "all applicable audits/manifest/normal signed newfreeze and BOTH original-family confirmations. "
        "All8466runtimehashes/versiona5bc9b199c7df334/manifest unchanged; 8488entries/30494847compressed/"
        "44681736inflated/44413398retainedbytes/perfilepathmedia originalguards verified. "
        "All previous gates/limits preserved verbatim in historicalExecution801Before802Native.nextAction. "
        "Combinedcurrentmain/nonrewritingmerge/changedteachingreview/fullrequiredPython/vocabulary/baseline-membership-links/"
        "manifestbudget/normal signing/ownerfastforward/terminalgreenCI/EVERYimmutableZIPmanifesthash/unchanged18000entries/"
        "42MiBcompressed80MiBinflated56MiBretained/perfilepathmedia/verifiedownerissue remainMANDATORY. "
        "No105/unreviewedpush/authoragents/concurrentheavywork/secondrunner/signingretry/guardincrease. "
        "Freshsignedheads/checkpoint/whollyclean/freshmain/liveparentancestry/decodedlauncher/exactsession required. "
        "Parent13320ownsrunner.lock:nochildacquire/delete/unlock/readprobe. Approvedcontrol/committedsource/frozeninputs only; "
        "nooptionalhistoricalsessionrecipe/newpermissiondenial. Preserve/report/yield actualnewdenial/signinghang/"
        "uncertainownership. QualifiedAndroidapprovedpairguard+schemaonly, NOTlatestappmain. "
        "Published130/1228/remainder1098unchanged; unaccepted劾/ONEsupport notdeliveredN1vocabulary; "
        "sixearlierN2placementsseparate/no duplicate/relevel. CompatibleAndroid#125+#132required; oldclientsignore. "
        "Original103finite128optionset/native/renderedbounded795/900x2000renditionsNOToriginalpixels/equalcomprehension/"
        "fallbackface/retentioncertification/GPTcompletevisualcoverageUNVERIFIED retained, no new73image-loop/newblindcredit. "
        "Physicalphone/generalrelease/whole-setoutstanding; projectincomplete."
    )
    inspection = load(D / "coordinator-inspection.json")
    checkpoint = {
        "schemaVersion": 1, "execution": 802, "checkpoint": 802, "batch": "104",
        "status": "continue", "stage": "batch-104-native-passed-awaiting-original-family-rendered-confirmations",
        "recordedAt": datetime.now(timezone.utc).isoformat(),
        "savedCommit": head, "signature": "G", "qualifiedAndroidHead": APP,
        "testedContentHead": BASE, "archiveContentSnapshot": route["contentSnapshot"],
        "evidence": "docs/n1-sources/execution-802.json",
        "issueUpdate": posted["url"], "ownerIssueAuthorAndExactBodyVerified": True,
        "nativeExecuted": True, "glyphCasePassed": True, "articleCasePassed": True,
        "terminalSuccessCases": 2, "terminalFailureCases": 0, "nativeSkipped": 0,
        "nativeExecutionComplete": True, "wholeBatchAcceptanceComplete": False,
        "productionContentSyncCalls": 1, **verified_runtime,
        "nativePngs": inspection["nativePngs"], "preservedRetryPngs": inspection["totalOriginalPngs"],
        "coordinatorViewedOriginalPngs": inspection["viewedCount"],
        "directSymmetricGuardChecks": 1120, "nontransitiveNeighborChecks": 320,
        "preservedWordGuardChecks": 448, "productionBuilderChoices": 64,
        "soleCuratedOnPersistedGoodAndDone": True, "actualKeys": ["がい"],
        "mappedReciprocalPairs": 1, "directedLinkTransitions": 2, "changedReusedArticles": 0,
        "ownedHelperStopped": True, "ownedQemuStopped": True, "sharedAdbTouched": False,
        "independentReviewersLaunched": 0, "independentRenderedReviewClosed": False,
        "newNativeOrdinarySenseFallbackSemanticAcceptance": "UNVERIFIED",
        "runtimeChanged": False, "manifestChanged": False, "runtimeAccepted": False, "runtimePublished": False,
        "reviewClosed": [], "published": [], "dedicatedWorktreesClean": True,
        "parentLockTouched": False, "optionalHistoricalHelpersAccessed": False, "actualNewPermissionDenials": [],
        "publishedAdditions": 130, "remainingAdditions": 1098, "lastPublishedCommit": before["lastPublishedCommit"],
        "physicalPhoneAcceptance": "outstanding", "generalReleaseAcceptance": "outstanding",
        "wholeProjectComplete": False, "nextBatchStarted": False, "nextAction": next_action, "blocker": None,
        "historicalRootKeysCompared": len(before), "allOriginalHistoricalValuesPreserved": True,
    }
    after = copy.deepcopy(current)
    assert "execution802CoordinatorCheckpoint" not in after
    assert "historicalExecution801Before802Native" not in after
    after["historicalExecution801Before802Native"] = copy.deepcopy(before["execution801CoordinatorCheckpoint"])
    after["execution802StartingState"]["status"] = "signed-local-native-checkpoint-complete"
    after["execution802CoordinatorCheckpoint"] = checkpoint
    changed = {"checkpoint", "status", "stage", "nextAction", "blocker"}
    for key in changed:
        after[key] = checkpoint[key]
    for key, value in before.items():
        if key not in changed:
            assert after[key] == value, key
    update(current, after, "finish")
    save(L / "checkpoint-802-summary.json", checkpoint)
    print(f"Checkpoint802 persisted; signed{head}; all{len(before)} historical root values preserved; continue.")


if __name__ == "__main__":
    {"start": start, "archive": archive, "resume-archive": archive, "finish": finish}[sys.argv[1]]()
